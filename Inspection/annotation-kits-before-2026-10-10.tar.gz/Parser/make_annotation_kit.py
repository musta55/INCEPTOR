"""Build the annotator kit for segment and purpose labelling.

For each pilot and test trajectory it writes one folder holding:
  <traj>_annotation.csv  the sheet the annotator fills (automatic segment and purpose labels removed)
  <traj>.atif.json       the full trajectory, copied unchanged
  <traj>_reading.md      the reading view, with the automatic purpose labels removed

plus tracker.csv, the list of trajectories with status columns.

Usage: python3 make_annotation_kit.py [output_dir]   (default: ../Annotation kit)
"""
import csv
import re
import shutil
import sys
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"
SETS = {"pilot": ["18"], "test": ["1138", "1563", "1299", "1446", "1202"]}
AGENTS = ["claude", "codex", "gemini"]

# (sheet column, source column in data/annotation/bug-<id>_actions.csv)
GIVEN = [
    ("action", "action_index"),
    ("step", "step_id"),
    ("scope", "scope"),
    ("tool", "tool"),
    ("action_category", "mid_level"),
    ("target", "target"),
    ("thought", "thought_preview"),
    ("result", "result_preview"),
    ("verdict", "verdict"),
    ("fail_kind", "fail_kind"),
    ("edit_role", "edit_role"),
    ("fix_stage", None),
    ("call_id", "call_id"),
]
TO_FILL = ["segment_id", "segment_goal", "segment_result", "purpose", "notes"]


def blind_reading(text: str) -> str:
    """Drop the automatic purpose sequence and the '/ <purpose>' part of each action header."""
    text = re.sub(r"^High-level trajectory:.*\n\n?", "", text, flags=re.M)
    return re.sub(r"^(## \d+\. [a-z_]+) / [a-z_]+", r"\1", text, flags=re.M)


def write_sheet(rows, path: Path) -> None:
    first_fix = next((i for i, r in enumerate(rows) if r["edit_role"] == "source"), len(rows))
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow([name for name, _ in GIVEN] + TO_FILL)
        for i, r in enumerate(rows):
            given = []
            for name, src in GIVEN:
                given.append(("pre-fix" if i < first_fix else "post-fix") if src is None else r[src])
            w.writerow(given + [""] * len(TO_FILL))


def main(out: Path) -> None:
    tracker = []
    for set_name, bugs in SETS.items():
        for bug in bugs:
            with (DATA / "annotation" / f"bug-{bug}_actions.csv").open() as f:
                rows = list(csv.DictReader(f))
            for agent in AGENTS:
                traj = f"bug-{bug}_{agent}"
                mine = [r for r in rows if r["agent"] == agent]
                folder = out / set_name / traj
                folder.mkdir(parents=True, exist_ok=True)
                write_sheet(mine, folder / f"{traj}_annotation.csv")
                shutil.copyfile(DATA / "atif" / f"{traj}.atif.json", folder / f"{traj}.atif.json")
                reading = (DATA / "reading" / f"{traj}.md").read_text()
                (folder / f"{traj}_reading.md").write_text(blind_reading(reading))
                tracker.append([set_name, traj, bug, agent, len(mine), f"{set_name}/{traj}"])
    with (out / "tracker.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["set", "trajectory", "bug", "agent", "actions", "kit_folder",
                    "annotator_1", "annotator_1_done", "annotator_2", "annotator_2_done",
                    "adjudicated", "comments"])
        for t in tracker:
            w.writerow(t + ["", "0", "", "0", "0", ""])
    print(f"{len(tracker)} trajectories, {sum(t[4] for t in tracker)} actions -> {out}")


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else DATA.parent.parent / "Annotation kit")
