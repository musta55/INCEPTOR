# Ground Truth: trajectories to annotate

The inputs for the manual annotation of segments and purposes. The procedure, label
definitions and a worked example are in the Google Doc *Trajectory Segmentation:
Annotation Procedure*.

## Folders

| Folder | Contents |
|---|---|
| `pilot/` | bug-18 for all three agents: 3 trajectories, 99 actions. Annotate these first. |
| `claude/`, `codex/`, `gemini/` | The 10 sampled bugs for one agent: 10 trajectories per folder, 30 in all, 1,495 actions. |
| `tracker.xlsx` | One row per trajectory, with columns for the annotators and their status. |

Each trajectory has two files with the same name:

- `bug-<id>_<agent>.xlsx` is the annotation workbook, the only file you write in. Its
  *annotation* tab has one row per action, in the order the agent made them (spreadsheet
  row N + 1 holds action N). Its *guide* tab lists the labels and shows a filled-in
  example.
- `bug-<id>_<agent>.atif.json` is the complete trajectory. Use it when a cut-off cell
  hides something you need. Do not edit it.

## Columns of the annotation tab

**You fill (yellow; the first two columns stay in view while you scroll)**

| Column | Value |
|---|---|
| `segment` | On the **first row of each segment**, one of: `orient`, `locate`, `reproduce`, `make-it-run`, `attempt`, `validate`, `review`, `delegate`, `other`. Leave it empty on the other rows of the segment. The cell offers these values as a dropdown. |
| `purpose` | On the same rows as `segment`, one of: `orientation`, `localization`, `reproduction`, `environment`, `repair`, `validation`, `review`. Also a dropdown. |
| `notes` | Optional, on any row. |

**Given (computed, do not edit)**

| Column | Meaning |
|---|---|
| `step` | The ATIF step the action came from. Actions of one step were issued together and share one thought. To find a step in the JSON file, search for `"step_id": <step>`. Sub-agent steps are under `subagent_trajectories`. |
| `sub_agent` | `yes` when a sub-agent made the action, empty when the agent itself made it. |
| `thought_preview` | The first 300 characters of the agent's reasoning and message for the step. It appears on the step's first action only. |
| `mid_level` | The kind of action: `read_file`, `search_code`, `orient`, `edit_file`, `build`, `run_test`, `env_setup`, `device_ops`, `wait_process`, `vcs`, `delegate`, `plan`, `web`, `run_shell`, `other`. |
| `target` | The file, command or search query (first 200 characters). |
| `result_preview` | The start of the tool's output (first 300 characters). |
| `verdict` | For a run (build, test, environment or device command, or a wait): `pass`, `fail`, or `none` when no result is visible. Empty for other actions. |
| `fail_kind` | Why a run failed: `test` (the test ran and failed), `build` (the code does not compile), `env` (the machine stopped it), `exit` (other error). |
| `edit_role` | For an edit: `source` (app code), `test` (test files) or `toolchain` (build files, `run_pipeline.sh`). |
| `fix_stage` | `pre-fix` before the agent's first edit of app source code, `post-fix` from that edit on. |
| `thought` | The full reasoning and message of the step, uncut. It appears on the step's first action only. |

Long cells show two lines; click a cell to read all of it.

## How this folder was made

`python3 make_ground_truth.py` (in `Parser/`) rebuilds `pilot/`, the agent folders and
`tracker.xlsx` from `data/atif/`. It does not touch this README. The sampling is seeded
and repeatable; the design is described in `Annotation codebook.md` §6.1.
