"""Deterministic BPE over action-label sequences (ProcGrep-compatible semantics).

Mirrors pg_repo/src/procgrep/bpe.py:
  * most frequent adjacent pair over the whole corpus (all adjacent positions counted,
    including overlapping ones inside runs, exactly as ProcGrep/Sennrich do)
  * ties broken lexicographically on the (left, right) tuple
  * merge applied greedily left-to-right, non-overlapping
  * token identity = left + SEP + right (so identity is the flattened atom string)
  * stop at n_merges or when the top pair frequency < min_freq (default 2)
Differences: incremental pair counting (same result, faster) and optional integer
per-sequence weights (used for bootstrap multiplicity).
NOTE: ProcGrep's K is vocab size = atoms + merges. Here K always means NUMBER OF MERGES.
"""
from __future__ import annotations

import json
import glob
import os
from collections import Counter, defaultdict

SEP = "▁"  # same separator as ProcGrep
CORPUS = ("/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/"
          "fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/corpus/annotation")
AGENTS = ("claude", "codex", "gemini")


# ----------------------------------------------------------------------------- data
def load_trajectories():
    """Return list of dicts: bug, agent, rows (sorted by action_index)."""
    by = defaultdict(list)
    for f in glob.glob(os.path.join(CORPUS, "bug-*_actions.jsonl")):
        with open(f) as fh:
            for line in fh:
                r = json.loads(line)
                by[(r["bug_id"], r["agent"])].append(r)
    out = []
    for (bug, agent), rows in by.items():
        rows.sort(key=lambda r: r["action_index"])
        out.append({"bug": bug, "agent": agent, "rows": rows})
    out.sort(key=lambda t: (int(t["bug"]), AGENTS.index(t["agent"])))
    return out


def rle(seq):
    """Collapse consecutive duplicates. Returns (symbols, run_lengths)."""
    syms, spans = [], []
    for s in seq:
        if syms and syms[-1] == s:
            spans[-1] += 1
        else:
            syms.append(s)
            spans.append(1)
    return syms, spans


def build_variants(trajs):
    """variant -> list of (symbols, spans) aligned with trajs. spans = actions per atom."""
    V = {"A": [], "B": [], "C": [], "A_rle": [], "C_rle": []}
    for t in trajs:
        mid = [r["mid_level"] for r in t["rows"]]
        hi = [r["high_level"] for r in t["rows"]]
        mid_f = [r["mid_level"] + ("!" if r["failed"] == "true" else "") for r in t["rows"]]
        V["A"].append((mid, [1] * len(mid)))
        V["B"].append((mid_f, [1] * len(mid_f)))
        V["C"].append((hi, [1] * len(hi)))
        V["A_rle"].append(rle(mid))
        V["C_rle"].append(rle(hi))
    return V


# ----------------------------------------------------------------------------- BPE
def _pairs(seq):
    return zip(seq, seq[1:])


def _merge_seq(seq, left, right, merged):
    out, i, n, fired = [], 0, len(seq), False
    while i < n:
        if i + 1 < n and seq[i] == left and seq[i + 1] == right:
            out.append(merged)
            i += 2
            fired = True
        else:
            out.append(seq[i])
            i += 1
    return out, fired


def fit_bpe(seqs, n_merges, weights=None, min_freq=2):
    """Learn up to n_merges merges.

    Returns (merges, tokenized) where merges is a list of dicts
      {pair, token, freq (weighted pair count at merge time), support (set of seq idx where it fired)}
    and tokenized is the final tokenization of every sequence.
    """
    seqs = [list(s) for s in seqs]
    w = weights if weights is not None else [1] * len(seqs)
    counts = Counter()
    where = defaultdict(set)
    for i, s in enumerate(seqs):
        if w[i] == 0:
            continue
        for p in _pairs(s):
            counts[p] += w[i]
            where[p].add(i)
    merges = []
    while len(merges) < n_merges:
        best, bc = None, 0
        for p, c in counts.items():
            if c > bc or (c == bc and c > 0 and p < best):
                best, bc = p, c
        if best is None or bc < min_freq:
            break
        left, right = best
        merged = left + SEP + right
        support = set()
        for i in list(where[best]):
            s = seqs[i]
            new, fired = _merge_seq(s, left, right, merged)
            if not fired:
                continue
            support.add(i)
            for p in _pairs(s):
                counts[p] -= w[i]
            for p in _pairs(new):
                counts[p] += w[i]
                where[p].add(i)
            seqs[i] = new
        # drop exhausted pairs
        for p in [p for p, c in counts.items() if c <= 0]:
            del counts[p]
            where.pop(p, None)
        merges.append({"pair": best, "token": merged, "freq": bc, "support": support})
    return merges, seqs


def apply_merges(seq, merges):
    """Tokenize one sequence with an ordered merge list. Returns (tokens, fired_merge_indices)."""
    out = list(seq)
    fired = set()
    for k, m in enumerate(merges):
        left, right = m["pair"]
        out, f = _merge_seq(out, left, right, m["token"])
        if f:
            fired.add(k)
    return out, fired


def atoms_of(token):
    return token.split(SEP)


def is_self_repetition(token):
    a = atoms_of(token)
    return len(a) > 1 and len(set(a)) == 1


def token_action_lengths(tokens, spans):
    """Actions covered by each token, given per-atom spans."""
    lens, pos = [], 0
    for t in tokens:
        k = t.count(SEP) + 1
        lens.append(sum(spans[pos:pos + k]))
        pos += k
    assert pos == len(spans), (pos, len(spans))
    return lens


def boundaries_from_lengths(lens):
    """Internal boundary positions b (split between action b and b+1, 1-indexed)."""
    out, c = [], 0
    for L in lens[:-1]:
        c += L
        out.append(c)
    return out


def raw_support(token, seqs):
    """Number of sequences whose raw atom list contains the flattened token contiguously."""
    D = "\x1f"
    needle = D + D.join(atoms_of(token)) + D
    return sum(1 for s in seqs if needle in (D + D.join(s) + D))
