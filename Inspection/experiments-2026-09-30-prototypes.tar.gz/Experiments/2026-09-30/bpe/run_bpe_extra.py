"""Supplementary analyses.  python3 run_bpe_extra.py -> results_extra.json + stdout.

 (a) Independent-replication learning curve: two DISJOINT bug sets of h bugs each (3h trajectories each),
     Jaccard of top-K vocabularies, h = 5..25; plus support-filtered vocabularies (tokens whose support
     >= 10% of that half's trajectories); log-linear extrapolation of J to h=50 (two corpora of our size).
 (b) Segment quality proxies on held-out (grouped-CV) tokenization: phase purity of multi-action segments,
     fragmentation of phase runs, exact recovery of phase runs of length >= 3; random-boundary baseline.
 (c) Concrete tokenized examples (for manual inspection).
"""
import json
import math
import random
import statistics as st
import sys
from collections import defaultdict

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import bpe_core as B

OUT = __file__.rsplit("/", 1)[0]
trajs = B.load_trajectories()
V = B.build_variants(trajs)
N = len(trajs)
bugs = sorted({t["bug"] for t in trajs}, key=int)
bug_of = [t["bug"] for t in trajs]
agent_of = [t["agent"] for t in trajs]
idx_by_bug = defaultdict(list)
for i, t in enumerate(trajs):
    idx_by_bug[t["bug"]].append(i)
phase = [[r["high_level"] for r in t["rows"]] for t in trajs]
n_actions = [len(p) for p in phase]
RX = {}


def seqs_of(v, idx):
    return [V[v][i][0] for i in idx]


def jacc(a, b):
    return len(a & b) / len(a | b) if (a or b) else 1.0


# ---------------------------------------------------------------- (a) learning curve
print("=== (a) INDEPENDENT-REPLICATION LEARNING CURVE (disjoint halves of h bugs each; 30 draws) ===")
HS = [5, 10, 15, 20, 25]
KL = [10, 20, 40, 80, 192]
RX["learning_curve"] = {}
for v in ["A", "B", "A_rle", "C_rle"]:
    rng = random.Random(2024)
    res = {}
    for h in HS:
        J = defaultdict(list)
        Jf, nf = [], []
        for _ in range(30):
            b = bugs[:]
            rng.shuffle(b)
            h1, h2 = b[:h], b[h:2 * h]
            m1, _ = B.fit_bpe(seqs_of(v, [i for x in h1 for i in idx_by_bug[x]]), 100000)
            m2, _ = B.fit_bpe(seqs_of(v, [i for x in h2 for i in idx_by_bug[x]]), 100000)
            for K in KL:
                J[K].append(jacc({m["token"] for m in m1[:K]}, {m["token"] for m in m2[:K]}))
            thr = math.ceil(0.10 * 3 * h)
            f1 = {m["token"] for m in m1 if len(m["support"]) >= thr}
            f2 = {m["token"] for m in m2 if len(m["support"]) >= thr}
            Jf.append(jacc(f1, f2))
            nf.append((len(f1) + len(f2)) / 2)
        res[h] = {"traj_per_half": 3 * h, **{f"K{K}": st.mean(J[K]) for K in KL},
                  "support10pct": st.mean(Jf), "support10pct_vocab_size": st.mean(nf)}
    # log-linear fit J = a + b ln(traj) and extrapolation
    ext = {}
    for key in [f"K{K}" for K in KL] + ["support10pct"]:
        xs = [math.log(3 * h) for h in HS]
        ys = [res[h][key] for h in HS]
        mx, my = st.mean(xs), st.mean(ys)
        bb = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
        aa = my - bb * mx
        need = {}
        for target in (0.5, 0.7):
            # only report extrapolations within 2 orders of magnitude of our corpus; beyond that = not reached
            x = (target - aa) / bb if bb > 0 else float("inf")
            need[target] = math.exp(x) if x < math.log(15000) else None
        ext[key] = {"slope_per_ln_traj": bb, "J_at_150_vs_150": aa + bb * math.log(150),
                    "traj_per_corpus_for_J0.5": need[0.5], "traj_per_corpus_for_J0.7": need[0.7]}
    RX["learning_curve"][v] = {"by_h": res, "extrapolation": ext}
    print(f"[{v}] traj/half: " + "  ".join(f"{3 * h:>6}" for h in HS))
    for key in [f"K{K}" for K in KL] + ["support10pct"]:
        e = ext[key]
        n5 = e["traj_per_corpus_for_J0.5"]
        n7 = e["traj_per_corpus_for_J0.7"]
        print(f"   {key:<13}" + "  ".join(f"{res[h][key]:>6.2f}" for h in HS)
              + f"   slope/ln(n) {e['slope_per_ln_traj']:+.3f}  extrap J(150 vs 150) {e['J_at_150_vs_150']:.2f}"
              + f"  n for J=0.5: {'>15,000' if n5 is None else f'{n5:,.0f}'}  J=0.7: {'>15,000' if n7 is None else f'{n7:,.0f}'}")
    print("   support10pct vocab size (mean of halves): " + "  ".join(f"{res[h]['support10pct_vocab_size']:>6.1f}" for h in HS))

# ---------------------------------------------------------------- (b) segment quality proxies
print("\n=== (b) SEGMENT QUALITY PROXIES, held-out grouped-CV tokenization (same folds as run_bpe.py) ===")
print("    NOTE: phase labels are rule-derived from mid_level; these are sanity checks, not validation.")
rng = random.Random(0)
fb = bugs[:]
rng.shuffle(fb)
folds = [fb[i::5] for i in range(5)]
fold_of = {b: f for f, tb in enumerate(folds) for b in tb}
models = {}
for v in ["A", "B", "A_rle"]:
    for f, tb in enumerate(folds):
        tr = [i for i in range(N) if bug_of[i] not in set(tb)]
        models[(v, f)], _ = B.fit_bpe(seqs_of(v, tr), 192)


def phase_runs(p):
    runs, s = [], 0
    for i in range(1, len(p) + 1):
        if i == len(p) or p[i] != p[s]:
            runs.append((s, i))  # [s, i)
            s = i
    return runs


def seg_metrics(seg_lens_per_traj):
    pure_multi, multi, frag, exact3, runs3, cover2 = 0, 0, [], 0, 0, 0
    for i, lens in enumerate(seg_lens_per_traj):
        p = phase[i]
        spans, c = [], 0
        for L in lens:
            spans.append((c, c + L))
            c += L
        for s, e in spans:
            if e - s >= 2:
                multi += 1
                pure_multi += len(set(p[s:e])) == 1
        starts = {s for s, _ in spans}
        ends = {e for _, e in spans}
        for s, e in phase_runs(p):
            nseg = sum(1 for a, b in spans if a < e and b > s)
            if e - s >= 3:
                runs3 += 1
                frag.append(nseg)
                exact3 += (s in starts and e in ends and nseg == 1)
                cover2 += nseg <= 2
    return {"phase_pure_share_of_multi_action_segments": pure_multi / multi if multi else float("nan"),
            "n_multi_action_segments": multi,
            "phase_runs_len_ge3": runs3,
            "exact_recovery_of_phase_runs_len_ge3": exact3 / runs3,
            "phase_runs_len_ge3_covered_by_le2_segments": cover2 / runs3,
            "median_segments_per_phase_run_len_ge3": st.median(frag)}


def random_lens(n, nseg, r):
    cuts = sorted(r.sample(range(1, n), min(nseg - 1, n - 1)))
    b = [0] + cuts + [n]
    return [b[k + 1] - b[k] for k in range(len(b) - 1)]


RX["segment_quality"] = {}
for v in ["A", "B", "A_rle"]:
    RX["segment_quality"][v] = {}
    for K in [0, 5, 10, 20, 40, 80, 192]:
        per = []
        for i in range(N):
            mk = models[(v, fold_of[bug_of[i]])][:K]
            toks, _ = B.apply_merges(V[v][i][0], mk)
            per.append(B.token_action_lengths(toks, V[v][i][1]))
        m = seg_metrics(per)
        r = random.Random(7)
        rb = [seg_metrics([random_lens(n_actions[i], len(per[i]), r) for i in range(N)]) for _ in range(10)]
        m["random_same_count"] = {k: st.mean(x[k] for x in rb) for k in m}
        RX["segment_quality"][v][K] = m
    print(f"[{v}]  K | phase-pure multi-action segs (rand) | exact recovery of phase runs>=3 (rand) | runs>=3 in <=2 segs | median segs per run>=3")
    for K in [0, 5, 10, 20, 40, 80, 192]:
        m = RX["segment_quality"][v][K]
        rr = m["random_same_count"]
        print(f"   {K:>3} | {m['phase_pure_share_of_multi_action_segments']:.2f} ({rr['phase_pure_share_of_multi_action_segments']:.2f}) n={m['n_multi_action_segments']:>4}"
              f" | {m['exact_recovery_of_phase_runs_len_ge3']:.2f} ({rr['exact_recovery_of_phase_runs_len_ge3']:.2f})"
              f" | {m['phase_runs_len_ge3_covered_by_le2_segments']:.2f} | {m['median_segments_per_phase_run_len_ge3']}")
print(f"   phase runs of length >= 3 in corpus: {RX['segment_quality']['A'][0]['phase_runs_len_ge3']}")

# ---------------------------------------------------------------- (c) examples
print("\n=== (c) EXAMPLES: held-out A_rle tokenization at K=40 (segments shown as action_index ranges) ===")
RX["examples"] = []
cands = []
for i in range(N):
    runs = phase_runs(phase[i])
    for s, e in runs:
        if phase[i][s] == "reproduction" and e - s >= 5:
            fails = sum(trajs[i]["rows"][k]["failed"] == "true" for k in range(s, e))
            cands.append((fails, e - s, i, s, e))
cands.sort(key=lambda x: (-x[0], -x[1], x[2]))
picked, seen_agents = [], set()
for c in cands:
    if agent_of[c[2]] not in seen_agents:
        picked.append(c)
        seen_agents.add(agent_of[c[2]])
    if len(picked) == 2:
        break
# add one claude trajectory with a long validation loop (claude has no reproduction phase by construction of its logs?)
cl = [(sum(1 for s, e in phase_runs(phase[i]) if phase[i][s] == "validation"), i) for i in range(N) if agent_of[i] == "claude"]
cl.sort(reverse=True)
for i in [c[2] for c in picked] + [cl[0][1]]:
    mk = models[("A_rle", fold_of[bug_of[i]])][:40]
    toks, _ = B.apply_merges(V["A_rle"][i][0], mk)
    lens = B.token_action_lengths(toks, V["A_rle"][i][1])
    rows = trajs[i]["rows"]
    segs, c = [], 0
    for t, L in zip(toks, lens):
        a0, a1 = rows[c]["action_index"], rows[c + L - 1]["action_index"]
        ph = sorted({rows[k]["high_level"] for k in range(c, c + L)})
        nf = sum(rows[k]["failed"] == "true" for k in range(c, c + L))
        segs.append({"actions": f"{a0}-{a1}" if a1 > a0 else f"{a0}", "token": t.replace(B.SEP, " > "),
                     "phases": ph, "n_failed": nf})
        c += L
    pr = [(phase[i][s], rows[s]["action_index"], rows[e - 1]["action_index"]) for s, e in phase_runs(phase[i])]
    ex = {"bug": bug_of[i], "agent": agent_of[i], "n_actions": n_actions[i], "phase_runs": pr, "bpe_segments": segs}
    RX["examples"].append(ex)
    print(f"\n bug-{bug_of[i]} {agent_of[i]} ({n_actions[i]} actions)")
    print("   phase runs: " + ", ".join(f"{p}[{a}-{b}]" for p, a, b in pr))
    for s in segs:
        print(f"   seg {s['actions']:>7}  {s['token']:<60} phases={','.join(s['phases'])}  failed={s['n_failed']}")

# ---------------------------------------------------------------- (d) loops = tandem repeats of BPE tokens
print("\n=== (d) LOOPS: maximal runs of >=2 identical consecutive multi-atom BPE tokens (held-out CV tokenization) ===")
for f, tb in enumerate(folds):
    tr = [i for i in range(N) if bug_of[i] not in set(tb)]
    models[("C_rle", f)], _ = B.fit_bpe(seqs_of("C_rle", tr), 192)
RX["loops"] = {}
fail = [[r["failed"] == "true" for r in t["rows"]] for t in trajs]
base_fail = sum(map(sum, fail)) / sum(n_actions)
for v, K in (("A_rle", 20), ("A_rle", 40), ("C_rle", 10), ("C_rle", 20)):
    loops, bodies, traj_with = [], defaultdict(int), defaultdict(set)
    for i in range(N):
        toks, _ = B.apply_merges(V[v][i][0], models[(v, fold_of[bug_of[i]])][:K])
        lens = B.token_action_lengths(toks, V[v][i][1])
        starts = [sum(lens[:k]) for k in range(len(lens))]
        k = 0
        while k < len(toks):
            j = k
            while j + 1 < len(toks) and toks[j + 1] == toks[k]:
                j += 1
            if j > k and B.SEP in toks[k]:
                a0, a1 = starts[k], starts[j] + lens[j]
                loops.append({"i": i, "body": toks[k], "iters": j - k + 1, "actions": a1 - a0,
                              "fail_share": sum(fail[i][a0:a1]) / (a1 - a0)})
                bodies[toks[k]] += 1
                traj_with[agent_of[i]].add(i)
            k = j + 1
    d = {"n_loops": len(loops), "traj_with_loop": sum(len(x) for x in traj_with.values()),
         "traj_with_loop_by_agent": {a: len(traj_with[a]) for a in B.AGENTS},
         "median_iters": st.median([l["iters"] for l in loops]) if loops else None,
         "median_actions": st.median([l["actions"] for l in loops]) if loops else None,
         "mean_fail_share_in_loops": st.mean([l["fail_share"] for l in loops]) if loops else None,
         "corpus_fail_rate": base_fail,
         "top_bodies": sorted(((b.replace(B.SEP, " > "), c) for b, c in bodies.items()), key=lambda x: -x[1])[:6]}
    RX["loops"][f"{v}/K{K}"] = d
    print(f"[{v} K={K}] loops {d['n_loops']} in {d['traj_with_loop']} traj {d['traj_with_loop_by_agent']}; median iters {d['median_iters']}, "
          f"median actions {d['median_actions']}; failed-action share inside loops {d['mean_fail_share_in_loops']:.3f} vs corpus {base_fail:.3f}")
    for b, c in d["top_bodies"]:
        print(f"     {c:>3}x  ({b})*")

with open(f"{OUT}/results_extra.json", "w") as fh:
    json.dump(json.loads(json.dumps(RX, default=str)), fh, indent=1)
print("\nwrote results_extra.json")
