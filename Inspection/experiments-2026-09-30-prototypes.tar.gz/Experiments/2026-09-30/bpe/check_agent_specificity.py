"""Provenance for two claims: (1) failure-bearing variant-B tokens with support >= 15 and their agent split;
(2) share of top-40 pooled tokens whose support is dominated (>= 80%) by one agent.  python3 check_agent_specificity.py"""
import sys
from collections import Counter
sys.path.insert(0, __file__.rsplit("/", 1)[0])
import bpe_core as B

trajs = B.load_trajectories()
V = B.build_variants(trajs)
agent_of = [t["agent"] for t in trajs]
for v in ["A", "B", "A_rle", "C_rle"]:
    merges, _ = B.fit_bpe([s for s, _ in V[v]], 100000)
    if v == "B":
        ft = [(k + 1, m) for k, m in enumerate(merges) if "!" in m["token"]]
        big = [(k, m) for k, m in ft if len(m["support"]) >= 15]
        print(f"[B] failure-bearing tokens: {len(ft)}; with support>=15: {len(big)}")
        for k, m in big:
            c = Counter(agent_of[i] for i in m["support"])
            print(f"    #{k} {m['token'].replace(B.SEP, ' > ')}  support {len(m['support'])}  c/x/g {[c[a] for a in B.AGENTS]}")
    for K in (20, 40):
        dom = 0
        for m in merges[:K]:
            c = Counter(agent_of[i] for i in m["support"])
            dom += max(c.values()) / sum(c.values()) >= 0.8
        print(f"[{v}] top-{K}: {dom}/{K} tokens have >=80% of their supporting trajectories from a single agent")
