"""BPE sufficiency / baseline-segmenter experiment.  python3 run_bpe.py  -> results.json + stdout report.

Variants:  A = mid_level ; B = mid_level + '!' if failed ; C = high_level phase
           A_rle / C_rle = same with consecutive duplicates collapsed first (extra controls, not requested)
K always = number of merges (ProcGrep's K=192 is vocab size = atoms+merges, i.e. ~176-178 merges).
"""
import json
import random
import statistics as st
import sys
from collections import Counter, defaultdict

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import bpe_core as B

OUT = __file__.rsplit("/", 1)[0]
KS = [5, 10, 20, 40, 80, 192]
KMAX = 192
VARIANTS = ["A", "B", "C", "A_rle", "C_rle"]
N_BOOT = 50

trajs = B.load_trajectories()
V = B.build_variants(trajs)
N = len(trajs)
bugs = sorted({t["bug"] for t in trajs}, key=int)
agent_of = [t["agent"] for t in trajs]
bug_of = [t["bug"] for t in trajs]
idx_by_bug = defaultdict(list)
for i, t in enumerate(trajs):
    idx_by_bug[t["bug"]].append(i)
gold = []  # phase-change boundaries per trajectory
for t in trajs:
    hi = [r["high_level"] for r in t["rows"]]
    gold.append({i + 1 for i in range(len(hi) - 1) if hi[i] != hi[i + 1]})
midchg = []
for t in trajs:
    m = [r["mid_level"] for r in t["rows"]]
    midchg.append({i + 1 for i in range(len(m) - 1) if m[i] != m[i + 1]})
n_actions = [len(t["rows"]) for t in trajs]

R = {"n_traj": N, "n_bugs": len(bugs), "n_actions": sum(n_actions), "KS": KS}
print(f"corpus: {N} trajectories, {len(bugs)} bugs, {sum(n_actions)} actions")
for v in VARIANTS:
    alph = sorted({a for s, _ in V[v] for a in s})
    nat = sum(len(s) for s, _ in V[v])
    R.setdefault("alphabet", {})[v] = {"size": len(alph), "n_atoms_total": nat}
    print(f"  variant {v}: alphabet {len(alph)} symbols, {nat} input atoms")


def seqs_of(v, idx=None):
    idx = range(N) if idx is None else idx
    return [V[v][i][0] for i in idx]


def pct(xs, q):
    xs = sorted(xs)
    if not xs:
        return float("nan")
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def fmt(x, d=3):
    return f"{x:.{d}f}"


# ============================================================================ 1. merge supply
print("\n=== 1. MERGE SUPPLY (full corpus, BPE run to exhaustion, min pair freq 2) ===")
full = {}
R["supply"] = {}
for v in VARIANTS:
    seqs = seqs_of(v)
    merges, tok = B.fit_bpe(seqs, 100000)
    full[v] = merges
    freqs = [m["freq"] for m in merges]
    sup = [len(m["support"]) for m in merges]
    first_below = {t: next((k for k, f in enumerate(freqs) if f < t), len(freqs)) for t in (5, 10, 20)}
    d = {
        "n_merges_freq_ge2": len(merges),
        "n_merges_freq_ge5": sum(f >= 5 for f in freqs),
        "n_merges_freq_ge10": sum(f >= 10 for f in freqs),
        "n_merges_freq_ge20": sum(f >= 20 for f in freqs),
        "merge_index_where_freq_first_below": first_below,
        "n_tokens_support_ge5": sum(s >= 5 for s in sup),
        "n_tokens_support_ge15_(10pct)": sum(s >= 15 for s in sup),
        "n_tokens_support_ge30_(20pct)": sum(s >= 30 for s in sup),
        "per_K": {},
    }
    for K in KS:
        sK = sup[:K]
        fK = freqs[:K]
        d["per_K"][K] = {
            "n": len(sK),
            "support_ge5": sum(s >= 5 for s in sK),
            "support_ge15": sum(s >= 15 for s in sK),
            "min_support": min(sK) if sK else None,
            "median_support": st.median(sK) if sK else None,
            "freq_at_Kth_merge": fK[-1] if fK else None,
            "max_token_atoms": max(len(B.atoms_of(m["token"])) for m in merges[:K]) if sK else None,
        }
    R["supply"][v] = d
    print(f"[{v}] merges available: freq>=2 {d['n_merges_freq_ge2']}, >=5 {d['n_merges_freq_ge5']}, "
          f">=10 {d['n_merges_freq_ge10']}, >=20 {d['n_merges_freq_ge20']};  freq first <5 at merge #{first_below[5]+1}, "
          f"<10 at #{first_below[10]+1}")
    print(f"      all learned tokens: support(traj) >=5: {d['n_tokens_support_ge5']}, >=15 (10%): "
          f"{d['n_tokens_support_ge15_(10pct)']}, >=30 (20%): {d['n_tokens_support_ge30_(20pct)']}")
    for K in KS:
        p = d["per_K"][K]
        print(f"      K={K:>3}: n={p['n']:>3} sup>=5 {p['support_ge5']:>3} sup>=15 {p['support_ge15']:>3} "
              f"min_sup {p['min_support']} median_sup {p['median_support']} freq@K {p['freq_at_Kth_merge']} "
              f"longest token {p['max_token_atoms']} atoms")

# per-agent supply
print("  per-agent BPE (50 trajectories each):")
R["supply_per_agent"] = {}
for v in ["A", "B", "A_rle"]:
    for a in B.AGENTS:
        idx = [i for i in range(N) if agent_of[i] == a]
        m, _ = B.fit_bpe(seqs_of(v, idx), 100000)
        fr = [x["freq"] for x in m]
        sp = [len(x["support"]) for x in m]
        R["supply_per_agent"][f"{v}/{a}"] = {"freq_ge2": len(m), "freq_ge5": sum(f >= 5 for f in fr),
                                             "freq_ge10": sum(f >= 10 for f in fr),
                                             "support_ge5_(10pct)": sum(s >= 5 for s in sp)}
        print(f"    [{v}/{a}] freq>=2 {len(m)}, >=5 {sum(f >= 5 for f in fr)}, >=10 {sum(f >= 10 for f in fr)}; "
              f"tokens with support>=5 traj (10% of 50): {sum(s >= 5 for s in sp)}")


# ============================================================================ 2. stability
print("\n=== 2. STABILITY (vocabulary Jaccard vs full-corpus vocabulary at same K) ===")


def vocab_prefix(merges, K):
    return {m["token"] for m in merges[:K]}


def jacc(a, b):
    return len(a & b) / len(a | b) if (a or b) else 1.0


Kgrid = list(range(1, KMAX + 1))
R["stability"] = {}
rng = random.Random(12345)
boot_samples = [[rng.choice(bugs) for _ in bugs] for _ in range(N_BOOT)]
rng = random.Random(777)
sub_samples = [rng.sample(bugs, 40) for _ in range(N_BOOT)]
rng = random.Random(4242)
halves = []
for _ in range(N_BOOT):
    b = bugs[:]
    rng.shuffle(b)
    halves.append((b[:25], b[25:]))

recovery = {}
for v in VARIANTS:
    fullv = full[v]
    res = {}
    # bootstrap (bugs with replacement, multiplicity as weights)
    J = defaultdict(list)
    boot_vocabs = []
    for samp in boot_samples:
        c = Counter(samp)
        w = [c[bug_of[i]] for i in range(N)]
        m, _ = B.fit_bpe(seqs_of(v), KMAX, weights=w)
        boot_vocabs.append(m)
        for K in Kgrid:
            J[K].append(jacc(vocab_prefix(m, K), vocab_prefix(fullv, K)))
    # subsample 40/50 bugs without replacement
    Js = defaultdict(list)
    for samp in sub_samples:
        idx = [i for b in samp for i in idx_by_bug[b]]
        m, _ = B.fit_bpe(seqs_of(v, idx), KMAX)
        for K in Kgrid:
            Js[K].append(jacc(vocab_prefix(m, K), vocab_prefix(fullv, K)))
    # split-half: two disjoint 25-bug halves vs each other
    Jh = defaultdict(list)
    for h1, h2 in halves:
        m1, _ = B.fit_bpe(seqs_of(v, [i for b in h1 for i in idx_by_bug[b]]), KMAX)
        m2, _ = B.fit_bpe(seqs_of(v, [i for b in h2 for i in idx_by_bug[b]]), KMAX)
        for K in Kgrid:
            Jh[K].append(jacc(vocab_prefix(m1, K), vocab_prefix(m2, K)))

    def first_below(JJ, thr=0.5):
        return next((K for K in Kgrid if st.mean(JJ[K]) < thr), None)

    def last_above(JJ, thr=0.5):
        above = [K for K in Kgrid if st.mean(JJ[K]) >= thr]
        return max(above) if above else None

    res["bootstrap"] = {K: {"mean": st.mean(J[K]), "sd": st.pstdev(J[K]), "p05": pct(J[K], 0.05)} for K in KS}
    res["subsample40"] = {K: {"mean": st.mean(Js[K]), "sd": st.pstdev(Js[K]), "p05": pct(Js[K], 0.05)} for K in KS}
    res["split_half"] = {K: {"mean": st.mean(Jh[K]), "sd": st.pstdev(Jh[K]), "p05": pct(Jh[K], 0.05)} for K in KS}
    res["curve_bootstrap_mean"] = {K: st.mean(J[K]) for K in Kgrid}
    res["curve_split_half_mean"] = {K: st.mean(Jh[K]) for K in Kgrid}
    for name, JJ in (("bootstrap", J), ("subsample40", Js), ("split_half", Jh)):
        res[f"{name}_first_K_below_0.5"] = first_below(JJ)
        res[f"{name}_last_K_at_or_above_0.5"] = last_above(JJ)
        res[f"{name}_first_K_below_0.7"] = first_below(JJ, 0.7)
    # per-token recovery rate in bootstrap vs token support (K=40 and K=192 vocabularies)
    rec = {}
    for K in (40, KMAX):
        rows = []
        for m in fullv[:K]:
            r = sum(m["token"] in vocab_prefix(bm, K) for bm in boot_vocabs) / N_BOOT
            rows.append((len(m["support"]), r))
        buckets = {"support<5": [r for s, r in rows if s < 5], "5<=support<15": [r for s, r in rows if 5 <= s < 15],
                   "support>=15": [r for s, r in rows if s >= 15]}
        rec[K] = {b: {"n": len(x), "mean_recovery": (st.mean(x) if x else None)} for b, x in buckets.items()}
    res["token_recovery_by_support"] = rec
    R["stability"][v] = res
    print(f"[{v}]  K:      " + "  ".join(f"{K:>14}" for K in KS))
    for name in ("bootstrap", "subsample40", "split_half"):
        print(f"   {name:<12}" + "  ".join(f"{res[name][K]['mean']:.2f}+-{res[name][K]['sd']:.2f}({res[name][K]['p05']:.2f})"
                                     for K in KS))
    print(f"   mean Jaccard first < 0.5 at K = bootstrap {res['bootstrap_first_K_below_0.5']}, "
          f"subsample40 {res['subsample40_first_K_below_0.5']}, split-half {res['split_half_first_K_below_0.5']}; "
          f"first < 0.7: boot {res['bootstrap_first_K_below_0.7']}, split-half {res['split_half_first_K_below_0.7']}")
    for K in (40, KMAX):
        print(f"   token recovery in bootstrap top-{K}: " + ", ".join(
            f"{b}: n={x['n']} rec={x['mean_recovery'] if x['mean_recovery'] is None else round(x['mean_recovery'], 2)}"
            for b, x in rec[K].items()))


# ============================================================================ 3. grouped CV
print("\n=== 3. GENERALIZATION: 5-fold CV grouped by bug (all 3 agents of a bug in one fold) ===")
rng = random.Random(0)
fb = bugs[:]
rng.shuffle(fb)
folds = [fb[i::5] for i in range(5)]
R["folds"] = folds
cv_models = {}  # (v, fold) -> merges
R["cv"] = {}
for v in VARIANTS:
    per = {K: defaultdict(list) for K in KS}
    for f, test_bugs in enumerate(folds):
        te = [i for b in test_bugs for i in idx_by_bug[b]]
        tr = [i for i in range(N) if bug_of[i] not in set(test_bugs)]
        m, _ = B.fit_bpe(seqs_of(v, tr), KMAX)
        cv_models[(v, f)] = (m, tr, te)
        # oracle: BPE fitted on the test fold itself
        mo, _ = B.fit_bpe(seqs_of(v, te), KMAX)
        for K in KS:
            mk = m[:K]
            tr_tok = [B.apply_merges(V[v][i][0], mk)[0] for i in tr]
            te_res = [B.apply_merges(V[v][i][0], mk) for i in te]
            fired = set().union(*[r[1] for r in te_res]) if te_res else set()
            fired_ge2 = sum(1 for k in range(len(mk)) if sum(k in r[1] for r in te_res) >= 2)
            tr_atoms = sum(len(V[v][i][0]) for i in tr)
            te_atoms = sum(len(V[v][i][0]) for i in te)
            per[K]["train_ratio"].append(sum(map(len, tr_tok)) / tr_atoms)
            per[K]["test_ratio"].append(sum(len(r[0]) for r in te_res) / te_atoms)
            per[K]["coverage"].append(len(fired) / len(mk) if mk else float("nan"))
            per[K]["coverage_ge2traj"].append(fired_ge2 / len(mk) if mk else float("nan"))
            mok = mo[:K]
            per[K]["oracle_test_ratio"].append(
                sum(len(B.apply_merges(V[v][i][0], mok)[0]) for i in te) / te_atoms)
            per[K]["n_merges_learned"].append(len(mk))
    R["cv"][v] = {K: {k: {"mean": st.mean(x), "sd": st.pstdev(x)} for k, x in per[K].items()} for K in KS}
    print(f"[{v}] tokens/atoms (lower = more compression); coverage = share of learned merges that fire in held-out")
    for K in KS:
        c = R["cv"][v][K]
        print(f"   K={K:>3}: train {fmt(c['train_ratio']['mean'])}  held-out {fmt(c['test_ratio']['mean'])}"
              f"+-{fmt(c['test_ratio']['sd'])}  (oracle fit-on-test {fmt(c['oracle_test_ratio']['mean'])})  "
              f"coverage {fmt(c['coverage']['mean'])}  coverage(>=2 held-out traj) {fmt(c['coverage_ge2traj']['mean'])}"
              f"  merges learned {c['n_merges_learned']['mean']:.0f}")


# ============================================================================ 4. cross-agent transfer
print("\n=== 4. CROSS-AGENT TRANSFER ===")
R["cross_agent"] = {}
for v in ["A", "B", "C", "A_rle"]:
    R["cross_agent"][v] = {}
    for X in B.AGENTS:
        tr = [i for i in range(N) if agent_of[i] != X]
        te = [i for i in range(N) if agent_of[i] == X]
        m, _ = B.fit_bpe(seqs_of(v, tr), KMAX)
        # reference 1: within-agent grouped CV (train on X's other 40 bugs)
        # reference 2: pooled grouped CV (train on all agents' other 40 bugs), evaluated on X only
        row = {}
        for K in KS:
            mk = m[:K]
            te_res = [B.apply_merges(V[v][i][0], mk) for i in te]
            tr_tok = [B.apply_merges(V[v][i][0], mk)[0] for i in tr]
            fired = set().union(*[r[1] for r in te_res])
            te_atoms = sum(len(V[v][i][0]) for i in te)
            tr_atoms = sum(len(V[v][i][0]) for i in tr)
            within, pooled, within_cov = [], [], []
            for f, test_bugs in enumerate(folds):
                tb = set(test_bugs)
                trX = [i for i in te if bug_of[i] not in tb]
                teX = [i for i in te if bug_of[i] in tb]
                mX, _ = B.fit_bpe(seqs_of(v, trX), K)
                resX = [B.apply_merges(V[v][i][0], mX) for i in teX]
                within.append(sum(len(r[0]) for r in resX) / sum(len(V[v][i][0]) for i in teX))
                within_cov.append(len(set().union(*[r[1] for r in resX])) / max(1, len(mX)))
                mp = cv_models[(v, f)][0][:K]
                pooled.append(sum(len(B.apply_merges(V[v][i][0], mp)[0]) for i in teX)
                              / sum(len(V[v][i][0]) for i in teX))
            row[K] = {"train_ratio_other2": sum(map(len, tr_tok)) / tr_atoms,
                      "transfer_ratio": sum(len(r[0]) for r in te_res) / te_atoms,
                      "transfer_coverage": len(fired) / len(mk),
                      "within_agent_cv_ratio": st.mean(within), "within_agent_cv_coverage": st.mean(within_cov),
                      "pooled_cv_ratio_on_agent": st.mean(pooled)}
        R["cross_agent"][v][X] = row
        print(f"[{v}] train on others -> {X}")
        for K in KS:
            r = row[K]
            print(f"   K={K:>3}: others in-sample {fmt(r['train_ratio_other2'])} | transfer {fmt(r['transfer_ratio'])} "
                  f"cov {fmt(r['transfer_coverage'])} | within-{X} CV {fmt(r['within_agent_cv_ratio'])} "
                  f"cov {fmt(r['within_agent_cv_coverage'])} | pooled CV on {X} {fmt(r['pooled_cv_ratio_on_agent'])}")

# agent-exclusive procedures
print("  agent-exclusive tokens (per-agent BPE, K=40; raw substring support in the OTHER two agents == 0):")
R["agent_exclusive"] = {}
for v in ["A", "B", "A_rle"]:
    for X in B.AGENTS:
        idx = [i for i in range(N) if agent_of[i] == X]
        oth = seqs_of(v, [i for i in range(N) if agent_of[i] != X])
        m, _ = B.fit_bpe(seqs_of(v, idx), 40)
        excl = [(mm["token"], len(mm["support"])) for mm in m if B.raw_support(mm["token"], oth) == 0]
        excl5 = [e for e in excl if e[1] >= 5]
        R["agent_exclusive"][f"{v}/{X}"] = {"n_exclusive": len(excl), "n_exclusive_support_ge5": len(excl5),
                                            "examples": [(t.replace(B.SEP, " > "), s) for t, s in excl5[:5]]}
        print(f"   [{v}/{X}] {len(excl)}/40 exclusive, {len(excl5)} with own-agent support>=5; e.g. "
              + "; ".join(f"{t.replace(B.SEP, ' > ')} (sup {s})" for t, s in excl5[:3]))


# ============================================================================ 5. triviality
print("\n=== 5. TRIVIALITY ===")
R["triviality"] = {}
for v in VARIANTS:
    m = full[v]
    d = {}
    for K in [10, 20] + KS:
        mk = m[:K]
        d[f"selfrep_share_top{K}"] = sum(B.is_self_repetition(x["token"]) for x in mk) / len(mk)
    for K in KS:
        mk = m[:K]
        cov = Counter()
        for i in range(N):
            toks, _ = B.apply_merges(V[v][i][0], mk)
            lens = B.token_action_lengths(toks, V[v][i][1])
            for t, L in zip(toks, lens):
                if B.SEP not in t:
                    cov["singleton"] += L
                elif B.is_self_repetition(t):
                    cov["selfrep"] += L
                else:
                    cov["mixed"] += L
        tot = sum(cov.values())
        d[f"action_share_K{K}"] = {k: cov[k] / tot for k in ("singleton", "selfrep", "mixed")}
    R["triviality"][v] = d
    print(f"[{v}] self-repetition share of merges: top10 {d['selfrep_share_top10']:.2f}, top20 {d['selfrep_share_top20']:.2f}, "
          + ", ".join(f"top{K} {d[f'selfrep_share_top{K}']:.2f}" for K in KS[2:]))
    print("      share of ACTIONS inside singleton / self-rep / mixed tokens: " + "; ".join(
        f"K={K}: {d[f'action_share_K{K}']['singleton']:.2f}/{d[f'action_share_K{K}']['selfrep']:.2f}/"
        f"{d[f'action_share_K{K}']['mixed']:.2f}" for K in KS))

# shuffle null (order destroyed within each trajectory, composition kept)
print("  within-trajectory shuffle null (10 shuffles), in-sample tokens/atoms:")
R["shuffle_null"] = {}
for v in ["A", "B"]:
    real = {K: sum(len(B.apply_merges(V[v][i][0], full[v][:K])[0]) for i in range(N)) / sum(n_actions) for K in KS}
    sh = defaultdict(list)
    sh_supply = []
    for s in range(10):
        r = random.Random(1000 + s)
        ss = []
        for i in range(N):
            x = list(V[v][i][0])
            r.shuffle(x)
            ss.append(x)
        m, _ = B.fit_bpe(ss, 100000)
        sh_supply.append(len(m))
        for K in KS:
            sh[K].append(sum(len(B.apply_merges(x, m[:K])[0]) for x in ss) / sum(n_actions))
    R["shuffle_null"][v] = {"real": real, "shuffled_mean": {K: st.mean(sh[K]) for K in KS},
                            "shuffled_supply_mean": st.mean(sh_supply)}
    print(f"   [{v}] real: " + " ".join(f"K{K}={real[K]:.3f}" for K in KS))
    print(f"   [{v}] shuf: " + " ".join(f"K{K}={st.mean(sh[K]):.3f}" for K in KS)
          + f"   (shuffled corpora still yield {st.mean(sh_supply):.0f} merges with freq>=2)")

# top-20 procedures
R["top20"] = {}
for v in ["A", "B", "A_rle", "C_rle"]:
    rows = []
    for k, m in enumerate(full[v][:20]):
        ag = Counter(agent_of[i] for i in m["support"])
        rows.append({"rank": k + 1, "token": m["token"].replace(B.SEP, " > "), "n_atoms": len(B.atoms_of(m["token"])),
                     "pair_freq_at_merge": m["freq"], "support_traj": len(m["support"]),
                     "raw_support_traj": B.raw_support(m["token"], seqs_of(v)),
                     "support_claude_codex_gemini": [ag[a] for a in B.AGENTS],
                     "self_repetition": B.is_self_repetition(m["token"])})
    R["top20"][v] = rows
    print(f"\n  TOP-20 learned procedures, variant {v}  (freq = pair count at merge time; sup = trajectories where merge fired /150;"
          f" raw = trajectories containing the atom string; c/x/g = per-agent support)")
    for r in rows:
        print(f"   {r['rank']:>2}. {'[self]' if r['self_repetition'] else '      '} {r['token']:<70} freq {r['pair_freq_at_merge']:>4} "
              f"sup {r['support_traj']:>3} raw {r['raw_support_traj']:>3} c/x/g {r['support_claude_codex_gemini']}")

# failure-bearing procedures in B
fail_toks = [(k, m) for k, m in enumerate(full["B"]) if "!" in m["token"] and B.SEP in m["token"]]
R["B_failure_tokens"] = [{"rank": k + 1, "token": m["token"].replace(B.SEP, " > "), "freq": m["freq"],
                          "support": len(m["support"]),
                          "support_c_x_g": [Counter(agent_of[i] for i in m["support"])[a] for a in B.AGENTS]}
                         for k, m in fail_toks[:15]]
print(f"\n  Variant B: merges containing a failed action: {len(fail_toks)} of {len(full['B'])}; "
      f"within top-40: {sum(1 for k, _ in fail_toks if k < 40)}, top-192: {sum(1 for k, _ in fail_toks if k < 192)}; "
      f"with support>=5: {sum(1 for _, m in fail_toks if len(m['support']) >= 5)}")
for r in R["B_failure_tokens"][:10]:
    print(f"   #{r['rank']:>3} {r['token']:<60} freq {r['freq']:>3} sup {r['support']:>3} c/x/g {r['support_c_x_g']}")


# ============================================================================ 6. segmenter
print("\n=== 6. BPE AS A SEGMENTER (boundaries between tokens) ===")
print("  Sanity check ONLY vs phase-change boundaries (phase is itself rule-derived from mid_level; NOT validation).")


def prf(preds, golds, tol):
    tp_p = sum(sum(1 for b in P if any(abs(b - g) <= tol for g in G)) for P, G in zip(preds, golds))
    tp_r = sum(sum(1 for g in G if any(abs(b - g) <= tol for b in P)) for P, G in zip(preds, golds))
    npred = sum(map(len, preds))
    ngold = sum(map(len, golds))
    p = tp_p / npred if npred else float("nan")
    r = tp_r / ngold if ngold else float("nan")
    f = 2 * p * r / (p + r) if p + r > 0 else 0.0
    return p, r, f


def random_baseline(preds, draws=20, seed=99):
    rng = random.Random(seed)
    acc = {0: [], 1: []}
    for _ in range(draws):
        rp = []
        for i, P in enumerate(preds):
            pos = list(range(1, n_actions[i]))
            rp.append(set(rng.sample(pos, min(len(P), len(pos)))))
        for tol in (0, 1):
            acc[tol].append(prf(rp, gold, tol))
    return {tol: tuple(st.mean(x[j] for x in acc[tol]) for j in range(3)) for tol in (0, 1)}


R["segmenter"] = {}
all_bound = [set(range(1, n - 1 + 1)) for n in n_actions]
base = {"every_action(K=0 on A)": all_bound, "mid_level_change(run-length)": midchg}
R["segmenter"]["baselines"] = {}
for name, P in base.items():
    lens = [n_actions[i] / (len(P[i]) + 1) for i in range(N)]
    R["segmenter"]["baselines"][name] = {
        "segments_per_traj_median": st.median(len(p) + 1 for p in P),
        "tol0": prf(P, gold, 0), "tol1": prf(P, gold, 1)}
    b = R["segmenter"]["baselines"][name]
    print(f"  baseline {name:<30} segs/traj med {b['segments_per_traj_median']:>5}  "
          f"P/R/F tol0 {'/'.join(fmt(x, 2) for x in b['tol0'])}  tol1 {'/'.join(fmt(x, 2) for x in b['tol1'])}")
print(f"  gold phase-change boundaries: {sum(map(len, gold))} total, median {st.median(map(len, gold))} per trajectory")

for v in ["A", "B", "A_rle", "C"]:
    R["segmenter"][v] = {}
    for mode in ("in_sample", "heldout_cv"):
        for K in [0] + KS:
            preds, seglens, nsegs = [None] * N, [], []
            for i in range(N):
                if mode == "in_sample":
                    mk = full[v][:K]
                else:
                    f = next(f for f, tb in enumerate(folds) if bug_of[i] in tb)
                    mk = cv_models[(v, f)][0][:K]
                toks, _ = B.apply_merges(V[v][i][0], mk)
                lens = B.token_action_lengths(toks, V[v][i][1])
                preds[i] = set(B.boundaries_from_lengths(lens))
                seglens.extend(lens)
                nsegs.append(len(lens))
            t0, t1 = prf(preds, gold, 0), prf(preds, gold, 1)
            rb = random_baseline(preds)
            R["segmenter"][v][f"{mode}/K{K}"] = {
                "segments_per_traj_median": st.median(nsegs), "segment_len_median": st.median(seglens),
                "segment_len_mean": st.mean(seglens), "segment_len_p90": pct(seglens, 0.9),
                "share_singleton_segments": sum(1 for L in seglens if L == 1) / len(seglens),
                "tol0": t0, "tol1": t1, "random_same_count_tol0": rb[0], "random_same_count_tol1": rb[1]}
    print(f"[{v}]  (P/R/F vs phase-change boundaries; 'rand' = same number of boundaries at random positions)")
    for mode in ("in_sample", "heldout_cv"):
        for K in [0] + KS:
            s = R["segmenter"][v][f"{mode}/K{K}"]
            print(f"   {mode:<10} K={K:>3}: segs/traj {s['segments_per_traj_median']:>5} seg len med {s['segment_len_median']:>4} "
                  f"mean {s['segment_len_mean']:.2f} p90 {s['segment_len_p90']:.1f} singleton {s['share_singleton_segments']:.2f} | "
                  f"tol0 {'/'.join(fmt(x, 2) for x in s['tol0'])} rand {'/'.join(fmt(x, 2) for x in s['random_same_count_tol0'])} | "
                  f"tol1 {'/'.join(fmt(x, 2) for x in s['tol1'])} rand {'/'.join(fmt(x, 2) for x in s['random_same_count_tol1'])}")

# per-agent segment length at K=40 held-out (variant A)
R["segmenter"]["per_agent_A_heldout_K40"] = {}
for X in B.AGENTS:
    lens_all, nseg = [], []
    for i in range(N):
        if agent_of[i] != X:
            continue
        f = next(f for f, tb in enumerate(folds) if bug_of[i] in tb)
        toks, _ = B.apply_merges(V["A"][i][0], cv_models[("A", f)][0][:40])
        L = B.token_action_lengths(toks, V["A"][i][1])
        lens_all.extend(L)
        nseg.append(len(L))
    R["segmenter"]["per_agent_A_heldout_K40"][X] = {"segs_per_traj_median": st.median(nseg),
                                                    "seg_len_median": st.median(lens_all),
                                                    "seg_len_mean": st.mean(lens_all)}
    print(f"   per-agent A held-out K=40 [{X}]: segs/traj med {st.median(nseg)}, seg len med {st.median(lens_all)}, "
          f"mean {st.mean(lens_all):.2f}")


def _json(o):
    if isinstance(o, dict):
        return {str(k): _json(x) for k, x in o.items()}
    if isinstance(o, (list, tuple)):
        return [_json(x) for x in o]
    if isinstance(o, set):
        return sorted(o)
    return o


with open(f"{OUT}/results.json", "w") as fh:
    json.dump(_json(R), fh, indent=1)
# save full-corpus vocabularies for inspection
with open(f"{OUT}/full_vocab.json", "w") as fh:
    json.dump({v: [{"rank": k + 1, "token": m["token"].replace(B.SEP, " > "), "freq": m["freq"],
                    "support": len(m["support"])} for k, m in enumerate(full[v])] for v in VARIANTS}, fh, indent=1)
print("\nwrote results.json, full_vocab.json")
