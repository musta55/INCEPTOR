"""ProcGrep's K-selection criterion on our corpus.
uv run --no-project --with scikit-learn --with scipy python3 vmeasure.py -> results_vmeasure.json + stdout

For each K (merges): per-trajectory token-frequency vector (L1-normalised counts of final BPE tokens, in-sample),
KMeans(k=3) x 10 seeds -> V-measure vs agent label.  Plus a GroupKFold(bug) logistic-regression agent probe.
Baselines: K=0 (unigram mid-level distribution) and trajectory length only.
Stability of the argmax-K: 30 bug-bootstrap resamples (BPE refit on each resample).
"""
import json
import random
import statistics as st
import sys
from collections import Counter, defaultdict

import numpy as np
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import v_measure_score
from sklearn.model_selection import GroupKFold

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import bpe_core as B

OUT = __file__.rsplit("/", 1)[0]
trajs = B.load_trajectories()
V = B.build_variants(trajs)
N = len(trajs)
agent = np.array([B.AGENTS.index(t["agent"]) for t in trajs])
bug = np.array([int(t["bug"]) for t in trajs])
bugs = sorted(set(bug.tolist()))
KG = [0, 2, 5, 10, 20, 40, 80, 120, 178, 250, 300]


def features(tok_seqs):
    vocab = sorted({t for s in tok_seqs for t in s})
    ix = {t: k for k, t in enumerate(vocab)}
    X = np.zeros((len(tok_seqs), len(vocab)))
    for i, s in enumerate(tok_seqs):
        for t, c in Counter(s).items():
            X[i, ix[t]] = c
    return X / X.sum(1, keepdims=True)


def vm(X, y, seeds=10):
    return [v_measure_score(y, KMeans(3, n_init=10, random_state=s).fit_predict(X)) for s in range(seeds)]


def probe(X, y, g):
    acc = []
    for tr, te in GroupKFold(5).split(X, y, g):
        clf = LogisticRegression(max_iter=5000).fit(X[tr], y[tr])
        acc.append((clf.predict(X[te]) == y[te]).mean())
    return float(np.mean(acc))


R = {}
loglen = np.log(np.array([len(t["rows"]) for t in trajs], dtype=float)).reshape(-1, 1)
R["length_only"] = {"vmeasure": float(np.mean(vm(loglen, agent))), "probe_acc": probe(loglen, agent, bug)}
print(f"length-only baseline: V-measure {R['length_only']['vmeasure']:.3f}, GroupKFold probe acc {R['length_only']['probe_acc']:.3f}")
for v in ["A", "B", "A_rle"]:
    seqs = [s for s, _ in V[v]]
    merges, _ = B.fit_bpe(seqs, 100000)
    n_atoms = len({a for s in seqs for a in s})
    rows = {}
    for K in KG:
        if K > len(merges):
            continue
        toks = [B.apply_merges(s, merges[:K])[0] for s in seqs]
        X = features(toks)
        v_ = vm(X, agent)
        rows[K] = {"vocab_size": n_atoms + K, "vmeasure_mean": float(np.mean(v_)), "vmeasure_sd": float(np.std(v_)),
                   "probe_acc": probe(X, agent, bug)}
    best = max(rows, key=lambda k: rows[k]["vmeasure_mean"])
    # bootstrap argmax
    rng = random.Random(55)
    arg = []
    for _ in range(30):
        samp = [rng.choice(bugs) for _ in bugs]
        idx = [i for b in samp for i in np.where(bug == b)[0]]
        s2 = [seqs[i] for i in idx]
        m2, _ = B.fit_bpe(s2, 300)
        y2 = agent[idx]
        curve = {}
        for K in KG:
            if K > len(m2):
                continue
            X2 = features([B.apply_merges(s, m2[:K])[0] for s in s2])
            curve[K] = np.mean(vm(X2, y2, seeds=3))
        arg.append(max(curve, key=curve.get))
    R[v] = {"curve": rows, "argmax_K": best, "bootstrap_argmax_K_counts": dict(Counter(arg))}
    print(f"[{v}] ({n_atoms} atoms; ProcGrep's vocab 192 ~ K={192 - n_atoms} merges)")
    for K, r in rows.items():
        print(f"   K={K:>3} (vocab {r['vocab_size']:>3}): V-measure {r['vmeasure_mean']:.3f}+-{r['vmeasure_sd']:.3f}   probe acc {r['probe_acc']:.3f}")
    print(f"   argmax K = {best};  bootstrap argmax distribution: {dict(sorted(Counter(arg).items()))}")

with open(f"{OUT}/results_vmeasure.json", "w") as fh:
    json.dump(json.loads(json.dumps(R, default=str)), fh, indent=1)
