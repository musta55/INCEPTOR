"""Check bpe_core.fit_bpe == ProcGrep reference algorithm (recount-every-iteration) on our corpus."""
import sys
from collections import Counter
sys.path.insert(0, __file__.rsplit("/", 1)[0])
import bpe_core as B


# --- verbatim logic of pg_repo/src/procgrep/bpe.py (_most_frequent_pair/_apply_merge/fit loop)
def ref_most_frequent_pair(sequences, min_frequency):
    counts = Counter()
    for seq in sequences:
        for i in range(len(seq) - 1):
            counts[(seq[i], seq[i + 1])] += 1
    if not counts:
        return None
    best_pair, best_count = min(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    if best_count < min_frequency:
        return None
    return best_pair


def ref_apply_merge(seq, pair):
    left, right = pair
    merged = left + B.SEP + right
    out, i, n = [], 0, len(seq)
    while i < n:
        if i + 1 < n and seq[i] == left and seq[i + 1] == right:
            out.append(merged); i += 2
        else:
            out.append(seq[i]); i += 1
    return out


def ref_fit(seqs, n):
    mat = [list(s) for s in seqs]
    merges = []
    for _ in range(n):
        p = ref_most_frequent_pair(mat, 2)
        if p is None:
            break
        merges.append(p)
        mat = [ref_apply_merge(s, p) for s in mat]
    return merges, mat


trajs = B.load_trajectories()
V = B.build_variants(trajs)
ok = True
for name in ["A", "B", "C", "A_rle", "C_rle"]:
    seqs = [s for s, _ in V[name]]
    rm, rt = ref_fit(seqs, 400)
    mm, mt = B.fit_bpe(seqs, 400)
    same = [m["pair"] for m in mm] == rm and mt == rt
    ok &= same
    print(f"{name}: ref merges={len(rm)} ours={len(mm)} identical={same}")
    # apply_merges reproduces in-sample tokenization
    re = [B.apply_merges(s, mm)[0] for s in seqs]
    print(f"   apply_merges reproduces fit tokenization: {re == mt}")
print("ALL IDENTICAL" if ok else "MISMATCH")
