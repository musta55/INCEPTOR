"""Reviewer checks on bpe experiment.
 (1) learning curve: how many merges (freq>=2) exist per half at h bugs -> is 'top-192' actually 192 at small h?
 (2) loops: action-weighted vs per-loop-mean failed share; per-agent composition; per-agent baseline
 (3) run-preserving null for A_rle: shuffle RLE atoms within trajectory (re-collapse adjacent duplicates)
 (4) boundary P/R/F with one-to-one matching at tol=1 vs the many-to-one prf in run_bpe.py
 (5) split-half last K with mean J >= 0.5 (from results.json)
"""
import json, math, random, statistics as st, sys
from collections import defaultdict, Counter
sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/bpe")
import bpe_core as B
E = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/bpe"
trajs = B.load_trajectories(); V = B.build_variants(trajs); N = len(trajs)
bugs = sorted({t["bug"] for t in trajs}, key=int)
bug_of = [t["bug"] for t in trajs]; agent_of = [t["agent"] for t in trajs]
idx_by_bug = defaultdict(list)
for i, t in enumerate(trajs): idx_by_bug[t["bug"]].append(i)
seqs_of = lambda v, idx: [V[v][i][0] for i in idx]

print("=== (1) merges available per half in learning curve (same RNG as run_bpe_extra.py) ===")
for v in ["A", "A_rle"]:
    rng = random.Random(2024)
    for h in [5, 10, 15, 20, 25]:
        ns = []
        for _ in range(30):
            b = bugs[:]; rng.shuffle(b)
            for half in (b[:h], b[h:2*h]):
                m, _ = B.fit_bpe(seqs_of(v, [i for x in half for i in idx_by_bug[x]]), 100000)
                ns.append(len(m))
        print(f"  [{v}] h={h:>2} ({3*h:>2} traj/half): merges available median {st.median(ns)}, min {min(ns)}, max {max(ns)}; "
              f"share of halves with <192 merges {sum(n < 192 for n in ns)/len(ns):.2f}; <80: {sum(n < 80 for n in ns)/len(ns):.2f}")

print("\n=== (2) loops (A_rle K=40 and C_rle K=10, held-out, same folds) ===")
rng = random.Random(0); fb = bugs[:]; rng.shuffle(fb); folds = [fb[i::5] for i in range(5)]
fold_of = {b: f for f, tb in enumerate(folds) for b in tb}
fail = [[r["failed"] == "true" for r in t["rows"]] for t in trajs]
n_act = [len(t["rows"]) for t in trajs]
agent_rate = {a: sum(sum(fail[i]) for i in range(N) if agent_of[i] == a) / sum(n_act[i] for i in range(N) if agent_of[i] == a) for a in B.AGENTS}
print("  per-agent failed-action rate:", {a: round(r, 3) for a, r in agent_rate.items()})
for v, K in (("A_rle", 20), ("A_rle", 40), ("C_rle", 10), ("C_rle", 20)):
    models = {}
    for f, tb in enumerate(folds):
        tr = [i for i in range(N) if bug_of[i] not in set(tb)]
        models[f], _ = B.fit_bpe(seqs_of(v, tr), 192)
    loops = []
    for i in range(N):
        toks, _ = B.apply_merges(V[v][i][0], models[fold_of[bug_of[i]]][:K])
        lens = B.token_action_lengths(toks, V[v][i][1]); starts = [sum(lens[:k]) for k in range(len(lens))]
        k = 0
        while k < len(toks):
            j = k
            while j + 1 < len(toks) and toks[j + 1] == toks[k]: j += 1
            if j > k and B.SEP in toks[k]:
                a0, a1 = starts[k], starts[j] + lens[j]
                loops.append((i, a0, a1))
            k = j + 1
    per_loop = st.mean(sum(fail[i][a0:a1]) / (a1 - a0) for i, a0, a1 in loops)
    weighted = sum(sum(fail[i][a0:a1]) for i, a0, a1 in loops) / sum(a1 - a0 for i, a0, a1 in loops)
    # expected under per-agent baseline (action-weighted)
    exp = sum(agent_rate[agent_of[i]] * (a1 - a0) for i, a0, a1 in loops) / sum(a1 - a0 for i, a0, a1 in loops)
    by_agent = Counter(agent_of[i] for i, _, _ in loops)
    fail_by_agent = {a: (sum(sum(fail[i][a0:a1]) for i, a0, a1 in loops if agent_of[i] == a), sum(a1 - a0 for i, a0, a1 in loops if agent_of[i] == a)) for a in B.AGENTS}
    top = sorted(((sum(fail[i][a0:a1]), bug_of[i], agent_of[i], a1 - a0) for i, a0, a1 in loops), reverse=True)[:3]
    print(f"  [{v} K={K}] {len(loops)} loops by agent {dict(by_agent)}; failed share per-loop-mean {per_loop:.3f}, action-weighted {weighted:.3f}, "
          f"expected from per-agent rates {exp:.3f}; failed/actions by agent {fail_by_agent}; top loops by #failed {top}")

print("\n=== (3) run-preserving shuffle null for A_rle (shuffle collapsed atoms, re-collapse adjacent dups) ===")
full, _ = B.fit_bpe(seqs_of("A_rle", range(N)), 100000)
real_atoms = sum(len(V["A_rle"][i][0]) for i in range(N))
KS = [5, 10, 20, 40, 80]
real = {K: sum(len(B.apply_merges(V["A_rle"][i][0], full[:K])[0]) for i in range(N)) / real_atoms for K in KS}
sh = defaultdict(list); sup = []
for s in range(10):
    r = random.Random(1000 + s); ss = []
    for i in range(N):
        x = list(V["A_rle"][i][0]); r.shuffle(x); ss.append(B.rle(x)[0])
    na = sum(map(len, ss))
    m, _ = B.fit_bpe(ss, 100000); sup.append(len(m))
    for K in KS:
        sh[K].append(sum(len(B.apply_merges(x, m[:K])[0]) for x in ss) / na)
print(f"  real A_rle: supply {len(full)}; tokens/atom " + " ".join(f"K{K}={real[K]:.3f}" for K in KS))
print(f"  shuffled  : supply {st.mean(sup):.0f}; tokens/atom " + " ".join(f"K{K}={st.mean(sh[K]):.3f}" for K in KS))
print("  gap (shuffled - real): " + " ".join(f"K{K}={st.mean(sh[K]) - real[K]:+.3f}" for K in KS))
# same for A (reproduce the reported A null for comparison)
fullA, _ = B.fit_bpe(seqs_of("A", range(N)), 100000)
realA = {K: sum(len(B.apply_merges(V["A"][i][0], fullA[:K])[0]) for i in range(N)) / 5400 for K in KS}
print("  (A gap reported by run_bpe.py for reference; see results.txt)")

print("\n=== (4) boundary F1: many-to-one (as in run_bpe.py) vs one-to-one greedy matching, A held-out ===")
gold = []
for t in trajs:
    hi = [r["high_level"] for r in t["rows"]]
    gold.append({i + 1 for i in range(len(hi) - 1) if hi[i] != hi[i + 1]})
def prf_many(P, G, tol):
    tp_p = sum(sum(1 for b in p if any(abs(b - g) <= tol for g in g_)) for p, g_ in zip(P, G))
    tp_r = sum(sum(1 for g in g_ if any(abs(b - g) <= tol for b in p)) for p, g_ in zip(P, G))
    pp, rr = tp_p / sum(map(len, P)), tp_r / sum(map(len, G)); return pp, rr, 2*pp*rr/(pp+rr)
def prf_one(P, G, tol):
    tp = 0
    for p, g_ in zip(P, G):
        used = set()
        for b in sorted(p, key=lambda b: min([abs(b - g) for g in g_] or [99])):
            cands = [g for g in g_ if abs(b - g) <= tol and g not in used]
            if cands:
                used.add(min(cands, key=lambda g: abs(b - g))); tp += 1
    pp, rr = tp / sum(map(len, P)), tp / sum(map(len, G)); return pp, rr, 2*pp*rr/(pp+rr)
models = {}
for f, tb in enumerate(folds):
    tr = [i for i in range(N) if bug_of[i] not in set(tb)]
    models[f], _ = B.fit_bpe(seqs_of("A", tr), 192)
for K in [10, 20, 40]:
    P = []
    for i in range(N):
        toks, _ = B.apply_merges(V["A"][i][0], models[fold_of[bug_of[i]]][:K])
        P.append(set(B.boundaries_from_lengths(B.token_action_lengths(toks, V["A"][i][1]))))
    r = random.Random(99); RP = [[], []]
    for _ in range(20):
        rp = [set(r.sample(range(1, n_act[i]), min(len(P[i]), n_act[i] - 1))) for i in range(N)]
        RP[0].append(prf_many(rp, gold, 1)[2]); RP[1].append(prf_one(rp, gold, 1)[2])
    print(f"  K={K}: tol1 F1 many-to-one BPE {prf_many(P, gold, 1)[2]:.2f} random {st.mean(RP[0]):.2f} | one-to-one BPE {prf_one(P, gold, 1)[2]:.2f} random {st.mean(RP[1]):.2f}")

print("\n=== (5) split-half last K with mean Jaccard >= 0.5 / first K below 0.5 ===")
R = json.load(open(f"{E}/results.json"))
for v in ["A", "B", "C", "A_rle", "C_rle"]:
    s = R["stability"][v]
    print(f"  [{v}] split-half: first<0.5 at K={s['split_half_first_K_below_0.5']}, last>=0.5 at K={s['split_half_last_K_at_or_above_0.5']}; "
          f"bootstrap first<0.5 {s['bootstrap_first_K_below_0.5']}")
    c = s["curve_split_half_mean"]
    print("     split-half mean J at K=1..30: " + " ".join(f"{c[str(k)]:.2f}" for k in range(1, 31)))
