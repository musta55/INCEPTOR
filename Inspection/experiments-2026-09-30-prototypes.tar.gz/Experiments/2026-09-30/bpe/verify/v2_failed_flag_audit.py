"""Audit: run_test/build actions flagged failed=='false' whose result_preview shows a failure signal, per agent."""
import json, glob, os, re
from collections import Counter, defaultdict
C = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/corpus/annotation"
PAT = re.compile(r"(BUILD FAILED|FAILURE:|tests? completed, \d+ failed|FAILED|Exit Code: [1-9]|exit code [1-9]|Process exited with code [1-9]|error:)", re.I)
cnt = defaultdict(Counter); ex = defaultdict(list)
for f in sorted(glob.glob(os.path.join(C, "bug-*_actions.jsonl"))):
    for line in open(f):
        r = json.loads(line)
        if r["mid_level"] not in ("run_test", "build"):
            continue
        a = r["agent"]; sig = bool(PAT.search(r["result_preview"] or ""))
        cnt[a][(r["failed"], sig)] += 1
        if r["failed"] == "false" and sig and len(ex[a]) < 3:
            ex[a].append((r["bug_id"], r["action_index"], r["mid_level"], (r["result_preview"] or "")[:160].replace("\n", " | ")))
for a in ("claude", "codex", "gemini"):
    c = cnt[a]
    print(f"[{a}] run_test+build: failed=true {c[('true',True)]+c[('true',False)]}; failed=false but failure text in 300-char preview: {c[('false',True)]}; failed=false, no signal: {c[('false',False)]}")
    for e in ex[a]:
        print("    e.g.", e)
