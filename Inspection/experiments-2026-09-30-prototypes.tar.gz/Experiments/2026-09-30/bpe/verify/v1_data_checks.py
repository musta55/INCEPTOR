"""Verify data assumptions: action_index type/contiguity, sub-agent splicing, failed-flag coverage per agent x mid_level."""
import json, glob, os
from collections import Counter, defaultdict
C = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/corpus/annotation"
by = defaultdict(list)
types = Counter(); failed_vals = Counter()
for f in glob.glob(os.path.join(C, "bug-*_actions.jsonl")):
    for line in open(f):
        r = json.loads(line)
        types[type(r["action_index"]).__name__] += 1
        failed_vals[repr(r["failed"])] += 1
        by[(r["bug_id"], r["agent"])].append(r)
print("action_index types:", types)
print("failed values:", failed_vals)
bad = 0
for k, rows in by.items():
    idx = sorted(r["action_index"] for r in rows)
    if idx != list(range(idx[0], idx[0] + len(idx))):
        bad += 1
    # file order vs action_index order
print("trajectories:", len(by), "non-contiguous action_index:", bad)
starts = Counter(min(r["action_index"] for r in rows) for rows in by.values())
print("action_index start values:", starts)
# is file order == action_index order?
unsorted = sum(1 for rows in by.values() if [r["action_index"] for r in rows] != sorted(r["action_index"] for r in rows))
print("trajectories whose file order != action_index order:", unsorted)
# subagent rows
sub = Counter(r["agent"] for rows in by.values() for r in rows if r["scope"] != "main")
print("sub-agent rows by agent:", sub)
# timestamp monotonicity for codex/gemini after sorting by action_index
nonmono = Counter()
for (b, a), rows in by.items():
    rows = sorted(rows, key=lambda r: r["action_index"])
    ts = [r["timestamp"] for r in rows if r["timestamp"]]
    if any(ts[i] > ts[i + 1] for i in range(len(ts) - 1)):
        nonmono[a] += 1
print("trajectories with non-monotone timestamps after sort:", dict(nonmono))
# failure rate by agent x mid_level
tab = defaultdict(lambda: [0, 0])
for (b, a), rows in by.items():
    for r in rows:
        t = tab[(a, r["mid_level"])]
        t[0] += 1; t[1] += r["failed"] == "true"
mids = sorted({m for _, m in tab})
print("\nfailed-rate by agent x mid_level (failed/total):")
print(f"{'mid':<14}" + "".join(f"{a:>18}" for a in ("claude", "codex", "gemini")))
for m in mids:
    print(f"{m:<14}" + "".join(f"{tab[(a,m)][1]:>7}/{tab[(a,m)][0]:<5} {tab[(a,m)][1]/tab[(a,m)][0] if tab[(a,m)][0] else float('nan'):.2f}" for a in ("claude", "codex", "gemini")))
tot = {a: [sum(tab[(a, m)][0] for m in mids), sum(tab[(a, m)][1] for m in mids)] for a in ("claude", "codex", "gemini")}
print("overall:", {a: f"{v[1]}/{v[0]} = {v[1]/v[0]:.3f}" for a, v in tot.items()})
