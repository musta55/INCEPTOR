"""Compare BPE segment granularity with phase-run and mid-level-run granularity (actions per unit)."""
import sys, statistics as st, random
from collections import defaultdict
sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/bpe")
import bpe_core as B
trajs = B.load_trajectories(); V = B.build_variants(trajs); N = len(trajs)
bugs = sorted({t["bug"] for t in trajs}, key=int); bug_of = [t["bug"] for t in trajs]
def desc(name, lens, per):
    print(f"  {name:<32} units/traj median {st.median(per):>5}  len median {st.median(lens)}  mean {st.mean(lens):.2f}  "
          f"share len>=5 {sum(l >= 5 for l in lens)/len(lens):.2f}  share of ACTIONS in units len>=5 {sum(l for l in lens if l >= 5)/sum(lens):.2f}")
ph = [B.rle([r["high_level"] for r in t["rows"]])[1] for t in trajs]
md = [V["A_rle"][i][1] for i in range(N)]
desc("phase runs", [l for x in ph for l in x], [len(x) for x in ph])
desc("mid-level runs", [l for x in md for l in x], [len(x) for x in md])
rng = random.Random(0); fb = bugs[:]; rng.shuffle(fb); folds = [fb[i::5] for i in range(5)]
fold_of = {b: f for f, tb in enumerate(folds) for b in tb}
for v in ["A", "A_rle"]:
    models = {}
    for f, tb in enumerate(folds):
        models[f], _ = B.fit_bpe([V[v][i][0] for i in range(N) if bug_of[i] not in set(tb)], 192)
    for K in [10, 20, 40]:
        L, P = [], []
        for i in range(N):
            toks, _ = B.apply_merges(V[v][i][0], models[fold_of[bug_of[i]]][:K])
            l = B.token_action_lengths(toks, V[v][i][1]); L += l; P.append(len(l))
        desc(f"BPE {v} K={K} held-out", L, P)
