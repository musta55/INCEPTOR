/* Dev-only interaction self-test (not shipped). Loaded by the scratch site when #selftest=1. */
(function () {
  if (!/selftest=1/.test(location.search)) return;
  var out = [], fails = 0;
  function log(ok, msg) { out.push((ok ? 'PASS ' : 'FAIL ') + msg); if (!ok) fails++; console.log('SELFTEST ' + (ok ? 'PASS ' : 'FAIL ') + msg); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function frame() { return wait(120); }
  function q(s) { return document.querySelector(s); }
  function qa(s) { return document.querySelectorAll(s); }
  function key(k) { document.body.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true })); }
  function mouse(el, type, x, y) { el.dispatchEvent(new MouseEvent(type, { bubbles: true, clientX: x, clientY: y, view: window })); }
  window.addEventListener('error', function (e) { log(false, 'window error: ' + e.message); });
  var TV = window.TV, S = TV.state;
  async function run() {
    await wait(300);
    TV.setTraj('bug-18/codex'); TV.setView('topdown'); await frame();
    log(qa('#view-topdown .pblk').length === TV.traj().purposes.length, 'topdown renders one block per purpose (' + qa('#view-topdown .pblk').length + ')');
    TV.setLevel('purposes'); await frame();
    log(qa('#view-topdown .sblk').length === 0, 'level purposes hides segments');
    TV.setLevel('segments'); await frame();
    log(qa('#view-topdown .sblk').length === TV.traj().segs.length && qa('#view-topdown .step').length === 0, 'level segments shows segments only');
    TV.setLevel('steps'); await frame();
    log(qa('#view-topdown .step').length === TV.traj().n, 'level steps shows all steps (' + qa('#view-topdown .step').length + ')');
    TV.setLevel('purposes'); await frame();
    q('#view-topdown .pb-h').click(); await frame();
    log(qa('#view-topdown .sblk').length === TV.traj().purposes[0].segments.length, 'click purpose expands it');
    q('#view-topdown .sb-h').click(); await frame();
    log(qa('#view-topdown .step').length === TV.traj().segs[0].end - TV.traj().segs[0].start + 1, 'click segment expands steps lazily');
    q('#view-topdown .st-h').click(); await frame();
    log(!!q('#view-topdown .st-d') && S.cursor === 1, 'click step opens details + sets cursor');
    TV.setLevel('segments'); await frame();
    TV.setCursor(5); await frame();
    log(!!q('#view-topdown .cur'), 'cursor highlights a block in topdown');
    key('j'); log(S.cursor === 6, 'j advances cursor (' + S.cursor + ')');
    key('k'); key('k'); log(S.cursor === 4, 'k moves back (' + S.cursor + ')');
    var before = S.traj; key(']'); await frame();
    log(S.traj !== before, '] next trajectory -> ' + S.traj);
    key('['); await frame();
    log(S.traj === before, '[ previous trajectory -> ' + S.traj);
    log(q('#drawer .dr-i') && q('#drawer .dr-i').textContent === '#' + S.cursor, 'drawer shows current action');

    /* timeline */
    TV.setView('timeline'); await frame();
    var svg = q('#view-timeline svg.tl');
    log(!!svg && qa('#view-timeline .mk').length === TV.traj().n, 'timeline: one mark per action (' + qa('#view-timeline .mk').length + ')');
    var wrapW = q('#view-timeline .tl-wrap').clientWidth;
    log(+svg.getAttribute('width') <= wrapW, 'timeline svg fits its container (' + svg.getAttribute('width') + ' <= ' + wrapW + ')');
    TV.setCursor(10); await frame();
    var pl = q('#view-timeline .playline');
    log(+pl.getAttribute('x1') > 100, 'playhead line moved (x=' + pl.getAttribute('x1') + ')');
    var ov = q('#view-timeline .overlay'), r = ov.getBoundingClientRect();
    mouse(ov, 'mousedown', r.left + r.width * 0.1, r.top + 20);
    mouse(ov, 'mousemove', r.left + r.width * 0.4, r.top + 20);
    mouse(window, 'mouseup', r.left + r.width * 0.4, r.top + 20);
    await frame();
    log(!!S.range, 'brush sets range ' + JSON.stringify(S.range));
    TV.setView('topdown'); await frame();
    log(qa('#view-topdown .sblk.off').length > 0, 'brushed range greys segments in topdown (' + qa('#view-topdown .sblk.off').length + ')');
    key('Escape'); await frame();
    log(!S.range, 'Esc clears range');
    TV.setView('timeline'); await frame();
    ov = q('#view-timeline .overlay'); r = ov.getBoundingClientRect();
    mouse(ov, 'mousedown', r.left + r.width * 0.5, r.top + 20);
    mouse(window, 'mouseup', r.left + r.width * 0.5, r.top + 20);
    log(S.cursor > 1 && !S.range, 'click on timeline sets cursor (' + S.cursor + ')');
    mouse(ov, 'mousemove', r.left + r.width * 0.3, r.top + 20);
    log(!q('#tip').hidden && q('#tip').textContent.length > 5, 'hover shows tooltip');
    TV.tip.hide();
    TV.setTraj('bug-18/claude'); await frame();
    log(q('#view-timeline [data-x="time"]').disabled, 'wall-clock disabled without timestamps (claude)');
    TV.setTraj('bug-18/codex'); await frame();
    q('#view-timeline [data-x="time"]').click(); await frame();
    log(S.timeMode && q('#view-timeline [data-x="time"]').getAttribute('aria-pressed') === 'true', 'wall-clock mode with timestamps');
    q('#view-timeline [data-x="index"]').click(); await frame();

    /* play */
    TV.setCursor(1); TV.togglePlay(); await wait(1200); TV.togglePlay();
    log(S.cursor > 1, 'play advanced cursor to ' + S.cursor);

    /* filters */
    var chip = q('.fchip[data-g="segOutcomes"][data-k="looped"]'); chip.click(); await frame();
    var m = TV.matchingTrajs().length;
    log(m > 0 && m < 150, 'segment-outcome=looped filter matches ' + m + ' trajectories');
    log(qa('#trajList .trow.off').length === 150 - m, 'non-matching rows greyed (' + qa('#trajList .trow.off').length + ')');
    q('#fHide').click(); await frame();
    log(qa('#trajList .trow').length === m, 'hide instead of grey (' + qa('#trajList .trow').length + ')');
    q('#fHide').click(); q('.fchip[data-g="segOutcomes"][data-k="looped"]').click(); await frame();
    q('#fProblems').click(); await frame();
    log(TV.matchingTrajs().length > 0, 'only failure & inefficiency: ' + TV.matchingTrajs().length + ' trajectories');
    q('#fProblems').click(); await frame();

    /* sankey */
    TV.setView('sankey'); await frame();
    var lks = qa('#view-sankey .lk');
    log(lks.length > 10, 'sankey ribbons: ' + lks.length);
    var mid = lks[Math.floor(lks.length / 2)];
    mid.dispatchEvent(new MouseEvent('click', { bubbles: true }));
    await frame();
    log(!!S.filters.sankey && TV.matchingTrajs().length < 150, 'sankey link click filters to ' + TV.matchingTrajs().length + ': ' + (S.filters.sankey && S.filters.sankey.label));
    S.filters.sankey = null; TV.filtersChanged();
    ['outcome', 'failheavy', 'agent'].forEach(function (sp) { S.sankey.split = sp; TV.invalidate(['sankey']); });
    await frame();

    /* fingerprint */
    TV.setView('fingerprint'); await frame();
    log(qa('#view-fingerprint svg.fp').length === 3, 'fingerprint small multiples: ' + qa('#view-fingerprint svg.fp').length);

    /* compare */
    TV.setView('compare'); await frame();
    var bx = qa('#view-compare .cbox[data-sid]');
    log(bx.length >= TV.trajsByBug['18'].reduce(function (n, t) { return n + t.segs.length; }, 0), 'compare boxes: ' + bx.length);
    var target = bx[bx.length - 1];
    target.click(); await frame(); await frame();
    log(S.view === 'topdown' && S.traj === target.dataset.id && !!q('#view-topdown .sblk[data-sid="' + target.dataset.sid + '"] .sb-body'), 'compare click opens segment in topdown');

    /* stats */
    TV.setView('stats'); await frame();
    log(qa('#view-stats tbody tr').length === 150, 'stats table rows: ' + qa('#view-stats tbody tr').length);
    q('#view-stats [data-sort="loops"]').click(); await frame();
    var first = q('#view-stats tbody tr');
    log(TV.byId[first.dataset.id].loops.length === Math.max.apply(null, TV.trajs.map(function (t) { return t.loops.length; })), 'sort by loops desc puts max first (' + first.dataset.id + ')');
    first.click(); await frame();
    log(S.view === 'topdown' && S.traj === first.dataset.id, 'row click opens trajectory');

    /* every trajectory x every view: no exceptions, and timing */
    var t0 = performance.now(), errs = 0;
    ['topdown', 'timeline', 'fingerprint', 'compare'].forEach(function (v) {
      TV.trajs.forEach(function (t) {
        S.traj = t.id; S.compare.bug = t.bug; S.cursor = 1;
        try { TV.views[v].render(document.getElementById('view-' + v)); if (TV.views[v].onCursor) TV.views[v].onCursor(t.n); }
        catch (e) { errs++; if (errs < 4) log(false, v + ' ' + t.id + ': ' + e.message); }
      });
    });
    var dt = performance.now() - t0;
    log(errs === 0, 'rendered 4 views x ' + TV.trajs.length + ' trajectories without errors in ' + Math.round(dt) + ' ms (' + (dt / 600).toFixed(1) + ' ms/render)');
    S.level = 'steps';
    t0 = performance.now();
    TV.trajs.forEach(function (t) { S.traj = t.id; TV.applyLevel(t, 'steps'); TV.views.topdown.render(document.getElementById('view-topdown')); });
    log(true, 'topdown fully expanded for all trajectories: ' + Math.round((performance.now() - t0) / TV.trajs.length) + ' ms/trajectory');
    t0 = performance.now(); TV.views.sankey.render(document.getElementById('view-sankey')); TV.views.stats.render(document.getElementById('view-stats'));
    log(true, 'sankey+stats render: ' + Math.round(performance.now() - t0) + ' ms');
    var biggest = TV.trajs.slice().sort(function (a, b) { return b.n - a.n; })[0];
    log(true, 'largest trajectory: ' + biggest.id + ' (' + biggest.n + ' actions)');

    var pre = document.createElement('pre'); pre.id = 'selftest-out';
    pre.textContent = 'SELFTEST ' + (fails ? fails + ' FAILED' : 'ALL PASSED') + '\n' + out.join('\n');
    document.body.appendChild(pre);
    console.log('SELFTEST DONE fails=' + fails);
  }
  window.addEventListener('load', function () { run().catch(function (e) { log(false, 'exception ' + e.message + ' ' + e.stack); }); });
})();
