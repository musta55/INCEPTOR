#!/bin/sh
D=/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/viewer-dev
T="t=bug-18%2Fcodex"
sh $D/shot.sh 01-topdown "v=topdown&$T&lvl=segments&i=4" 1440 900 &
sh $D/shot.sh 02-topdown-steps "v=topdown&$T&lvl=steps&i=4" 1440 900 &
sh $D/shot.sh 03-timeline "v=timeline&$T&lvl=steps&i=12" 1440 900 &
sh $D/shot.sh 04-fingerprint "v=fingerprint&$T&lvl=steps&i=12" 1440 900 &
wait
sh $D/shot.sh 05-compare "v=compare&$T" 1440 900 &
sh $D/shot.sh 06-sankey "v=sankey&$T" 1440 900 &
sh $D/shot.sh 07-stats "v=stats&$T" 1440 900 &
sh $D/shot.sh 08-timeline-dark-1100 "v=timeline&$T&lvl=steps&i=20&theme=dark" 1100 800 &
wait
