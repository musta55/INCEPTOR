#!/bin/sh
# copy the viewer sources into the scratch site and use the sample corpus there
D=/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/viewer-dev
V="/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Parser/viewer"
mkdir -p "$D/site/data"
cp "$V"/index.html "$V"/*.css "$V"/*.js "$D/site/"
cp "$D/sample_corpus.js" "$D/site/data/corpus.js"
cp "$D/selftest.js" "$D/site/selftest.js"
sed -i '' 's|<script src="viewer.js"></script>|<script src="viewer.js"></script><script src="selftest.js"></script>|' "$D/site/index.html"
