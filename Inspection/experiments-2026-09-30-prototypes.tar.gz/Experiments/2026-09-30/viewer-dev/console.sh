#!/bin/sh
D=/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/viewer-dev
for v in topdown timeline fingerprint compare sankey stats; do
  sh $D/chrome.sh 10 --user-data-dir="$D/prof-c-$v" --enable-logging=stderr --v=0 --virtual-time-budget=3000 --dump-dom "file://$D/site/index.html#v=$v&t=bug-18%2Fcodex&lvl=steps$1" 2>$D/err_$v.txt > $D/dom_$v.html
  rm -rf "$D/prof-c-$v"
  echo "== $v: dom $(wc -c < $D/dom_$v.html) bytes"; grep "CONSOLE" $D/err_$v.txt | head -5
done
