#!/bin/sh
# run headless chrome with a hard wall-clock limit: chrome.sh <seconds> <args...>
S=$1; shift
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless=new --disable-gpu --no-first-run --hide-scrollbars "$@" &
P=$!
i=0; while kill -0 $P 2>/dev/null && [ $i -lt $S ]; do sleep 1; i=$((i+1)); done
kill $P 2>/dev/null; sleep 0.5; kill -9 $P 2>/dev/null
exit 0
