#!/bin/sh
# usage: shot.sh <name> <hash> [width] [height]
D=/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/viewer-dev
W=${3:-1440}; H=${4:-900}
rm -f "$D/shots/$1.png"
sh $D/chrome.sh 12 --user-data-dir="$D/prof-$1" --window-size=$W,$H --virtual-time-budget=3000 \
  --screenshot="$D/shots/$1.png" "file://$D/site/index.html#$2" >/dev/null 2>&1
rm -rf "$D/prof-$1"
ls -la "$D/shots/$1.png" 2>/dev/null | awk '{print $5, $9}'
