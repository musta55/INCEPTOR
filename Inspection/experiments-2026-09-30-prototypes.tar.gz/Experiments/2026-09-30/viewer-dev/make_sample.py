"""Throwaway adapter: prototype hierarchy + annotation rows + APR outcomes -> trajview/1 sample_corpus.js.

Only for viewer development. The real producer is `python3 -m atif.cli view --all`.
"""
import csv, json, os, re, sys, datetime, collections

SP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad"
SEG = SP + "/experiments/segments"
ANN = SP + "/corpus/annotation"
APR = "/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset/APR_results"
OUT = SP + "/viewer-dev/sample_corpus.js"
CONFIG = "code_localization_tests"
sys.path.insert(0, SEG)
from seglib_verdict import verdict_kind  # noqa: E402

MID = ["read_file", "search_code", "orient", "edit_file", "build", "run_test", "device_ops",
       "env_setup", "vcs", "plan", "delegate", "wait_process", "web", "run_shell", "other"]
PURPOSES = ["orientation", "localization", "reproduction", "environment", "repair", "validation", "review"]
TYPES = ["targeted_lookup", "file_by_file_localization_sweep", "lookup_tool_errors", "orientation_planning",
         "delegated_exploration", "delegated_edit", "reproduction_succeeded", "reproduction_blocked",
         "reproduction_not_reproduced", "reproduction_other", "toolchain_wrestling", "stuck_repeating_failure",
         "test_or_harness_modification", "fix_attempt_passed", "fix_attempt_failed", "fix_attempt_breaks_build",
         "fix_attempt_blocked_by_env", "fix_attempt_other", "unverified_edit", "validation_passed",
         "validation_failed", "validation_blocked_by_env", "validation_other", "review_patch", "other"]
FLAGS = ["retried_immediately", "retried_after_detour", "abandoned", "ends_trajectory_unresolved",
         "stuck_repeating_command", "env_wrestling", "edits_toolchain", "edits_harness", "edits_test_script",
         "reverts_changes", "off_patch_exploration", "rereads_same_file", "tool_errors", "recovered_after_repeats"]
EXEC_KINDS = ("exec", "fix_attempt", "toolchain_fix", "test_edit")


def code(s):  # copy of codebook.py code()
    k, p, d, f = s["kind"], s["purpose"], s["outcome_detail"], set(s["flags"])
    if k in EXEC_KINDS and s["outcome"] == "looped":
        return "stuck_repeating_failure"
    if k == "test_edit" or "edits_harness" in f:
        return "test_or_harness_modification"
    if p == "reproduction" and k in EXEC_KINDS:
        if d == "reproduced": return "reproduction_succeeded"
        if d and d.startswith("blocked"): return "reproduction_blocked"
        if d == "not_reproduced": return "reproduction_not_reproduced"
        return "reproduction_other"
    if k == "toolchain_fix" or (p == "environment" and k == "exec"):
        return "toolchain_wrestling"
    if k == "fix_attempt":
        if d == "edit_not_followed_by_run": return "unverified_edit"
        return {"tests_pass": "fix_attempt_passed", "tests_fail": "fix_attempt_failed",
                "patch_breaks_build": "fix_attempt_breaks_build",
                "blocked_env": "fix_attempt_blocked_by_env"}.get(d, "fix_attempt_other")
    if p == "validation" and k == "exec":
        if d == "tests_pass": return "validation_passed"
        if d in ("tests_fail", "patch_breaks_build"): return "validation_failed"
        if d and d.startswith("blocked"): return "validation_blocked_by_env"
        return "validation_other"
    if k == "delegate":
        return "delegated_" + ("edit" if p == "repair" else "exploration")
    if k == "vcs" or p == "review": return "review_patch"
    if p in ("orientation", "planning"): return "orientation_planning"
    if k == "explore":
        if s["outcome"] == "failed": return "lookup_tool_errors"
        if s["mid_seq"].count("read_file") >= 3 and len(s["files"]) >= 3: return "file_by_file_localization_sweep"
        return "targeted_lookup"
    return "other"


def outcomes():
    res = {}
    for ag in ("claude", "codex", "gemini"):
        for r in csv.DictReader(open(f"{APR}/test_results_{ag}.csv", encoding="utf-8-sig")):
            res.setdefault((r["bug"], ag), {})[r.get("Config") or r.get("config")] = r["all_pass"] == "1"
    return res


def ts_parse(t):
    try:
        return datetime.datetime.fromisoformat(t.replace("Z", "+00:00"))
    except Exception:
        return None


RE_CLAIM = re.compile(r"(tests?|it|script)\s+(now\s+)?(pass|passes|passed|succeed)|all tests pass|fix(ed)? (is )?(complete|verified)|BUILD SUCCESSFUL", re.I)


def main():
    H = json.load(open(SEG + "/all_hierarchy.json"))
    OUTC = outcomes()
    trajs = []
    for bug in sorted(H, key=lambda b: int(b)):
        rows = [json.loads(l) for l in open(f"{ANN}/bug-{bug}_actions.jsonl")]
        for agent in ("claude", "codex", "gemini"):
            h = H[bug].get(agent)
            if not h:
                continue
            acts_raw = sorted((r for r in rows if r["agent"] == agent), key=lambda r: int(r["action_index"]))
            seg_of = {}
            failed_steps = set()
            for p in h["purposes"]:
                for s in p["segments"]:
                    for i in s["steps"]:
                        seg_of[i] = s
                    failed_steps.update(s.get("failed_steps") or [])
            actions = []
            for k, r in enumerate(acts_raw):
                i = k + 1
                v, kind = verdict_kind(r)
                if v not in ("pass", "fail"):
                    v, kind = "none", None
                if i in failed_steps and v != "fail":
                    v, kind = "fail", kind or "exit"
                phase = r["high_level"] if r["high_level"] in PURPOSES else seg_of[i]["purpose"]
                actions.append({
                    "i": i, "step": int(r["step_id"]), "scope": r["scope"], "tool": r["tool"],
                    "mid": r["mid_level"] if r["mid_level"] in MID else "other", "phase": phase,
                    "target": " ".join((r["target"] or "").split())[:200], "verdict": v, "fail_kind": kind,
                    "failed_raw": r["failed"] == "true", "ts": r["timestamp"] or None,
                    "thought": " ".join((r["thought_preview"] or "").split())[:300],
                    "result": " ".join((r["result_preview"] or "").split())[:300], "call_id": r["call_id"]})
            n = len(actions)
            assert n == h["n_actions"], (bug, agent, n, h["n_actions"])
            purposes = []
            all_segs = []
            for p in h["purposes"]:
                segs = []
                for s in p["segments"]:
                    seg = {"id": s["id"], "type": code(s), "kind": s["kind"], "label": s["label"],
                           "purpose": s["purpose"], "nested": bool(s.get("nested")), "outcome": s["outcome"],
                           "outcome_detail": s["outcome_detail"], "start": s["start"], "end": s["end"],
                           "steps": s["steps"], "flags": [f for f in s["flags"] if f in FLAGS]}
                    segs.append(seg); all_segs.append(seg)
                purposes.append({"id": p["id"], "label": p["label"], "start": p["start"], "end": p["end"], "segments": segs})
            loops = []
            for l in h["loops"]:
                loops.append({"type": l["type"], "start": l["start"], "end": l["end"],
                              "iterations": l.get("iterations", len(l["segment_ids"])),
                              "failed_iterations": l.get("failed_iterations", l.get("iterations", 1)),
                              "ended": {"looped": "failed"}.get(l["ended"], l["ended"]),
                              "segment_ids": l["segment_ids"]})
            fse = h.get("first_source_edit")
            tests = [a for a in actions if a["mid"] == "run_test" and a["verdict"] != "none"]
            last_thought = next((a["thought"] for a in reversed(actions) if a["thought"]), "")
            env_ids = sum(1 for a in actions if a["phase"] == "environment" or a["mid"] == "env_setup")
            tss = [ts_parse(a["ts"]) for a in actions if a["ts"]]
            tss = [t for t in tss if t]
            fix = [s for s in all_segs if s["kind"] == "fix_attempt"]
            oc = OUTC.get((bug, agent), {})
            trajs.append({
                "id": f"bug-{bug}/{agent}", "bug": bug, "agent": agent, "app": "",
                "n_actions": n, "n_steps": len({(a["scope"], a["step"]) for a in actions}),
                "outcome": {"pass": oc.get(CONFIG), "by_config": oc},
                "badges": {
                    "self_claims_pass": bool(RE_CLAIM.search(last_thought)),
                    "reproduced_before_fix": any(a["fail_kind"] == "test" and (fse is None or a["i"] < fse) for a in tests),
                    "edits_test_script": any("edits_test_script" in s["flags"] or s["kind"] == "test_edit" for s in all_segs),
                    "edits_harness": any("edits_harness" in s["flags"] for s in all_segs),
                    "env_blocked_runs": sum(1 for a in actions if a["fail_kind"] == "env"),
                    "last_test_verdict": tests[-1]["verdict"] if tests else "none"},
                "stats": {
                    "n_segments": len(all_segs), "n_purposes": len(purposes),
                    "n_failed_actions": sum(1 for a in actions if a["verdict"] == "fail"),
                    "n_fix_attempts": len(fix),
                    "n_failed_fix_attempts": sum(1 for s in fix if s["outcome"] in ("failed", "looped")),
                    "n_loops": len(loops), "n_stuck_segments": sum(1 for l in loops if l["type"] == "stuck_segment"),
                    "env_share": round(env_ids / n, 3) if n else 0.0, "first_source_edit": fse,
                    "duration_s": round((max(tss) - min(tss)).total_seconds(), 1) if len(tss) > 1 else None},
                "actions": actions, "purposes": purposes, "loops": loops})
    data = {"schema": "trajview/1", "generated_by": "viewer-dev sample adapter", "outcome_config": CONFIG,
            "vocab": {"mid": MID, "purposes": PURPOSES, "segment_types": TYPES, "flags": FLAGS},
            "trajectories": trajs}
    # invariants
    for t in trajs:
        assert all(a["i"] == k + 1 for k, a in enumerate(t["actions"]))
        cov = [i for p in t["purposes"] for i in range(p["start"], p["end"] + 1)]
        assert cov == list(range(1, t["n_actions"] + 1)), t["id"]
        for p in t["purposes"]:
            sc = [i for s in p["segments"] for i in s["steps"]]
            assert sc == list(range(p["start"], p["end"] + 1)), t["id"]
            for s in p["segments"]:
                assert s["type"] in TYPES, s["type"]
    with open(OUT, "w") as f:
        f.write("window.TRAJ_DATA = " + json.dumps(data, separators=(",", ":")) + ";\n")
    print(f"wrote {OUT}: {len(trajs)} trajectories, {sum(t['n_actions'] for t in trajs)} actions, "
          f"{os.path.getsize(OUT)/1e6:.2f} MB")


if __name__ == "__main__":
    main()
