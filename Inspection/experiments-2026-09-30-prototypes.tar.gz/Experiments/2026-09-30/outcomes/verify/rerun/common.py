"""Shared loaders for the 'outcomes' experiment. Read-only access to the raw dataset and
the converted corpus; nothing here writes outside this experiment directory."""
from __future__ import annotations

import ast
import csv
import glob
import json
import os
import re
from pathlib import Path

ROOT = Path("/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis")
DATASET = ROOT / "Inspection" / "Dataset"
CLAUDE_DIR = DATASET / "localized-tests-logs-claude" / "logs"
CODEX_DIR = DATASET / "results-localization-codex"
GEMINI_DIR = DATASET / "results_localized_withtests-gemini"

SP = Path("/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-"
          "Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad")
CORPUS = SP / "corpus"
EXP = SP / "experiments" / "outcomes" / "verify" / "rerun"
OUT = EXP / "out"
OUT.mkdir(parents=True, exist_ok=True)

AGENTS = ("claude", "codex", "gemini")


def bug_ids():
    ids = sorted({re.search(r"bug-(\d+)_actions", p).group(1)
                  for p in glob.glob(str(CORPUS / "annotation" / "bug-*_actions.jsonl"))},
                 key=int)
    return ids


def actions(bug):
    with open(CORPUS / "annotation" / f"bug-{bug}_actions.jsonl") as fh:
        return [json.loads(l) for l in fh if l.strip()]


def atif(bug, agent):
    with open(CORPUS / "atif" / f"bug-{bug}_{agent}.atif.json") as fh:
        return json.load(fh)


def iter_atif_calls(traj, _scope="main"):
    """Yield (scope, step, tool_call, observation_text) for main + embedded subagents."""
    for step in traj.get("steps", []):
        obs = {}
        for r in (step.get("observation") or {}).get("results", []) or []:
            obs.setdefault(r.get("source_call_id"), []).append(r)
        for tc in step.get("tool_calls") or []:
            rs = obs.get(tc.get("tool_call_id"), [])
            text = "\n".join(str(r.get("content") or "") for r in rs)
            yield _scope, step, tc, text, rs
    for sub in traj.get("subagent_trajectories") or []:
        yield from iter_atif_calls(sub, _scope="sub-" + str(sub.get("trajectory_id", "")))


def call_index(traj):
    """call_id -> (tool_call, observation_text, results)."""
    out = {}
    for scope, step, tc, text, rs in iter_atif_calls(traj):
        out[tc.get("tool_call_id")] = (tc, text, rs, step)
    return out


# ---------------------------------------------------------------- Codex raw
def codex_rollouts(bug):
    paths = sorted((CODEX_DIR / f"log-{bug}" / "logs").glob("*.jsonl"))
    return sorted(paths, key=lambda p: p.stat().st_size, reverse=True)


def codex_rows(path):
    with open(path, errors="replace") as fh:
        return [json.loads(l) for l in fh if l.strip()]


def codex_csv(bug):
    p = CODEX_DIR / f"test_results_run_{bug}.csv"
    with open(p, newline="") as fh:
        rows = list(csv.DictReader(fh))
    return rows


def codex_task_prompt(rows):
    for r in rows:
        p = r.get("payload", {})
        if p.get("type") == "user_message":
            return p.get("message", "")
    for r in rows:
        p = r.get("payload", {})
        if p.get("type") == "message" and p.get("role") == "user":
            for c in p.get("content", []):
                t = c.get("text", "")
                if "## Bug Description" in t:
                    return t
    return ""


# ---------------------------------------------------------------- Gemini raw
def gemini_events(bug):
    evs = []
    n_lines = 0
    with open(GEMINI_DIR / f"bug-{bug}_raw.json", errors="replace") as fh:
        for line in fh:
            n_lines += 1
            s = line.strip()
            if not s.startswith("{"):
                continue
            try:
                evs.append(json.loads(s))
            except Exception:
                pass
    return evs, n_lines


# ---------------------------------------------------------------- Claude raw
def _node(n):
    """Safe AST -> python value walker (never eval). Calls become dicts with __type__."""
    if isinstance(n, ast.Constant):
        return n.value
    if isinstance(n, ast.Dict):
        return {_node(k): _node(v) for k, v in zip(n.keys, n.values)}
    if isinstance(n, (ast.List, ast.Tuple, ast.Set)):
        return [_node(e) for e in n.elts]
    if isinstance(n, ast.Call):
        name = n.func.id if isinstance(n.func, ast.Name) else getattr(n.func, "attr", "?")
        d = {"__type__": name}
        for i, a in enumerate(n.args):
            d[f"_arg{i}"] = _node(a)
        for kw in n.keywords:
            d[kw.arg] = _node(kw.value)
        return d
    if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub):
        v = _node(n.operand)
        return -v if isinstance(v, (int, float)) else v
    if isinstance(n, ast.Name):
        return {"True": True, "False": False, "None": None}.get(n.id, n.id)
    return None


def claude_messages(bug):
    msgs = []
    with open(CLAUDE_DIR / f"bug-{bug}_output.txt", errors="replace") as fh:
        for line in fh:
            s = line.strip()
            if not s:
                continue
            try:
                msgs.append(_node(ast.parse(s, mode="eval").body))
            except SyntaxError:
                msgs.append({"__type__": "UNPARSED", "raw": s[:200]})
    return msgs


# ---------------------------------------------------------------- self-report classifier
def classify_self_report(text):
    """Heuristic classification of an agent's final natural-language report.
    Returns (label, evidence).  Labels:
      claims_all_pass   - asserts the bug-exposing test / full suite passes
      claims_partial    - reports some tests still failing / could not verify some
      env_blocked       - says tests could not be run / verified because of environment
      gives_up          - says the fix is not done / could not fix
      no_claim          - describes a change without any test verdict
      empty             - no text
    """
    if not text or not text.strip():
        return "empty", ""
    t = text.lower()
    # explicit counts first
    m = re.search(r"(\d+)\s*(?:passed|pass|tests? pass(?:ed)?)[^\n]{0,40}?(\d+)\s*failed", t)
    m2 = re.search(r"(\d+)\s*/\s*(\d+)\s*(?:tests?\s*)?pass", t)
    fail_words = re.search(
        r"(still fail|still failing|fails? (?:in this|due to|because|before)|\bfailed\b|"
        r"\bfailing\b|could not (?:be )?(?:run|verif|complete|reproduce)|unable to (?:run|verif)|"
        r"not (?:able|possible) to (?:run|verif)|couldn['’]t (?:run|verif)|"
        r"did not pass|does not pass|not pass)", t)
    env_words = re.search(
        r"(emulator|no (?:connected )?device|sandbox|operation not permitted|environment|"
        r"adb|timed? ?out|timeout|network|offline|permission)", t)
    pass_words = re.search(
        r"(all (?:\d+ )?(?:tests?|test cases?) (?:now )?pass|all (?:\d+ )?pass(?:ed)?\b|"
        r"tests? (?:now )?pass(?:es|ed)?\b|passes successfully|passed successfully|"
        r"\bok \(1 test\)|build successful|builds? successfully|✅|test(?:s)? .*?:\s*passed|"
        r"\bpassed\b|\bpasses\b)", t)
    giveup = re.search(r"(i was unable to fix|could not fix|couldn['’]t fix|unable to fix|"
                       r"not (?:been )?fixed|did not fix|no fix)", t)
    if m:
        p, f = int(m.group(1)), int(m.group(2))
        if f == 0 and p > 0:
            return "claims_all_pass", m.group(0)
        return ("env_blocked" if env_words else "claims_partial"), m.group(0)
    if m2:
        a, b = int(m2.group(1)), int(m2.group(2))
        if a == b and a > 0:
            return "claims_all_pass", m2.group(0)
        return "claims_partial", m2.group(0)
    if giveup:
        return "gives_up", giveup.group(0)
    if fail_words and env_words:
        return "env_blocked", fail_words.group(0) + " | " + env_words.group(0)
    if fail_words and not pass_words:
        return "claims_partial", fail_words.group(0)
    if pass_words and fail_words:
        return "claims_partial", pass_words.group(0) + " | " + fail_words.group(0)
    if pass_words:
        return "claims_all_pass", pass_words.group(0)
    return "no_claim", ""


def write_csv(path, rows, fields=None):
    path = Path(path)
    if not rows:
        path.write_text("")
        return
    fields = fields or list(rows[0].keys())
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


# ---------------------------------------------------------------- shell helpers
SHELL_TOOLS = {"exec_command", "run_shell_command", "Bash", "shell"}
_SEG = re.compile(r"&&|\|\||;|\n|\|")
_ASSIGN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=")
_WRAP = {"sudo", "time", "nohup", "nice", "env", "command", "exec", "timeout", "gtimeout"}


def shell_command(tc):
    if tc.get("function_name") not in SHELL_TOOLS:
        return None
    a = tc.get("arguments") or {}
    return str(a.get("command") or a.get("cmd") or "")


def pipeline_invocations(cmd):
    """Return the argument of every ./run_pipeline.sh invocation in a shell command."""
    import shlex
    out = []
    if not cmd or "run_pipeline" not in cmd:
        return out
    for seg in _SEG.split(cmd):
        try:
            toks = shlex.split(seg, posix=True)
        except ValueError:
            toks = seg.split()
        while toks and (_ASSIGN.match(toks[0]) or toks[0] in _WRAP or re.match(r"^-?\d+[smh]?$", toks[0])):
            toks.pop(0)
        if not toks:
            continue
        prog = toks[0].rsplit("/", 1)[-1]
        if prog in ("bash", "sh", "zsh") and len(toks) > 1:
            toks = toks[1:]
            prog = toks[0].rsplit("/", 1)[-1]
        if prog == "run_pipeline.sh":
            arg = toks[1] if len(toks) > 1 else ""
            arg = re.sub(r"[^\w].*$", "", arg)
            out.append(arg)
    return out


def instrument_invocation(cmd):
    return bool(cmd) and bool(re.search(r"\bam\s+instrument\b", cmd))


# ---------------------------------------------------------------- shell-side file writes
_W_PATTERNS = [
    ("sed_inplace", re.compile(r"\bsed\s+(?:-[a-zA-Z]*\s+)*-i")),
    ("perl_inplace", re.compile(r"\bperl\s+(?:-\w+\s+)*-p?i")),
    ("redirect_write", re.compile(r"(?<![0-9&])>{1,2}\s*(?!/dev/|&|/tmp/|\$TMPDIR)([\w./$~{}-]+\.(?:java|kt|xml|gradle|sh|properties|pro|kts|jar))")),
    ("tee_write", re.compile(r"\btee\s+(?:-a\s+)?(?!/dev/)([\w./$~{}-]+\.(?:java|kt|xml|gradle|sh|properties))")),
    ("python_write", re.compile(r"python3?\b[\s\S]*?(?:write_text|open\([^)]*['\"]w)")),
    ("git_apply", re.compile(r"\bgit\s+apply\b|\bpatch\s+-p\d")),
    ("git_revert_files", re.compile(r"\bgit\s+(?:checkout\s+(?:--\s+)?\S+|restore\b|stash\b|reset\s+--hard)")),
    ("cp_mv_into_src", re.compile(r"\b(?:cp|mv)\b[^\n;&|]*\s(\S*(?:src/|gradle/wrapper|reproducing_script_project|run_pipeline\.sh)\S*)\s*(?=$|[\n;&|])")),
]


def shell_writes(cmd):
    """Best-effort detection of a shell command that modifies files. Returns a list of
    (kind, segment) where segment is the shell segment (split on && || ; | newline) that
    performs the write, so the caller can classify which file class it touches."""
    out = []
    if not cmd:
        return out
    for seg in _SEG.split(cmd):
        for kind, rx in _W_PATTERNS:
            if kind == "python_write":
                continue
            if rx.search(seg):
                out.append((kind, seg.strip()[:200]))
    if _W_PATTERNS[4][1].search(cmd):
        out.append(("python_write", cmd[:400]))
    return out


_ORACLE = re.compile(r"reproducing_script_project/\S*androidTest/\S*\.java|\bScript\d+\w*\.java")
_TESTPROJ = re.compile(r"reproducing_script_project/")
_PROJ_TESTS = re.compile(r"/src/(?:test|androidTest)/")
_HARNESS_PATH = re.compile(r"run_pipeline\.sh")
_BUILD_PATH = re.compile(r"(build\.gradle|settings\.gradle|gradle-wrapper\.(?:jar|properties)|gradle\.properties|"
                         r"local\.properties)")

PATH_CLASSES = ("oracle_test", "harness_script", "test_project_config", "project_tests", "build_config", "app_code")


def classify_path(p):
    """oracle_test: the benchmark's bug-exposing UI test scripts (reproducing_script_project
    androidTest *.java); harness_script: run_pipeline.sh; test_project_config: anything else in
    reproducing_script_project; project_tests: the app's own unit/instrumented tests;
    build_config: gradle/local properties; app_code: everything else."""
    p = str(p)
    if _HARNESS_PATH.search(p) and not re.search(r"\bgit\s+diff", p):
        return "harness_script"
    if _ORACLE.search(p):
        return "oracle_test"
    if _TESTPROJ.search(p):
        return "test_project_config"
    if _PROJ_TESTS.search(p):
        return "project_tests"
    if _BUILD_PATH.search(p):
        return "build_config"
    return "app_code"


def norm_path(p):
    p = str(p).strip().strip("'\"")
    m = re.search(r"bug-\d+/(.*)$", p)
    return m.group(1) if m else p.lstrip("./")


EDIT_TOOLS = {"Edit", "MultiEdit", "Write", "NotebookEdit", "apply_patch", "replace", "write_file"}


def edit_targets(tc):
    """Files touched by a structured edit tool call -> list of (op, path)."""
    fn = tc.get("function_name")
    a = tc.get("arguments") or {}
    if fn in ("Edit", "MultiEdit", "replace"):
        return [("update", a.get("file_path", ""))]
    if fn in ("Write", "write_file"):
        return [("write", a.get("file_path", ""))]
    if fn == "NotebookEdit":
        return [("update", a.get("notebook_path", ""))]
    if fn == "apply_patch":
        txt = a.get("input") or a.get("patch") or ""
        return [(m.group(1).lower(), m.group(2).strip())
                for m in re.finditer(r"\*\*\* (Update|Add|Delete) File:\s*(.+)", txt)]
    return []
