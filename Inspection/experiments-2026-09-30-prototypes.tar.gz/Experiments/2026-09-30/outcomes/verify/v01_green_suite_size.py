"""Verify: do 'loose'/'strict' greens really require a 5/5 suite (as the report claims)?"""
import csv, collections
P = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes/out/05_proxy_outcome.csv"
rows = list(csv.DictReader(open(P)))
for ag in ("claude", "codex", "gemini"):
    rr = [r for r in rows if r["agent"] == ag]
    loose = [r for r in rr if r["P3_target_final"] == "PASS" and r["P4_suite_final"] == "PASS_ALL"]
    strict = [r for r in rr if r["strict_green"] == "True"]
    def sz(rs): return collections.Counter((r["P4_pass"], r["P4_fail"]) for r in rs)
    print(ag, "loose", len(loose), dict(sz(loose)), "| strict", len(strict), dict(sz(strict)))
    for r in strict:
        if r["P4_pass"] != "5":
            print("   strict-green with suite != 5/0:", ag, r["bug"], r["P4_pass"], r["P4_fail"])
    loose5 = [r for r in loose if r["P4_pass"] == "5" or (r["bug"] in ("",))]
    strict5 = [r for r in strict if r["P4_pass"] == "5"]
    print("   loose with 5/0:", len(loose5), " strict with 5/0:", len(strict5))
