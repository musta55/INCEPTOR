"""Scan every observation in which an agent READ a target oracle Script<bug>.java (any agent, before
any oracle edit) for a bare Java `assert` statement (disabled by default on Android ART, so it can
never fail) vs JUnit Assert.* / assertTrue / assertEquals / fail(."""
import re, sys, collections
EXP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes"
sys.path.insert(0, EXP); import common as C
RX_JAVA_ASSERT = re.compile(r"(?<![\w.])assert\s*\(|(?<![\w.])assert\s+[^;(]*;")
RX_JUNIT = re.compile(r"\b(assertTrue|assertFalse|assertEquals|assertNotNull|assertNull|assertThat|fail)\s*\(|Assert\.")
seen = {}
for bug in C.bug_ids():
    tgt = f"Script{bug}.java"
    for ag in C.AGENTS:
        for scope, step, tc, text, rs in C.iter_atif_calls(C.atif(bug, ag)):
            fn = tc.get("function_name"); args = str(tc.get("arguments"))
            if fn in C.EDIT_TOOLS and tgt in args: break           # stop at the first oracle edit
            if tgt in args and ("class Script" in text) and fn not in C.EDIT_TOOLS:
                if bug not in seen or len(text) > len(seen[bug][1]):
                    seen[bug] = (ag, text)
res = collections.Counter(); lst = []
for bug, (ag, text) in seen.items():
    ja = bool(RX_JAVA_ASSERT.search(text)); ju = bool(RX_JUNIT.search(text))
    res[(ja, ju)] += 1
    if ja: lst.append((bug, ag, ju, RX_JAVA_ASSERT.search(text).group(0)))
print("bugs whose pristine target oracle text was observed:", len(seen))
print("(has bare java assert, has junit assert/fail) :", dict(res))
print("bugs with a bare Java assert in the target oracle:", lst)
