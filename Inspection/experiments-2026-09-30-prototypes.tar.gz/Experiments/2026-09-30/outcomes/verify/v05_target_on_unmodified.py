"""For each bug: target-test verdicts observed on UNMODIFIED code (before the agent's first write of
any kind: structured edit, heredoc apply_patch, or shell write), per agent. Only verdicts from
test-executing / output-polling actions are used. Also lists the 6 bugs no agent saw failing."""
import re, sys, importlib.util, collections, csv
EXP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes"
sys.path.insert(0, EXP); import common as C
spec = importlib.util.spec_from_file_location("p05", EXP + "/05_proxy_outcome.py")
p05 = importlib.util.module_from_spec(spec); spec.loader.exec_module(p05)
EXEC = {"run_test", "wait_process", "build", "device_ops", "run_shell", "env_setup"}
res = {}
for bug in C.bug_ids():
    acts_all = C.actions(bug); tgt = f"Script{bug}"
    for ag in C.AGENTS:
        acts = sorted((a for a in acts_all if a["agent"] == ag), key=lambda a: int(a["action_index"]))
        idx = C.call_index(C.atif(bug, ag))
        pre = []; wrote = False
        for a in acts:
            tc, text, rs, st = idx.get(a["call_id"], (None, "", [], None))
            if tc is None: continue
            cmd = C.shell_command(tc) or ""
            if C.edit_targets(tc) or ("apply_patch" in cmd and "*** Begin Patch" in cmd) or \
               any(k != "git_revert_files" for k, _ in C.shell_writes(cmd)):
                wrote = True
            if wrote: break
            if a["mid_level"] not in EXEC: continue
            v = p05.parse_verdict(text, cmd)
            if v and tgt in v["tests"]:
                pre.append("P" if v["tests"][tgt] else "F")
        res[(bug, ag)] = "".join(pre)
rows = []
for bug in C.bug_ids():
    r = {ag: res[(bug, ag)] for ag in C.AGENTS}
    anyF = any("F" in s for s in r.values()); anyP = any("P" in s for s in r.values())
    rows.append((bug, r, anyF, anyP))
print("bugs with target seen FAILING on unmodified code by >=1 agent:", sum(1 for x in rows if x[2]))
print("bugs with target seen PASSING on unmodified code by >=1 agent:", sum(1 for x in rows if x[3]))
print("per agent: #traj with any pre-write target verdict / any F / any P:")
for ag in C.AGENTS:
    s = [res[(b, ag)] for b in C.bug_ids()]
    print("  ", ag, sum(1 for x in s if x), sum(1 for x in s if "F" in x), sum(1 for x in s if "P" in x))
print("bugs where target PASSED on unmodified code (verdict strings claude/codex/gemini):")
for bug, r, f, p in rows:
    if p: print("  ", bug, r)
print("bugs never seen failing on unmodified code by any agent:")
for bug, r, f, p in rows:
    if not f: print("  ", bug, r)
