"""Verify Fisher, McNemar and app-permutation statistics with scipy, from the experiment's CSVs."""
import csv, collections, random
from scipy.stats import fisher_exact, binomtest
E = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes/out/"
print("Fisher never-built-without-override [[13,17],[2,18]] greater:", fisher_exact([[13,17],[2,18]], alternative="greater"))
print("Fisher two-sided:", fisher_exact([[13,17],[2,18]]))
print("Fisher jdk error [[10,11],[5,24]] greater:", fisher_exact([[10,11],[5,24]], alternative="greater"))
for a,b in ((16,3),(17,2),(9,7)):
    print(f"McNemar exact {a} vs {b}:", binomtest(min(a,b), a+b, 0.5).pvalue)
# recompute from 08 labels
lab = list(csv.DictReader(open(E + "08_outcome_labels.csv")))
print("08 columns:", list(lab[0].keys())[:40])
