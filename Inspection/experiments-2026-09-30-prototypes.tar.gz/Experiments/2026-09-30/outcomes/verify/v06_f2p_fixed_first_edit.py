"""05 line 182 defines 'first edit' as the first mid_level=='edit_file' action, which misses Codex
`apply_patch <<'PATCH'` heredocs run via exec_command (labelled run_shell), although 05 itself counts
those as code changes for last_change. Re-run analyse() with first_edit including heredoc apply_patch
and recompute the 08 F2P numbers. Writes nothing outside verify/."""
import csv, sys, types
EXP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes"
sys.path.insert(0, EXP); import common as C
src = open(EXP + "/05_proxy_outcome.py").read()
old = 'first_edit = min([int(x["action_index"]) for x in acts if x["mid_level"] == "edit_file"] or [10 ** 9])'
new = ('first_edit = min([int(x["action_index"]) for x in acts if x["mid_level"] == "edit_file" or '
       '("apply_patch" in x["target"] and "*** Begin Patch" in x["target"])] or [10 ** 9])')
assert old in src
m = types.ModuleType("p05fix"); exec(compile(src.replace(old, new).replace('if __name__ == "__main__":', "if False:"), "p05fix", "exec"), m.__dict__)
lab = {(r["bug"], r["agent"]): r for r in csv.DictReader(open(EXP + "/out/08_outcome_labels.csv"))}
rep = {}
for bug in C.bug_ids():
    acts_all = C.actions(bug)
    for ag in C.AGENTS:
        acts = sorted((a for a in acts_all if a["agent"] == ag), key=lambda a: int(a["action_index"]))
        r = m.analyse(bug, ag, acts, C.atif(bug, ag), None)
        rep[(bug, ag)] = bool(r.get("P3_target_failed_before_first_change"))
bugs = C.bug_ids()
for ag in C.AGENTS:
    n = sum(rep[(b, ag)] for b in bugs)
    f2p = sum(1 for b in bugs if rep[(b, ag)] and lab[(b, ag)]["proxy_strict_green"] == "True")
    changed = [b for b in bugs if rep[(b, ag)] != (lab[(b, ag)]["reproduced_before_first_edit"] == "True")]
    print(f"{ag}: reproduced-before-first-edit={n}  F2P (reproduced & strict green)={f2p}  changed vs original: {changed}")
anyrep = [b for b in bugs if any(rep[(b, a)] for a in C.AGENTS)]
print("bugs seen failing on unmodified code by >=1 agent:", len(anyrep), " never:", [b for b in bugs if b not in anyrep])
print("claude strict-green bugs never seen failing by any agent:",
      [b for b in bugs if lab[(b, "claude")]["proxy_strict_green"] == "True" and b not in anyrep])
