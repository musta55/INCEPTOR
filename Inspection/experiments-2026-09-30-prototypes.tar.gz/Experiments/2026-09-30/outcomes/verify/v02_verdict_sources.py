"""Verify: which mid_levels do the parsed verdict observations come from, and does restricting
verdict parsing to test-executing / output-polling actions change the green labels?
Re-implements 05's analyse() by importing it and monkeypatching parse_verdict per action."""
import collections, csv, importlib.util, re, sys
EXP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes"
sys.path.insert(0, EXP)
import common as C
spec = importlib.util.spec_from_file_location("p05", EXP + "/05_proxy_outcome.py")
p05 = importlib.util.module_from_spec(spec); spec.loader.exec_module(p05)
orig = p05.parse_verdict

# 1) mid_level of every verdict-bearing observation and of the chosen P2 / P4 observation
src = collections.Counter(); chosen = collections.Counter()
rows05 = {(r["bug"], r["agent"]): r for r in csv.DictReader(open(EXP + "/out/05_proxy_outcome.csv"))}
EXEC_MIDS = {"run_test", "wait_process", "build", "device_ops", "run_shell", "env_setup"}
def is_exec(a, cmd):
    if a["mid_level"] in EXEC_MIDS: return True
    # reading a log file the agent itself wrote (cat /tmp/x.log) is legit output polling
    if a["mid_level"] == "read_file" and re.search(r"\.(log|txt|out)\b", cmd or a.get("target","")): return True
    return False
for bug in C.bug_ids():
    acts_all = C.actions(bug)
    for ag in C.AGENTS:
        acts = sorted((a for a in acts_all if a["agent"] == ag), key=lambda a: int(a["action_index"]))
        idx = C.call_index(C.atif(bug, ag))
        for a in acts:
            tc, text, rs, st = idx.get(a["call_id"], (None, "", [], None))
            if tc is None: continue
            v = orig(text, C.shell_command(tc) or "")
            if v: src[(ag, a["mid_level"], is_exec(a, C.shell_command(tc)))] += 1
print("verdict-bearing observations by (agent, mid_level, counted-as-exec):")
for k, n in sorted(src.items()): print("  ", k, n)

# 2) re-run analyse with verdicts only from exec-like actions
cur = {}
def patched_analyse(bug, agent, acts, traj, harness):
    idx = C.call_index(traj)
    allowed = set()
    for a in acts:
        tc = idx.get(a["call_id"], (None,))[0]
        if tc is not None and is_exec(a, C.shell_command(tc)): allowed.add(a["call_id"])
    def pv(text, cmd, _allowed=allowed):
        return orig(text, cmd) if cur["cid"] in _allowed else None
    p05.parse_verdict = pv
    # analyse iterates acts in order; wrap iteration to expose current call_id
    class It:
        def __iter__(self_):
            for a in acts:
                cur["cid"] = a["call_id"]; yield a
        def __len__(self_): return len(acts)
    return p05.analyse(bug, agent, It(), traj, harness)
res = []
for bug in C.bug_ids():
    acts_all = C.actions(bug); harness = C.codex_csv(bug)[0]
    for ag in C.AGENTS:
        acts = sorted((a for a in acts_all if a["agent"] == ag), key=lambda a: int(a["action_index"]))
        res.append(patched_analyse(bug, ag, acts, C.atif(bug, ag), harness if ag == "codex" else None))
def strict(r):
    g = r["P3_target_final"] == "PASS" and r["P4_suite_final"] == "PASS_ALL"
    clean = not (r.get("P3_oracle_dirty") or r.get("P4_oracle_dirty") or r.get("P3_harness_dirty") or r.get("P4_harness_dirty"))
    return g and clean and bool(r.get("P3_after_last_change")) and bool(r.get("P4_after_last_change"))
def strict5(r):
    return strict(r) and r.get("P4_pass") in (5, 3) and (r.get("P4_pass") == 5 or r["bug"] in THREE)
THREE = set()
print("\nre-computed with exec-only verdict parsing:")
for ag in C.AGENTS:
    rr = [r for r in res if r["agent"] == ag]
    s = [r for r in rr if strict(r)]
    loose = [r for r in rr if r["P3_target_final"] == "PASS" and r["P4_suite_final"] == "PASS_ALL"]
    repro = sum(1 for r in rr if r.get("P3_target_failed_before_first_change"))
    flips = [(r["bug"], rows05[(r["bug"], ag)]["strict_green"], strict(r)) for r in rr
             if (rows05[(r["bug"], ag)]["strict_green"] == "True") != strict(r)]
    p4 = collections.Counter((r.get("P4_pass"), r.get("P4_fail")) for r in s)
    print(f"  {ag}: loose={len(loose)} strict={len(s)} strict suite sizes={dict(p4)} reproduced-before-edit={repro}")
    print(f"     strict flips vs original: {flips}")
csv.writer(open(EXP + "/verify/v02_exec_only_strict.csv", "w")).writerows(
    [("bug", "agent", "strict_exec_only", "P4_pass", "P4_fail")] +
    [(r["bug"], r["agent"], strict(r), r.get("P4_pass"), r.get("P4_fail")) for r in res])
