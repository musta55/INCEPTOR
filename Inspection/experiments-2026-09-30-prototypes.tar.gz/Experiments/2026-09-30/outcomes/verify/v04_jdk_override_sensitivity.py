"""Sensitivity of 06's 'never built OK without a JDK override' to how 'override' is detected.
Variant A (06): RX_JDK_OVR anywhere in the command (includes JDK paths inside jenv-shim heredocs).
Variant B: only an explicit JAVA_HOME=/export JAVA_HOME / -Dorg.gradle.java.home / --java-home that is
           NOT inside a heredoc body (heredoc bodies stripped before matching)."""
import re, sys, importlib.util, collections
EXP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes"
sys.path.insert(0, EXP); import common as C
spec = importlib.util.spec_from_file_location("p06", EXP + "/06_codex_env_forensics.py")
p06 = importlib.util.module_from_spec(spec); spec.loader.exec_module(p06)
from scipy.stats import fisher_exact
HEREDOC = re.compile(r"<<-?\s*['\"]?(\w+)['\"]?\n.*?\n\1\b", re.S)
RX_B = re.compile(r"(\bJAVA_HOME=|export\s+JAVA_HOME|org\.gradle\.java\.home|--java-home|java_home\s+-v)")
tab = {"A": collections.Counter(), "B": collections.Counter()}
detail = []
for bug in C.bug_ids():
    h = C.codex_csv(bug)[0]; lab = "compile_fail" if h["compile_fail"] == "Yes" else "test_fail"
    acts = sorted((a for a in C.actions(bug) if a["agent"] == "codex"), key=lambda a: int(a["action_index"]))
    idx = C.call_index(C.atif(bug, "codex"))
    okA = okB = False; n_ok = 0
    for a in acts:
        tc, text, rs, st = idx.get(a["call_id"], (None, "", [], None))
        if tc is None: continue
        cmd = C.shell_command(tc) or ""
        is_app_build = bool(re.search(r"gradlew[^\n;&|]*\b(assembleDebug|assemble\b|build\b)", cmd)) and "reproducing_script_project" not in cmd.split("gradlew")[0][-80:]
        if not (is_app_build or C.pipeline_invocations(cmd)): continue
        if p06.outcome(text) != "ok": continue
        n_ok += 1
        if not p06.RX_JDK_OVR.search(cmd): okA = True
        if not RX_B.search(HEREDOC.sub("", cmd)): okB = True
    tab["A"][(lab, okA)] += 1; tab["B"][(lab, okB)] += 1
    detail.append((bug, lab, n_ok, okA, okB))
for v in ("A", "B"):
    t = tab[v]
    m = [[t[("compile_fail", False)], t[("test_fail", False)]], [t[("compile_fail", True)], t[("test_fail", True)]]]
    print(v, "never-built-OK-without-override (rows: never / did) x (compile_fail, test_fail):", m,
          "Fisher one-sided p=%.4f" % fisher_exact(m, alternative="greater")[1])
print("bugs where A and B disagree:", [(b, l, n, a, bb) for b, l, n, a, bb in detail if a != bb])
