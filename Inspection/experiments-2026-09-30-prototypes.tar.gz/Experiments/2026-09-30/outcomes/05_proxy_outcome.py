"""Step 5: a proxy outcome read from the trajectory itself, for all 150 trajectories.

For every action (chronological action_index, subagents spliced in) we take the FULL
observation from ATIF (not the 300-char preview) and parse any test verdict it contains:

  pipeline markers   '>>> ScriptX: PASSED|FAILED' and '=== Results: N passed, M failed ==='
  instrumentation    'OK (N tests)' / 'Tests run: N,  Failures: M'  (only used when no
                     pipeline markers are present, because run_pipeline.sh tees the
                     instrumentation output and would double count)

Proxies per trajectory:
  P1 last_run_test   verdict in the observation of the LAST action whose mid_level is
                     run_test (can be NO_VERDICT: backgrounded / output filtered / env error)
  P2 last_verdict    the LAST observation anywhere that contains a parseable verdict
                     (includes write_stdin / TaskOutput / cat of a log file)
  P3 target_final    status of the bug-exposing Script<id> the last time it was reported
  P4 suite_final     last verdict covering >=2 tests (the 'all' run)
plus: was the last verdict observed AFTER the last code change (else it is stale), and
did the agent modify test code / run_pipeline.sh / build config (tampering flags).

Then P2/P3 are cross-tabulated against the Codex harness verdict.
"""
import collections
import json
import re
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C

RX_TEST = re.compile(r">>> (Script\w+): (PASSED|FAILED)")
RX_RES = re.compile(r"=== Results: (\d+) passed, (\d+) failed ===")
RX_OK = re.compile(r"\bOK \((\d+) tests?\)")
RX_RUN = re.compile(r"Tests run: (\d+),\s+Failures: (\d+)")
RX_BUILD_FAIL = re.compile(r"(BUILD FAILED|FAILURE: Build failed|Compilation failed|compileDebugJavaWithJavac FAILED|"
                           r"error: cannot find symbol|Execution failed for task)")
RX_ENV = re.compile(r"(jenv: version|SandboxDenied|No connected Android device|"
                    r"(?<!tee: /dev/stderr: )Operation not permitted|Unable to locate a Java Runtime|"
                    r"JAVA_HOME is not set|Could not determine java version|Unsupported class file major version|"
                    r"requires Java \d+|INSTALL_FAILED)")
TAMPER_LOG = []
RX_CLASS = re.compile(r"-e\s+class\s+['\"]?edu\.sage\.android\.(Script\w+)")


def parse_verdict(text, cmd):
    """Return dict or None. keys: n_pass, n_fail, tests{name:bool}, source."""
    tests = {}
    for m in RX_TEST.finditer(text):
        tests[m.group(1)] = (m.group(2) == "PASSED")
    res = RX_RES.findall(text)
    if tests or res:
        if res:
            p, f = map(int, res[-1])
        else:
            p = sum(tests.values())
            f = len(tests) - p
        return {"n_pass": p, "n_fail": f, "tests": tests, "source": "pipeline"}
    oks = [int(x) for x in RX_OK.findall(text)]
    runs = [(int(a), int(b)) for a, b in RX_RUN.findall(text)]
    if oks or runs:
        p = sum(oks) + sum(a - b for a, b in runs)
        f = sum(b for a, b in runs)
        classes = RX_CLASS.findall(cmd or "")
        if len(classes) == 1 and len(oks) + len(runs) == 1:
            tests[classes[0]] = bool(oks)
        return {"n_pass": p, "n_fail": f, "tests": tests, "source": "instrument"}
    return None


def verdict_label(v):
    if v is None:
        return None
    if v["n_pass"] + v["n_fail"] == 0:
        return "EMPTY_RUN"
    if v["n_fail"] == 0:
        return "PASS_ALL"
    if v["n_pass"] == 0:
        return "FAIL_ALL"
    return "PARTIAL"


def no_verdict_reason(text):
    if not text.strip():
        return "NO_OUTPUT"
    if RX_BUILD_FAIL.search(text):
        return "BUILD_FAIL"
    if RX_ENV.search(text):
        return "ENV_FAIL"
    return "NO_VERDICT"


RX_GIT_RESTORE = re.compile(r"\bgit\s+(checkout|restore)\b(.*)")
RX_GIT_ALL = re.compile(r"\bgit\s+(?:stash\b(?!\s+(?:list|show))|reset\s+--hard|checkout\s+(?:--\s+)?\.(?:\s|$)|restore\s+(?:--\S+\s+)*\.(?:\s|$))")


def analyse(bug, agent, acts, traj, harness):
    idx = C.call_index(traj)
    target = f"Script{bug}"
    evs = []                 # (action_index, verdict dict, mid, label, dirty_snapshot)
    last_change = 0
    tamper = collections.Counter()
    dirty = {}               # norm path -> class, for oracle_test / harness_script / test_project_config
    run_tests = []
    for a in acts:
        ai = int(a["action_index"])
        tc, text, rs, step = idx.get(a["call_id"], (None, "", [], None))
        if tc is None:
            continue
        cmd = C.shell_command(tc) or ""
        # ---- code changes via structured edit tools (+ Codex `apply_patch <<'PATCH'` heredocs run via exec_command)
        tg = C.edit_targets(tc)
        if not tg and re.search(r"\bapply_patch\b", cmd) and "*** Begin Patch" in cmd:
            tg = [(m.group(1).lower(), m.group(2).strip())
                  for m in re.finditer(r"\*\*\* (Update|Add|Delete) File:\s*(.+)", cmd)]
        for op, path in tg:
            last_change = ai
            cls = C.classify_path(path)
            tamper[cls] += 1
            if cls in ("oracle_test", "harness_script", "test_project_config"):
                dirty[C.norm_path(path)] = cls
            if cls != "app_code":
                TAMPER_LOG.append({"bug": bug, "agent": agent, "action_index": ai, "via": tc["function_name"],
                                   "class": cls, "evidence": f"{op} {path}"})
        # ---- code changes / restores via shell
        for kind, frag in C.shell_writes(cmd):
            if kind == "git_revert_files":
                if RX_GIT_ALL.search(frag):
                    dirty.clear()
                else:
                    m = RX_GIT_RESTORE.search(frag)
                    toks = [t for t in (m.group(2).split() if m else []) if not t.startswith("-")]
                    for t in toks:
                        tn = C.norm_path(t)
                        for k in list(dirty):
                            if k.endswith(tn) or tn.endswith(k):
                                del dirty[k]
                TAMPER_LOG.append({"bug": bug, "agent": agent, "action_index": ai, "via": "shell:" + kind,
                                   "class": "restore", "evidence": frag.replace("\n", " ")[:200]})
                continue
            last_change = ai
            cls = C.classify_path(frag)
            tamper["shell:" + cls] += 1
            if cls in ("oracle_test", "harness_script", "test_project_config"):
                dirty["shell@%d:%s" % (ai, frag[:60])] = cls
            if cls != "app_code":
                TAMPER_LOG.append({"bug": bug, "agent": agent, "action_index": ai, "via": "shell:" + kind,
                                   "class": cls, "evidence": frag.replace("\n", " ")[:200]})
        v = parse_verdict(text, cmd)
        snap = collections.Counter(dirty.values())
        if v is not None:
            evs.append((ai, v, a["mid_level"], verdict_label(v), snap))
        if a["mid_level"] == "run_test":
            run_tests.append((ai, v, text))
    out = {"bug": bug, "agent": agent, "n_actions": len(acts), "n_run_test": len(run_tests),
           "n_verdict_obs": len(evs), "last_code_change_ai": last_change}
    # P1
    if run_tests:
        ai, v, text = run_tests[-1]
        out["P1_last_run_test_ai"] = ai
        out["P1_last_run_test"] = verdict_label(v) or no_verdict_reason(text)
    else:
        out["P1_last_run_test"] = "NO_TEST_RUN"
    # P2
    if evs:
        ai, v, mid, lab, snap = evs[-1]
        out.update(P2_last_verdict=lab, P2_ai=ai, P2_mid=mid, P2_pass=v["n_pass"], P2_fail=v["n_fail"],
                   P2_source=v["source"], P2_after_last_change=ai > last_change,
                   P2_oracle_dirty=snap["oracle_test"] > 0, P2_harness_dirty=snap["harness_script"] > 0)
    else:
        out.update(P2_last_verdict="NO_VERDICT_EVER", P2_after_last_change="")
    # P3 target
    tgt = [(ai, v["tests"][target], snap) for ai, v, mid, lab, snap in evs if target in v["tests"]]
    if tgt:
        out["P3_target_final"] = "PASS" if tgt[-1][1] else "FAIL"
        out["P3_ai"] = tgt[-1][0]
        out["P3_after_last_change"] = tgt[-1][0] > last_change
        out["P3_oracle_dirty"] = tgt[-1][2]["oracle_test"] > 0
        out["P3_harness_dirty"] = tgt[-1][2]["harness_script"] > 0
        out["P3_target_ever_failed"] = any(not ok for _, ok, _s in tgt)
        out["P3_target_ever_passed"] = any(ok for _, ok, _s in tgt)
        first_fail = next((ai for ai, ok, _s in tgt if not ok), None)
        first_edit = min([int(x["action_index"]) for x in acts if x["mid_level"] == "edit_file"] or [10 ** 9])
        out["P3_target_failed_before_first_change"] = bool(first_fail is not None and first_fail < first_edit)
    else:
        out["P3_target_final"] = "NEVER_REPORTED"
    # P4 suite
    suite = [(ai, v, snap) for ai, v, mid, lab, snap in evs if v["n_pass"] + v["n_fail"] >= 2]
    if suite:
        ai, v, snap = suite[-1]
        out.update(P4_suite_final=verdict_label(v), P4_pass=v["n_pass"], P4_fail=v["n_fail"],
                   P4_after_last_change=ai > last_change, P4_oracle_dirty=snap["oracle_test"] > 0,
                   P4_harness_dirty=snap["harness_script"] > 0)
    else:
        out["P4_suite_final"] = "NEVER_RUN"
    for cls in C.PATH_CLASSES:
        out["edits_" + cls] = tamper[cls] + tamper["shell:" + cls]
    out["dirty_at_end_oracle"] = sum(1 for c in dirty.values() if c == "oracle_test")
    out["dirty_at_end_harness"] = sum(1 for c in dirty.values() if c == "harness_script")
    out["n_structured_edits"] = sum(v for k, v in tamper.items() if not k.startswith("shell:"))
    out["n_shell_write_hits"] = sum(v for k, v in tamper.items() if k.startswith("shell:"))
    if harness:
        out["harness"] = ("pass" if harness["pass"] == "Yes" else
                          "compile_fail" if harness["compile_fail"] == "Yes" else
                          "test_fail" if harness["test_fail"] == "Yes" else "other")
    else:
        out["harness"] = ""
    return out


def main():
    rows = []
    for bug in C.bug_ids():
        acts_all = C.actions(bug)
        harness = C.codex_csv(bug)[0]
        for ag in C.AGENTS:
            acts = sorted((a for a in acts_all if a["agent"] == ag), key=lambda a: int(a["action_index"]))
            rows.append(analyse(bug, ag, acts, C.atif(bug, ag), harness if ag == "codex" else None))
    fields = sorted({k for r in rows for k in r}, key=lambda k: (k not in ("bug", "agent"), k))
    C.write_csv(C.OUT / "05_proxy_outcome.csv", rows, fields)
    C.write_csv(C.OUT / "05_tamper_evidence.csv", TAMPER_LOG)

    for ag in C.AGENTS:
        rr = [r for r in rows if r["agent"] == ag]
        n = len(rr)
        print(f"\n===== {ag} (n={n})")
        print("  P1 last run_test action verdict:", dict(collections.Counter(r["P1_last_run_test"] for r in rr)))
        print("  P2 last verdict anywhere:", dict(collections.Counter(r["P2_last_verdict"] for r in rr)))
        print("     ... observed after last code change:",
              dict(collections.Counter(r["P2_after_last_change"] for r in rr)))
        print("     ... source:", dict(collections.Counter(r.get("P2_source") for r in rr)))
        print("  P3 target test final status:", dict(collections.Counter(r["P3_target_final"] for r in rr)))
        print("     ... target ever FAILED in trajectory:", sum(1 for r in rr if r.get("P3_target_ever_failed")),
              "| ever PASSED:", sum(1 for r in rr if r.get("P3_target_ever_passed")))
        print("     ... target failed at least once before first edit (reproduced):",
              sum(1 for r in rr if r.get("P3_target_failed_before_first_change")))
        print("  P4 suite final:", dict(collections.Counter(r["P4_suite_final"] for r in rr)))
        green = [r for r in rr if r["P3_target_final"] == "PASS" and r["P4_suite_final"] == "PASS_ALL"]
        print(f"  GREEN (target PASS and last suite PASS_ALL): {len(green)}/{n}; "
              f"of which both after last code change: "
              f"{sum(1 for r in green if r.get('P3_after_last_change') and r.get('P4_after_last_change'))}")
        print("  trajectories that modified:", {cls: sum(1 for r in rr if r["edits_" + cls]) for cls in C.PATH_CLASSES})
        print("  oracle test / run_pipeline.sh still modified at end of run:",
              sum(1 for r in rr if r["dirty_at_end_oracle"]), "/", sum(1 for r in rr if r["dirty_at_end_harness"]))
        green_clean = [r for r in green if not r.get("P3_oracle_dirty") and not r.get("P4_oracle_dirty")
                       and not r.get("P3_harness_dirty") and not r.get("P4_harness_dirty")]
        print(f"  GREEN with oracle test AND run_pipeline.sh unmodified at the time of the green runs: {len(green_clean)}/{n}")
        green_strict = [r for r in green_clean if r.get("P3_after_last_change") and r.get("P4_after_last_change")]
        print(f"  ... and both green runs after the last code change (STRICT GREEN): {len(green_strict)}/{n}")
        for r in rr:
            r["strict_green"] = r in green_strict

    cx = [r for r in rows if r["agent"] == "codex"]
    print("\n===== Codex proxy vs harness verdict")
    tab = collections.Counter((r["harness"], r["P3_target_final"], r["P4_suite_final"]) for r in cx)
    for k, v in sorted(tab.items()):
        print(f"  harness={k[0]:12s} target={k[1]:15s} suite={k[2]:10s}: {v}")
    g = [r for r in cx if r["P3_target_final"] == "PASS" and r["P4_suite_final"] == "PASS_ALL"]
    print(f"  proxy GREEN while harness != pass: {sum(1 for r in g if r['harness'] != 'pass')}/{len(g)} green; "
          f"harness pass count = {sum(1 for r in cx if r['harness'] == 'pass')}")
    tp = [r for r in cx if r["P3_target_final"] == "PASS"]
    print(f"  target PASS in-trajectory while harness != pass: {sum(1 for r in tp if r['harness'] != 'pass')}/{len(tp)}")
    for lab in ("compile_fail", "test_fail"):
        sub = [r for r in cx if r["harness"] == lab]
        print(f"  harness={lab}: n={len(sub)}  P2 last verdict: {dict(collections.Counter(r['P2_last_verdict'] for r in sub))}"
              f"  strict green: {sum(1 for r in sub if r['strict_green'])}"
              f"  build-config edits: {sum(1 for r in sub if r['edits_build_config'])}")
    C.write_csv(C.OUT / "05_proxy_outcome.csv", rows, fields + ["strict_green"])


if __name__ == "__main__":
    main()
