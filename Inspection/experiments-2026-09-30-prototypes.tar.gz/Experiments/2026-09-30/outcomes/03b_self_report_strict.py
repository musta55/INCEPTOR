"""Step 3/4 (stricter): classify each agent's FINAL natural-language report by what it claims
about testing. The loose classifier in common.classify_self_report counts 'Build successful'
as a pass claim; this one separates build-only, target-only, suite, failure and env claims.

Final text per agent:
  claude  ResultMessage.result (raw SDK dump)
  codex   task_complete.last_agent_message (raw rollout)
  gemini  concatenated assistant deltas after the last tool call (raw stream-json)

Labels (first match wins, in this order):
  reports_failure    explicitly reports a failing/unvalidated test (N passed, M>0 failed; 'still fails';
                     'could not validate'; 'flaky'; 'fails in this environment'; red cross)
  claims_suite_pass  claims the full suite / all N tests pass
  claims_target_pass claims the bug-exposing test passes, no suite claim
  claims_unit_tests  claims only (unit) tests of the app pass, not the Script* UI suite
  claims_build_only  claims a successful build / compile, no test claim
  no_test_claim      describes the change, no verification claim
  empty
Also flags 'mentions_env_workaround' (shim / sandbox / env override / jenv / equivalent manual steps)
and 'mentions_test_edit' (says it changed the reproduction scripts / tests).
Outputs out/03b_self_report_strict.csv and a printed per-agent table plus the evidence per row.
"""
import collections
import re
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C

F = re.I | re.S
R_FAIL = [
    r"\b\d+ passed, [1-9]\d* failed", r"\bpass=\d+ fail=[1-9]", r"still (?:has )?(?:one |an? )?(?:unstable )?(?:fail|failing)",
    r"(?<!hard-)fail(?:ed|s)? in this (?:environment|sandbox|emulator)", r"could not (?:be )?(?:fully )?(?:validat|verif|get a clean pass)",
    r"\bflaky\b", r"❌", r"all tests failed", r"not (?:be )?(?:fully )?validated", r"unable to (?:run|verify|validate)",
    r"(?:test|suite|script)\S* (?:still )?fails\b", r"except the flaky", r"\bFAIL\*\*",
]
R_SUITE = [
    r"all (?:\d+ )?(?:of the )?(?:tests?|test cases?|scripts?)(?: \w+){0,3} (?:now )?pass", r"\b(?:[2-9]|\d{2,}) passed, 0 failed", r"\bpass=\d+ fail=0",
    r"OK \([2-9] tests\)", r"(?:full|entire|whole) (?:test )?suite[^.\n]{0,80}?pass", r"all other tests[^.\n]{0,40}pass",
    r"run_pipeline\.sh all[^\n]{0,80}pass", r"(?:all|every) (?:\w+ ){0,3}tests? (?:\w+ ){0,3}pass(?:ed|es)? successfully",
    r"test suite[^.\n]{0,40}(?:passes|passed|pass\b)", r"no regressions", r"tests? passed(?:,| and)? including",
]
R_TARGET = [r"Script\d+\w*`?\)?[^\n]{0,60}?(?:pass|OK \(1 test\))", r"bug-exposing test[^\n]{0,60}?pass",
            r"reproduc\w+ (?:test|script)[^\n]{0,80}?pass", r"\b1 passed, 0 failed", r"OK \(1 test\)"]
R_UNIT = [r"unit tests? pass"]
R_BUILD = [r"build (?:succeeds|succeeded|successful|passed|passes)", r"BUILD SUCCESSFUL", r"compiles? (?:successfully|without errors)",
           r"verified (?:for|by) compil"]
R_ENV = r"(shim|sandbox|env(?:ironment)? overrides?|jenv|equivalent (?:manual )?(?:build|steps|instrumentation)|in this environment|GRADLE_USER_HOME|JAVA_HOME|Java \d+)"
R_TESTEDIT = r"(updated|modified|changed|made)[^.\n]{0,60}(Script\d+\w*\.java|test(?:ing)? scripts?|instrumentation tests|reproduction test case|reproducing_script_project)"


def first(pats, t):
    for p in pats:
        m = re.search(p, t, F)
        if m:
            return m.group(0)
    return None


def classify(t):
    if not t or not t.strip():
        return "empty", ""
    for lab, pats in (("reports_failure", R_FAIL), ("claims_suite_pass", R_SUITE), ("claims_target_pass", R_TARGET),
                      ("claims_unit_tests", R_UNIT), ("claims_build_only", R_BUILD)):
        ev = first(pats, t)
        if ev:
            return lab, ev
    return "no_test_claim", ""


def gemini_text(bug):
    evs, _ = C.gemini_events(bug)
    last_tool = max((i for i, e in enumerate(evs) if e.get("type") in ("tool_use", "tool_result")), default=-1)
    return "".join(e.get("content", "") for e in evs[last_tool + 1:] if e.get("type") == "message" and e.get("role") == "assistant")


def claude_text(bug):
    res = [m for m in C.claude_messages(bug) if m.get("__type__") == "ResultMessage"]
    return (res[-1].get("result") or "") if res else ""


def codex_text(bug):
    rows = C.codex_rows(C.codex_rollouts(bug)[0])
    tc = [x["payload"] for x in rows if x.get("payload", {}).get("type") == "task_complete"]
    return (tc[-1].get("last_agent_message") or "") if tc else ""


def main():
    rows = []
    for bug in C.bug_ids():
        for ag, fn in (("claude", claude_text), ("codex", codex_text), ("gemini", gemini_text)):
            t = fn(bug)
            lab, ev = classify(t)
            rows.append({"bug": bug, "agent": ag, "self_report": lab, "evidence": ev.replace("\n", " ")[:160],
                         "mentions_env_workaround": bool(re.search(R_ENV, t, F)),
                         "mentions_test_edit": bool(re.search(R_TESTEDIT, t, F)), "chars": len(t)})
    C.write_csv(C.OUT / "03b_self_report_strict.csv", rows)
    labs = ["claims_suite_pass", "claims_target_pass", "claims_unit_tests", "claims_build_only", "reports_failure",
            "no_test_claim", "empty"]
    print(f"{'label':20s} " + " ".join(f"{a:>7s}" for a in C.AGENTS))
    for l in labs:
        print(f"{l:20s} " + " ".join(f"{sum(1 for r in rows if r['agent'] == a and r['self_report'] == l):7d}" for a in C.AGENTS))
    for k in ("mentions_env_workaround", "mentions_test_edit"):
        print(f"{k:20s} " + " ".join(f"{sum(1 for r in rows if r['agent'] == a and r[k]):7d}" for a in C.AGENTS))
    print("\nper-row evidence (for manual review):")
    for r in rows:
        print(f"  {r['agent']:6s} {r['bug']:>6s} {r['self_report']:18s} env={int(r['mentions_env_workaround'])} "
              f"testedit={int(r['mentions_test_edit'])} | {r['evidence'][:110]}")


if __name__ == "__main__":
    main()
