"""Step 5b: is the Codex harness verdict about the PATCH or about the MACHINE?

Codex ran on a different machine (/Users/sagelab/...) than Claude (/Volumes/Dumpy) and
Gemini (/Users/jingjingwu). run_pipeline.sh does `set -e` and `jenv local 11`. For every Codex
build/test command we record the command's env overrides and the observed outcome/signature,
then relate them to the harness label (compile_fail vs test_fail).

Questions:
  Q1 does `jenv local 11` fail on the Codex machine (=> an unshimmed run_pipeline.sh exits
     before printing '=== Results', which would give failed_tests='' and all_test_results=0)?
  Q2 does the UNMODIFIED repo (builds before the first edit) fail with a JDK-version error?
  Q3 did Codex's last successful app build need a JDK override (JAVA_HOME etc.)?
  Q4 does compile_fail cluster by app (environmental) rather than by patch?
Outputs out/06_codex_env_forensics.csv and printed tables.
"""
import collections
import re
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C

RX_JDK_OVR = re.compile(r"(JAVA_HOME|java\.home|java_home|/Library/Java/JavaVirtualMachines|openjdk@|jdk-?\d|temurin|zulu)", re.I)
RX_ENV_OVR = re.compile(r"(GRADLE_USER_HOME|ANDROID_SDK_HOME|ANDROID_USER_HOME|ANDROID_PREFS_ROOT|-Duser\.home|HOME=|"
                        r"PATH=[^ ]*(?:fakebin|\.bin|shim|bin)|jenv\(\)|function jenv|tee\(\))")
SIG = [
    ("jdk_version", re.compile(r"(Unsupported class file major version|Unsupported Java|requires Java \d+|"
                               r"incompatible with the Java|Could not determine java version|"
                               r"Android Gradle plugin requires Java|class file has wrong version|"
                               r"invalid source release|release version \d+ not supported|"
                               r"Unable to locate a Java Runtime|JAVA_HOME is set to an invalid)", re.I)),
    ("jenv", re.compile(r"jenv: version .11. not installed")),
    ("sandbox", re.compile(r"(SandboxDenied|(?<!tee: /dev/stderr: )Operation not permitted)")),
    ("compile_error", re.compile(r"(\.java:\d+: error:|\.kt: \(\d+|error: cannot find symbol|compileDebugJavaWithJavac FAILED|"
                                 r"Compilation failed; see the compiler error output|compileDebugKotlin FAILED)")),
    ("network", re.compile(r"(Could not resolve|Could not GET|UnknownHostException|Could not download)")),
]


def signature(text):
    for name, rx in SIG:
        if rx.search(text):
            return name
    return "other"


def outcome(text):
    if "BUILD SUCCESSFUL" in text and "BUILD FAILED" not in text:
        return "ok"
    if re.search(r"(BUILD FAILED|FAILURE: Build failed|SandboxDenied|jenv: version)", text):
        return "fail"
    return "unknown"


def app_of(bug):
    p = open(C.EXP / "prompts" / f"codex_{bug}.txt").read()
    m = re.search(r"File path: (\S+)", p)
    path = m.group(1) if m else ""
    m2 = re.search(r"/(?:java|kotlin)/(.+)$", path)
    comps = m2.group(1).split("/")[:-1] if m2 else []
    # first TWO package components identify the app (io.pslab.activity / io.pslab.fragment are one app)
    pkg = ".".join(comps[:2]) if comps else path.split("/")[0]
    return pkg


def main():
    rows = []
    for bug in C.bug_ids():
        h = C.codex_csv(bug)[0]
        harness = "compile_fail" if h["compile_fail"] == "Yes" else "test_fail" if h["test_fail"] == "Yes" else "pass"
        acts = sorted((a for a in C.actions(bug) if a["agent"] == "codex"), key=lambda a: int(a["action_index"]))
        idx = C.call_index(C.atif(bug, "codex"))
        first_edit = min([int(a["action_index"]) for a in acts if a["mid_level"] == "edit_file"] or [10 ** 9])
        builds = []   # (ai, kind, jdk_ovr, env_ovr, outcome, sig)
        jenv_hit = False
        for a in acts:
            tc, text, rs, step = idx.get(a["call_id"], (None, "", [], None))
            if tc is None:
                continue
            cmd = C.shell_command(tc) or ""
            if re.search(r"jenv: version .11. not installed", text):
                jenv_hit = True
            is_app_build = bool(re.search(r"gradlew[^\n;&|]*\b(assembleDebug|assemble\b|build\b)", cmd)) and "reproducing_script_project" not in cmd.split("gradlew")[0][-80:]
            is_pipe = bool(C.pipeline_invocations(cmd))
            if not (is_app_build or is_pipe):
                continue
            kind = "pipeline" if is_pipe else "gradle"
            o = outcome(text)
            builds.append((int(a["action_index"]), kind, bool(RX_JDK_OVR.search(cmd)), bool(RX_ENV_OVR.search(cmd)),
                           o, signature(text) if o != "ok" else "", "clean" in cmd))
        pre = [b for b in builds if b[0] < first_edit]
        gradle_pre = [b for b in pre if b[1] == "gradle"]
        ok_builds = [b for b in builds if b[4] == "ok"]
        r = {"bug": bug, "app": app_of(bug), "harness": harness, "n_build_or_pipeline_cmds": len(builds),
             "jenv11_error_seen": jenv_hit,
             "pre_edit_cmds": len(pre),
             "pre_edit_any_jdk_version_error": any(b[5] == "jdk_version" for b in pre),
             "pre_edit_first_gradle_outcome": gradle_pre[0][4] if gradle_pre else "none",
             "pre_edit_first_gradle_sig": gradle_pre[0][5] if gradle_pre else "",
             "pre_edit_first_gradle_jdk_override": gradle_pre[0][2] if gradle_pre else "",
             "any_jdk_version_error": any(b[5] == "jdk_version" for b in builds),
             "any_compile_error": any(b[5] == "compile_error" for b in builds),
             "any_ok_build": bool(ok_builds),
             "any_ok_build_without_jdk_override": any(not b[2] for b in ok_builds),
             "last_ok_build_jdk_override": ok_builds[-1][2] if ok_builds else "",
             "last_ok_build_env_override": ok_builds[-1][3] if ok_builds else "",
             "last_cmd_outcome": builds[-1][4] if builds else "", "last_cmd_sig": builds[-1][5] if builds else ""}
        rows.append(r)
    C.write_csv(C.OUT / "06_codex_env_forensics.csv", rows)

    def tab(key):
        print(f"\n{key}:")
        for lab in ("compile_fail", "test_fail"):
            sub = [r for r in rows if r["harness"] == lab]
            print(f"   {lab:12s} n={len(sub):2d}  {dict(collections.Counter(str(r[key]) for r in sub))}")

    print("Codex bugs:", len(rows))
    for k in ("jenv11_error_seen", "pre_edit_any_jdk_version_error", "pre_edit_first_gradle_outcome",
              "pre_edit_first_gradle_sig", "any_jdk_version_error", "any_compile_error", "any_ok_build",
              "any_ok_build_without_jdk_override", "last_ok_build_jdk_override", "last_cmd_outcome"):
        tab(k)
    print("\nharness label by app (app = Java package of the first Good-Starting-Point file):")
    by = collections.defaultdict(collections.Counter)
    for r in rows:
        by[r["app"]][r["harness"]] += 1
    mixed = 0
    for app, c in sorted(by.items(), key=lambda kv: -sum(kv[1].values())):
        print(f"   {app:40s} {dict(c)}")
        mixed += len(c) > 1
    print(f"apps: {len(by)}; apps with BOTH labels: {mixed}; single-bug apps: {sum(1 for c in by.values() if sum(c.values()) == 1)}")
    # 2x2: jdk-version error anywhere vs compile_fail
    a = sum(1 for r in rows if r["any_jdk_version_error"] and r["harness"] == "compile_fail")
    b = sum(1 for r in rows if r["any_jdk_version_error"] and r["harness"] == "test_fail")
    c = sum(1 for r in rows if not r["any_jdk_version_error"] and r["harness"] == "compile_fail")
    d = sum(1 for r in rows if not r["any_jdk_version_error"] and r["harness"] == "test_fail")
    print(f"\n2x2 JDK-version error seen by Codex (rows) x harness (cols compile_fail, test_fail): yes=[{a},{b}] no=[{c},{d}]")
    try:
        from math import comb
        # one-sided Fisher exact p for association (hypergeometric tail)
        n1, n2, k = a + b, c + d, a + c
        N = n1 + n2
        p = sum(comb(n1, x) * comb(n2, k - x) for x in range(a, min(n1, k) + 1)) / comb(N, k)
        print(f"   Fisher exact one-sided p = {p:.2e}")
    except Exception as e:
        print("fisher failed", e)

    def fisher_one_sided(a, b, c, d):
        from math import comb
        n1, n2, k = a + b, c + d, a + c
        return sum(comb(n1, x) * comb(n2, k - x) for x in range(a, min(n1, k) + 1)) / comb(n1 + n2, k)

    a = sum(1 for r in rows if not r["any_ok_build_without_jdk_override"] and r["harness"] == "compile_fail")
    b = sum(1 for r in rows if not r["any_ok_build_without_jdk_override"] and r["harness"] == "test_fail")
    c = sum(1 for r in rows if r["any_ok_build_without_jdk_override"] and r["harness"] == "compile_fail")
    d = sum(1 for r in rows if r["any_ok_build_without_jdk_override"] and r["harness"] == "test_fail")
    print(f"2x2 'never built OK without a JDK override' x harness (compile_fail, test_fail): yes=[{a},{b}] no=[{c},{d}]  "
          f"Fisher one-sided p = {fisher_one_sided(a, b, c, d):.2e}")

    # permutation test: is compile_fail more app-clustered than chance?
    import random
    random.seed(0)
    apps = [r["app"] for r in rows]
    labs = [r["harness"] for r in rows]

    def n_mixed(lbls):
        g = collections.defaultdict(set)
        for ap, l in zip(apps, lbls):
            g[ap].add(l)
        return sum(1 for v in g.values() if len(v) > 1)

    obs = n_mixed(labs)
    multi = sum(1 for ap in set(apps) if apps.count(ap) > 1)
    perm = []
    for _ in range(20000):
        sh = labs[:]
        random.shuffle(sh)
        perm.append(n_mixed(sh))
    p = sum(1 for x in perm if x <= obs) / len(perm)
    print(f"apps with >=2 bugs: {multi}; observed mixed-label apps: {obs}; permutation mean {sum(perm)/len(perm):.2f}; "
          f"P(mixed <= observed) = {p:.4f} (20000 shuffles)")


if __name__ == "__main__":
    main()


# ---------------------------------------------------------------------------------------------
# Q1b: can an UNSHIMMED ./run_pipeline.sh ever reach '=== Results' on each agent's machine?
# A pipeline call counts as shimmed if the same command (or an earlier command in the session,
# via exported PATH / function) provides a fake `jenv`. We are conservative: any call whose command
# text mentions jenv / fakebin / shim / a PATH override / 'function' is 'shimmed_or_modified'.
RX_SHIM = re.compile(r"(jenv|fakebin|shim|PATH=|export PATH|\(\)\s*\{|function\s+\w+|tee\(\)|\.bin)")


def pipeline_reach():
    """Per pipeline call: its full output = own observation + later write_stdin polls of the same
    session (Codex backgrounds long commands: 'Process running with session ID N')."""
    out = {}
    for ag in C.AGENTS:
        c_cmd = collections.Counter()      # shim judged from this command's text only
        c_carry = collections.Counter()    # shim also inherited from any earlier shim-creating command
        bugs_plain_cmd, bugs_plain_carry = set(), set()
        for bug in C.bug_ids():
            acts = sorted((a for a in C.actions(bug) if a["agent"] == ag), key=lambda a: int(a["action_index"]))
            idx = C.call_index(C.atif(bug, ag))
            seq = [(idx.get(a["call_id"], (None, "", [], None))[0], idx.get(a["call_id"], (None, "", [], None))[1]) for a in acts]
            shim_seen = False
            for i, (tc, text) in enumerate(seq):
                if tc is None:
                    continue
                cmd = C.shell_command(tc) or ""
                if not C.pipeline_invocations(cmd):
                    if RX_SHIM.search(cmd):
                        shim_seen = True
                    continue
                full = text
                m = re.search(r"Process running with session ID (\d+)", text)
                if m:
                    sid = int(m.group(1))
                    for tc2, text2 in seq[i + 1:]:
                        if tc2 is not None and tc2.get("function_name") == "write_stdin" and \
                                int((tc2.get("arguments") or {}).get("session_id", -1)) == sid:
                            full += "\n" + text2
                            if "Process exited" in text2:
                                break
                reached = "=== Results:" in full
                jenv_fail = bool(re.search(r"jenv: version .11. not installed", full))
                sandbox = "SandboxDenied" in full
                res = "results" if reached else ("jenv_fail" if jenv_fail else ("sandbox" if sandbox else "no_results"))
                own = bool(RX_SHIM.search(cmd))
                c_cmd[("shimmed" if own else "plain", res)] += 1
                c_carry[("shimmed" if (own or shim_seen) else "plain", res)] += 1
                if reached and not own:
                    bugs_plain_cmd.add(bug)
                if reached and not (own or shim_seen):
                    bugs_plain_carry.add(bug)
                if own:
                    shim_seen = True
        out[ag] = (c_cmd, c_carry, bugs_plain_cmd, bugs_plain_carry)
    return out


if __name__ == "__main__":
    print("\nQ1b pipeline calls by (shim status, outcome) per agent; 'plain' = no jenv/PATH/function shim in this or an earlier command:")
    for ag, (c1, c2, b1, b2) in pipeline_reach().items():
        print(f"   {ag}: shim judged per command : {dict(sorted(c1.items()))}")
        print(f"   {ag}: shim inherited (strict) : {dict(sorted(c2.items()))}")
        print(f"      bugs where a run_pipeline.sh with no shim in its own command reached '=== Results': {len(b1)}/50; "
              f"with no shim anywhere earlier either: {len(b2)}/50")
