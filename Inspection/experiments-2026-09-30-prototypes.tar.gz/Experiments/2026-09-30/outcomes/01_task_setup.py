"""Step 1: what were the agents told, and under what configuration?

For every bug:
  * Codex prompt (rollout user_message) and Gemini prompt (stream-json role=user message);
    are they byte-identical?  Which sections does the prompt carry?
  * Claude has no prompt in its log; collect indirect evidence that it received the same
    prompt (first actions open the 'Good Starting Points' files; it invokes
    ./run_pipeline.sh Script<id>; it reads reproducing_script_project/ first).
  * Codex run configuration (sandbox, approval, model, reasoning effort), Claude init
    (model, permissionMode, cwd root), Gemini init (model).
  * How often each agent's own runs of ./run_pipeline.sh hit the environment
    (sandbox denials, no device) -- this is setup, not agent skill.
"""
import collections
import json
import re
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C

SECTIONS = ["## Bug Description", "## Final Output", "## Success Criteria", "## Test Location",
            "## Building the Project and Running Test Cases", "## Good Starting Points"]
LIMIT_WORDS = re.compile(r"(time limit|timeout|minutes|turn limit|max(?:imum)? (?:turns|steps)|budget)",
                         re.I)


def prompt_facts(p):
    d = {s: (s in p) for s in SECTIONS}
    m = re.search(r"\./run_pipeline\.sh (Script\w+)", p)
    d["target_script"] = m.group(1) if m else ""
    sp = p.split("## Good Starting Points", 1)[1] if "## Good Starting Points" in p else ""
    d["n_start_files"] = len(re.findall(r"File path:", sp))
    d["n_start_methods"] = len(re.findall(r"Method name:", sp))
    d["start_files"] = re.findall(r"File path:\s*(\S+)", sp)
    d["mentions_limit"] = bool(LIMIT_WORDS.search(p))
    d["says_one_failing_test"] = "one failing test case" in p
    d["len"] = len(p)
    return d


def main():
    rows = []
    agg = collections.Counter()
    codex_cfg = collections.Counter()
    claude_cfg = collections.Counter()
    gemini_cfg = collections.Counter()
    template_variants = collections.Counter()
    for bug in C.bug_ids():
        r = {"bug": bug}
        # ---- Codex
        rolls = C.codex_rollouts(bug)
        r["codex_rollouts"] = len(rolls)
        crow = C.codex_rows(rolls[0])
        cp = C.codex_task_prompt(crow)
        meta = next((x["payload"] for x in crow if x.get("type") == "session_meta"), {})
        tc = next((x["payload"] for x in crow if x.get("type") == "turn_context"), {})
        codex_cfg[("model", tc.get("model"))] += 1
        codex_cfg[("sandbox", (tc.get("sandbox_policy") or {}).get("type"))] += 1
        codex_cfg[("network", (tc.get("sandbox_policy") or {}).get("network_access"))] += 1
        codex_cfg[("approval", tc.get("approval_policy"))] += 1
        codex_cfg[("reasoning_effort", (tc.get("collaboration_mode") or {}).get("settings", {}).get("reasoning_effort"))] += 1
        codex_cfg[("cli", meta.get("cli_version"))] += 1
        codex_cfg[("originator", meta.get("originator"))] += 1
        n_user_msgs = sum(1 for x in crow if x.get("payload", {}).get("type") == "user_message")
        r["codex_user_messages"] = n_user_msgs
        agg[("codex_user_messages", n_user_msgs)] += 1
        # ---- Gemini
        evs, _ = C.gemini_events(bug)
        gp_list = [e.get("content", "") for e in evs if e.get("type") == "message" and e.get("role") == "user"]
        gp = gp_list[0] if gp_list else ""
        r["gemini_user_messages"] = len(gp_list)
        init = next((e for e in evs if e.get("type") == "init"), {})
        gemini_cfg[("model", init.get("model"))] += 1
        # ---- compare prompts
        r["prompts_identical"] = (cp.strip() == gp.strip()) and bool(cp)
        if not r["prompts_identical"]:
            # locate first difference
            a, b = cp.strip(), gp.strip()
            i = next((k for k in range(min(len(a), len(b))) if a[k] != b[k]), min(len(a), len(b)))
            r["first_diff_at"] = i
            r["diff_codex"] = a[max(0, i - 40): i + 80]
            r["diff_gemini"] = b[max(0, i - 40): i + 80]
        f = prompt_facts(cp or gp)
        for k, v in f.items():
            if k != "start_files":
                r["p_" + k] = v
        # template = prompt with bug-specific parts removed
        tmpl = re.sub(r"## Bug Description:.*?You are currently located", "<BUG>You are currently located",
                      cp, flags=re.S)
        tmpl = re.sub(r"## Good Starting Points.*", "<STARTPOINTS>", tmpl, flags=re.S)
        tmpl = re.sub(r"Script\w+", "<SCRIPT>", tmpl)
        template_variants[tmpl] += 1
        # ---- Claude evidence
        msgs = C.claude_messages(bug)
        init = next((m for m in msgs if m.get("__type__") == "SystemMessage" and m.get("subtype") == "init"), {})
        data = init.get("data", {}) if isinstance(init.get("data"), dict) else {}
        claude_cfg[("model", data.get("model"))] += 1
        claude_cfg[("permissionMode", data.get("permissionMode"))] += 1
        claude_cfg[("version", data.get("claude_code_version"))] += 1
        cwd = data.get("cwd", "")
        claude_cfg[("cwd_root", re.sub(r"bug-\d+$", "", cwd))] += 1
        r["claude_cwd"] = cwd
        acts = C.actions(bug)
        ca = [a for a in acts if a["agent"] == "claude" and a["scope"] == "main"]
        first5 = " ".join(a["target"] for a in ca[:5])
        start_basenames = [s.rsplit("/", 1)[-1] for s in f["start_files"]]
        r["claude_first5_hits_startpoint"] = any(b and b in first5 for b in start_basenames)
        r["claude_first5_hits_testdir"] = "reproducing_script_project" in first5 or "androidTest" in first5
        r["claude_first5_home_user_paths"] = "/home/user/" in first5
        allc = [a for a in acts if a["agent"] == "claude"]
        thoughts = " ".join(a["thought_preview"] for a in allc[:10])
        r["claude_early_thought_mentions_startpoint"] = any(b and b.replace(".java", "") in thoughts
                                                             for b in start_basenames)
        for ag in ("codex", "gemini"):
            aa = [a for a in acts if a["agent"] == ag and a["scope"] == "main"]
            t5 = " ".join(a["target"] for a in aa[:5])
            r[f"{ag}_first5_hits_startpoint"] = any(b and b in t5 for b in start_basenames)
        # ---- own test invocations (from full ATIF commands) and environment hits
        for ag in C.AGENTS:
            t = C.atif(bug, ag)
            n_pipe = n_sandbox = n_nodev = n_perm_real = n_instr = 0
            args_seen = []
            roots = set()
            for scope, step, tcall, text, rs in C.iter_atif_calls(t):
                cmd = C.shell_command(tcall)
                for v in (tcall.get("arguments") or {}).values():
                    m = re.match(r"(/(?:Users|Volumes)/[^/]+/(?:[^/]+/)*?)bug-\d+", str(v))
                    if m:
                        roots.add(m.group(1))
                if C.instrument_invocation(cmd):
                    n_instr += 1
                inv = C.pipeline_invocations(cmd)
                if not inv:
                    continue
                n_pipe += 1
                args_seen += inv
                if "SandboxDenied" in text:
                    n_sandbox += 1
                if "No connected Android device" in text:
                    n_nodev += 1
                # 'tee: /dev/stderr: Operation not permitted' is cosmetic (grep still sees stdout)
                if re.search(r"(?<!tee: /dev/stderr: )Operation not permitted", text):
                    n_perm_real += 1
            r[f"{ag}_pipeline_calls"] = n_pipe
            r[f"{ag}_pipeline_target_calls"] = sum(1 for x in args_seen if x == f["target_script"])
            r[f"{ag}_pipeline_all_calls"] = sum(1 for x in args_seen if x == "all")
            r[f"{ag}_pipeline_other_calls"] = sum(1 for x in args_seen if x not in ("all", f["target_script"]))
            r[f"{ag}_direct_instrument_calls"] = n_instr
            r[f"{ag}_pipeline_sandbox_denied"] = n_sandbox
            r[f"{ag}_pipeline_no_device"] = n_nodev
            r[f"{ag}_pipeline_op_not_permitted_nontee"] = n_perm_real
            r[f"{ag}_path_roots"] = ";".join(sorted(roots))
        rows.append(r)

    C.write_csv(C.OUT / "01_task_setup_per_bug.csv", rows,
                fields=sorted({k for r in rows for k in r}, key=lambda k: (k != "bug", k)))
    n = len(rows)
    print(f"bugs: {n}")
    print("Codex/Gemini prompts byte-identical (stripped):", sum(r["prompts_identical"] for r in rows), "/", n)
    for r in rows:
        if not r["prompts_identical"]:
            print("  DIFF bug", r["bug"], "at", r.get("first_diff_at"), "\n    codex :", repr(r.get("diff_codex")),
                  "\n    gemini:", repr(r.get("diff_gemini")))
    print("prompt template variants (bug text/startpoints/script masked):", len(template_variants),
          [c for c in template_variants.values()])
    for s in SECTIONS:
        print(f"  section {s!r}: {sum(r['p_' + s] for r in rows)}/{n}")
    print("  says 'one failing test case':", sum(r["p_says_one_failing_test"] for r in rows))
    print("  mentions any time/turn/budget limit:", sum(r["p_mentions_limit"] for r in rows))
    sf = collections.Counter(r["p_n_start_files"] for r in rows)
    sm = collections.Counter(r["p_n_start_methods"] for r in rows)
    print("  #starting-point files per prompt:", dict(sorted(sf.items())))
    print("  #starting-point methods per prompt:", dict(sorted(sm.items())))
    print("  target script == Script<bug>:", sum(r["p_target_script"] == f"Script{r['bug']}" for r in rows))
    print("Codex rollouts per bug:", collections.Counter(r["codex_rollouts"] for r in rows))
    print("Codex user_message events per rollout:", collections.Counter(r["codex_user_messages"] for r in rows))
    print("Gemini user messages per log:", collections.Counter(r["gemini_user_messages"] for r in rows))
    print("Codex config:", sorted(codex_cfg.items(), key=str))
    print("Claude config:", sorted(claude_cfg.items(), key=str))
    print("Gemini config:", sorted(gemini_cfg.items(), key=str))
    print("Claude prompt evidence:")
    for k in ("claude_first5_hits_startpoint", "claude_first5_hits_testdir", "claude_first5_home_user_paths",
              "claude_early_thought_mentions_startpoint",
              "codex_first5_hits_startpoint", "gemini_first5_hits_startpoint"):
        print(f"  {k}: {sum(bool(r[k]) for r in rows)}/{n}")
    print("Own ./run_pipeline.sh invocations (parsed from full commands) and environment failures:")
    for ag in C.AGENTS:
        tot = sum(r[f"{ag}_pipeline_calls"] for r in rows)
        bugs_any = sum(1 for r in rows if r[f"{ag}_pipeline_calls"] > 0)
        bugs_tgt = sum(1 for r in rows if r[f"{ag}_pipeline_target_calls"] > 0)
        bugs_all = sum(1 for r in rows if r[f"{ag}_pipeline_all_calls"] > 0)
        sb = sum(r[f"{ag}_pipeline_sandbox_denied"] for r in rows)
        bugs_sb = sum(1 for r in rows if r[f"{ag}_pipeline_sandbox_denied"] > 0)
        nd = sum(r[f"{ag}_pipeline_no_device"] for r in rows)
        bugs_nd = sum(1 for r in rows if r[f"{ag}_pipeline_no_device"] > 0)
        op = sum(r[f"{ag}_pipeline_op_not_permitted_nontee"] for r in rows)
        ins = sum(r[f"{ag}_direct_instrument_calls"] for r in rows)
        print(f"  {ag}: pipeline calls={tot} in {bugs_any}/{n} bugs; ran target script in {bugs_tgt} bugs; "
              f"ran 'all' in {bugs_all} bugs; direct 'am instrument' calls={ins}; "
              f"SandboxDenied={sb} calls ({bugs_sb} bugs); 'No connected Android device'={nd} calls ({bugs_nd} bugs); "
              f"non-tee 'Operation not permitted'={op} calls")
    roots = collections.Counter()
    for r in rows:
        for ag in C.AGENTS:
            for x in r[f"{ag}_path_roots"].split(";"):
                if x:
                    roots[(ag, x)] += 1
    print("Absolute workspace roots seen in tool arguments (agent, root): #bugs")
    for (ag, x), c in sorted(roots.items()):
        print(f"  {ag:6s} {x}: {c}")


if __name__ == "__main__":
    main()
