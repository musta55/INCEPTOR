"""Step 2: tabulate the 50 Codex harness CSVs and relate them to the rollout itself.

For each bug: CSV fields + rollout wall-clock (first..last timestamp), task_complete present,
final agent message, and the number of exec_command calls. Checks whether CSV `duration`
is the agent session length (i.e. what the harness actually timed).
Outputs: 02_codex_harness.csv, printed summary.
"""
import csv, json, os, glob, re, datetime, statistics, collections

DS = "/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset/results-localization-codex"
OUT = os.path.dirname(os.path.abspath(__file__))


def ts(s):
    return datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))


rows = []
for f in sorted(glob.glob(f"{DS}/test_results_run_*.csv")):
    with open(f) as fh:
        r = list(csv.DictReader(fh))
    assert len(r) == 1
    r = r[0]
    bug = r["bug"]
    rolls = sorted(glob.glob(f"{DS}/log-{bug}/logs/*.jsonl"), key=os.path.getsize, reverse=True)
    first = last = None
    tc = None
    n_exec = 0
    task_started = 0
    for line in open(rolls[0]):
        o = json.loads(line)
        t = o.get("timestamp")
        if t:
            first = first or ts(t)
            last = ts(t)
        p = o.get("payload", {})
        if o["type"] == "event_msg" and p.get("type") == "task_complete":
            tc = p.get("last_agent_message") or ""
        if o["type"] == "event_msg" and p.get("type") == "task_started":
            task_started += 1
        if o["type"] == "response_item" and p.get("type") in ("function_call", "custom_tool_call"):
            n_exec += 1
    wall = (last - first).total_seconds()
    rows.append({
        "bug": bug, "pass": r["pass"], "test_fail": r["test_fail"], "compile_fail": r["compile_fail"],
        "failed_tests": r["failed_tests"], "all_test_results": r["all_test_results"],
        "all_failed_tests": r["all_failed_tests"], "csv_duration_s": float(r["duration"]),
        "rollout_wallclock_s": round(wall, 1), "n_rollouts": len(rolls), "task_started_events": task_started,
        "task_complete": tc is not None, "n_tool_calls": n_exec,
        "final_msg_claims_pass": bool(tc and re.search(r"\b(pass(es|ed)?|green|succe(ss|eded))\b", tc, re.I)),
        "final_msg_mentions_blocker": bool(tc and re.search(r"(could not|couldn't|unable|blocked|not able|no (connected )?device|emulator|sandbox|cannot|can't)", tc, re.I)),
        "final_msg": (tc or "").replace("\n", " ")[:600],
    })

rows.sort(key=lambda r: int(r["bug"]))
with open(f"{OUT}/out/02_codex_harness.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

N = len(rows)
print("Codex harness CSVs:", N)
print("pass:", collections.Counter(r["pass"] for r in rows))
print("test_fail:", collections.Counter(r["test_fail"] for r in rows), " compile_fail:", collections.Counter(r["compile_fail"] for r in rows))
print("(test_fail,compile_fail) combos:", collections.Counter((r["test_fail"], r["compile_fail"]) for r in rows))
print("failed_tests non-empty:", sum(bool(r["failed_tests"].strip()) for r in rows))
print("all_test_results values:", collections.Counter(r["all_test_results"] for r in rows))
print("all_failed_tests values:", collections.Counter(r["all_failed_tests"] for r in rows))
d = [r["csv_duration_s"] for r in rows]
print("csv duration s: median %.0f, min %.0f, max %.0f" % (statistics.median(d), min(d), max(d)))
diff = [r["csv_duration_s"] - r["rollout_wallclock_s"] for r in rows]
print("csv_duration - rollout wallclock: median %.1f s, min %.1f, max %.1f" % (statistics.median(diff), min(diff), max(diff)))
print("  |diff| < 60 s for", sum(abs(x) < 60 for x in diff), "/", N)
print("task_complete present:", sum(r["task_complete"] for r in rows), "/", N, "; multiple rollouts:", [r["bug"] for r in rows if r["n_rollouts"] > 1])
print("final msg claims pass/success words:", sum(r["final_msg_claims_pass"] for r in rows))
print("final msg mentions a blocker (could not / device / sandbox...):", sum(r["final_msg_mentions_blocker"] for r in rows))
for k in ("Yes",):
    tf = [r for r in rows if r["compile_fail"] == "Yes"]
    print("compile_fail bugs:", [r["bug"] for r in tf])
