"""Step 7: consolidate every outcome signal into one per-trajectory label table and compute the
contrasts that remain meaningful when the only harness verdict (Codex) is 0/50.

Inputs (all produced by scripts in this directory):
  out/05_proxy_outcome.csv  out/03b_self_report_strict.csv  out/06_codex_env_forensics.csv
  out/07_patch_recoverability.csv  + the corpus annotation rows and ATIF for suite composition.
Outputs: out/08_outcome_labels.csv (150 rows) and printed tables.
"""
import collections
import csv
import re
import statistics
import sys
from math import comb

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C


def load(name):
    with open(C.OUT / name) as fh:
        return {(r["bug"], r.get("agent", "codex")): r for r in csv.DictReader(fh)}


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    return min(1.0, 2 * sum(comb(n, i) for i in range(0, k + 1)) / 2 ** n)


def main():
    px = load("05_proxy_outcome.csv")
    sr = load("03b_self_report_strict.csv")
    env = {k[0]: v for k, v in load("06_codex_env_forensics.csv").items()}
    rec = load("07_patch_recoverability.csv")
    bugs = C.bug_ids()

    # ---- suite composition from pipeline output lines
    suite_names = collections.defaultdict(set)
    for bug in bugs:
        for ag in C.AGENTS:
            for scope, step, tc, text, rs in C.iter_atif_calls(C.atif(bug, ag)):
                for m in re.finditer(r">>> (Script\w+): (?:PASSED|FAILED)", text):
                    suite_names[bug].add(m.group(1))
    comp = collections.Counter()
    for bug in bugs:
        kinds = collections.Counter(re.sub(r"^Script\d+", "", n).rstrip("0123456789") or "<target>" for n in suite_names[bug])
        comp[tuple(sorted(kinds.items()))] += 1
    print("suite composition per bug (from '>>> ScriptX: PASSED|FAILED' lines, union over agents):")
    for k, v in comp.most_common():
        print(f"   {v:2d} bugs: {dict(k)}")
    print("   suite size per bug:", dict(collections.Counter(len(suite_names[b]) for b in bugs)))

    rows = []
    for bug in bugs:
        for ag in C.AGENTS:
            p, s, rc = px[(bug, ag)], sr[(bug, ag)], rec[(bug, ag)]
            acts = [a for a in C.actions(bug) if a["agent"] == ag]
            r = {"bug": bug, "agent": ag, "app": env[bug]["app"], "n_actions": len(acts),
                 "n_failed_actions": sum(a["failed"] == "true" for a in acts),
                 "n_env_setup": sum(a["mid_level"] == "env_setup" for a in acts),
                 "harness_verdict": p.get("harness", "") if ag == "codex" else "none_collected",
                 "self_report": s["self_report"],
                 "self_claims_pass": s["self_report"] in ("claims_suite_pass", "claims_target_pass"),
                 "proxy_target_final": p["P3_target_final"], "proxy_suite_final": p["P4_suite_final"],
                 "proxy_suite_pass": p.get("P4_pass", ""), "proxy_suite_fail": p.get("P4_fail", ""),
                 "proxy_strict_green": p["strict_green"] == "True",
                 "proxy_green_loose": p["P3_target_final"] == "PASS" and p["P4_suite_final"] == "PASS_ALL",
                 "reproduced_before_first_edit": p.get("P3_target_failed_before_first_change") == "True",
                 "oracle_test_edited": int(p["edits_oracle_test"] or 0) > 0,
                 "oracle_dirty_at_end": int(p["dirty_at_end_oracle"] or 0) > 0,
                 "harness_script_edited": int(p["edits_harness_script"] or 0) > 0,
                 "env_workaround_in_report": s["mentions_env_workaround"] == "True",
                 "replay_class": rc["replay_class"]}
            rows.append(r)
    C.write_csv(C.OUT / "08_outcome_labels.csv", rows)
    by = {(r["bug"], r["agent"]): r for r in rows}

    print("\n=== label availability / values per agent (n=50 each)")
    hdr = f"{'':46s} " + " ".join(f"{a:>7s}" for a in C.AGENTS)
    print(hdr)
    def line(name, f):
        print(f"{name:46s} " + " ".join(f"{sum(1 for r in rows if r['agent'] == a and f(r)):7d}" for a in C.AGENTS))
    line("harness verdict exists", lambda r: r["harness_verdict"] not in ("none_collected", ""))
    line("harness pass", lambda r: r["harness_verdict"] == "pass")
    line("self-report claims pass (suite or target)", lambda r: r["self_claims_pass"])
    line("proxy loose green (target PASS & suite 5/5)", lambda r: r["proxy_green_loose"])
    line("proxy STRICT green", lambda r: r["proxy_strict_green"])
    line("self claims pass but NOT strict green", lambda r: r["self_claims_pass"] and not r["proxy_strict_green"])
    line("strict green but self-report no pass claim", lambda r: r["proxy_strict_green"] and not r["self_claims_pass"])
    line("reproduced target failure before first edit", lambda r: r["reproduced_before_first_edit"])
    line("edited oracle Script*.java", lambda r: r["oracle_test_edited"])
    line("oracle still modified at end", lambda r: r["oracle_dirty_at_end"])
    line("edited run_pipeline.sh", lambda r: r["harness_script_edited"])
    line("env workaround mentioned in final report", lambda r: r["env_workaround_in_report"])
    line("patch replayable from structured edits (R1)", lambda r: r["replay_class"] == "R1_structured_only")

    print("\n=== self-report precision against the STRICT proxy")
    for a in C.AGENTS:
        cl = [r for r in rows if r["agent"] == a and r["self_claims_pass"]]
        g = sum(r["proxy_strict_green"] for r in cl)
        print(f"   {a}: {g}/{len(cl)} pass-claims are strict-green ({100 * g / max(1, len(cl)):.0f}%)")

    print("\n=== Codex: self-report / proxy vs harness")
    cx = [r for r in rows if r["agent"] == "codex"]
    print("   self-report x harness:", dict(collections.Counter((r["self_report"], r["harness_verdict"]) for r in cx)))
    print("   strict-green x harness:", dict(collections.Counter((r["proxy_strict_green"], r["harness_verdict"]) for r in cx)))

    print("\n=== paired, same-bug comparison of STRICT green (confounded by machine: 3 different hosts)")
    k = collections.Counter(sum(by[(b, a)]["proxy_strict_green"] for a in C.AGENTS) for b in bugs)
    print("   #agents strict-green per bug:", dict(sorted(k.items())))
    for a1, a2 in (("claude", "codex"), ("claude", "gemini"), ("codex", "gemini")):
        both = sum(by[(b, a1)]["proxy_strict_green"] and by[(b, a2)]["proxy_strict_green"] for b in bugs)
        only1 = sum(by[(b, a1)]["proxy_strict_green"] and not by[(b, a2)]["proxy_strict_green"] for b in bugs)
        only2 = sum(not by[(b, a1)]["proxy_strict_green"] and by[(b, a2)]["proxy_strict_green"] for b in bugs)
        neither = len(bugs) - both - only1 - only2
        print(f"   {a1} vs {a2}: both={both} only_{a1}={only1} only_{a2}={only2} neither={neither} "
              f"McNemar exact p={mcnemar_exact(only1, only2):.3f}")

    print("\n=== Codex compile_fail vs test_fail: trajectory features (median [min-max])")
    for lab in ("compile_fail", "test_fail"):
        sub = [r for r in cx if r["harness_verdict"] == lab]
        f = lambda key: f"{statistics.median([r[key] for r in sub]):.0f} [{min(r[key] for r in sub)}-{max(r[key] for r in sub)}]"
        print(f"   {lab:12s} n={len(sub):2d} actions={f('n_actions')} failed_actions={f('n_failed_actions')} "
              f"env_setup={f('n_env_setup')} strict_green={sum(r['proxy_strict_green'] for r in sub)} "
              f"apps={len(set(r['app'] for r in sub))}")

    print("\n=== fail-to-pass (F2P) observable inside the trajectory")
    for a in C.AGENTS:
        f2p = sum(1 for r in rows if r["agent"] == a and r["reproduced_before_first_edit"] and r["proxy_strict_green"])
        print(f"   {a}: target seen FAILING on unmodified code AND strict green at end: {f2p}/50")
    anyrep = [b for b in bugs if any(by[(b, a)]["reproduced_before_first_edit"] for a in C.AGENTS)]
    print(f"   bugs whose target test was seen failing on unmodified code by >=1 agent: {len(anyrep)}/50")
    cl_green_unrep = sum(1 for b in bugs if by[(b, "claude")]["proxy_strict_green"] and b not in anyrep)
    print(f"   claude strict-green bugs where NO agent ever saw the target fail on unmodified code: {cl_green_unrep}")

    print("\n=== partial pass counts available (last suite run, pass/fail out of the 5 Script tests)")
    for a in C.AGENTS:
        c = collections.Counter(f"{r['proxy_suite_pass']}/{r['proxy_suite_fail']}" if r["proxy_suite_final"] != "NEVER_RUN" else "never_run"
                                for r in rows if r["agent"] == a)
        print(f"   {a}: {dict(c)}")


if __name__ == "__main__":
    main()
