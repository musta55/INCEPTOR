"""Step 4: Gemini CLI -- the final 'result' event + stats and the final assistant text
(delta fragments after the last tool_result, concatenated).  Also Codex's task_complete
last_agent_message, so all three agents' self-reports can be compared to evidence.
Final texts are dumped verbatim for manual checking."""
import collections
import statistics
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C


def gemini_final(bug):
    evs, n_lines = C.gemini_events(bug)
    res = [e for e in evs if e.get("type") == "result"]
    errs = [e for e in evs if e.get("type") == "error"]
    last_tool = max((i for i, e in enumerate(evs) if e.get("type") in ("tool_use", "tool_result")), default=-1)
    tail_text = "".join(e.get("content", "") for e in evs[last_tool + 1:]
                        if e.get("type") == "message" and e.get("role") == "assistant")
    r = {"bug": bug, "n_json_events": len(evs), "n_lines": n_lines, "n_result_events": len(res),
         "n_error_events": len(errs), "last_event_type": evs[-1].get("type") if evs else ""}
    if res:
        m = res[-1]
        st = m.get("stats") or {}
        r.update(status=m.get("status"), error=str(m.get("error") or "")[:200],
                 duration_ms=st.get("duration_ms"), tool_calls=st.get("tool_calls"),
                 total_tokens=st.get("total_tokens"), output_tokens=st.get("output_tokens"),
                 stats_keys=",".join(sorted(st.keys())))
    r["error_messages"] = " || ".join(str(e.get("message") or e.get("error") or e)[:160] for e in errs[:3])
    return r, tail_text


def codex_final(bug):
    rows = C.codex_rows(C.codex_rollouts(bug)[0])
    tc = [x["payload"] for x in rows if x.get("payload", {}).get("type") == "task_complete"]
    return (tc[-1].get("last_agent_message") or "") if tc else ""


def main():
    grows, crows = [], []
    gdump = ["# Gemini final assistant text after the last tool call (verbatim)\n"]
    cdump = ["# Codex task_complete.last_agent_message (verbatim)\n"]
    for bug in C.bug_ids():
        r, text = gemini_final(bug)
        lab, ev = C.classify_self_report(text)
        r.update(self_report_auto=lab, self_report_evidence=ev, final_chars=len(text))
        grows.append(r)
        gdump.append(f"\n## bug-{bug}  [auto: {lab}]  status={r.get('status')} tool_calls={r.get('tool_calls')}\n\n"
                     + text.strip()[-2500:] + "\n")
        ct = codex_final(bug)
        clab, cev = C.classify_self_report(ct)
        crows.append({"bug": bug, "self_report_auto": clab, "self_report_evidence": cev, "final_chars": len(ct)})
        cdump.append(f"\n## bug-{bug}  [auto: {clab}]\n\n" + ct.strip()[-3000:] + "\n")
    C.write_csv(C.OUT / "04_gemini_result.csv", grows)
    C.write_csv(C.OUT / "04_codex_final_message.csv", crows)
    (C.OUT / "04_gemini_final_texts.md").write_text("\n".join(gdump))
    (C.OUT / "04_codex_final_texts.md").write_text("\n".join(cdump))

    n = len(grows)
    print("Gemini logs:", n, " exactly one result event:", sum(r["n_result_events"] == 1 for r in grows))
    print("last event type:", dict(collections.Counter(r["last_event_type"] for r in grows)))
    print("result.status:", dict(collections.Counter(r.get("status") for r in grows)))
    print("result.error non-empty:", sum(1 for r in grows if r.get("error")))
    print("stream 'error' events: total", sum(r["n_error_events"] for r in grows),
          "in", sum(1 for r in grows if r["n_error_events"]), "logs")
    print("stats keys variants:", dict(collections.Counter(r.get("stats_keys") for r in grows)))
    for k in ("duration_ms", "tool_calls", "total_tokens"):
        v = [r[k] for r in grows if isinstance(r.get(k), (int, float))]
        print(f"{k}: n={len(v)} median={statistics.median(v):.0f} min={min(v)} max={max(v)}")
    print("Gemini final text empty:", sum(1 for r in grows if r["final_chars"] == 0))
    print("Gemini self-report (auto):", dict(collections.Counter(r["self_report_auto"] for r in grows)))
    print("Codex final message empty:", sum(1 for r in crows if r["final_chars"] == 0))
    print("Codex self-report (auto):", dict(collections.Counter(r["self_report_auto"] for r in crows)))


if __name__ == "__main__":
    main()
