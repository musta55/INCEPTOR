"""Step 6: can the FINAL patch of each trajectory be recovered, so the harness can be re-run
for Claude and Gemini (and re-run cleanly for Codex)?

Per trajectory (150):
  * structured edits (Claude Edit/MultiEdit/Write, Codex apply_patch, Gemini replace/write_file):
    count, failed count, whether the arguments carry the full edit (old/new strings, file
    content, or a complete '*** Begin Patch ... *** End Patch' block), and the file class touched
  * shell-side writes (sed -i, redirects into source files, python writes, cp/mv into src,
    git apply) -- replayable only by re-executing the command in order
  * reverts (git checkout/restore/stash/reset) -- order-sensitive
  * git: was the workspace a git repo? any `git diff` output that shows a diff AFTER the
    last code change (a ready-made final patch)?
  * does the final message itself contain a unified diff?
Replay class:
  R1 structured edits only (no shell writes, no reverts)  -> deterministic string replay on the base repo
  R2 structured + shell writes and/or reverts              -> ordered replay incl. shell commands
  R0 no code change at all
Outputs out/07_patch_recoverability.csv and printed tables.
"""
import collections
import re
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C

RX_NOT_GIT = re.compile(r"(not a git repository|does not have any commits yet|ambiguous argument 'HEAD'|No HEAD|bad revision 'HEAD')", re.I)
RX_DIFF = re.compile(r"^diff --git |^--- a/|^\+\+\+ b/", re.M)
RX_GIT_DIFF_CMD = re.compile(r"\bgit\s+(?:-C\s+\S+\s+|--no-pager\s+)*(diff|show)\b")
RX_GIT_STATUS_CMD = re.compile(r"\bgit\s+(?:-C\s+\S+\s+|--no-pager\s+)*status\b")


def full_args(tc):
    fn = tc.get("function_name")
    a = tc.get("arguments") or {}
    if fn == "Edit":
        return isinstance(a.get("old_string"), str) and isinstance(a.get("new_string"), str)
    if fn == "MultiEdit":
        return all(isinstance(e.get("old_string"), str) and isinstance(e.get("new_string"), str) for e in a.get("edits", []))
    if fn in ("Write", "write_file"):
        return isinstance(a.get("content"), str)
    if fn == "replace":
        return isinstance(a.get("old_string"), str) and isinstance(a.get("new_string"), str)
    if fn == "apply_patch":
        t = a.get("input") or a.get("patch") or ""
        return t.lstrip().startswith("*** Begin Patch") and t.rstrip().endswith("*** End Patch")
    return False


def main():
    rows = []
    for bug in C.bug_ids():
        acts_all = C.actions(bug)
        for ag in C.AGENTS:
            acts = sorted((a for a in acts_all if a["agent"] == ag), key=lambda a: int(a["action_index"]))
            traj = C.atif(bug, ag)
            idx = C.call_index(traj)
            r = {"bug": bug, "agent": ag}
            n_struct = n_struct_failed = n_full = 0
            cls_files = collections.defaultdict(set)
            shell_kinds = collections.Counter()
            shell_cls = collections.Counter()
            n_revert = 0
            last_change = 0
            git_diff_after = False
            git_diff_any = False
            not_git = False
            n_git_cmds = 0
            n_shell_patch = 0
            for a in acts:
                tc, text, rs, step = idx.get(a["call_id"], (None, "", [], None))
                if tc is None:
                    continue
                ai = int(a["action_index"])
                tg = C.edit_targets(tc)
                cmd = C.shell_command(tc) or ""
                via_shell_patch = False
                if not tg and re.search(r"\bapply_patch\b", cmd) and "*** Begin Patch" in cmd:
                    # Codex sometimes runs apply_patch as a heredoc inside exec_command (mid_level = run_shell)
                    tg = [(m.group(1).lower(), m.group(2).strip())
                          for m in re.finditer(r"\*\*\* (Update|Add|Delete) File:\s*(.+)", cmd)]
                    via_shell_patch = True
                    n_shell_patch += 1
                if tg:
                    n_struct += 1
                    ok = a["failed"] != "true"
                    n_struct_failed += (not ok)
                    n_full += True if via_shell_patch else full_args(tc)
                    if ok:
                        last_change = ai
                        for op, p in tg:
                            cls_files[C.classify_path(p)].add(C.norm_path(p))
                if re.search(r"\bgit\b", cmd):
                    n_git_cmds += 1
                    if RX_NOT_GIT.search(text):
                        not_git = True
                for kind, frag in C.shell_writes(cmd):
                    if kind == "git_revert_files":
                        n_revert += 1
                        continue
                    shell_kinds[kind] += 1
                    shell_cls[C.classify_path(frag)] += 1
                    last_change = ai
                if RX_GIT_DIFF_CMD.search(cmd) and RX_DIFF.search(text):
                    git_diff_any = True
                    if ai >= last_change:
                        git_diff_after = True
            # final text
            if ag == "claude":
                res = [m for m in C.claude_messages(bug) if m.get("__type__") == "ResultMessage"]
                final = (res[-1].get("result") or "") if res else ""
            elif ag == "codex":
                rws = C.codex_rows(C.codex_rollouts(bug)[0])
                tcs = [x["payload"] for x in rws if x.get("payload", {}).get("type") == "task_complete"]
                final = (tcs[-1].get("last_agent_message") or "") if tcs else ""
            else:
                evs, _ = C.gemini_events(bug)
                final = "".join(e.get("content", "") for e in evs if e.get("type") == "message" and e.get("role") == "assistant")[-20000:]
            n_shell_src = sum(shell_kinds.values())
            if n_struct == 0 and n_shell_src == 0:
                rc = "R0_no_change"
            elif n_shell_src == 0 and n_revert == 0:
                rc = "R1_structured_only"
            else:
                rc = "R2_needs_ordered_shell_replay"
            r.update(n_shell_apply_patch=n_shell_patch, n_struct_edits=n_struct, n_struct_failed=n_struct_failed, n_struct_full_args=n_full,
                     all_struct_args_full=(n_full == n_struct),
                     n_files_app_code=len(cls_files["app_code"]), n_files_oracle=len(cls_files["oracle_test"]),
                     n_files_harness=len(cls_files["harness_script"]), n_files_build=len(cls_files["build_config"]),
                     n_files_test_proj=len(cls_files["test_project_config"]), n_files_proj_tests=len(cls_files["project_tests"]),
                     n_shell_writes=n_shell_src, shell_write_kinds=";".join(f"{k}:{v}" for k, v in shell_kinds.items()),
                     shell_write_classes=";".join(f"{k}:{v}" for k, v in shell_cls.items()),
                     n_reverts=n_revert, n_git_cmds=n_git_cmds, not_a_git_repo_seen=not_git,
                     git_diff_with_hunks_any=git_diff_any, git_diff_after_last_change=git_diff_after,
                     final_text_has_diff=bool(RX_DIFF.search(final)), replay_class=rc)
            rows.append(r)
    C.write_csv(C.OUT / "07_patch_recoverability.csv", rows)

    def col(k, f=lambda v: bool(v)):
        return " ".join(f"{sum(1 for r in rows if r['agent'] == a and f(r[k])):7d}" for a in C.AGENTS)

    print(f"{'(trajectories, n=50 per agent)':44s} " + " ".join(f"{a:>7s}" for a in C.AGENTS))
    print(f"{'>=1 structured edit':44s} " + col("n_struct_edits"))
    print(f"{'structured edits total':44s} " + " ".join(f"{sum(r['n_struct_edits'] for r in rows if r['agent'] == a):7d}" for a in C.AGENTS))
    print(f"{'  of which apply_patch heredoc via shell':44s} " + " ".join(f"{sum(r['n_shell_apply_patch'] for r in rows if r['agent'] == a):7d}" for a in C.AGENTS))
    print(f"{'structured edits failed':44s} " + " ".join(f"{sum(r['n_struct_failed'] for r in rows if r['agent'] == a):7d}" for a in C.AGENTS))
    print(f"{'structured edits with full args':44s} " + " ".join(f"{sum(r['n_struct_full_args'] for r in rows if r['agent'] == a):7d}" for a in C.AGENTS))
    print(f"{'all structured edits have full args':44s} " + col("all_struct_args_full"))
    print(f"{'touches app code':44s} " + col("n_files_app_code"))
    print(f"{'touches oracle test (Script*.java)':44s} " + col("n_files_oracle"))
    print(f"{'touches run_pipeline.sh':44s} " + col("n_files_harness"))
    print(f"{'touches build config (gradle/properties)':44s} " + col("n_files_build"))
    print(f"{'touches reproducing_script_project config':44s} " + col("n_files_test_proj"))
    print(f"{'touches app own tests (src/test|androidTest)':44s} " + col("n_files_proj_tests"))
    print(f"{'>=1 shell-side source write':44s} " + col("n_shell_writes"))
    print(f"{'>=1 revert (git checkout/restore/stash)':44s} " + col("n_reverts"))
    print(f"{'ran any git command':44s} " + col("n_git_cmds"))
    print(f"{'saw not-a-git-repo / no HEAD':44s} " + col("not_a_git_repo_seen"))
    print(f"{'git diff with hunks observed (any time)':44s} " + col("git_diff_with_hunks_any"))
    print(f"{'git diff with hunks AFTER last change':44s} " + col("git_diff_after_last_change"))
    print(f"{'final message contains a unified diff':44s} " + col("final_text_has_diff"))
    for rc in ("R0_no_change", "R1_structured_only", "R2_needs_ordered_shell_replay"):
        print(f"{'replay ' + rc:44s} " + col("replay_class", lambda v, rc=rc: v == rc))
    print("\nfiles modified per trajectory (app code), median:")
    import statistics
    for a in C.AGENTS:
        v = [r["n_files_app_code"] for r in rows if r["agent"] == a]
        print(f"   {a}: median {statistics.median(v)}, max {max(v)}")
    print("\nshell write kinds per agent:")
    for a in C.AGENTS:
        c = collections.Counter()
        for r in rows:
            if r["agent"] == a and r["shell_write_kinds"]:
                for kv in r["shell_write_kinds"].split(";"):
                    k, v = kv.split(":")
                    c[k] += int(v)
        print(f"   {a}: {dict(c)}")
    print("\nR2 trajectories:", [(r["agent"], r["bug"], r["shell_write_kinds"], r["n_reverts"]) for r in rows if r["replay_class"].startswith("R2")])


if __name__ == "__main__":
    main()
