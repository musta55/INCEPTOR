#!/bin/bash
# Re-runs the whole 'outcomes' experiment in dependency order. Reads the raw dataset and the
# converted corpus read-only; writes only into this directory (out/, prompts/).
set -e
cd "$(dirname "$0")"
mkdir -p out prompts
python3 01_task_prompts.py      > out/01_task_prompts.txt      # prompts/*.txt (used by 06)
python3 01_task_setup.py        > out/01_task_setup.txt
python3 02_codex_harness.py     > out/02_codex_harness.txt
python3 03_claude_result.py     > out/03_claude_result.txt
python3 03b_self_report_strict.py > out/03b_self_report_strict.txt
python3 04_gemini_codex_final.py > out/04_gemini_codex_final.txt
python3 05_proxy_outcome.py     > out/05_proxy_outcome.txt
python3 06_codex_env_forensics.py > out/06_codex_env_forensics.txt
python3 07_patch_recoverability.py > out/07_patch_recoverability.txt
python3 08_labels_and_contrasts.py > out/08_labels_and_contrasts.txt
echo done
