"""Step 1: recover the task prompt given to each agent and check it is the same template.

Codex: user message (not the AGENTS.md one) in the rollout JSONL.
Gemini: first {"type":"message","role":"user"} event in the stream-json.
Claude: the SDK repr dump has no user prompt; we look for indirect evidence
(does it call ./run_pipeline.sh Script<id> without discovering it first; do its
first file reads hit the "Good Starting Points" files named in the Codex/Gemini prompt).

Outputs: prompts/<agent>_<bug>.txt, 01_task_prompts.json, printed summary.
"""
import json, os, re, glob, collections, difflib

DS = "/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset"
OUT = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(OUT, "prompts"), exist_ok=True)


def codex_prompt(bug):
    files = glob.glob(f"{DS}/results-localization-codex/log-{bug}/logs/*.jsonl")
    # bug-447 has two rollouts (an aborted 20-line one); same rule as Parser/atif/corpus.py: take the largest
    files.sort(key=lambda f: os.path.getsize(f), reverse=True)
    meta = {}
    prompt = None
    agents_md = None
    for line in open(files[0]):
        o = json.loads(line)
        p = o.get("payload", {})
        if o["type"] == "session_meta":
            meta["cwd"] = p.get("cwd")
            meta["cli_version"] = p.get("cli_version")
        if o["type"] == "turn_context" and "model" not in meta:
            meta["model"] = p.get("model")
            meta["approval_policy"] = p.get("approval_policy")
            meta["sandbox"] = p.get("sandbox_policy", {}).get("type")
            meta["reasoning_effort"] = p.get("collaboration_mode", {}).get("settings", {}).get("reasoning_effort")
        if o["type"] == "response_item" and p.get("type") == "message" and p.get("role") == "user":
            txt = "".join(c.get("text", "") for c in p.get("content", []))
            if txt.startswith("# AGENTS.md"):
                agents_md = txt
            elif prompt is None:
                prompt = txt
    return prompt, agents_md, meta


def gemini_prompt(bug):
    f = f"{DS}/results_localized_withtests-gemini/bug-{bug}_raw.json"
    meta = {}
    with open(f) as fh:
        for line in fh:
            if not line.startswith("{"):
                continue
            try:
                o = json.loads(line)
            except Exception:
                continue
            if o.get("type") == "init":
                meta["model"] = o.get("model")
            if o.get("type") == "message" and o.get("role") == "user":
                return o.get("content"), meta
    return None, meta


def features(p):
    """Structural features of the prompt template."""
    if p is None:
        return None
    sp = re.findall(r"\* File path: (\S+)", p)
    methods = re.findall(r"Method name: (\S+)", p)
    script = re.findall(r"run_pipeline\.sh (Script\S+)", p)
    return {
        "chars": len(p),
        "has_bug_description": "## Bug Description" in p,
        "says_one_failing_test": "one failing test case" in p,
        "has_test_location": "## Test Location" in p,
        "has_build_cmd": "./gradlew clean assembleDebug" in p,
        "has_run_pipeline_single": bool(script),
        "has_run_pipeline_all": "./run_pipeline.sh all" in p,
        "has_good_starting_points": "## Good Starting Points" in p,
        "n_starting_files": len(sp),
        "n_starting_methods": len(methods),
        "starting_files": sp,
        "script_name": script[0] if script else None,
        "mentions_time_limit": bool(re.search(r"(time limit|minutes|timeout|max(imum)? (turns|steps))", p, re.I)),
        "success_criteria": re.search(r"## Success Criteria:(.*?)(##|$)", p, re.S).group(1).strip() if "## Success Criteria" in p else None,
    }


def template(p, bug):
    """Strip bug-specific parts to compare templates."""
    t = re.sub(r"## Bug Description:.*?You are currently located", "## Bug Description: <BUG>\n You are currently located", p, flags=re.S)
    t = re.sub(r"## Test Location:.*?## Building", "## Test Location: <LOC>\n## Building", t, flags=re.S)
    t = re.sub(r"## Good Starting Points to Reveal Failure:.*", "## Good Starting Points to Reveal Failure: <SP>", t, flags=re.S)
    t = t.replace(f"Script{bug}", "Script<ID>")
    t = re.sub(r"Script\w+", "Script<ID>", t)
    return t


def claude_evidence(bug, sp_files):
    f = f"{DS}/localized-tests-logs-claude/logs/bug-{bug}_output.txt"
    s = open(f).read()
    cwd = re.search(r"'cwd': '([^']*)'", s).group(1)
    model = re.search(r"'model': '([^']*)'", s).group(1)
    version = re.search(r"'claude_code_version': '([^']*)'", s)
    has_user_prompt = bool(re.search(r"^UserMessage\(content='", s, re.M))
    # order of tool uses
    tool_uses = re.findall(r"ToolUseBlock\(id='[^']*', name='([^']*)', input=(\{.*?\})\)\]", s)
    rp = [i for i, (n, inp) in enumerate(tool_uses) if "run_pipeline.sh" in inp]
    # did it read/ls run_pipeline.sh before first use? (discovery)
    first_rp_cmd = tool_uses[rp[0]][1][:200] if rp else None
    uses_script_name = bool(re.search(rf"run_pipeline\.sh Script{re.escape(bug)}\b", s))
    # first 5 file paths touched
    first_paths = []
    for n, inp in tool_uses[:8]:
        m = re.search(r"'(?:file_path|path|pattern)': '([^']*)'", inp)
        if m:
            first_paths.append(m.group(1))
    sp_base = {os.path.basename(x) for x in sp_files}
    hit_sp = any(os.path.basename(p) in sp_base for p in first_paths)
    return {
        "cwd": cwd, "model": model, "claude_code_version": version.group(1) if version else None,
        "has_user_prompt_in_log": has_user_prompt,
        "n_tool_uses": len(tool_uses), "n_run_pipeline_calls": len(rp),
        "uses_exact_script_name": uses_script_name, "first_run_pipeline_call": first_rp_cmd,
        "first_paths": first_paths, "early_read_hits_starting_point_file": hit_sp,
        "first_path_is_home_user": bool(first_paths) and first_paths[0].startswith("/home/user"),
    }


bugs = sorted({re.match(r"bug-(\d+)_", os.path.basename(f)).group(1)
               for f in glob.glob(f"{DS}/localized-tests-logs-claude/logs/*.txt")}, key=int)
res = {}
tmpl_counter = collections.Counter()
tmpl_examples = {}
same_prompt = 0
for b in bugs:
    cp, amd, cmeta = codex_prompt(b)
    gp, gmeta = gemini_prompt(b)
    open(f"{OUT}/prompts/codex_{b}.txt", "w").write(cp or "")
    open(f"{OUT}/prompts/gemini_{b}.txt", "w").write(gp or "")
    cf, gf = features(cp), features(gp)
    identical = (cp or "").strip() == (gp or "").strip()
    same_prompt += identical
    ct = template(cp, b); gt = template(gp, b)
    tmpl_counter[("codex", ct)] += 1; tmpl_counter[("gemini", gt)] += 1
    ce = claude_evidence(b, cf["starting_files"] if cf else [])
    res[b] = {"codex": {"features": cf, "meta": cmeta, "agents_md_chars": len(amd or "")},
              "gemini": {"features": gf, "meta": gmeta},
              "codex_gemini_prompt_identical": identical,
              "codex_gemini_similarity": round(difflib.SequenceMatcher(None, cp or "", gp or "").ratio(), 4),
              "claude": ce}

json.dump(res, open(f"{OUT}/out/01_task_prompts.json", "w"), indent=1)

# ---- summary
N = len(bugs)
print(f"bugs: {N}")
print(f"codex==gemini prompt byte-identical (strip): {same_prompt}/{N}")
sims = sorted(r["codex_gemini_similarity"] for r in res.values())
print("min similarity codex vs gemini:", sims[:5])
distinct = collections.Counter(a for a, _ in tmpl_counter)
print("distinct templates after masking bug-specific parts:", {a: sum(1 for (x, _) in tmpl_counter if x == a) for a in ("codex", "gemini")})
for a in ("codex", "gemini"):
    keys = [k for k in tmpl_counter if k[0] == a]
    for k in keys:
        print(f"  {a} template used by {tmpl_counter[k]} bugs")
# write the dominant template
dom = max((k for k in tmpl_counter if k[0] == "codex"), key=lambda k: tmpl_counter[k])
open(f"{OUT}/prompts/TEMPLATE_codex_dominant.txt", "w").write(dom[1])
# differences between templates
ck = [k for k in tmpl_counter if k[0] == "codex"]
if len(ck) > 1:
    for k in ck:
        if k != dom:
            d = list(difflib.unified_diff(dom[1].splitlines(), k[1].splitlines(), lineterm="", n=0))
            print("  --- template diff vs dominant (codex, n=%d):" % tmpl_counter[k]); print("\n".join(d[:30]))

for a in ("codex", "gemini"):
    fs = [res[b][a]["features"] for b in bugs if res[b][a]["features"]]
    print(f"\n{a}: prompts found {len(fs)}/{N}")
    for key in ["has_bug_description", "says_one_failing_test", "has_test_location", "has_build_cmd",
                "has_run_pipeline_single", "has_run_pipeline_all", "has_good_starting_points", "mentions_time_limit"]:
        print(f"   {key}: {sum(bool(f[key]) for f in fs)}")
    print("   n_starting_files dist:", collections.Counter(f["n_starting_files"] for f in fs))
    print("   success criteria variants:", collections.Counter(f["success_criteria"] for f in fs).most_common(3))
    print("   meta:", collections.Counter(json.dumps({k: v for k, v in res[b][a]["meta"].items() if k != 'cwd'}) for b in bugs))

cl = [res[b]["claude"] for b in bugs]
print("\nclaude:")
print("   user prompt present in log:", sum(c["has_user_prompt_in_log"] for c in cl), "/", N)
print("   models:", collections.Counter(c["model"] for c in cl), "versions:", collections.Counter(c["claude_code_version"] for c in cl))
print("   cwd roots:", collections.Counter(os.path.dirname(c["cwd"]) for c in cl))
print("   calls ./run_pipeline.sh at least once:", sum(c["n_run_pipeline_calls"] > 0 for c in cl))
print("   uses exact Script<bug> name:", sum(c["uses_exact_script_name"] for c in cl))
print("   early (first 8 tool uses) path hits a Good-Starting-Point file:", sum(c["early_read_hits_starting_point_file"] for c in cl))
print("   first path starts with /home/user (hallucinated root):", sum(c["first_path_is_home_user"] for c in cl))
print("codex cwd roots:", collections.Counter(os.path.dirname(res[b]['codex']['meta']['cwd']) for b in bugs))
