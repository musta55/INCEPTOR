"""Step 3: Claude Code -- the SDK ResultMessage per log (subtype, is_error, num_turns,
duration, cost) and the self-reported final text, classified heuristically.  Final texts
are dumped verbatim to out/03_claude_final_texts.md for manual checking of the classifier.
"""
import collections
import statistics
import sys

sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/outcomes")
import common as C


def main():
    rows = []
    dump = ["# Claude final ResultMessage.result texts (verbatim)\n"]
    for bug in C.bug_ids():
        msgs = C.claude_messages(bug)
        res = [m for m in msgs if m.get("__type__") == "ResultMessage"]
        unparsed = sum(1 for m in msgs if m.get("__type__") == "UNPARSED")
        r = {"bug": bug, "n_result_messages": len(res), "unparsed_lines": unparsed,
             "last_line_type": msgs[-1].get("__type__") if msgs else ""}
        if res:
            m = res[-1]
            r.update(subtype=m.get("subtype"), is_error=m.get("is_error"), num_turns=m.get("num_turns"),
                     duration_ms=m.get("duration_ms"), duration_api_ms=m.get("duration_api_ms"),
                     total_cost_usd=m.get("total_cost_usd"),
                     output_tokens=(m.get("usage") or {}).get("output_tokens"),
                     stop_reason=m.get("stop_reason"))
            text = m.get("result") or ""
        else:
            text = ""
        # also the last assistant TextBlock (should equal result)
        last_text = ""
        for mm in msgs:
            if mm.get("__type__") == "AssistantMessage" and mm.get("parent_tool_use_id") in (None, "None"):
                for b in mm.get("content") or []:
                    if isinstance(b, dict) and b.get("__type__") == "TextBlock":
                        last_text = b.get("text") or ""
        r["result_equals_last_text"] = (text.strip() == last_text.strip())
        lab, ev = C.classify_self_report(text)
        r["self_report_auto"] = lab
        r["self_report_evidence"] = ev
        r["result_chars"] = len(text)
        rows.append(r)
        dump.append(f"\n## bug-{bug}  [auto: {lab}]  subtype={r.get('subtype')} turns={r.get('num_turns')}\n\n"
                    + text.strip()[-2500:] + "\n")
    C.write_csv(C.OUT / "03_claude_result.csv", rows)
    (C.OUT / "03_claude_final_texts.md").write_text("\n".join(dump))

    n = len(rows)
    print("logs:", n, " with exactly one ResultMessage:", sum(r["n_result_messages"] == 1 for r in rows))
    print("unparsed lines total:", sum(r["unparsed_lines"] for r in rows))
    print("last line type:", dict(collections.Counter(r["last_line_type"] for r in rows)))
    print("subtype:", dict(collections.Counter(r.get("subtype") for r in rows)))
    print("is_error:", dict(collections.Counter(r.get("is_error") for r in rows)))
    print("stop_reason field:", dict(collections.Counter(r.get("stop_reason") for r in rows)))
    for k in ("num_turns", "duration_ms", "total_cost_usd"):
        v = [r[k] for r in rows if isinstance(r.get(k), (int, float))]
        print(f"{k}: n={len(v)} median={statistics.median(v):.2f} min={min(v):.2f} max={max(v):.2f} sum={sum(v):.2f}")
    print("result == last main TextBlock:", sum(r["result_equals_last_text"] for r in rows))
    print("self-report (auto heuristic):", dict(collections.Counter(r["self_report_auto"] for r in rows)))


if __name__ == "__main__":
    main()
