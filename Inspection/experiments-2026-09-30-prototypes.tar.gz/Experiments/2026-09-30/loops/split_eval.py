"""Which Sankey split separates phase-transition structure best?
For each candidate 2-way split, compute the Jensen-Shannon divergence between the two groups'
RLE phase-transition (bigram incl. START/END) distributions, and a permutation p-value
(labels shuffled 2000x, same group sizes) because small groups inflate JSD by noise alone.
Reported as observed JSD, permutation-null mean, and excess = observed - null mean.
"""
import csv, json, os, random
from collections import Counter
import numpy as np
from common import OUT

recs = list(csv.DictReader(open(os.path.join(OUT, "per_trajectory.csv"))))


def seq(r):
    return [x.split("(")[0] for x in r["phase_seq"].split(" > ")]


def bigrams(rs):
    c = Counter()
    for r in rs:
        s = ["START"] + seq(r) + ["END"]
        c.update(zip(s, s[1:]))
    return c


def jsd(c1, c2):
    keys = sorted(set(c1) | set(c2))
    p = np.array([c1[k] for k in keys], float); p /= p.sum()
    q = np.array([c2[k] for k in keys], float); q /= q.sum()
    m = (p + q) / 2

    def kl(a, b):
        nz = a > 0
        return float(np.sum(a[nz] * np.log2(a[nz] / b[nz])))
    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def evaluate(pool, label, name, perms=2000, seed=0):
    g1 = [r for r in pool if label(r)]
    g0 = [r for r in pool if not label(r)]
    if len(g1) < 3 or len(g0) < 3:
        return dict(split=name, n1=len(g1), n0=len(g0), note="group too small")
    obs = jsd(bigrams(g1), bigrams(g0))
    rng = random.Random(seed)
    null = []
    for _ in range(perms):
        sh = pool[:]
        rng.shuffle(sh)
        null.append(jsd(bigrams(sh[:len(g1)]), bigrams(sh[len(g1):])))
    null = np.array(null)
    return dict(split=name, n1=len(g1), n0=len(g0), jsd=round(obs, 4), null_mean=round(float(null.mean()), 4),
                excess=round(obs - float(null.mean()), 4), perm_p=round(float((null >= obs).mean()), 4))


out = []
# pooled over agents
allr = recs
out.append(evaluate(allr, lambda r: r["agent"] == "gemini", "ALL: gemini vs rest (by agent)"))
out.append(evaluate(allr, lambda r: r["agent"] == "claude", "ALL: claude vs rest (by agent)"))
out.append(evaluate(allr, lambda r: r["end_state"] == "last_test_pass", "ALL: ends with own test pass vs not"))
med = {a: float(np.median([float(r["loop_span_share"]) for r in recs if r["agent"] == a])) for a in ("claude", "codex", "gemini")}
out.append(evaluate(allr, lambda r: float(r["loop_span_share"]) > med[r["agent"]], "ALL: loop-heavy vs loop-light (within-agent median)"))
out.append(evaluate(allr, lambda r: float(r["env_runs"]) > 0, "ALL: any environment phase vs none"))
cx = [r for r in recs if r["agent"] == "codex" and r["codex_outcome"] in ("compile_fail", "test_fail")]
out.append(evaluate(cx, lambda r: r["codex_outcome"] == "compile_fail", "CODEX: compile_fail vs test_fail (harness)"))
out.append(evaluate(cx, lambda r: r["end_state"] == "last_test_pass", "CODEX: ends with own test pass vs not"))
out.append(evaluate(cx, lambda r: float(r["loop_span_share"]) > med["codex"], "CODEX: loop-heavy vs loop-light"))
out.append(evaluate(cx, lambda r: float(r["env_runs"]) > 0, "CODEX: any environment phase vs none"))
for a in ("claude", "gemini"):
    rs = [r for r in recs if r["agent"] == a]
    out.append(evaluate(rs, lambda r: r["end_state"] == "last_test_pass", a.upper() + ": ends with own test pass vs not"))
    out.append(evaluate(rs, lambda r: float(r["loop_span_share"]) > med[a], a.upper() + ": loop-heavy vs loop-light"))
json.dump(out, open(os.path.join(OUT, "split_eval.json"), "w"), indent=1)
for d in out:
    print(d)

# non-circular split: bug is "env-hard" if EITHER OTHER agent had an environment phase on it
envb = {}
for r in recs:
    envb.setdefault(r["bug"], {})[r["agent"]] = float(r["env_runs"]) > 0


def env_hard_other(r):
    return any(v for a, v in envb[r["bug"]].items() if a != r["agent"])


print("\ncross-agent env-hard split (label from the OTHER two agents only):")
extra = []
extra.append(evaluate(allr, env_hard_other, "ALL: bug env-hard per other agents vs not"))
for a in ("claude", "codex", "gemini"):
    rs = [r for r in recs if r["agent"] == a]
    extra.append(evaluate(rs, env_hard_other, a.upper() + ": bug env-hard per other agents vs not"))
for d in extra:
    print(d)
out.extend(extra)
json.dump(out, open(os.path.join(OUT, "split_eval.json"), "w"), indent=1)

# write the Sankey for this split
from loops import sankey_layered, phase_graph
sk = {"_definition": "env_hard_bug = at least one of the OTHER two agents entered an environment phase "
                     "(env_setup) on this bug; the plotted agent's own labels are not used to define the split",
      "_eval": extra}
for a in ("claude", "codex", "gemini"):
    for lab, pred in (("env_hard_bug", env_hard_other), ("env_easy_bug", lambda r: not env_hard_other(r))):
        s = [seq(r) for r in recs if r["agent"] == a and pred(r)]
        sk[a + "|" + lab] = dict(sankey_layered(s), phase_graph=phase_graph(s))
# (sankey file now written by sankey_views.py)
print({k: v["n_trajectories"] for k, v in sk.items() if not k.startswith("_")})

# robustness: splits NOT defined from phase labels, and the env split re-scored with the
# 'environment' phase deleted from every sequence (so the defining node cannot drive the JSD)
import pickle
from common import load_trajectories
V = pickle.load(open(os.path.join(OUT, "_verdicts.pkl"), "rb"))
early = {k: sum(v["eff_fail"][:10]) >= 2 for k, v in V.items()}
_seq_orig = seq


def seq_noenv(r):
    s = [p for p in _seq_orig(r) if p != "environment"]
    return [p for i, p in enumerate(s) if i == 0 or p != s[i - 1]]


rob = []
print("\nrobustness:")
for nm, pool, lab in [("ALL: early-blocked (>=2 failures in first 10 actions) vs not", allr, lambda r: early[(r["bug"], r["agent"])]),
                      ("ALL: has failing retry chain vs not", allr, lambda r: float(r["n_retry_chains"]) > 0),
                      ("CODEX: early-blocked vs not", cx, lambda r: early[(r["bug"], r["agent"])]),
                      ("GEMINI: early-blocked vs not", [r for r in recs if r["agent"] == "gemini"], lambda r: early[(r["bug"], r["agent"])]),
                      ("CLAUDE: early-blocked vs not", [r for r in recs if r["agent"] == "claude"], lambda r: early[(r["bug"], r["agent"])])]:
    rob.append(evaluate(pool, lab, nm))
seq = seq_noenv
for nm, pool, lab in [("ALL [env phase deleted]: any environment phase vs none", allr, lambda r: float(r["env_runs"]) > 0),
                      ("CODEX [env phase deleted]: any environment phase vs none", cx, lambda r: float(r["env_runs"]) > 0),
                      ("CODEX [env phase deleted]: compile_fail vs test_fail", cx, lambda r: r["codex_outcome"] == "compile_fail"),
                      ("ALL [env phase deleted]: early-blocked vs not", allr, lambda r: early[(r["bug"], r["agent"])])]:
    rob.append(evaluate(pool, lab, nm))
seq = _seq_orig
for d in rob:
    print(d)
out.extend(rob)
json.dump(out, open(os.path.join(OUT, "split_eval.json"), "w"), indent=1)


def evaluate_stratified(pool, label, name, perms=2000, seed=1):
    """pooled split, but the permutation null shuffles labels WITHIN each agent, so a split that
    merely re-encodes agent identity gets no credit."""
    g1 = [r for r in pool if label(r)]
    g0 = [r for r in pool if not label(r)]
    obs = jsd(bigrams(g1), bigrams(g0))
    rng = random.Random(seed)
    by = {}
    for r in pool:
        by.setdefault(r["agent"], []).append(r)
    labs = {a: [label(r) for r in rs] for a, rs in by.items()}
    null = []
    for _ in range(perms):
        a1, a0 = [], []
        for a, rs in by.items():
            l = labs[a][:]
            rng.shuffle(l)
            for r, x in zip(rs, l):
                (a1 if x else a0).append(r)
        null.append(jsd(bigrams(a1), bigrams(a0)))
    null = np.array(null)
    return dict(split=name + " [agent-stratified null]", n1=len(g1), n0=len(g0), jsd=round(obs, 4),
                null_mean=round(float(null.mean()), 4), excess=round(obs - float(null.mean()), 4),
                perm_p=round(float((null >= obs).mean()), 4))


strat = []
for nm, lab in [("ALL: ends with own test pass vs not", lambda r: r["end_state"] == "last_test_pass"),
                ("ALL: loop-heavy vs loop-light", lambda r: float(r["loop_span_share"]) > med[r["agent"]]),
                ("ALL: any environment phase vs none", lambda r: float(r["env_runs"]) > 0),
                ("ALL: early-blocked vs not", lambda r: early[(r["bug"], r["agent"])]),
                ("ALL: has failing retry chain vs not", lambda r: float(r["n_retry_chains"]) > 0),
                ("ALL: bug env-hard per other agents", env_hard_other)]:
    strat.append(evaluate_stratified(allr, lab, nm))
seq = seq_noenv
strat.append(evaluate_stratified(allr, lambda r: float(r["env_runs"]) > 0, "ALL [env phase deleted]: any environment phase vs none"))
strat.append(evaluate_stratified(allr, lambda r: float(r["n_retry_chains"]) > 0, "ALL [env phase deleted]: has failing retry chain vs not"))
seq = _seq_orig
print("\nagent-stratified:")
for d in strat:
    print(d)
out.extend(strat)
json.dump(out, open(os.path.join(OUT, "split_eval.json"), "w"), indent=1)

print("\nwithin-agent retry-chain splits:")
rc = []
for a in ("claude", "codex", "gemini"):
    rs = [r for r in recs if r["agent"] == a]
    m = float(np.median([float(r["n_retry_chain_actions"]) for r in rs]))
    rc.append(evaluate(rs, lambda r: float(r["n_retry_chains"]) > 0, a.upper() + ": has failing retry chain"))
    rc.append(evaluate(rs, lambda r: float(r["n_retry_chain_actions"]) > m, a.upper() + ": retry-chain actions > agent median (%.0f)" % m))
    seq = seq_noenv
    rc.append(evaluate(rs, lambda r: float(r["n_retry_chain_actions"]) > m, a.upper() + " [env deleted]: retry-chain actions > agent median (%.0f)" % m))
    seq = _seq_orig
for d in rc:
    print(d)
out.extend(rc)
json.dump(out, open(os.path.join(OUT, "split_eval.json"), "w"), indent=1)

# write the recommended split Sankey: blocked (in a failing retry chain) vs not
skr = {"_definition": "retry_blocked = trajectory contains >=1 failing retry chain: >=2 actions of the same "
                      "mid-level with the same core command (env prefixes / output filters stripped), all "
                      "failing (tool error or failing test/build verdict), before a success of that command. "
                      "Defined from mid-level + results, not from phase labels.",
       "_eval": [d for d in out if "retry" in d["split"]]}
for a in ("claude", "codex", "gemini", "all"):
    for lab, pred in (("retry_blocked", lambda r: float(r["n_retry_chains"]) > 0),
                      ("not_retry_blocked", lambda r: float(r["n_retry_chains"]) == 0)):
        s = [seq(r) for r in recs if (a == "all" or r["agent"] == a) and pred(r)]
        if s:
            skr[a + "|" + lab] = dict(sankey_layered(s), phase_graph=phase_graph(s))
# (sankey file now written by sankey_views.py)
print({k: v["n_trajectories"] for k, v in skr.items() if not k.startswith("_")})
