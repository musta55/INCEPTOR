"""Do Codex retry chains / re-runs mean what the report says?"""
import sys, json, re, pickle
from collections import Counter
D = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops"
sys.path.insert(0, D)
from common import load_trajectories
from loops import norm_cmd, ASSIGN
T = load_trajectories(); V = pickle.load(open(D + "/_verdicts.pkl", "rb"))
I = [json.loads(l) for l in open(D + "/loop_instances.jsonl")]
for ag in ("codex", "gemini"):
    ch = [x for x in I if x["kind"] == "failing_retry_chain" and x["agent"] == ag]
    cross_edit = sum(1 for x in ch if x["edits_between"] > 0)
    phases = Counter()
    unrec = [x for x in ch if x["recovered_at"] is None]
    later_verdict = 0; unrec_trajs = set(); unrec_trajs_later = set()
    for x in ch:
        rows = T[(x["bug"], ag)]; idx = {r["action_index"]: i for i, r in enumerate(rows)}
        phases[tuple(sorted({rows[idx[m]]["high_level"] for m in x["members"]}))] += 1
    for x in unrec:
        rows = T[(x["bug"], ag)]; idx = {r["action_index"]: i for i, r in enumerate(rows)}
        vf = V[(x["bug"], ag)]["vfine"]
        last = idx[x["members"][-1]]
        unrec_trajs.add(x["bug"])
        if any(rows[j]["mid_level"] == "run_test" and vf[j] in ("pass", "test_fail") for j in range(last + 1, len(rows))):
            later_verdict += 1; unrec_trajs_later.add(x["bug"])
    print("==", ag, "chains", len(ch), "| with an edit between members:", cross_edit,
          "| member-phase sets:", dict(phases))
    print("   unrecovered", len(unrec), "in", len(unrec_trajs), "trajs; of these, a LATER run_test reached pass/test_fail anyway:",
          later_verdict, "chains in", len(unrec_trajs_later), "trajs")
    # trajectories where no run_test EVER reached a verdict
    never = [b for (b, a), rows in T.items() if a == ag and not any(rows[i]["mid_level"] == "run_test" and V[(b, a)]["vfine"][i] in ("pass", "test_fail") for i in range(len(rows)))]
    print("   trajectories where no run_test ever reached pass/test_fail:", len(never))
    # rerun_same_outcome: members differ how?
    rr = [x for x in I if x["kind"] == "rerun_same_outcome" and x["agent"] == ag]
    kinds = Counter(); errchange = 0; pairs = 0
    for x in rr:
        rows = T[(x["bug"], ag)]; idx = {r["action_index"]: i for i, r in enumerate(rows)}
        mem = [rows[idx[m]] for m in x["members"]]
        for p, q in zip(mem, mem[1:]):
            pairs += 1
            ap = {t for t in re.findall(r"(?:^|[\s;&(])([A-Za-z_][A-Za-z0-9_]*)=", p["command"])}
            aq = {t for t in re.findall(r"(?:^|[\s;&(])([A-Za-z_][A-Za-z0-9_]*)=", q["command"])}
            if norm_cmd(p["command"]) == norm_cmd(q["command"]): kinds["identical"] += 1
            elif ap != aq or ("export" in q["command"] and q["command"].count("export") != p["command"].count("export")): kinds["env-var/export differs"] += 1
            else: kinds["other diff (filter/flags)"] += 1
            # crude error signature: first line matching error-ish
            def sig(t):
                m = re.search(r"(SandboxDenied|Could not determine java version[^\n]*|Unsupported class file major version \d+|Operation not permitted|BUILD FAILED|What went wrong:\n[^\n]*|command not found|No connected devices|INSTALL_FAILED\w*)", t)
                return m.group(0)[:80] if m else "?"
            errchange += sig(p["content"]) != sig(q["content"])
    print("   rerun_same_outcome groups", len(rr), "pairs", pairs, dict(kinds), "| pairs whose error signature changes:", errchange)
