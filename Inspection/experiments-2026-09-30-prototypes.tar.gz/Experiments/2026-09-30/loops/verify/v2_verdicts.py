import sys, re, pickle
from collections import Counter
sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops")
from common import load_trajectories
T = load_trajectories()
V = pickle.load(open("/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops/_verdicts.pkl", "rb"))
ALT_FAIL = re.compile(r"tests? completed, \d+ failed|There were failing tests|> Task :\S*[Tt]est\S* FAILED|\bFAILED\b|Failures: [1-9]|failed: [1-9]|\d+ failed", re.I)
for ag in ("claude", "codex", "gemini"):
    dist = Counter(); miss = []
    for (b, a), rows in T.items():
        if a != ag: continue
        vf = V[(b, a)]["vfine"]
        for i, r in enumerate(rows):
            if r["mid_level"] not in ("run_test", "build"): continue
            dist[(r["high_level"], r["mid_level"], vf[i])] += 1
            if r["mid_level"] == "run_test" and vf[i] in ("infra_fail", "unknown", "build_fail"):
                text = r["content"]
                j = i + 1
                while j < len(rows) and rows[j]["mid_level"] == "wait_process":
                    text += "\n" + rows[j]["content"]; j += 1
                m = ALT_FAIL.search(text)
                if m:
                    miss.append((b, r["action_index"], vf[i], text[max(0, m.start()-120): m.end()+80].replace("\n", " | ")))
    print("=====", ag)
    for k, v in sorted(dist.items()): print("  ", k, v)
    print("  run_test non-verdict with an alt fail phrase:", len(miss))
    for x in miss[:12]: print("    ", x[:3], x[3][:260])
