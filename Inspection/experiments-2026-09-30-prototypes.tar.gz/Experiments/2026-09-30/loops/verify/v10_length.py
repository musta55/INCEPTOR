import csv, statistics as st
R = list(csv.DictReader(open("/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops/per_trajectory.csv")))
for a in ("claude", "codex", "gemini"):
    rs = [r for r in R if r["agent"] == a]
    f = lambda k, d: [float(r[k]) / float(r[d]) for r in rs if float(r[d]) > 0]
    print("%-7s revisits/runs median %.2f | revisits/actions median %.3f | fv_cycles per 10 actions mean %.3f | runs/actions median %.3f" % (
        a, st.median(f("revisits", "n_runs")), st.median(f("revisits", "n_actions")),
        10 * st.mean(f("fv_cycles", "n_actions")), st.median(f("n_runs", "n_actions"))))
    # length-matched: trajectories with 20-45 actions
    mid = [r for r in rs if 20 <= int(r["n_actions"]) <= 45]
    print("         20-45 actions: n=%d revisits median %.1f fv prevalence %.0f%%" % (
        len(mid), st.median(float(r["revisits"]) for r in mid), 100 * sum(float(r["fv_cycles"]) > 0 for r in mid) / len(mid)))
