import glob, json, os
from collections import Counter, defaultdict
ANN = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/corpus/annotation"
T = defaultdict(list)
types = Counter(); failed_vals = Counter(); scopes = Counter()
for f in sorted(glob.glob(ANN + "/bug-*_actions.jsonl")):
    for line in open(f):
        r = json.loads(line)
        types[type(r["action_index"]).__name__] += 1
        failed_vals[(r["agent"], repr(r["failed"]))] += 1
        scopes[(r["agent"], "main" if r["scope"] == "main" else "sub")] += 1
        T[(r["bug_id"], r["agent"])].append(r)
print("action_index types", types)
print("failed values", failed_vals)
print("scopes", scopes)
# action_index contiguous?
noncontig = 0
for k, rows in T.items():
    idx = sorted(r["action_index"] for r in rows)
    if idx != list(range(idx[0], idx[0] + len(idx))):
        noncontig += 1
print("non-contiguous trajectories", noncontig, "start values", Counter(min(r["action_index"] for r in rows) for rows in T.values()))
# file order vs action_index order
misorder = sum(1 for rows in T.values() if [r["action_index"] for r in rows] != sorted(r["action_index"] for r in rows))
print("trajectories where file order != action_index order:", misorder)
# Claude reproduction claim
for ag in ("claude", "codex", "gemini"):
    n_rep = sum(1 for (b, a), rows in T.items() if a == ag and any(r["high_level"] == "reproduction" for r in rows))
    # checks before first edit
    pre = Counter()
    first_edit_pos = []
    for (b, a), rows in T.items():
        if a != ag: continue
        rows = sorted(rows, key=lambda r: r["action_index"])
        fe = next((i for i, r in enumerate(rows) if r["mid_level"] == "edit_file"), None)
        first_edit_pos.append(fe if fe is not None else -1)
        for r in rows[: fe if fe is not None else len(rows)]:
            pre[r["mid_level"]] += 1
    print(ag, "trajs with reproduction:", n_rep, "mid_levels before first edit:", dict(pre))
    print("   first edit position (0-based) sorted:", sorted(first_edit_pos))
# phase counts
print(Counter(r["high_level"] for rows in T.values() for r in rows))
# sub-agent: does Claude delegate? are sub rows between main rows?
for (b, a), rows in T.items():
    if a == "claude" and any(r["scope"] != "main" for r in rows):
        rows = sorted(rows, key=lambda r: r["action_index"])
        print(b, [(r["action_index"], r["scope"][:8], r["mid_level"], r["high_level"]) for r in rows][:25])
        break
