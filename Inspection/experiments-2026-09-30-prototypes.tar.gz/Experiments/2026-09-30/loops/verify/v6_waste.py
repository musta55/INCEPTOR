"""Recompute the narrow waste share, counting a re-run / retry as waste only when it repeats the previous
member's error signature AND does not change env vars (a real state change)."""
import sys, json, re, pickle, statistics as st
from collections import defaultdict
D = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops"
sys.path.insert(0, D)
import importlib.util
spec = importlib.util.spec_from_file_location("cs", D + "/chain_signatures.py")
from common import load_trajectories
from loops import action_key, STATE_CHANGING, SKIP_STAGNANT
src = open(D + "/chain_signatures.py").read().split("T = load_trajectories()")[0]
ns = {}; exec(src, ns); signature = ns["signature"]
T = load_trajectories(); V = pickle.load(open(D + "/_verdicts.pkl", "rb"))
I = [json.loads(l) for l in open(D + "/loop_instances.jsonl")]
ASG = re.compile(r"(?:^|[\s;&(])([A-Za-z_][A-Za-z0-9_]*)=")
def text_of(rows, i):
    t = rows[i]["content"]; j = i + 1
    while j < len(rows) and rows[j]["mid_level"] == "wait_process":
        t += "\n" + rows[j]["content"]; j += 1
    return t
by = defaultdict(list)
for x in I: by[(x["bug"], x["agent"])].append(x)
orig = defaultdict(list); strict = defaultdict(list)
for (b, a), rows in T.items():
    n = len(rows); idx = {r["action_index"]: i for i, r in enumerate(rows)}
    eff = V[(b, a)]["eff_fail"]
    # noprog as in loops.py
    noprog = set(); last_seen = {}; last_change = -1
    for i, r in enumerate(rows):
        m = r["mid_level"]
        if m in SKIP_STAGNANT: continue
        if m in STATE_CHANGING: last_change = i; continue
        k = (m, action_key(r), eff[i])
        if k in last_seen and last_seen[k] > last_change: noprog.add(i)
        last_seen[k] = i
    chain_nf, rerun, chain_nf_s, rerun_s = set(), set(), set(), set()
    for x in by[(b, a)]:
        if x["kind"] not in ("failing_retry_chain", "rerun_same_outcome"): continue
        mem = [idx[m] for m in x["members"]]
        for p, q in zip(mem, mem[1:]):
            (chain_nf if x["kind"] == "failing_retry_chain" else rerun).add(q)
            same_err = signature(text_of(rows, p)) == signature(text_of(rows, q))
            same_env = set(ASG.findall(rows[p]["command"])) == set(ASG.findall(rows[q]["command"]))
            if same_err and same_env:
                (chain_nf_s if x["kind"] == "failing_retry_chain" else rerun_s).add(q)
    orig[a].append(len(noprog | chain_nf | rerun) / n)
    strict[a].append(len(noprog | chain_nf_s | rerun_s) / n)
for a in ("claude", "codex", "gemini"):
    print(a, "narrow waste median orig %.4f (prev %.0f%%) | strict %.4f (prev %.0f%%) | mean orig %.4f strict %.4f" % (
        st.median(orig[a]), 100 * sum(v > 0 for v in orig[a]) / 50, st.median(strict[a]),
        100 * sum(v > 0 for v in strict[a]) / 50, st.mean(orig[a]), st.mean(strict[a])))
