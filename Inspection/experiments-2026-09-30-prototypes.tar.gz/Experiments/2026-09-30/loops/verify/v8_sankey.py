import json
from collections import defaultdict
D = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops/"
for fn in ("sankey.json", "sankey_split_failheavy.json", "sankey_codex_outcome.json"):
    d = json.load(open(D + fn))
    for k, v in d.items():
        if not isinstance(v, dict) or "nodes" not in v: 
            print(fn, "non-bundle top-level key:", k, type(v).__name__); continue
        for view in ("main", "prefix_k10", "stages"):
            b = v if view == "main" else v[view]
            n = len(b["nodes"]); inflow = defaultdict(int); outflow = defaultdict(int); back = 0
            for l in b["links"]:
                inflow[l["target"]] += l["value"]; outflow[l["source"]] += l["value"]
                if b["nodes"][l["source"]]["layer"] >= b["nodes"][l["target"]]["layer"]: back += 1
                assert b["nodes"][l["source"]]["id"] == l["source_id"] and b["nodes"][l["target"]]["id"] == l["target_id"]
            src = [i for i in range(n) if inflow[i] == 0]; end = [i for i, x in enumerate(b["nodes"]) if x["id"] == "END"]
            bad = [b["nodes"][i]["id"] for i in range(n) if i not in src and b["nodes"][i]["id"] != "END" and inflow[i] != outflow[i]]
            if fn == "sankey.json" or view == "main":
                print("%-28s %-16s %-10s nodes %3d starts %4d END-in %4d n_traj %s non-conserving %d back-links %d" % (
                    fn, k, view, n, sum(outflow[i] for i in src), inflow[end[0]], v.get("n_trajectories"), len(bad), back))
