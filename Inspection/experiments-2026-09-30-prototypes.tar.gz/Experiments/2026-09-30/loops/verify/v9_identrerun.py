import sys, pickle, statistics as st
D = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops"
sys.path.insert(0, D)
from common import load_trajectories
from loops import norm_cmd, SKIP_STAGNANT
T = load_trajectories(); V = pickle.load(open(D + "/_verdicts.pkl", "rb"))
for ag in ("claude", "codex", "gemini"):
    tot = with_edit = 0; per = []; per_strict = []
    for (b, a), rows in T.items():
        if a != ag: continue
        eff = V[(b, a)]["eff_fail"]; seen = {}; c = cs = 0
        for i, r in enumerate(rows):
            if not r["command"] or r["mid_level"] in SKIP_STAGNANT: continue
            k = norm_cmd(r["command"])
            if eff[i]:
                if k in seen:
                    tot += 1; c += 1
                    j = seen[k]
                    if any(rows[x]["mid_level"] in ("edit_file", "env_setup") for x in range(j + 1, i)): with_edit += 1
                    else: cs += 1
                seen[k] = i   # compare with the most recent failing occurrence
        per.append(c); per_strict.append(cs)
    print("%-7s identical failing re-runs %3d | with an edit/env_setup since the previous failing run %3d | "
          "strict (no state change) prevalence %2.0f%% mean %.2f (orig prevalence %2.0f%% mean %.2f)" % (
          ag, tot, with_edit, 100 * sum(x > 0 for x in per_strict) / 50, st.mean(per_strict), 100 * sum(x > 0 for x in per) / 50, st.mean(per)))
