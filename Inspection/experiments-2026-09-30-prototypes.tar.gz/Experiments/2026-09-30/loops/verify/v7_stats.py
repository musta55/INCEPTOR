import csv, glob
import numpy as np
from scipy import stats
D = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops"
R = list(csv.DictReader(open(D + "/per_trajectory.csv")))
# outcome read directly with csv module (not naive split)
oc = {}
for f in glob.glob("/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset/results-localization-codex/test_results_run_*.csv"):
    for r in csv.DictReader(open(f)):
        oc[r["bug"]] = "compile_fail" if r["compile_fail"] == "Yes" else ("test_fail" if r["test_fail"] == "Yes" else "other")
cx = [r for r in R if r["agent"] == "codex"]
mism = [r["bug"] for r in cx if r["codex_outcome"] != oc[r["bug"]]]
print("outcome mismatches vs csv module:", mism, "| counts", {k: sum(1 for v in oc.values() if v == k) for k in set(oc.values())})
def mw(k, rows, grp):
    a = np.array([float(r[k]) for r in rows if grp(r) and r[k] != ""]); b = np.array([float(r[k]) for r in rows if not grp(r) and r[k] != ""])
    u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
    return 2 * u / (len(a) * len(b)) - 1, p, len(a), len(b)
for k in ("n_retry_chain_actions", "n_eff_failed", "env_runs", "env_returns", "n_env_setup", "n_actions", "n_failed"):
    print("codex", k, "r_rb %+.3f p %.5f n=%d/%d" % mw(k, cx, lambda r: oc[r["bug"]] == "compile_fail"))
for ag in ("claude", "gemini"):
    rs = [r for r in R if r["agent"] == ag]
    for k in ("env_runs", "n_env_setup", "n_eff_failed", "n_actions"):
        print(ag, "on codex-cf bugs", k, "r_rb %+.3f p %.5f n=%d/%d" % mw(k, rs, lambda r: oc[r["bug"]] == "compile_fail"))
# partial check: within Codex, does env struggle still separate outcome after controlling for the bug's env difficulty (Gemini env_setup)?
gem = {r["bug"]: float(r["n_env_setup"]) for r in R if r["agent"] == "gemini"}
easy = [r for r in cx if gem[r["bug"]] == 0]
print("codex bugs where gemini did 0 env_setup:", len(easy), "cf:", sum(oc[r["bug"]] == "compile_fail" for r in easy))
if sum(oc[r["bug"]] == "compile_fail" for r in easy) >= 3:
    for k in ("n_retry_chain_actions", "env_runs"):
        print("  within gemini-env-easy bugs", k, "r_rb %+.3f p %.4f n=%d/%d" % mw(k, easy, lambda r: oc[r["bug"]] == "compile_fail"))
# Codex: how many harness compile_fail bugs does gemini also struggle on
cf = [b for b, v in oc.items() if v == "compile_fail"]
print("cf bugs with gemini env_setup>0:", sum(gem[b] > 0 for b in cf), "/", len(cf), "| tf bugs:", sum(gem[b] > 0 for b, v in oc.items() if v == "test_fail"), "/", sum(v == "test_fail" for v in oc.values()))
