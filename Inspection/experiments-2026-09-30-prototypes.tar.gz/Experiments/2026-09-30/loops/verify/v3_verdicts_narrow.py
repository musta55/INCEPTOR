import sys, re, pickle
from collections import Counter
sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops")
from common import load_trajectories
T = load_trajectories()
V = pickle.load(open("/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops/_verdicts.pkl", "rb"))
TEST_FAIL2 = re.compile(r"tests? completed, \d+ failed|There were failing tests|Task :\S*(connected|[Tt]est)\S* FAILED|INSTRUMENTATION_STATUS_CODE: -2|Tests? FAILED|failures=\"[1-9]|\bFAIL:|OK \(|Tests run:|Results:", re.I)
for ag in ("codex", "gemini", "claude"):
    hits = []
    for (b, a), rows in T.items():
        if a != ag: continue
        vf = V[(b, a)]["vfine"]
        for i, r in enumerate(rows):
            if r["mid_level"] != "run_test" or vf[i] not in ("infra_fail", "unknown", "build_fail"): continue
            text = r["content"]; j = i + 1
            while j < len(rows) and rows[j]["mid_level"] == "wait_process":
                text += "\n" + rows[j]["content"]; j += 1
            m = TEST_FAIL2.search(text)
            if m:
                hits.append((b, r["action_index"], r["high_level"], vf[i], text[max(0, m.start()-150): m.end()+120].replace("\n", " | ")))
    print("=====", ag, "non-verdict run_test with test-output phrase:", len(hits), Counter((h[2], h[3]) for h in hits))
    for h in hits[:10]: print("   ", h[:4], h[4][:300])
