"""Independent re-implementation of fix-verify cycles from the jsonl + checks on the non-product share."""
import sys, json, glob
from collections import Counter, defaultdict
sys.path.insert(0, "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/experiments/loops")
from common import load_trajectories, rle
from loops import edit_target, is_product
T = load_trajectories()
for ag in ("claude", "codex", "gemini"):
    tot = 0; per_traj = Counter(); np_old = 0; np_closing = 0; np_traj = Counter()
    rep_runs = 0; rep_runs_np = 0
    for (b, a), rows in T.items():
        if a != ag: continue
        runs = rle([r["high_level"] for r in rows])
        def nonprod(run):
            p, s, e = run
            return any(rows[i]["mid_level"] == "edit_file" and not any(is_product(f) for f in edit_target(rows[i])) for i in range(s, e + 1))
        for run in runs:
            if run[0] == "repair":
                rep_runs += 1; rep_runs_np += nonprod(run)
        last_rep = None; seen_val = False
        for k, run in enumerate(runs):
            if run[0] == "repair":
                if last_rep is not None and seen_val:
                    tot += 1; per_traj[b] += 1
                    # the harness's way: any non-product edit anywhere in span
                    s, e = runs[last_rep][1], run[2]
                    if any(rows[i]["mid_level"] == "edit_file" and not any(is_product(f) for f in edit_target(rows[i])) for i in range(s, e + 1)):
                        np_old += 1; np_traj[b] += 1
                    if nonprod(run): np_closing += 1
                last_rep, seen_val = k, False
            elif run[0] == "validation" and last_rep is not None:
                seen_val = True
    print(ag, "cycles", tot, "trajs", len(per_traj), "top trajectories", per_traj.most_common(5))
    print("    cycles w/ non-product edit in span (reported method):", np_old, "in", len(np_traj), "trajs; top", np_traj.most_common(4))
    print("    cycles whose CLOSING repair run has a non-product edit (no double count):", np_closing)
    print("    repair runs:", rep_runs, "with non-product edit:", rep_runs_np)
