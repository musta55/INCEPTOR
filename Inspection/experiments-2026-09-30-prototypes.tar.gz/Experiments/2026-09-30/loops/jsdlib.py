"""Jensen-Shannon divergence between two groups' RLE phase-bigram distributions (START/END
included), with permutation nulls. Same maths as split_eval.py, importable without side effects."""
import random
from collections import Counter
import numpy as np


def seq_from_rec(r, drop=()):
    s = [x.split("(")[0] for x in r["phase_seq"].split(" > ")]
    s = [p for p in s if p not in drop]
    return [p for i, p in enumerate(s) if i == 0 or p != s[i - 1]]


def bigrams(seqs):
    c = Counter()
    for s in seqs:
        s = ["START"] + s + ["END"]
        c.update(zip(s, s[1:]))
    return c


def jsd(c1, c2):
    keys = sorted(set(c1) | set(c2))
    p = np.array([c1[k] for k in keys], float); p /= p.sum()
    q = np.array([c2[k] for k in keys], float); q /= q.sum()
    m = (p + q) / 2

    def kl(a, b):
        nz = a > 0
        return float(np.sum(a[nz] * np.log2(a[nz] / b[nz])))
    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def evaluate(recs, label, name, drop=(), perms=2000, seed=0, stratify=False, strata=None, tag=""):
    """observed JSD vs a label-permutation null. stratify=True shuffles labels within agent,
    so a split that only re-encodes agent identity gets no credit."""
    seqs = [seq_from_rec(r, drop) for r in recs]
    labs = [bool(label(r)) for r in recs]
    n1 = sum(labs)
    n0 = len(labs) - n1
    if n1 < 3 or n0 < 3:
        return dict(split=name, n1=n1, n0=n0, note="group too small")

    def score(ls):
        return jsd(bigrams([s for s, l in zip(seqs, ls) if l]), bigrams([s for s, l in zip(seqs, ls) if not l]))
    obs = score(labs)
    rng = random.Random(seed)
    groups = {}
    for i, r in enumerate(recs):
        key = strata(r) if strata else (r["agent"] if stratify else "_")
        groups.setdefault(key, []).append(i)
    null = []
    for _ in range(perms):
        ls = labs[:]
        for idx in groups.values():
            vals = [labs[i] for i in idx]
            rng.shuffle(vals)
            for i, v in zip(idx, vals):
                ls[i] = v
        null.append(score(ls))
    null = np.array(null)
    return dict(split=name + (" [agent-stratified null]" if stratify else "") + tag + (" [drop %s]" % ",".join(drop) if drop else ""),
                n1=n1, n0=n0, jsd=round(obs, 4), null_mean=round(float(null.mean()), 4),
                excess=round(obs - float(null.mean()), 4), perm_p=round(float((null >= obs).mean()), 4))
