"""What would a STATE-based phase rule change?  (proposal, not applied to the corpus labels)

rule v1 (current): build/run_test/device_ops/run_shell -> reproduction before the first edit_file of ANY
                   file, validation after it; every edit_file -> repair.
rule v2 (proposal): - edit_file of a non-product file (test script under androidTest / reproducing_script_project,
                      run_pipeline.sh, gradle / build config) -> 'harness_edit' (not repair)
                    - a check is 'validation' only while the product code carries an un-reverted edit;
                      otherwise it is 'reproduction'.  A git checkout/restore/stash that touches product
                      files resets the product state to baseline.
Prints how many actions change label and which new transitions become possible."""
import re
from collections import Counter
from common import load_trajectories, rle
from loops import edit_target, is_product

CHECK = ("build", "run_test", "device_ops", "run_shell")
REVERT = re.compile(r"git (checkout|restore|stash)\b(.*)", re.S)
T = load_trajectories()
chg = Counter()
new_tr = Counter()
repro_after_edit = Counter()
traj_changed = Counter()
for (bug, agent), rows in T.items():
    dirty = False
    v2 = []
    for r in rows:
        m, lab = r["mid_level"], r["high_level"]
        if m == "edit_file":
            if any(is_product(f) for f in edit_target(r)):
                dirty, new = True, "repair"
            else:
                new = "harness_edit"
        elif m in CHECK:
            new = "validation" if dirty else "reproduction"
        else:
            new = lab
        mm = REVERT.search(r["command"] or "")
        if mm and (is_product(mm.group(2)) or mm.group(1) == "stash" or " -- ." in mm.group(2) or mm.group(2).strip() == "."):
            dirty = False
        if m == "wait_process" and v2:
            new = v2[-1]
        v2.append(new)
    first_edit = next((i for i, r in enumerate(rows) if r["mid_level"] == "edit_file"), None)
    n = 0
    for i, (r, new) in enumerate(zip(rows, v2)):
        if new != r["high_level"]:
            chg[(agent, r["high_level"], new)] += 1
            n += 1
        if new == "reproduction" and first_edit is not None and i > first_edit:
            repro_after_edit[agent] += 1
    traj_changed[agent] += int(n > 0)
    ph = [p for p, _, _ in rle(v2)]
    for a, b in zip(ph, ph[1:]):
        if (a, b) in (("validation", "reproduction"), ("repair", "reproduction"), ("harness_edit", "reproduction")):
            new_tr[(agent, a + "->" + b)] += 1

print("label changes v1 -> v2 (agent, old, new): count")
for k, v in sorted(chg.items()):
    print("  ", k, v)
tot = Counter()
for (a, _, _), v in chg.items():
    tot[a] += v
print("actions relabeled per agent:", dict(tot), "| trajectories with any change:", dict(traj_changed))
print("reproduction actions AFTER the first edit under v2 (impossible under v1):", dict(repro_after_edit))
print("new back-transitions into reproduction:", dict(new_tr))
