"""Inside each failing retry chain (and each no-progress re-run group): is the agent hitting the SAME
error again (true stagnation) or a DIFFERENT error each time (peeling layers of an environment problem)?
Error signature = the name of the last-matching error pattern in the action's output (+ its polls)."""
import json, os, re
from collections import Counter
from common import load_trajectories, OUT

SIG = [("sandbox_denied", r"SandboxDenied|Operation not permitted"),
       ("java_version", r"Could not determine java version|Unsupported class file major version|"
                        r"jenv: version|Unable to locate a Java Runtime|java_home"),
       ("gradle_lock", r"Timeout waiting to lock|currently in use by another Gradle|\.lck"),
       ("sdk_or_keystore", r"SDK location not found|ANDROID_HOME|debug keystore|not writable|licen[cs]e"),
       ("dependency", r"Could not resolve|Could not find [\w.-]+:[\w.-]+|Required by:"),
       ("compile_error", r"error: |Compilation failed|compileDebugJava.*FAILED"),
       ("device", r"No connected devices|device offline|INSTALL_FAILED|adb: "),
       ("test_failed", r"FAILURES!!!|=== Results: \d+ passed, [1-9]|AssertionError"),
       ("command_not_found", r"command not found|No such file or directory"),
       ("build_failed_other", r"BUILD FAILED|FAILURE: Build failed"),
       ("exit_nonzero", r"Process exited with code [1-9]|Exit code [1-9]")]


def signature(text):
    best, pos = "none", -1
    for name, p in SIG:
        for m in re.finditer(p, text):
            if m.start() > pos:
                best, pos = name, m.start()
    return best


T = load_trajectories()
I = [json.loads(l) for l in open(os.path.join(OUT, "loop_instances.jsonl"))]
res = {}
for kind in ("failing_retry_chain", "rerun_same_outcome"):
    for a in ("claude", "codex", "gemini"):
        xs = [x for x in I if x["kind"] == kind and x["agent"] == a]
        if not xs:
            continue
        same = changed = 0
        sigs = Counter()
        for x in xs:
            rows = T[(x["bug"], a)]
            idx = {r["action_index"]: i for i, r in enumerate(rows)}
            ss = []
            for m in x["members"]:
                i = idx[m]
                text = rows[i]["content"]
                j = i + 1
                while j < len(rows) and rows[j]["mid_level"] == "wait_process":
                    text += "\n" + rows[j]["content"]
                    j += 1
                ss.append(signature(text))
            sigs.update(ss)
            if len(set(ss)) == 1:
                same += 1
            else:
                changed += 1
        res["%s|%s" % (kind, a)] = dict(n=len(xs), same_error_every_time=same, error_changes=changed,
                                        signature_counts=dict(sigs.most_common()))
        print("%-22s %-7s n=%3d same-error=%3d error-changes=%3d  signatures=%s" % (
            kind, a, len(xs), same, changed, dict(sigs.most_common(6))))
json.dump(res, open(os.path.join(OUT, "chain_signatures.json"), "w"), indent=1)
