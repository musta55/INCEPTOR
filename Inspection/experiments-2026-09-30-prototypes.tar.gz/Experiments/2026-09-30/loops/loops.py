"""Loop / inefficiency detectors over the 150-trajectory APR corpus.

Outputs (all under experiments/loops/):
  per_trajectory.csv          one row per (bug, agent) with every signal
  loop_instances.jsonl        every detected loop instance with action_index spans
  agent_summary.json          per-agent medians / means / prevalence
  transitions.json            RLE phase transition counts + row-normalised matrices
                              per agent and, for codex, per harness outcome
  (sankey_*.json are written by sankey_views.py, which reuses sankey_layered / phase_graph from here)
  construction_checks.json    what the positional phase rule makes impossible / mislabels
"""
import csv, json, os, re, statistics as st
from collections import Counter, defaultdict
from common import load_trajectories, codex_outcomes, rle, OUT, AGENTS

PHASES = ["orientation", "reproduction", "localization", "planning", "repair",
          "validation", "environment", "review"]
CHECK_MIDS = ("run_test", "build")
STATE_CHANGING = ("edit_file", "env_setup")      # actions that can legitimately change a re-run's result
SKIP_STAGNANT = ("wait_process", "plan")         # polling / todo updates are not "stagnant" actions

# ----------------------------------------------------------------------------- normalisation
WS_RE = re.compile(r"""/[^\s'"]*?/bug-\d+(?=/|\s|$|['"])/?""")


def norm_path(p):
    p = WS_RE.sub("", p or "").strip()
    p = re.sub(r"^\./", "", p)
    return re.sub(r"/+", "/", p)


SPLIT_RE = re.compile(r"&&|\|\||;|\n")
NOISE = {"cd", "export", "set", "unset", "source", ".", "mkdir", "pushd", "popd", "true", "eval"}
WRAP = {"sudo", "time", "nohup", "nice", "env", "command", "exec"}
FILTERS = {"tail", "head", "grep", "tee", "sed", "awk", "cat", "wc", "sort", "uniq", "cut", "rg"}
ASSIGN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*=\S*")


def norm_cmd(cmd):
    """exact key: workspace root removed, whitespace collapsed"""
    return " ".join(WS_RE.sub("<WS>/", cmd or "").split())


def core_cmd(cmd):
    """variant key: drop cd/export/env-assignment prefixes, redirections, output filters.
    `export GRADLE_USER_HOME=/tmp/g && ./run_pipeline.sh S1 2>&1 | tail -30` -> `run_pipeline.sh S1`"""
    text = WS_RE.sub("", cmd or "")
    text = re.sub(r"<<'?(\w+)'?.*?\n\1\b", " ", text, flags=re.S)       # heredoc bodies
    keep = []
    for seg in SPLIT_RE.split(text):
        parts = seg.split("|")
        head = parts[0]
        toks = head.replace("2>&1", " ").split()
        # drop redirections
        cleaned = []
        skip = False
        for t in toks:
            if skip:
                skip = False
                continue
            if t in (">", ">>", "2>", "&>", "<"):
                skip = True
                continue
            if re.match(r"^\d?[>&]+\S+", t) or t.startswith(">"):
                continue
            cleaned.append(t)
        toks = cleaned
        while toks and (ASSIGN.match(toks[0]) or toks[0] in WRAP):
            toks.pop(0)
        if toks and toks[0] == "timeout" and len(toks) > 1:
            toks = toks[2:]
        if not toks or toks[0] in NOISE or (keep and toks[0] in FILTERS):
            continue
        toks[0] = toks[0].rsplit("/", 1)[-1] if toks[0].endswith(".sh") or "gradlew" in toks[0] else toks[0]
        toks[0] = toks[0].lstrip("./") or toks[0]
        keep.append(" ".join(toks))
        # pipes after the head are output filters unless they run a real program
        for p in parts[1:]:
            pt = p.split()
            if pt and pt[0] not in FILTERS:
                keep.append(" ".join(pt))
    return " ; ".join(keep).strip()


READ_SHELL = re.compile(r"^(sed|cat|nl|head|tail|less|bat)\b")
PATHLIKE = re.compile(r"[\w./<>-]+\.(java|kt|xml|gradle|properties|sh|txt|md|json|kts|pro|cfg|yml|yaml|log)\b")


def read_targets(r):
    """(file, range) pairs for a read action; shell reads parsed from the command."""
    a = r["args"]
    if r["tool"] not in ("exec_command", "run_shell_command", "Bash"):
        f = norm_path(a.get("file_path") or a.get("absolute_path") or a.get("path") or r["target"])
        rng = "%s-%s" % (a.get("offset", a.get("start_line", "")), a.get("limit", a.get("end_line", "")))
        return [(f, rng)]
    out = []
    for seg in SPLIT_RE.split(WS_RE.sub("", r["command"])):
        seg = seg.strip()
        if READ_SHELL.match(seg) or seg.startswith("javap"):
            m = re.search(r"-n\s+'?([\d,$p]+)'?", seg)
            rng = m.group(1) if m else ""
            for pm in PATHLIKE.finditer(seg):
                out.append((norm_path(pm.group(0)), rng))
    return out


def edit_target(r):
    a = r["args"]
    if r["tool"] in ("apply_patch",) or "apply_patch" in (r["command"] or ""):
        txt = a.get("input") or r["command"] or json.dumps(a)
        fs = re.findall(r"\*\*\* (?:Update|Add|Delete) File: (\S+)", txt)
        return [norm_path(f) for f in fs] or [norm_path(r["target"])]
    return [norm_path(a.get("file_path") or a.get("path") or a.get("absolute_path") or r["target"])]


def action_key(r):
    """exact key used for stagnant-loop detection"""
    if r["command"]:
        return "cmd:" + norm_cmd(r["command"])
    a = r["args"]
    if r["mid_level"] == "search_code":
        return "search:%s|%s" % (a.get("pattern") or a.get("query") or "",
                                 norm_path(a.get("path") or a.get("dir_path") or a.get("include_pattern")
                                           or a.get("include") or a.get("glob") or ""))
    if r["mid_level"] == "read_file":
        f, rng = read_targets(r)[0]
        return "read:%s@%s" % (f, rng)
    if r["mid_level"] == "edit_file":
        return "edit:" + "|".join(edit_target(r))
    return "%s:%s" % (r["tool"], norm_path(r["target"]))


def variant_key(r):
    return "core:" + core_cmd(r["command"]) if r["command"] else action_key(r)


# ----------------------------------------------------------------------------- test verdicts
FAIL_PAT = [r"=== Results: \d+ passed, [1-9]\d* failed", r"FAILURES!!!", r"Tests run: \d+,\s+Failures: [1-9]",
            r">>> \S+: FAILED", r"INSTRUMENTATION_FAILED", r"Process crashed", r"shortMsg=Process crashed",
            r"java\.lang\.AssertionError"]
PASS_PAT = [r"=== Results: [1-9]\d* passed, 0 failed", r"\bOK \(\d+ tests?\)"]
BFAIL = [r"BUILD FAILED", r"Compilation failed", r"FAILURE: Build failed",
         r"Could not find or load main class"]
#: hard shell-error markers used for non-check shell actions (the per-agent `failed` flag is
#: exit-code based for codex, is_error for claude (masked by `| tail`), tool-status for gemini)
SHELL_ERR = re.compile(r"Operation not permitted|command not found|No such file or directory|^fatal: |"
                       r"Permission denied|exec_command failed|Exit code [1-9]|not installed|"
                       r"Unable to locate a Java Runtime", re.M)
SHELL_ERR_MIDS = ("env_setup", "run_shell", "device_ops", "vcs", "orient")
BPASS = [r"BUILD SUCCESSFUL"]


def _last(text, pats):
    best = -1
    for p in pats:
        for m in re.finditer(p, text):
            best = max(best, m.start())
    return best


INFRA = [r"SandboxDenied", r"Could not find or load main class", r"Operation not permitted",
         r"Unable to locate a Java Runtime", r"command not found", r"Could not determine java version",
         r"Unsupported class file major version", r"Timeout waiting to lock", r"currently in use by another Gradle",
         r"No connected devices", r"device offline", r"INSTALL_FAILED"]


def verdict_fine(r, text):
    """pass / test_fail / build_fail / infra_fail / unknown for a run_test or build action,
    from its (and its polls') output.  test_fail = the test RAN and failed (in reproduction that is the
    desired outcome); build_fail = compilation / gradle failure; infra_fail = sandbox, JDK, device,
    tool error -- execution never reached a verdict."""
    tf, tp = _last(text, FAIL_PAT), _last(text, PASS_PAT)
    bf, bp = _last(text, BFAIL), _last(text, BPASS)
    if r["mid_level"] == "run_test" and max(tf, tp) >= 0:
        return "test_fail" if tf > tp else "pass"
    infra = _last(text, INFRA) >= 0 or text.startswith("exec_command failed")
    if max(bf, bp) >= 0:
        if bf > bp:
            return "infra_fail" if infra else "build_fail"
        if r["mid_level"] == "build":
            return "pass"
    if r["is_failed"] or infra:
        return "infra_fail"
    m = re.search(r"Process exited with code (\d+)", text)
    if m:
        return "infra_fail" if m.group(1) != "0" else ("pass" if r["mid_level"] == "build" else "unknown")
    return "unknown"


def verdict(r, text):
    v = verdict_fine(r, text)
    return v if v in ("pass", "unknown") else "fail"


# ----------------------------------------------------------------------------- detectors
def phase_cycles(runs):
    ph = [x[0] for x in runs]
    n = len(ph)
    fv_cycles = 0            # repair ... validation ... repair (validation seen since previous repair run)
    seen_val = False
    seen_rep = False
    for p in ph:
        if p == "repair":
            if seen_rep and seen_val:
                fv_cycles += 1
            seen_rep, seen_val = True, False
        elif p == "validation" and seen_rep:
            seen_val = True
    val_to_loc = sum(1 for a, b in zip(ph, ph[1:]) if a == "validation" and b == "localization")
    # regression (broad): a validation run followed by localization before the next repair run
    regress_broad = 0
    pending = False
    for p in ph:
        if p == "validation":
            pending = True
        elif p == "localization" and pending:
            regress_broad += 1
            pending = False
        elif p == "repair":
            pending = False
    pingpong = sum(1 for a, b, c in zip(ph, ph[1:], ph[2:])
                   if a == c and {a, b} == {"localization", "repair"})
    env_runs = ph.count("environment")
    env_returns = max(env_runs - 1, 0)
    env_triples = sum(1 for a, b, c in zip(ph, ph[1:], ph[2:]) if a == c == "environment")
    revisits = n - len(set(ph))
    per_phase_rev = {p: max(ph.count(p) - 1, 0) for p in set(ph)}
    return dict(n_runs=n, fv_cycles=fv_cycles, val_to_loc=val_to_loc, regress_broad=regress_broad,
                loc_repair_pingpong=pingpong, env_runs=env_runs, env_returns=env_returns,
                env_x_env=env_triples, revisits=revisits, per_phase_rev=per_phase_rev)


def analyse(bug, agent, rows):
    n = len(rows)
    phases = [r["high_level"] for r in rows]
    mids = [r["mid_level"] for r in rows]
    runs = rle(phases)
    inst = []   # loop instances

    def ai(i):
        return rows[i]["action_index"]

    # --- effective failure: tool error OR failing test/build verdict (incl. following polls)
    verd = [None] * n
    vfine = [None] * n
    for i, r in enumerate(rows):
        if r["mid_level"] in CHECK_MIDS:
            text = r["content"]
            j = i + 1
            while j < n and rows[j]["mid_level"] == "wait_process":
                text += "\n" + rows[j]["content"]
                j += 1
            vfine[i] = verdict_fine(r, text)
            verd[i] = "pass" if vfine[i] == "pass" else ("unknown" if vfine[i] == "unknown" else "fail")
    eff_fail = [bool(r["is_failed"]) or verd[i] == "fail" or
                (r["command"] != "" and r["mid_level"] in SHELL_ERR_MIDS and bool(SHELL_ERR.search(r["content"][:4000])))
                for i, r in enumerate(rows)]
    # blocking failure: execution never produced a test verdict (tool / infra / build error).
    # A test that ran and failed is NOT blocking (in reproduction it is the goal).
    block = [eff_fail[i] and vfine[i] != "test_fail" for i in range(n)]

    # --- 1. phase cycles
    pc = phase_cycles(runs)
    # instance spans for fix-verify cycles and regressions
    seen_val, last_rep = None, None
    for k, (p, s, e) in enumerate(runs):
        if p == "repair":
            if last_rep is not None and seen_val is not None:
                inst.append(dict(kind="fix_verify_cycle", start=ai(runs[last_rep][1]), end=ai(e),
                                 phases=[x[0] for x in runs[last_rep:k + 1]]))
            last_rep, seen_val = k, None
        elif p == "validation" and last_rep is not None:
            seen_val = k
    for k in range(len(runs) - 1):
        if runs[k][0] == "validation" and runs[k + 1][0] == "localization":
            inst.append(dict(kind="validation_to_localization", start=ai(runs[k][1]), end=ai(runs[k + 1][2]),
                             phases=["validation", "localization"]))
    for k in range(len(runs) - 2):
        a, b, c = runs[k][0], runs[k + 1][0], runs[k + 2][0]
        if a == c and {a, b} == {"localization", "repair"}:
            inst.append(dict(kind="loc_repair_pingpong", start=ai(runs[k][1]), end=ai(runs[k + 2][2]),
                             phases=[a, b, c]))
    env_idx = [k for k, x in enumerate(runs) if x[0] == "environment"]
    for k1, k2 in zip(env_idx, env_idx[1:]):
        inst.append(dict(kind="environment_return", start=ai(runs[k1][1]), end=ai(runs[k2][2]),
                         phases=[x[0] for x in runs[k1:k2 + 1]]))

    # --- 2. mid-level stagnant loops (AgentDiff-style, literal): same mid, same key, same failed flag, >=2
    groups = defaultdict(list)
    for i, r in enumerate(rows):
        if r["mid_level"] in SKIP_STAGNANT:
            continue
        groups[(r["mid_level"], action_key(r), r["is_failed"])].append(i)
    stag = {k: v for k, v in groups.items() if len(v) >= 2}
    stag_fail = {k: v for k, v in stag.items() if k[2]}
    stag_by_mid = Counter(k[0] for k in stag)
    stag_consec = sum(1 for v in stag.values() if any(b == a + 1 for a, b in zip(v, v[1:])))
    for (m, key, f), v in stag_fail.items():
        inst.append(dict(kind="stagnant_failing_repeat", start=ai(v[0]), end=ai(v[-1]), mid=m, key=key[:160],
                         members=[ai(i) for i in v]))

    # --- 2b. identical failing command re-run (exact normalised command, effective failure)
    seen_fail_cmd = {}
    ident_fail_rerun = 0
    for i, r in enumerate(rows):
        if not r["command"] or r["mid_level"] in SKIP_STAGNANT:
            continue
        k = norm_cmd(r["command"])
        if eff_fail[i]:
            if k in seen_fail_cmd:
                ident_fail_rerun += 1
            seen_fail_cmd.setdefault(k, i)

    # --- 2c. no-progress repeats: same exact key & same effective outcome, no state change in between
    noprog = set()
    last_seen = {}
    last_change = -1
    for i, r in enumerate(rows):
        m = r["mid_level"]
        if m in SKIP_STAGNANT:
            continue
        if m in STATE_CHANGING:
            last_change = i
            # edits are the state change itself; do not count them as repeats
            continue
        k = (m, action_key(r), eff_fail[i])
        if k in last_seen and last_seen[k] > last_change:
            noprog.add(i)
        last_seen[k] = i

    # --- 2d. blocked retry chains on the VARIANT key: same core command, >=2 blocking failures before
    #         the command gets through (a pass OR a test that ran and failed closes the chain)
    chains = []
    open_chain = {}
    for i, r in enumerate(rows):
        if r["mid_level"] in SKIP_STAGNANT or r["mid_level"] in ("read_file", "search_code", "orient", "edit_file"):
            continue
        k = (r["mid_level"], variant_key(r))
        if block[i]:
            open_chain.setdefault(k, []).append(i)
        elif k in open_chain:
            c = open_chain.pop(k)
            if len(c) >= 2:
                chains.append((k, c, i))
    for k, c in open_chain.items():
        if len(c) >= 2:
            chains.append((k, c, None))
    for (m, key), c, rec in chains:
        inst.append(dict(kind="failing_retry_chain", start=ai(c[0]), end=ai(rec if rec is not None else c[-1]),
                         mid=m, key=key[:160], members=[ai(i) for i in c],
                         recovered_at=ai(rec) if rec is not None else None,
                         distinct_exact_cmds=len({norm_cmd(rows[i]["command"]) for i in c}),
                         edits_between=sum(1 for j in range(c[0], c[-1]) if rows[j]["mid_level"] == "edit_file"),
                         env_between=sum(1 for j in range(c[0], c[-1]) if rows[j]["mid_level"] == "env_setup"),
                         phase_first=rows[c[0]]["high_level"]))
    chain_members = {i for _, c, _ in chains for i in c}

    # --- 2e. no-progress CHECK re-runs on the variant key (env prefixes / output filters stripped):
    #         a build/run_test whose core command and parsed verdict equal an earlier check's, with no
    #         state-changing action in between (edit_file, env_setup, device_ops, or a reverting vcs command).
    #         Catches `run_pipeline.sh X | tail -30` followed by `run_pipeline.sh X | grep ...` (re-run only
    #         to read a different slice of the same output), which the exact-command detectors miss.
    def changes_state(r):
        if r["mid_level"] in ("edit_file", "env_setup", "device_ops"):
            return True
        return r["mid_level"] == "vcs" and bool(re.search(r"git (checkout|restore|stash|reset|apply|revert)\b", r["command"] or ""))
    rerun = []
    last_chk = {}
    last_change2 = -1
    for i, r in enumerate(rows):
        if changes_state(r):
            last_change2 = i
        if r["mid_level"] not in CHECK_MIDS or vfine[i] is None:
            continue
        k = (r["mid_level"], variant_key(r), vfine[i])
        j = last_chk.get(k)
        if j is not None and j > last_change2:
            rerun.append((j, i, norm_cmd(rows[j]["command"]) != norm_cmd(r["command"])))
        last_chk[k] = i
    rerun_idx = {i for _, i, _ in rerun}
    # group consecutive repeats of one key into one instance
    grp = {}
    for j, i, _ in rerun:
        root = next((g for g, mem in grp.items() if j in mem), None)
        if root is None:
            grp[j] = [j, i]
        else:
            grp[root].append(i)
    for mem in grp.values():
        inst.append(dict(kind="rerun_same_outcome", start=ai(mem[0]), end=ai(mem[-1]), mid=rows[mem[0]]["mid_level"],
                         key=variant_key(rows[mem[0]])[:160], verdict=vfine[mem[0]], members=[ai(i) for i in mem],
                         filter_only_variants=len({norm_cmd(rows[i]["command"]) for i in mem})))
    pure_chains = [c for _, c, _ in chains if not any(rows[j]["mid_level"] == "edit_file" for j in range(c[0], c[-1]))]

    # --- 3. inefficiency
    first_edit = next((i for i, m in enumerate(mids) if m == "edit_file"), None)
    last_edit = max((i for i, m in enumerate(mids) if m == "edit_file"), default=None)
    val_checks = [i for i, r in enumerate(rows) if r["mid_level"] in CHECK_MIDS and r["high_level"] == "validation"]
    last_val = val_checks[-1] if val_checks else None
    n_edits = mids.count("edit_file")
    ealv = sum(1 for i, m in enumerate(mids) if m == "edit_file" and (last_val is None or i > last_val))
    # repeated reads
    reads = []
    edit_pos = defaultdict(list)
    for i, r in enumerate(rows):
        if r["mid_level"] == "read_file":
            for f, rng in read_targets(r):
                reads.append((i, f, rng))
        if r["mid_level"] == "edit_file":
            for f in edit_target(r):
                edit_pos[f].append(i)
    per_file = Counter(f for _, f, _ in reads)
    repeated_reads = sum(c - 1 for c in per_file.values() if c > 1)
    files_reread = sum(1 for c in per_file.values() if c > 1)
    max_reads_one_file = max(per_file.values(), default=0)
    dup_reads = 0      # same file + same range, no edit to that file in between
    last_read = {}
    for i, f, rng in reads:
        k = (f, rng)
        if k in last_read and not any(last_read[k] < e < i for e in edit_pos.get(f, [])):
            dup_reads += 1
        last_read[k] = i
    # recovery windows (tool-error failures) : episode = first failure of mid m .. next success of m
    episodes = []
    open_ep = {}
    for i, r in enumerate(rows):
        m = r["mid_level"]
        if m in SKIP_STAGNANT:
            continue
        if r["is_failed"]:
            open_ep.setdefault(m, i)
        elif m in open_ep:
            s = open_ep.pop(m)
            episodes.append((m, s, i))
    unrec = [(m, s) for m, s in open_ep.items()]
    windows = [e - s for _, s, e in episodes]
    # recovery on validation tests: first failing validation test -> next passing validation test
    vt = [(i, verd[i]) for i in val_checks if rows[i]["mid_level"] == "run_test" and verd[i] in ("pass", "fail")]
    test_windows, test_unrec = [], 0
    k = 0
    while k < len(vt):
        if vt[k][1] == "fail":
            j = next((j for j in range(k + 1, len(vt)) if vt[j][1] == "pass"), None)
            if j is None:
                test_unrec += 1
                break
            test_windows.append(vt[j][0] - vt[k][0])
            k = j + 1
        else:
            k += 1
    # end state (additional Sankey split)
    after_last_edit = [i for i in val_checks if last_edit is not None and i > last_edit]
    tests_after = [i for i in after_last_edit if rows[i]["mid_level"] == "run_test" and verd[i] != "unknown"]
    builds_after = [i for i in after_last_edit if rows[i]["mid_level"] == "build" and verd[i] != "unknown"]
    if first_edit is None:
        end_state = "no_edit"
    elif not val_checks:
        end_state = "never_validated"
    elif ealv > 0:
        end_state = "edited_after_last_check"
    elif tests_after:
        end_state = "last_test_pass" if verd[tests_after[-1]] == "pass" else "last_test_fail"
    elif builds_after:
        end_state = "last_build_only_pass" if verd[builds_after[-1]] == "pass" else "last_test_fail"
    else:
        end_state = "last_check_unknown"
    # waste proxy (narrow): no-progress repeats + non-first members of failing retry chains
    #                       + no-progress check re-runs (2e)
    chain_nonfirst = {i for _, c, _ in chains for i in c[1:]}
    waste = noprog | chain_nonfirst | rerun_idx
    loop_span = set()   # broad: every action inside any detected phase cycle or chain span
    idx_of = {r["action_index"]: i for i, r in enumerate(rows)}
    for x in inst:
        if x["kind"] in ("fix_verify_cycle", "failing_retry_chain", "stagnant_failing_repeat",
                         "environment_return", "loc_repair_pingpong", "rerun_same_outcome"):
            loop_span.update(range(idx_of[x["start"]], idx_of[x["end"]] + 1))

    etargets = [edit_target(r) for r in rows if r["mid_level"] == "edit_file"]
    n_nonproduct_edits = sum(1 for ts in etargets if not any(is_product(x) for x in ts))
    n_test_script_edits = sum(1 for ts in etargets if any(TESTSCRIPT_RE.search(x) for x in ts))
    rep_checks = [i for i, r in enumerate(rows) if r["high_level"] == "reproduction" and r["mid_level"] in CHECK_MIDS]
    rep_tests = [i for i in rep_checks if rows[i]["mid_level"] == "run_test"]
    repro_achieved = any(vfine[i] == "test_fail" for i in rep_tests)
    first_verdict = next((i for i, v in enumerate(vfine) if v in ("pass", "test_fail") and rows[i]["mid_level"] == "run_test"), None)
    n_block_before_first_verdict = sum(1 for i in range(first_verdict if first_verdict is not None else n) if block[i]
                                       and rows[i]["mid_level"] in CHECK_MIDS + ("env_setup", "run_shell", "device_ops"))
    rec = dict(bug=bug, agent=agent, n_actions=n, n_failed=sum(r["is_failed"] for r in rows),
               n_eff_failed=sum(eff_fail), n_edits=n_edits,
               **{k: v for k, v in pc.items() if k != "per_phase_rev"},
               n_stagnant_groups=len(stag), n_stagnant_actions=sum(len(v) for v in stag.values()),
               n_stagnant_fail_groups=len(stag_fail), n_stagnant_fail_actions=sum(len(v) for v in stag_fail.values()),
               stagnant_consecutive_groups=stag_consec,
               stag_read=stag_by_mid["read_file"], stag_edit=stag_by_mid["edit_file"],
               stag_search=stag_by_mid["search_code"], stag_run_test=stag_by_mid["run_test"],
               stag_build=stag_by_mid["build"], stag_env=stag_by_mid["env_setup"], stag_orient=stag_by_mid["orient"],
               ident_fail_rerun=ident_fail_rerun, n_noprogress_repeats=len(noprog),
               n_rerun_same_outcome=len(rerun), n_rerun_filter_only=sum(1 for _, _, d in rerun if d),
               n_rerun_groups=len(grp), n_rerun_test_fail=sum(1 for _, i, _ in rerun if vfine[i] == "test_fail"),
               n_retry_chains=len(chains), n_retry_chain_actions=len(chain_members),
               n_retry_chains_unrecovered=sum(1 for c in chains if c[2] is None),
               n_pure_retry_chains=len(pure_chains), n_pure_retry_actions=sum(len(c) for c in pure_chains),
               n_nonproduct_edits=n_nonproduct_edits, n_test_script_edits=n_test_script_edits,
               n_repro_checks=len(rep_checks), n_repro_tests=len(rep_tests), repro_achieved=int(repro_achieved),
               repro_blocked=int(bool(rep_checks) and not any(vfine[i] in ("pass", "test_fail") for i in rep_tests)),
               n_block_before_first_verdict=n_block_before_first_verdict,
               first_test_verdict_at=(rows[first_verdict]["action_index"] if first_verdict is not None else ""),
               n_blocking=sum(block),
               n_env_setup=mids.count("env_setup"), n_wait=mids.count("wait_process"),
               edits_after_last_validation=ealv, has_ealv=int(ealv > 0), no_validation=int(last_val is None),
               repeated_reads=repeated_reads, files_reread=files_reread, max_reads_one_file=max_reads_one_file,
               dup_reads=dup_reads, n_fail_episodes=len(episodes) + len(unrec), n_unrecovered=len(unrec),
               median_recovery_window=(st.median(windows) if windows else ""),
               n_test_fail_episodes=len(test_windows) + test_unrec, test_unrecovered=test_unrec,
               median_test_recovery=(st.median(test_windows) if test_windows else ""),
               waste_share=round(len(waste) / n, 4), loop_span_share=round(len(loop_span) / n, 4),
               n_val_tests=sum(1 for i in val_checks if rows[i]["mid_level"] == "run_test"),
               n_val_tests_fail=sum(1 for i in val_checks if rows[i]["mid_level"] == "run_test" and verd[i] == "fail"),
               n_val_tests_pass=sum(1 for i in val_checks if rows[i]["mid_level"] == "run_test" and verd[i] == "pass"),
               end_state=end_state, phase_seq=" > ".join("%s(%d)" % (p, e - s + 1) for p, s, e in runs))
    for x in inst:
        x.update(bug=bug, agent=agent)
        if "phases" not in x:
            s, e = idx_of[x["start"]], idx_of[x["end"]]
            x["phases"] = [p for p, _, _ in rle(phases[s:e + 1])]
        s, e = idx_of[x["start"]], idx_of[x["end"]]
        x["mid_seq"] = [m for m, _, _ in rle(mids[s:e + 1])]
    extra = dict(runs=runs, verd=verd, vfine=vfine, block=block, eff_fail=eff_fail, first_edit=first_edit, rows=rows)
    return rec, inst, extra


# ----------------------------------------------------------------------------- construction checks
PRODUCT_RE = re.compile(r"(^|/)src/main/")          # app source incl. res/*.xml
TESTSCRIPT_RE = re.compile(r"androidTest|reproducing_script_project/.*Script\d")
PIPELINE_RE = re.compile(r"run_pipeline\.sh|gradle\.properties|build\.gradle|settings\.gradle|gradle-wrapper")


REPRO_INTENT = re.compile(r"without (the |my )?(fix|change|patch)|original (code|state)|baseline|"
                          r"fails? as expected|confirm (that )?(the )?(test|it|script\w*) (still )?fails|"
                          r"before (the|my|any) (fix|change|patch)|unfixed|unpatched|on (the )?original", re.I)


def is_product(f):
    return bool(PRODUCT_RE.search(f)) and "reproducing_script_project" not in f


def construction_checks(trajs):
    out = defaultdict(Counter)
    samples = defaultdict(list)
    for (bug, agent), rows in trajs.items():
        mids = [r["mid_level"] for r in rows]
        fe = next((i for i, m in enumerate(mids) if m == "edit_file"), None)
        repro_after = sum(1 for i, r in enumerate(rows) if r["high_level"] == "reproduction" and fe is not None and i > fe)
        val_before = sum(1 for i, r in enumerate(rows) if r["high_level"] == "validation" and (fe is None or i < fe))
        out[agent]["reproduction_after_first_edit"] += repro_after
        out[agent]["validation_before_first_edit"] += val_before
        out[agent]["trajectories"] += 1
        if fe is None:
            out[agent]["no_edit_at_all"] += 1
            continue
        f = edit_target(rows[fe])[0]
        if not is_product(f):
            out[agent]["trajs_first_edit_not_product_code"] += 1
            samples[agent + "_first_edit_not_product"].append("%s:%d %s" % (bug, rows[fe]["action_index"], f))
        # checks after the first edit but before the first PRODUCT edit are labeled validation although
        # nothing in the app has been patched yet (they are semantically reproduction / env debugging)
        fe_p = next((i for i, r in enumerate(rows) if r["mid_level"] == "edit_file"
                     and any(is_product(x) for x in edit_target(r))), None)
        lim = fe_p if fe_p is not None else len(rows)
        mis = sum(1 for i in range(fe + 1, lim) if rows[i]["mid_level"] in ("build", "run_test", "device_ops", "run_shell"))
        out[agent]["checks_labeled_validation_before_first_product_edit"] += mis
        out[agent]["trajs_with_such_checks"] += int(mis > 0)
        # revert-to-baseline-and-retest: a git checkout/restore of product code after the first edit,
        # followed (same command or next check before any edit) by a test -> semantically reproduction
        for i in range(fe + 1, len(rows)):
            r = rows[i]
            c = r["command"] or ""
            m = re.search(r"git (checkout|restore|stash)\b(.*)", c, re.S)
            if not m or not (is_product(m.group(2)) or "stash" in m.group(1)):
                continue
            if r["mid_level"] == "run_test":
                j = i
            else:
                j = next((j for j in range(i + 1, len(rows)) if rows[j]["mid_level"] in ("run_test", "edit_file")), None)
            if j is not None and rows[j]["mid_level"] == "run_test":
                out[agent]["revert_to_baseline_then_test_labeled_validation"] += 1
                samples[agent + "_revert_then_test"].append("%s:%d->%d" % (bug, r["action_index"], rows[j]["action_index"]))
        # stated intent says "reproduce / baseline / without the fix" but the rule says validation
        for i in range(fe + 1, len(rows)):
            r = rows[i]
            if r["high_level"] != "validation" or r["mid_level"] not in ("run_test", "build"):
                continue
            txt = (r["target"] if not r["command"] or r["target"] != " ".join(r["command"].split())[:200] else "") \
                + " " + (r["thought_preview"] or "")
            if REPRO_INTENT.search(txt):
                out[agent]["validation_checks_with_reproduction_intent"] += 1
                samples[agent + "_repro_intent"].append("%s:%d %s" % (bug, r["action_index"], txt.strip()[:90]))
        # edits to the test oracle / pipeline (not product code)
        te = [r for r in rows if r["mid_level"] == "edit_file" and any(TESTSCRIPT_RE.search(x) for x in edit_target(r))]
        pe = [r for r in rows if r["mid_level"] == "edit_file" and any(PIPELINE_RE.search(x) for x in edit_target(r))]
        out[agent]["edits_to_test_scripts"] += len(te)
        out[agent]["trajs_editing_test_scripts"] += int(bool(te))
        out[agent]["edits_to_pipeline_or_build_config"] += len(pe)
        out[agent]["trajs_editing_pipeline_or_build_config"] += int(bool(pe))
        for r in te[:1]:
            samples[agent + "_test_script_edit"].append("%s:%d %s" % (bug, r["action_index"], edit_target(r)[0]))
    return {k: dict(v) for k, v in out.items()}, {k: v[:25] for k, v in samples.items()}


# ----------------------------------------------------------------------------- transitions & sankey
def transitions(seqs):
    c = Counter()
    for ph in seqs:
        full = ["START"] + ph + ["END"]
        for a, b in zip(full, full[1:]):
            c[(a, b)] += 1
    return c


def matrix(c):
    rows = ["START"] + PHASES
    cols = PHASES + ["END"]
    m = {}
    for a in rows:
        tot = sum(c[(a, b)] for b in cols)
        m[a] = {b: (round(c[(a, b)] / tot, 3) if tot else 0.0) for b in cols}
        m[a]["_n"] = tot
    return m


def sankey_layered(seqs, K=10):
    """Acyclic, d3-sankey-ready: node = (run position k, phase). Runs beyond K collapse into
    'K+1: ...continues'; every trajectory terminates in END."""
    links = Counter()
    for ph in seqs:
        cut = ph[:K]
        nodes = ["%02d:%s" % (k + 1, p) for k, p in enumerate(cut)]
        tail = "%02d:...continues(>%d runs)" % (K + 1, K) if len(ph) > K else "END"
        nodes.append(tail)
        if tail != "END":
            nodes.append("END")
        for a, b in zip(nodes, nodes[1:]):
            links[(a, b)] += 1
    names = sorted({x for ab in links for x in ab}, key=lambda s: (s == "END", s))
    idx = {n: i for i, n in enumerate(names)}
    return dict(nodes=[dict(id=n, name=n.split(":", 1)[-1], layer=(int(n[:2]) if n[:2].isdigit() else K + 2))
                       for n in names],
                links=[dict(source=idx[a], target=idx[b], source_id=a, target_id=b, value=v)
                       for (a, b), v in sorted(links.items())],
                n_trajectories=len(seqs), max_layer=K)


def phase_graph(seqs):
    c = transitions(seqs)
    names = ["START"] + PHASES + ["END"]
    used = [n for n in names if any(n in ab for ab in c)]
    idx = {n: i for i, n in enumerate(used)}
    return dict(nodes=[dict(id=n, name=n) for n in used],
                links=[dict(source=idx[a], target=idx[b], source_id=a, target_id=b, value=v)
                       for (a, b), v in sorted(c.items())],
                note="cyclic (contains self-returns like repair->validation->repair); use for a force/chord view, "
                     "not d3-sankey")


def main():
    trajs = load_trajectories()
    oc = codex_outcomes()
    recs, insts, extras = [], [], {}
    for (bug, agent), rows in sorted(trajs.items(), key=lambda kv: (kv[0][1], int(kv[0][0]))):
        rec, inst, extra = analyse(bug, agent, rows)
        rec["codex_outcome"] = oc.get(bug, "") if agent == "codex" else ""
        recs.append(rec)
        insts.extend(inst)
        extras[(bug, agent)] = extra
    cols = list(recs[0].keys())
    with open(os.path.join(OUT, "per_trajectory.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(recs)
    with open(os.path.join(OUT, "loop_instances.jsonl"), "w") as f:
        for x in insts:
            f.write(json.dumps(x) + "\n")

    # per-agent summary
    numeric = [c for c in cols if c not in ("bug", "agent", "end_state", "phase_seq", "codex_outcome")]
    summ = {}
    for ag in AGENTS:
        rs = [r for r in recs if r["agent"] == ag]
        s = {"n": len(rs)}
        for c in numeric:
            vals = [float(r[c]) for r in rs if r[c] != ""]
            if not vals:
                continue
            q = sorted(vals)
            s[c] = dict(median=st.median(vals), mean=round(st.mean(vals), 3),
                        q1=q[len(q) // 4], q3=q[(3 * len(q)) // 4], max=max(vals),
                        prevalence=round(sum(1 for v in vals if v > 0) / len(vals), 3), n=len(vals))
        s["end_state"] = dict(Counter(r["end_state"] for r in rs))
        s["instances"] = dict(Counter(x["kind"] for x in insts if x["agent"] == ag))
        summ[ag] = s
    json.dump(summ, open(os.path.join(OUT, "agent_summary.json"), "w"), indent=1)

    # transitions
    def seqs_for(pred):
        return [[p for p, _, _ in extras[k]["runs"]] for k in extras if pred(k)]
    tr = {}
    for ag in AGENTS:
        c = transitions(seqs_for(lambda k: k[1] == ag))
        tr[ag] = dict(counts={"%s->%s" % ab: v for ab, v in sorted(c.items())}, row_normalised=matrix(c))
    for o in ("compile_fail", "test_fail"):
        c = transitions(seqs_for(lambda k: k[1] == "codex" and oc.get(k[0]) == o))
        tr["codex|" + o] = dict(counts={"%s->%s" % ab: v for ab, v in sorted(c.items())}, row_normalised=matrix(c))
    json.dump(tr, open(os.path.join(OUT, "transitions.json"), "w"), indent=1)

    # all sankey_*.json files are written by sankey_views.py (single writer, one bundle format)

    cc, samples = construction_checks(trajs)
    json.dump(dict(counts=cc, samples=samples), open(os.path.join(OUT, "construction_checks.json"), "w"), indent=1)
    import pickle
    pickle.dump({k: dict(verd=v["verd"], vfine=v["vfine"], block=v["block"], eff_fail=v["eff_fail"]) for k, v in extras.items()},
                open(os.path.join(OUT, "_verdicts.pkl"), "wb"))
    print("wrote", len(recs), "trajectories,", len(insts), "loop instances")


if __name__ == "__main__":
    main()
