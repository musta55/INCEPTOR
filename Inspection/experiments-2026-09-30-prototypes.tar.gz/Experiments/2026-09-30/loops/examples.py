"""Hand-picked loop examples (chosen from detector output) printed action by action, and cross-checked
against the human-readable transcripts in corpus/reading/: each '## N. <mid> / <phase>' header must
match the annotation row with action_index N.  Also reports which detector instance covers the span."""
import json, os, pickle, re
from common import load_trajectories, OUT, S

EXAMPLES = [
    ("codex", "8", 2, 5, "failed reproduction attempt (failing retry chain on run_pipeline.sh, never recovered)"),
    ("gemini", "44", 12, 20, "fix-verify cycles driven by failing tests: repair -> validation(test_fail) -> localization -> repair, twice"),
    ("claude", "114", 17, 26, "re-run-to-read-output loop: same pipeline run 5x with different | tail/grep filters, no edit in between"),
    ("codex", "44", 21, 27, "environment return loop: env_setup -> read -> env_setup -> build fail x2 -> env_setup x2"),
    ("gemini", "123451", 21, 24, "validation oscillation without edits: single test passes, full suite fails, repeated (flaky / order-dependent)"),
    ("gemini", "18", 33, 37, "FALSE POSITIVE of the phase rule: a 'fix-verify cycle' that is really build-config (environment) repair"),
]

T = load_trajectories()
V = pickle.load(open(os.path.join(OUT, "_verdicts.pkl"), "rb"))
INST = [json.loads(l) for l in open(os.path.join(OUT, "loop_instances.jsonl"))]
HDR = re.compile(r"^## (\d+)\. (\S+) / (\S+)\s+\((.+?)\)", re.M)

for agent, bug, s, e, why in EXAMPLES:
    rows = T[(bug, agent)]
    v = V[(bug, agent)]
    md = os.path.join(S, "corpus/reading/bug-%s_%s.md" % (bug, agent))
    hdr = {int(m.group(1)): (m.group(2), m.group(3), m.group(4)) for m in HDR.finditer(open(md).read())}
    print("=" * 110)
    print("bug-%s %s actions %d-%d : %s" % (bug, agent, s, e, why))
    print("verify in:", md)
    ok = True
    for i, r in enumerate(rows):
        if not s <= r["action_index"] <= e:
            continue
        h = hdr.get(r["action_index"])
        match = h is not None and h[0] == r["mid_level"] and h[1] == r["high_level"]
        ok &= match
        tgt = (r["command"] or r["target"]).replace("\n", " ")
        tgt = re.sub(r"/(Users|Volumes)/[^ ]*?/bug-\d+/", "<ws>/", tgt)[:88]
        print("  %3d %-12s %-12s failed=%-5s verdict=%-10s %s%s" % (
            r["action_index"], r["high_level"], r["mid_level"], r["failed"], v["vfine"][i] or "-", tgt,
            "" if match else "   <-- MISMATCH with reading md"))
    cover = sorted({x["kind"] for x in INST if x["bug"] == bug and x["agent"] == agent
                    and x["start"] <= e and x["end"] >= s})
    print("  reading-md headers match annotation:", ok, "| overlapping detector instances:", cover)
