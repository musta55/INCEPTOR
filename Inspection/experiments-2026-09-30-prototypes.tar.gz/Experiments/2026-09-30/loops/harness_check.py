"""How much can the Codex harness verdict be trusted as an outcome label?  Tabulates the 50 CSVs."""
import csv, glob, os
from collections import Counter
from common import CODEX_RES

rows = []
for f in glob.glob(os.path.join(CODEX_RES, "test_results_run_*.csv")):
    rows += list(csv.DictReader(open(f)))
print("csv rows:", len(rows))
print("(pass,test_fail,compile_fail):", dict(Counter((r["pass"], r["test_fail"], r["compile_fail"]) for r in rows)))
print("all_test_results:", dict(Counter(r["all_test_results"] for r in rows)))
print("all_failed_tests:", dict(Counter(r["all_failed_tests"] for r in rows)))
print("failed_tests non-empty:", sum(1 for r in rows if r["failed_tests"].strip()))
print("compile_fail bugs:", sorted((r["bug"] for r in rows if r["compile_fail"] == "Yes"), key=int))
