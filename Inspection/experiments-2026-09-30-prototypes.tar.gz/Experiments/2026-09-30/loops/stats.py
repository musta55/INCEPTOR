"""Codex only: relate each loop/inefficiency signal to the harness outcome
(compile_fail n=15 vs test_fail n=35; there are no passes). Exploratory.
Also: cross-agent Kruskal-Wallis for context, and end_state x harness outcome.
Run with:  uv run --no-project --with scipy python3 stats.py
"""
import csv, json, os
from collections import Counter
import numpy as np
from scipy import stats
from common import OUT

recs = list(csv.DictReader(open(os.path.join(OUT, "per_trajectory.csv"))))
cx = [r for r in recs if r["agent"] == "codex" and r["codex_outcome"] in ("compile_fail", "test_fail")]
CONT = ["n_actions", "n_runs", "n_failed", "n_eff_failed", "n_edits", "n_nonproduct_edits", "n_env_setup", "n_wait",
        "fv_cycles", "val_to_loc", "regress_broad", "loc_repair_pingpong", "env_runs", "env_returns", "revisits",
        "n_stagnant_groups", "n_stagnant_actions", "ident_fail_rerun", "n_noprogress_repeats",
        "n_retry_chains", "n_retry_chain_actions", "n_retry_chains_unrecovered",
        "repeated_reads", "files_reread", "dup_reads", "n_fail_episodes", "n_unrecovered",
        "median_recovery_window", "n_test_fail_episodes", "median_test_recovery",
        "waste_share", "loop_span_share", "n_val_tests", "n_val_tests_fail", "n_val_tests_pass"]
BIN = {"has_fv_cycle": lambda r: float(r["fv_cycles"]) > 0,
       "has_env_return": lambda r: float(r["env_returns"]) > 0,
       "has_unrecovered_retry_chain": lambda r: float(r["n_retry_chains_unrecovered"]) > 0,
       "has_stagnant_group": lambda r: float(r["n_stagnant_groups"]) > 0,
       "has_nonproduct_edit": lambda r: float(r["n_nonproduct_edits"]) > 0,
       "ends_with_own_test_pass": lambda r: r["end_state"] == "last_test_pass",
       "has_test_unrecovered": lambda r: float(r["test_unrecovered"]) > 0}


def holm(ps):
    order = np.argsort(ps)
    m = len(ps)
    adj = np.empty(m)
    run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * ps[i])
        adj[i] = min(run, 1.0)
    return adj


res = {"n": dict(Counter(r["codex_outcome"] for r in cx)), "continuous": {}, "binary": {}}
rows = []
for c in CONT:
    a = np.array([float(r[c]) for r in cx if r["codex_outcome"] == "compile_fail" and r[c] != ""])
    b = np.array([float(r[c]) for r in cx if r["codex_outcome"] == "test_fail" and r[c] != ""])
    if len(a) < 3 or len(b) < 3 or (np.all(a == a[0]) and np.all(b == a[0])):
        continue
    u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
    rbc = 2 * u / (len(a) * len(b)) - 1          # rank-biserial, >0 means compile_fail larger
    rows.append((c, p))
    res["continuous"][c] = dict(compile_fail_median=float(np.median(a)), test_fail_median=float(np.median(b)),
                                compile_fail_mean=round(float(a.mean()), 3), test_fail_mean=round(float(b.mean()), 3),
                                n_cf=len(a), n_tf=len(b), U=float(u), p=round(float(p), 4),
                                rank_biserial=round(float(rbc), 3))
adj = holm(np.array([p for _, p in rows]))
for (c, _), q in zip(rows, adj):
    res["continuous"][c]["p_holm"] = round(float(q), 4)
brow = []
for name, f in BIN.items():
    t = [[sum(1 for r in cx if r["codex_outcome"] == o and f(r)), sum(1 for r in cx if r["codex_outcome"] == o and not f(r))]
         for o in ("compile_fail", "test_fail")]
    orr, p = stats.fisher_exact(t)
    brow.append((name, p))
    res["binary"][name] = dict(table_cf_yes_no=t[0], table_tf_yes_no=t[1],
                               share_cf=round(t[0][0] / 15, 3), share_tf=round(t[1][0] / 35, 3),
                               odds_ratio=(round(float(orr), 3) if np.isfinite(orr) else "inf"), p=round(float(p), 4))
adjb = holm(np.array([p for _, p in brow]))
for (c, _), q in zip(brow, adjb):
    res["binary"][c]["p_holm"] = round(float(q), 4)
res["end_state_x_outcome"] = {o: dict(Counter(r["end_state"] for r in cx if r["codex_outcome"] == o))
                              for o in ("compile_fail", "test_fail")}

# cross-agent context (Kruskal-Wallis), not an outcome analysis
kw = {}
for c in ["n_actions", "fv_cycles", "regress_broad", "env_returns", "revisits", "n_retry_chains",
          "n_stagnant_groups", "ident_fail_rerun", "repeated_reads", "waste_share", "loop_span_share",
          "n_failed", "n_eff_failed"]:
    g = [[float(r[c]) for r in recs if r["agent"] == a] for a in ("claude", "codex", "gemini")]
    h, p = stats.kruskal(*g)
    kw[c] = dict(H=round(float(h), 3), p=float("%.3g" % p), medians=[float(np.median(x)) for x in g])
res["kruskal_by_agent"] = kw
json.dump(res, open(os.path.join(OUT, "codex_outcome_tests.json"), "w"), indent=1)

print("n", res["n"])
print("%-28s %8s %8s %7s %7s %7s" % ("signal", "cf_med", "tf_med", "r_rb", "p", "p_holm"))
for c, d in sorted(res["continuous"].items(), key=lambda kv: kv[1]["p"]):
    print("%-28s %8.3g %8.3g %7.3f %7.4f %7.4f" % (c, d["compile_fail_median"], d["test_fail_median"],
                                                  d["rank_biserial"], d["p"], d["p_holm"]))
print()
for c, d in sorted(res["binary"].items(), key=lambda kv: kv[1]["p"]):
    print("%-30s cf %s/15  tf %s/35  OR %s p %.4f holm %.4f" % (c, d["table_cf_yes_no"][0], d["table_tf_yes_no"][0],
                                                               d["odds_ratio"], d["p"], d["p_holm"]))
print(res["end_state_x_outcome"])
print()
for c, d in kw.items():
    print("KW %-22s H=%.2f p=%.3g medians(cl,cx,ge)=%s" % (c, d["H"], d["p"], d["medians"]))

# bug-level confound: do the OTHER agents also struggle more on the bugs where codex hit compile_fail?
oc = {r["bug"]: r["codex_outcome"] for r in cx}
conf = {}
print("\nconfound check: other agents on codex-compile_fail bugs vs codex-test_fail bugs")
for ag in ("claude", "gemini"):
    for c in ("n_eff_failed", "env_runs", "n_env_setup", "n_retry_chains", "n_actions"):
        a = [float(r[c]) for r in recs if r["agent"] == ag and oc.get(r["bug"]) == "compile_fail"]
        b = [float(r[c]) for r in recs if r["agent"] == ag and oc.get(r["bug"]) == "test_fail"]
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        rbc = 2 * u / (len(a) * len(b)) - 1
        conf["%s|%s" % (ag, c)] = dict(cf_median=float(np.median(a)), tf_median=float(np.median(b)),
                                       cf_mean=round(float(np.mean(a)), 3), tf_mean=round(float(np.mean(b)), 3),
                                       rank_biserial=round(float(rbc), 3), p=round(float(p), 4))
        print("  %-7s %-15s cf med %.1f mean %.2f | tf med %.1f mean %.2f | r_rb %.3f p %.4f" % (
            ag, c, np.median(a), np.mean(a), np.median(b), np.mean(b), rbc, p))
res["bug_level_confound_other_agents"] = conf
json.dump(res, open(os.path.join(OUT, "codex_outcome_tests.json"), "w"), indent=1)
