"""Shared loader for the loops experiment. Read-only over the corpus."""
import glob, json, os, re
S = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad"
ANN = os.path.join(S, "corpus/annotation")
ATIF = os.path.join(S, "corpus/atif")
CODEX_RES = "/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset/results-localization-codex"
OUT = os.path.join(S, "experiments/loops")
AGENTS = ("claude", "codex", "gemini")


def shell_command(args):
    # mirrors Parser/atif/taxonomy.shell_command (re-implemented to avoid importing
    # from the read-only Parser dir, which would write __pycache__ there)
    args = args or {}
    for key in ("cmd", "command", "input", "shell_command", "script"):
        v = args.get(key)
        if isinstance(v, str) and v:
            return v
        if isinstance(v, list):
            return " ".join(str(x) for x in v)
    return ""


def _index_calls(traj, out):
    for step in traj.get("steps", []):
        res = {r.get("source_call_id"): r for r in (step.get("observation") or {}).get("results", [])}
        for c in step.get("tool_calls") or []:
            r = res.get(c["tool_call_id"]) or {}
            content = r.get("content") or ""
            if not isinstance(content, str):
                content = json.dumps(content)
            out[c["tool_call_id"]] = {"args": c.get("arguments") or {},
                                      "command": shell_command(c.get("arguments")),
                                      "content": content,
                                      "extra": r.get("extra") or {}}
    for sub in traj.get("subagent_trajectories") or []:
        _index_calls(sub, out)


def load_trajectories():
    """{(bug, agent): [row,...]} in action_index order, rows enriched with the raw
    shell command and full result text from ATIF (joined on call_id)."""
    trajs = {}
    for f in sorted(glob.glob(os.path.join(ANN, "bug-*_actions.jsonl"))):
        for line in open(f):
            r = json.loads(line)
            trajs.setdefault((r["bug_id"], r["agent"]), []).append(r)
    for (bug, agent), rows in trajs.items():
        rows.sort(key=lambda r: r["action_index"])
        calls = {}
        p = os.path.join(ATIF, f"bug-{bug}_{agent}.atif.json")
        _index_calls(json.load(open(p)), calls)
        for r in rows:
            c = calls.get(r["call_id"], {})
            r["command"] = c.get("command", "")
            r["args"] = c.get("args", {})
            r["content"] = c.get("content", "")
            r["is_failed"] = (r["failed"] == "true")
    return trajs


def codex_outcomes():
    out = {}
    for f in glob.glob(os.path.join(CODEX_RES, "test_results_run_*.csv")):
        lines = open(f).read().strip().splitlines()
        hdr = lines[0].split(",")
        vals = lines[1].split(",")
        d = dict(zip(hdr, vals))
        oc = "pass" if d["pass"] == "Yes" else ("compile_fail" if d["compile_fail"] == "Yes"
                                                   else ("test_fail" if d["test_fail"] == "Yes" else "other"))
        out[d["bug"]] = oc
    return out


def rle(seq):
    out = []
    for i, x in enumerate(seq):
        if out and out[-1][0] == x:
            out[-1][2] = i
        else:
            out.append([x, i, i])
    return out  # [label, start_pos, end_pos] (positions are 0-based indices into rows)
