"""Second round of Sankey-split candidates, restricted to splits that are NOT defined from the
phase labels themselves (so a JSD difference cannot be true by construction) and that are
balanced WITHIN each agent (median splits), so the split can be drawn per agent.

Selection criterion, fixed before looking at results:
  1. pooled over agents, agent-stratified permutation p < 0.05 (not just re-encoding agent)
  2. still p < 0.05 (stratified) when the 'environment' phase is deleted from every sequence
  3. >= 10 trajectories on each side within every agent
  4. pooled p < 0.05 under a LENGTH-controlled null (labels shuffled within agent x n_runs-tercile
     strata): bigram distributions include START/END, whose weight is 2/(n_runs+1), so any split
     correlated with length gets JSD for free.  'long (n_actions)' is kept only as that reference.
  5. among survivors, largest mean within-agent length-controlled excess JSD
Writes split_eval2.json and prints a table.  Run after loops.py.
"""
import csv, json, os, statistics as st
from common import OUT
from jsdlib import evaluate

recs = list(csv.DictReader(open(os.path.join(OUT, "per_trajectory.csv"))))
AG = ("claude", "codex", "gemini")


def f(r, k):
    return float(r[k]) if r[k] != "" else None


def first_verdict_share(r):
    v = r["first_test_verdict_at"]
    return 1.0 if v == "" else (float(v) - 1) / float(r["n_actions"])


FEATS = {
    "slow_start (share of actions before first test verdict)": first_verdict_share,
    "block_heavy (blocking failures per action)": lambda r: f(r, "n_blocking") / f(r, "n_actions"),
    "fail_heavy (effective failures per action)": lambda r: f(r, "n_eff_failed") / f(r, "n_actions"),
    "reread_heavy (repeated reads per action)": lambda r: f(r, "repeated_reads") / f(r, "n_actions"),
    "long (n_actions)": lambda r: f(r, "n_actions"),
}
def _terciles():
    t = {}
    for a in AG:
        rs = sorted((int(r["n_runs"]), r["bug"]) for r in recs if r["agent"] == a)
        for k, (_, b) in enumerate(rs):
            t[(b, a)] = min(3 * k // len(rs), 2)
    return t


TER = _terciles()


def len_strata(r):
    return (r["agent"], TER[(r["bug"], r["agent"])])


med = {(name, a): st.median([fn(r) for r in recs if r["agent"] == a]) for name, fn in FEATS.items() for a in AG}
splits = {name: (lambda fn, name: (lambda r: fn(r) > med[(name, r["agent"])]))(fn, name) for name, fn in FEATS.items()}
splits["own_last_check_not_pass (resolved/unresolved substitute)"] = lambda r: r["end_state"] != "last_test_pass"

out = []
for name, lab in splits.items():
    row = dict(split=name, per_agent_sizes={a: [sum(1 for r in recs if r["agent"] == a and lab(r)),
                                                 sum(1 for r in recs if r["agent"] == a and not lab(r))] for a in AG})
    row["pooled_strat"] = evaluate(recs, lab, name, stratify=True)
    row["pooled_strat_noenv"] = evaluate(recs, lab, name, stratify=True, drop=("environment",))
    row["pooled_lenctl"] = evaluate(recs, lab, name, strata=len_strata, tag=" [agent x length-tercile null]")
    row["within_lenctl"] = {a: evaluate([r for r in recs if r["agent"] == a], lab, name, strata=len_strata,
                                        tag=" [length-tercile null]") for a in AG}
    row["within"] = {a: evaluate([r for r in recs if r["agent"] == a], lab, name) for a in AG}
    row["within_noenv"] = {a: evaluate([r for r in recs if r["agent"] == a], lab, name, drop=("environment",)) for a in AG}
    ok_sizes = all(min(v) >= 10 for v in row["per_agent_sizes"].values())
    ps = row["pooled_strat"].get("perm_p", 1)
    pn = row["pooled_strat_noenv"].get("perm_p", 1)
    pl = row["pooled_lenctl"].get("perm_p", 1)
    ex = [row["within_lenctl"][a].get("excess", 0) for a in AG]
    row["mean_within_excess_lenctl"] = round(sum(ex) / 3, 4)
    row["mean_within_excess"] = round(sum(row["within"][a].get("excess", 0) for a in AG) / 3, 4)
    row["passes_criteria"] = bool(ps < 0.05 and pn < 0.05 and pl < 0.05 and ok_sizes and not name.startswith("long"))
    out.append(row)

out.sort(key=lambda r: (not r["passes_criteria"], -r["mean_within_excess_lenctl"]))
json.dump(dict(medians={"%s|%s" % k: v for k, v in med.items()}, results=out),
          open(os.path.join(OUT, "split_eval2.json"), "w"), indent=1)
for r in out:
    print("\n==", r["split"], "| sizes", r["per_agent_sizes"], "| PASSES" if r["passes_criteria"] else "| fails")
    for k in ("pooled_strat", "pooled_strat_noenv", "pooled_lenctl"):
        d = r[k]
        print("   %-20s excess %s p %s" % (k, d.get("excess"), d.get("perm_p")))
    for a in AG:
        d, e, l = r["within"][a], r["within_noenv"][a], r["within_lenctl"][a]
        print("   within %-7s excess %s p %s | no-env excess %s p %s | len-ctl excess %s p %s" % (
            a, d.get("excess"), d.get("perm_p"), e.get("excess"), e.get("perm_p"), l.get("excess"), l.get("perm_p")))
    print("   mean within-agent excess", r["mean_within_excess"], "| length-controlled", r["mean_within_excess_lenctl"])
