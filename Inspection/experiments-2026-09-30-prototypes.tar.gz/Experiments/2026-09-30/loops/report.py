"""Consolidated, human-readable report of the loops experiment (prints to stdout -> report.out).
Everything is recomputed from per_trajectory.csv, loop_instances.jsonl, _verdicts.pkl and the JSON
outputs of stats.py / split_eval*.py, so run it last (run_all.sh)."""
import csv, hashlib, json, os, pickle, statistics as st
from collections import Counter, defaultdict
from common import load_trajectories, OUT
from loops import edit_target, is_product, TESTSCRIPT_RE, PHASES

AG = ("claude", "codex", "gemini")
R = list(csv.DictReader(open(os.path.join(OUT, "per_trajectory.csv"))))
I = [json.loads(l) for l in open(os.path.join(OUT, "loop_instances.jsonl"))]
V = pickle.load(open(os.path.join(OUT, "_verdicts.pkl"), "rb"))
T = load_trajectories()


def col(a, k):
    return [float(r[k]) for r in R if r["agent"] == a and r[k] != ""]


def cell(v):
    if not v:
        return "-"
    return "%5.3g / %5.3g / %3.0f%%" % (st.median(v), st.mean(v), 100 * sum(1 for x in v if x > 0) / len(v))


print("# 1. Per-agent signals   (median / mean / % of trajectories with value > 0 ; n=50 each unless noted)")
SIG = [("n_actions", "actions"), ("n_runs", "phase runs (RLE)"), ("revisits", "phase revisits (runs - distinct phases)"),
       ("fv_cycles", "fix-verify cycles repair>..validation..>repair"), ("val_to_loc", "validation -> localization (direct)"),
       ("regress_broad", "validation then localization before next repair"),
       ("loc_repair_pingpong", "loc<->repair ping-pong (a,b,a)"), ("env_runs", "environment runs"),
       ("env_returns", "returns to environment (env runs - 1)"), ("env_x_env", "env -> X -> env"),
       ("n_stagnant_groups", "stagnant groups (same mid,key,failed flag >=2)"),
       ("n_stagnant_fail_groups", "  ... of which failed-flag=true"),
       ("ident_fail_rerun", "identical failing command re-run (exact cmd)"),
       ("n_noprogress_repeats", "no-progress repeats (exact key, same outcome, no state change)"),
       ("n_rerun_same_outcome", "no-progress CHECK re-runs (core cmd, same verdict)"),
       ("n_rerun_filter_only", "  ... differing only in env prefix / output filter"),
       ("n_retry_chains", "failing retry chains (>=2 blocking fails, core cmd)"),
       ("n_retry_chains_unrecovered", "  ... never recovered"),
       ("n_retry_chain_actions", "actions inside retry chains"),
       ("edits_after_last_validation", "EditsAfterLastVerify"), ("repeated_reads", "repeated reads of a file"),
       ("dup_reads", "duplicate reads (same file+range, no edit between)"),
       ("n_fail_episodes", "tool-error episodes"), ("n_unrecovered", "  ... never recovered"),
       ("median_recovery_window", "median recovery window, actions (traj with >=1 episode)"),
       ("n_test_fail_episodes", "failing-validation-test episodes"), ("test_unrecovered", "  ... never followed by a passing test"),
       ("median_test_recovery", "median test recovery window, actions"),
       ("n_failed", "raw failed flag = true"), ("n_eff_failed", "effective failures (flag or parsed verdict/text)"),
       ("n_block_before_first_verdict", "blocking failures before first test verdict"),
       ("repro_achieved", "reproduced: test ran and failed before first edit"),
       ("repro_blocked", "reproduction attempted but never reached a verdict"),
       ("waste_share", "waste share (narrow: repeats + retry non-first + re-runs)"),
       ("loop_span_share", "loop-span share (broad: inside any loop span)")]
print("%-62s %-24s %-24s %-24s" % ("signal", *AG))
for k, lab in SIG:
    vals = [col(a, k) for a in AG]
    extra = "" if all(len(v) == 50 for v in vals) else "  (n=%s)" % [len(v) for v in vals]
    print("%-62s %-24s %-24s %-24s%s" % (lab, *[cell(v) for v in vals], extra))

print("\n# 2. Loop instances per agent (loop_instances.jsonl)")
kinds = sorted({x["kind"] for x in I})
print("%-28s" % "kind" + "".join("%9s" % a for a in AG))
for k in kinds:
    print("%-28s" % k + "".join("%9d" % sum(1 for x in I if x["kind"] == k and x["agent"] == a) for a in AG))

print("\n# 3. What triggers a fix-verify cycle? (verdicts of the checks between the two repair runs)")
for a in AG:
    c = Counter()
    nonprod = 0
    for x in [y for y in I if y["kind"] == "fix_verify_cycle" and y["agent"] == a]:
        rows = T[(x["bug"], a)]
        vf = V[(x["bug"], a)]["vfine"]
        idx = {r["action_index"]: i for i, r in enumerate(rows)}
        s, e = idx[x["start"]], idx[x["end"]]
        vs = [vf[i] for i in range(s, e + 1) if rows[i]["high_level"] == "validation" and vf[i]]
        if "test_fail" in vs:
            c["after failing test"] += 1
        elif any(v in ("build_fail", "infra_fail") for v in vs):
            c["after build/infra failure only"] += 1
        elif "pass" in vs:
            c["after passing checks only"] += 1
        else:
            c["no parsed verdict"] += 1
        eds = [edit_target(rows[i]) for i in range(s, e + 1) if rows[i]["mid_level"] == "edit_file"]
        if any(not any(is_product(f) for f in ts) for ts in eds):
            nonprod += 1
    tot = sum(c.values())
    print("  %-7s cycles=%3d  %s  | cycles touching a non-product file (test script / build config): %d" % (
        a, tot, dict(c), nonprod))

print("\n# 4. Same-file edits vs identical edits (refines the stagnant 'edit' groups, whose key is only the file)")
for a in AG:
    same_file = ident = 0
    for (b, ag), rows in T.items():
        if ag != a:
            continue
        seenf, seenp = Counter(), Counter()
        for r in rows:
            if r["mid_level"] != "edit_file":
                continue
            f = "|".join(edit_target(r))
            p = hashlib.md5(json.dumps(r["args"], sort_keys=True).encode()).hexdigest()
            same_file += seenf[f] > 0
            ident += seenp[p] > 0
            seenf[f] += 1
            seenp[p] += 1
    print("  %-7s edits to an already-edited file: %3d | byte-identical edit payload re-applied: %d" % (a, same_file, ident))

print("\n# 5. No-progress check re-runs (rerun_same_outcome instances)")
for a in AG:
    xs = [x for x in I if x["kind"] == "rerun_same_outcome" and x["agent"] == a]
    acts = sum(len(x["members"]) - 1 for x in xs)
    print("  %-7s groups=%3d repeat-actions=%3d trajectories=%2d verdicts=%s multi-variant groups=%d" % (
        a, len(xs), acts, len({x["bug"] for x in xs}), dict(Counter(x["verdict"] for x in xs)),
        sum(1 for x in xs if x["filter_only_variants"] > 1)))

print("\n# 6. Failing retry chains")
for a in AG:
    xs = [x for x in I if x["kind"] == "failing_retry_chain" and x["agent"] == a]
    if not xs:
        print("  %-7s none" % a)
        continue
    print("  %-7s chains=%d trajectories=%d unrecovered=%d first-phase=%s mid=%s run_pipeline=%d edits-inside=%d" % (
        a, len(xs), len({x["bug"] for x in xs}), sum(1 for x in xs if x["recovered_at"] is None),
        dict(Counter(x["phase_first"] for x in xs)), dict(Counter(x["mid"] for x in xs)),
        sum(1 for x in xs if "run_pipeline" in x["key"]), sum(1 for x in xs if x["edits_between"] > 0)))

print("\n# 7. Construction checks (positional phase rule)")
cc = json.load(open(os.path.join(OUT, "construction_checks.json")))["counts"]
keys = sorted({k for v in cc.values() for k in v})
for k in keys:
    print("  %-55s" % k + "".join("%8s" % cc[a].get(k, 0) for a in AG))
tr = json.load(open(os.path.join(OUT, "transitions.json")))
used = Counter()
for a in AG:
    for k, v in tr[a]["counts"].items():
        used[k] += v
phase_count = Counter(r2["high_level"] for rows in T.values() for r2 in rows)
print("  actions per phase (all agents):", dict(phase_count))
imp = ["validation->reproduction", "repair->reproduction", "reproduction->validation"]
print("  transitions impossible by the rule (observed counts, must be 0):", {k: used.get(k, 0) for k in imp})
zero = [("%s->%s" % (x, y)) for x in PHASES for y in PHASES if x != y and used.get("%s->%s" % (x, y), 0) == 0]
print("  all zero off-diagonal phase transitions across agents:", zero)
for a in AG:
    print("  %-7s trajectories with any reproduction action: %d/50" % (
        a, sum(1 for (b, ag), rows in T.items() if ag == a and any(x["high_level"] == "reproduction" for x in rows))))

print("\n# 8. Codex: signal vs harness outcome (compile_fail n=15 vs test_fail n=35; exploratory)")
co = json.load(open(os.path.join(OUT, "codex_outcome_tests.json")))
for k, d in sorted(co["continuous"].items(), key=lambda kv: kv[1]["p"])[:10]:
    print("  %-28s cf med %-6.3g tf med %-6.3g r_rb %+.2f p %.4f holm %.4f" % (
        k, d["compile_fail_median"], d["test_fail_median"], d["rank_biserial"], d["p"], d["p_holm"]))
for k, d in sorted(co["binary"].items(), key=lambda kv: kv[1]["p"]):
    print("  %-28s cf %d/15 tf %d/35 OR %s p %.4f holm %.4f" % (k, d["table_cf_yes_no"][0], d["table_tf_yes_no"][0],
                                                               d["odds_ratio"], d["p"], d["p_holm"]))
print("  bug-level confound (other agents on the same bugs):")
for k, d in co["bug_level_confound_other_agents"].items():
    if "env" in k:
        print("    %-22s cf mean %.2f tf mean %.2f r_rb %+.2f p %.4f" % (k, d["cf_mean"], d["tf_mean"], d["rank_biserial"], d["p"]))

print("\n# 9. Sankey split evaluation (JSD of RLE phase-bigram distributions; excess over permutation null)")
for d in json.load(open(os.path.join(OUT, "split_eval.json"))):
    if "note" not in d:
        print("  %-86s n=%3d/%3d excess %+.4f p %.4f" % (d["split"][:86], d["n1"], d["n0"], d["excess"], d["perm_p"]))
e2 = json.load(open(os.path.join(OUT, "split_eval2.json")))["results"]
print("  -- non-circular within-agent median splits (split_eval2.py):")
for r in e2:
    print("  %-62s passes=%-5s pooled len-ctl excess %+.4f p %.4f | within-agent len-ctl p %s" % (
        r["split"][:62], r["passes_criteria"], r["pooled_lenctl"]["excess"], r["pooled_lenctl"]["perm_p"],
        {a: r["within_lenctl"][a].get("perm_p") for a in AG}))
