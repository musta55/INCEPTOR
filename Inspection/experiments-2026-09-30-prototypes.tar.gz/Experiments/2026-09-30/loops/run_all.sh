#!/bin/sh
# Re-runs the whole loops experiment in dependency order. Read-only over the corpus.
set -e
cd "$(dirname "$0")"
python3 loops.py
uv run --no-project --with scipy --with numpy python3 stats.py > stats.out
python3 split_eval.py > split_eval.out
python3 split_eval2.py > split_eval2.out
python3 sankey_views.py
python3 harness_check.py > harness_check.out
python3 examples.py > examples.out
python3 chain_signatures.py > chain_signatures.out
python3 rule_v2.py > rule_v2.out
python3 report.py > report.out
