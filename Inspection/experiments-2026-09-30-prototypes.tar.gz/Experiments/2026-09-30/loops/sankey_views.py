"""Single writer of every Sankey JSON in experiments/loops/.  Run after loops.py / split_eval*.py.

Every Sankey entry has the same bundle shape:
  nodes : [{id, name, layer}]                        d3-sankey-ready, acyclic
  links : [{source, target, value, source_id, target_id}]   source/target are node indices
  view  : "head_tail"  -- the primary layered view on the RLE phase sequence (Graphectory-style
          collapse of repeated neighbours).  Runs 1..H are drawn as layers H01..H06; if a
          trajectory has more than H runs its LAST T runs are drawn as layers T-4..T-1 (aligned to
          the end), and when more than H+T runs exist the skipped middle goes through one GAP node.
          So every trajectory's opening AND ending are visible, and flow is conserved.
  prefix_k10 : the earlier view (first 10 runs, rest collapsed into one '...continues' node).
               Kept for comparison; it hides the ending of the 82/150 trajectories with >10 runs (claude 9, codex 38, gemini 35).
  stages : position-in-run view: each trajectory's ACTIONS split into 5 equal position bins,
           node = dominant phase of the bin (ties -> phase whose last action is latest). No
           truncation, but minority phases inside a bin are invisible.
  phase_graph : cyclic phase->phase transition counts incl. START/END (for a chord / force view;
                not valid input for d3-sankey).
"""
import csv, json, os, statistics as st
from collections import Counter
from common import OUT
from loops import sankey_layered, phase_graph

H, T, S = 6, 4, 5
AG = ("claude", "codex", "gemini")
recs = list(csv.DictReader(open(os.path.join(OUT, "per_trajectory.csv"))))


def runs_of(r):
    out = []
    for x in r["phase_seq"].split(" > "):
        p, n = x[:-1].split("(")
        out.append((p, int(n)))
    return out


def seq(r):
    return [p for p, _ in runs_of(r)]


def actions(r):
    return [p for p, n in runs_of(r) for _ in range(n)]


def _pack(links, layer_of):
    names = sorted({x for ab in links for x in ab}, key=lambda s: (layer_of(s), s))
    idx = {n: i for i, n in enumerate(names)}
    return dict(nodes=[dict(id=n, name=n.split(":", 1)[-1], layer=layer_of(n)) for n in names],
                links=[dict(source=idx[a], target=idx[b], source_id=a, target_id=b, value=v)
                       for (a, b), v in sorted(links.items())])


def headtail_layer(n):
    if n == "END":
        return H + T + 2
    if n.startswith("GAP"):
        return H + 1
    if n.startswith("H"):
        return int(n[1:3])
    return H + 1 + (T - int(n[2]) + 1)          # T-4 -> H+2 ... T-1 -> H+T+1


def sankey_headtail(seqs):
    links = Counter()
    gap_runs = []
    for ph in seqs:
        n = len(ph)
        nodes = ["H%02d:%s" % (k + 1, p) for k, p in enumerate(ph[:H])]
        if n > H + T:
            nodes.append("GAP:(middle runs skipped)")
            gap_runs.append(n - H - T)
            tail = ph[-T:]
        else:
            tail = ph[H:]
        nodes += ["T-%d:%s" % (len(tail) - j, p) for j, p in enumerate(tail)]
        nodes.append("END")
        for a, b in zip(nodes, nodes[1:]):
            links[(a, b)] += 1
    d = _pack(links, headtail_layer)
    d.update(view="head_tail", H=H, T=T, n_trajectories=len(seqs),
             n_through_gap=len(gap_runs), gap_runs_median=(st.median(gap_runs) if gap_runs else 0))
    return d


def sankey_stages(action_seqs):
    links = Counter()
    for ph in action_seqs:
        n = len(ph)
        bins = [[] for _ in range(S)]
        for i, p in enumerate(ph):
            bins[min(i * S // n, S - 1)].append((i, p))
        path = []
        for k, b in enumerate(bins):
            if not b:                      # only possible when n < S
                continue
            c = Counter(p for _, p in b)
            top = max(c.values())
            cand = [p for p in c if c[p] == top]
            last = {p: i for i, p in b}
            path.append("S%d:%s" % (k + 1, max(cand, key=lambda p: last[p])))
        path.append("END")
        for a, b in zip(path, path[1:]):
            links[(a, b)] += 1
    d = _pack(links, lambda n: S + 1 if n == "END" else int(n[1]))
    d.update(view="stages", n_stages=S, n_trajectories=len(action_seqs))
    return d


def bundle(rs):
    s = [seq(r) for r in rs]
    d = sankey_headtail(s)
    d["prefix_k10"] = sankey_layered(s, K=10)
    d["stages"] = sankey_stages([actions(r) for r in rs])
    d["phase_graph"] = phase_graph(s)
    d["members"] = ["%s|%s" % (r["bug"], r["agent"]) for r in rs]
    return d


def write(name, groups, meta=None):
    out = dict(meta or {})
    for k, rs in groups.items():
        if rs:
            out[k] = bundle(rs)
    json.dump(out, open(os.path.join(OUT, name), "w"), indent=1)
    print("%-36s" % name, {k: len(v) for k, v in groups.items() if v})


def by(pred, agents=AG + ("all",)):
    return {a: [r for r in recs if (a == "all" or r["agent"] == a) and pred(r)] for a in agents}


def two_way(label_true, label_false, pred, agents=AG + ("all",)):
    g = {}
    for a in agents:
        g["%s|%s" % (a, label_true)] = [r for r in recs if (a == "all" or r["agent"] == a) and pred(r)]
        g["%s|%s" % (a, label_false)] = [r for r in recs if (a == "all" or r["agent"] == a) and not pred(r)]
    return g


def med_of(key_fn, a):
    return st.median([key_fn(r) for r in recs if r["agent"] == a])


# 1. required: per agent
write("sankey.json", {a: [r for r in recs if r["agent"] == a] for a in AG},
      {"_definition": __doc__})
# 2. codex by harness outcome (weak ground truth: harness recorded 0 test results for all 50 bugs)
write("sankey_codex_outcome.json",
      {"codex|" + o: [r for r in recs if r["agent"] == "codex" and r["codex_outcome"] == o]
       for o in ("compile_fail", "test_fail")},
      {"_definition": "Codex split by harness verdict. CAVEAT: every harness CSV has all_test_results=0 "
                      "and empty failed_tests (see harness_check.py); treat as weak ground truth."})

# 3. RECOMMENDED additional split (split_eval2.py criterion winner): fail-heavy vs fail-light
ev2 = json.load(open(os.path.join(OUT, "split_eval2.json")))
ev = {r["split"].split(" (")[0]: r for r in ev2["results"]}


def rate_fail(r):
    return float(r["n_eff_failed"]) / float(r["n_actions"])


MF = {a: med_of(rate_fail, a) for a in AG}
write("sankey_split_failheavy.json",
      two_way("fail_heavy", "fail_light", lambda r: rate_fail(r) > MF[r["agent"]]),
      {"_definition": "RECOMMENDED split. fail_heavy = effective failures per action (tool error, failing "
                      "build/test verdict parsed from output, or hard shell-error text) above the agent's own "
                      "median (%s). Defined from action results, not from phase labels." %
                      {a: round(v, 4) for a, v in MF.items()},
       "_eval": {k: ev["fail_heavy"][k] for k in ("pooled_strat", "pooled_strat_noenv", "pooled_lenctl",
                                                  "within_lenctl", "per_agent_sizes")}})


def first_share(r):
    v = r["first_test_verdict_at"]
    return 1.0 if v == "" else (float(v) - 1) / float(r["n_actions"])


MS = {a: med_of(first_share, a) for a in AG}
write("sankey_split_slowstart.json",
      two_way("slow_start", "fast_start", lambda r: first_share(r) > MS[r["agent"]]),
      {"_definition": "Near-tie alternative. slow_start = share of actions before the first test verdict "
                      "(a run_test whose output shows pass or a test that ran and failed; never -> 1.0) above "
                      "the agent's median (%s)." % {a: round(v, 4) for a, v in MS.items()},
       "_eval": {k: ev["slow_start"][k] for k in ("pooled_strat", "pooled_strat_noenv", "pooled_lenctl",
                                                  "within_lenctl", "per_agent_sizes")}})

# 4. earlier candidates, kept for comparison with their verdicts
es_groups = {}
for g in sorted({r["end_state"] for r in recs}):
    for a in AG + ("all",):
        es_groups["%s|%s" % (a, g)] = [r for r in recs if (a == "all" or r["agent"] == a) and r["end_state"] == g]
write("sankey_split_endstate.json", es_groups,
      {"_definition": "end_state = how the trajectory ends relative to the agent's OWN checks (last run_test "
                      "after the final edit: pass / fail; last_build_only_pass; edited_after_last_check; "
                      "never_validated; no_edit).",
       "_status": "NOT recommended: last_test_pass vs rest does not separate phase structure (agent-stratified "
                  "perm p=0.28, length-controlled p=0.21; split_eval*.json)."})
ML = {a: med_of(lambda r: float(r["loop_span_share"]), a) for a in AG}
write("sankey_split_loopheavy.json",
      two_way("loop_heavy", "loop_light", lambda r: float(r["loop_span_share"]) > ML[r["agent"]]),
      {"_definition": "loop_heavy = loop_span_share above the agent's median %s" % ML,
       "_status": "Separates strongly but is CIRCULAR: loop_span_share is computed from the same phase "
                  "sequence the Sankey draws."})
envb = {}
for r in recs:
    envb.setdefault(r["bug"], {})[r["agent"]] = float(r["env_runs"]) > 0
write("sankey_split_envhard.json",
      two_way("env_hard_bug", "env_easy_bug",
              lambda r: any(v for a, v in envb[r["bug"]].items() if a != r["agent"]), agents=AG),
      {"_definition": "env_hard_bug = at least one of the OTHER two agents entered an environment phase on this bug",
       "_status": "NOT recommended: no separation under an agent-stratified null (p=0.86)."})
write("sankey_split_retryblocked.json",
      two_way("retry_blocked", "not_retry_blocked", lambda r: float(r["n_retry_chains"]) > 0),
      {"_definition": "retry_blocked = >=1 failing retry chain (same core command, >=2 blocking failures)",
       "_status": "NOT recommended: re-encodes agent identity (claude 0/50, codex 50/50, gemini 5/50); "
                  "agent-stratified perm p=0.28."})
