# Annotation codebook — what a low-, mid- and high-level action is

**Purpose.** This document defines the actions we expect to see at each level of a
trajectory. Two people use it:

- a **human annotator**, labelling the reference set by hand;
- a **reviewer**, checking whether the automatic labels are right.

Both follow the same definitions, and the human labels become the ground truth that the
tool is scored against. How the tool builds each level is in
[Segmentation spec.md](Segmentation%20spec.md).

**Corpus.** 50 Android bugs × 3 agents (Claude Code, Codex, Gemini CLI). The setting is
`code_localization_tests`: each agent got the bug report, one failing UI test and a few
"Good Starting Points".

---

## 1. The four levels at a glance

| Level | Name | Unit | Answers | Example (bug-18, Codex) |
|---|---|---|---|---|
| **L0** | low-level action | one tool call | *what exactly was executed* | `./run_pipeline.sh Script18` → `SandboxDenied` |
| **L1** | mid-level action | one tool call, categorised | *what kind of thing was done* | `run_test` |
| **L2** | high-level action (segment) | a contiguous run of L0 actions with one immediate goal and one outcome | *what the agent was trying to get done, and did it work* | actions 2–6: "reproduce the bug — blocked by the environment (sandbox, JDK, compile error)" |
| **L3** | purpose | a contiguous run of segments | *which stage of repair the agent is in* | `reproduction` [2–6] |

Nesting is strict:

- every L0 action belongs to exactly one segment;
- every segment belongs to exactly one purpose;
- segments and purposes are contiguous: no gaps, no overlaps.

**This document's "high-level action" is the segment.** The Parser's older `high_level`
column is a per-action phase tag and is kept only for backward compatibility. Its
replacement is the per-action `phase`; neither is a segment.

---

## 2. L0 — low-level actions (one tool call)

There is nothing to label at L0. The annotator **checks** it. One row in the annotation
sheet is one L0 action, in execution order. Subagent actions (`scope = sub-…`) are spliced
in at the call that delegated them.

What an L0 action carries, and what to check:

| Field | Check |
|---|---|
| `tool`, `target` | the command or file is what the row says (open the reading view if in doubt) |
| `verdict` (`pass` / `fail` / `none`) | for build/test runs: did the run *actually* report a result? A cut-off `\| head -60` with no results line is `none`, not `pass` |
| `fail_kind` (`test` / `build` / `env` / `exit`) | **test**: the test ran and failed. **build**: compiler error in project code. **env**: sandbox, JDK/SDK, keystore, Gradle plugin, lock or permission problem. **exit**: any other non-zero exit |
| `edit_role` (edits only: `source` / `toolchain` / `test`) | **source**: app code. **toolchain**: `*.gradle`, `*.properties`, wrapper, `run_pipeline.sh`. **test**: `reproducing_script_project/`, `androidTest/`, `/test/` |

**Low-level actions you will see in this corpus:**

- **Reads:** `Read X.java`, `sed -n '1,200p' X.java`, `cat`, `nl -ba`, `read_file`.
- **Searches:** `rg "setTargetFragment"`, `grep -rn`, `find . -name`, `Glob`, `grep_search`.
- **Orienting:** `ls`, `pwd`, `tree`, `list_directory`.
- **Edits:**
  - Claude: `Edit`, `MultiEdit`, `Write`.
  - Codex: `apply_patch`, including `apply_patch <<'PATCH'` heredocs inside a shell command.
  - Gemini: `replace`, `write_file`.
- **Builds:** `./gradlew clean assembleDebug`.
- **Tests:** `./run_pipeline.sh Script<id>`, `./run_pipeline.sh all`, `adb shell am instrument …`,
  `./gradlew testDebugUnitTest`.
- **Device:** `adb devices`, `emulator -avd …`, `adb install`.
- **Environment:** `export JAVA_HOME=…`, `jenv`, `/usr/libexec/java_home -V`,
  `GRADLE_USER_HOME=/tmp/…`, editing `local.properties`, creating shims under `/tmp`.
- **Version control:** `git diff`, `git status`, `git checkout -- file`.
- **Waiting:** Codex `write_stdin` polling a background run, `sleep`, Claude
  `TaskOutput`.
- **Delegation:** Claude `Task`/`Agent`; Gemini `generalist` (whose inner actions are not
  logged).
- **Web:** `WebSearch`, `web_fetch`, `curl`.

---

## 3. L1 — mid-level actions (15 categories)

One category per L0 action. Shell commands are categorised by **the program they run**, not
by words anywhere in the command line. In a compound command, the highest-priority part
wins:

`run_test > build > device_ops > env_setup > edit_file > vcs > search_code > read_file > web > wait_process > orient > run_shell`

`cd`, `export` and `mkdir` prefixes are ignored when another part remains.

| Category | Definition | Typical L0 | Common confusion → rule |
|---|---|---|---|
| `read_file` | look at the contents of a known file | `Read`, `cat`, `sed -n`, `nl` | reading `run_pipeline.sh` or a build log is still `read_file` at L1; the *segment* level may class it as environment work |
| `search_code` | find where something is | `rg`, `grep`, `find`, `Glob` | `ls -la && rg --files` → `search_code` (priority) |
| `orient` | inspect workspace or system state, not code | `ls`, `pwd`, `which`, `wc` | — |
| `edit_file` | change a file | `Edit`, `apply_patch`, `replace` | an `apply_patch` heredoc run through the shell is `edit_file`, not `run_shell` |
| `build` | compile or assemble without running tests | `./gradlew assembleDebug` | a gradle **test task** (`test`, `testDebugUnitTest`, `connectedAndroidTest`) is `run_test` |
| `run_test` | execute a test or the test pipeline | `./run_pipeline.sh …`, `am instrument` | the path containing `androidTest` does not make a file read a test run |
| `device_ops` | manage the emulator or device | `adb devices`, `emulator` | `adb … instrument` is `run_test` |
| `env_setup` | change the toolchain or environment | `export JAVA_HOME`, `jenv`, `rm -rf .gradle`, `cp`, `chmod` | `cat > file` (writing) is `env_setup`, not `read_file` |
| `vcs` | version-control state | `git diff`, `git status`, `git checkout` | — |
| `plan` | explicit planning tool | `TodoWrite`, `update_plan` | never called in this corpus |
| `delegate` | hand work to a subagent | `Task`, `Agent`, `generalist` | — |
| `wait_process` | wait for or poll a running process | `write_stdin`, `sleep`, `TaskOutput` | belongs to the run it waits on |
| `web` | internet lookup | `WebSearch`, `curl` | — |
| `run_shell` | a shell command the rules cannot classify | — | should be rare (0.9%); write down what it really is |
| `other` | an unclassified non-shell tool | `AskUserQuestion` | — |

---

## 4. L2 — high-level actions (segments)

### 4.1 Definition

A **segment** is the shortest contiguous run of actions that:

1. serves **one immediate goal**, for example "find where the dialog is shown", "get the
   failing test to run", "try this fix", "confirm the suite passes";
2. **ends at a decisive moment**: the goal was reached, a run gave a verdict, or the agent
   switched goals.

### 4.2 Boundary rules for annotators

Apply in order:

1. **Goal switch.** Start a new segment when the immediate goal changes, e.g. from reading
   code to running the test.
2. **An attempt includes its judgement.** An edit plus the run that judges it is one
   segment: the *fix attempt*. Include a `git diff` between the edit and the run. Stop at
   the first run that gives a verdict: a failing build or test, or a passing test.
3. **Retrying is one segment while nothing changes.** Re-running the *same* failing
   command with no edit and no environment change in between belongs to the same segment.
   That segment is *stuck*.
   - If the command, an environment variable or the error message changes, the agent is
     working around the problem. It is still one segment if the goal is the same (e.g.
     "get the test to run"); mark it *environment wrestling*.
4. **Localization splits by code area.** Reading files in one area (one package, the test
   scripts, the build config) is one segment. Moving to a different area starts a new one.
5. **Ignore blips.** A single `ls`, `wait` or quick look between two parts of the same
   attempt does not split it.
6. **Reviewing one's own patch** after the last edit (re-reading edited lines, `git diff`)
   is its own segment.

### 4.3 Segment types (codebook v1)

Pick exactly one type per segment. The families make the list easier to scan.

| Family | Type | Use when | Example |
|---|---|---|---|
| **Explore** | `targeted_lookup` | 1–2 reads/searches aimed at a named file or symbol | read `MedicineCreateOrEditFragment.java` from the starting points |
| | `file_by_file_localization_sweep` | ≥3 different files read in sequence, looking for the fault | Codex bug-1130: `QueueRecyclerAdapter` → `AllEpisodesRecycleAdapter` → … |
| | `lookup_tool_errors` | most calls in the segment errored | Claude reading a hallucinated `/home/user/...` path |
| | `orientation_planning` | getting bearings: `ls`, `pwd`, plan | — |
| | `delegated_exploration` | a subagent explored for the agent | Claude bug-18 actions 1–11 |
| **Reproduce** | `reproduction_succeeded` | before any source edit, the target test ran **and failed** | Gemini bug-44: `run_pipeline.sh Script44` → 0 passed, 1 failed |
| | `reproduction_blocked` | tried to run the test before fixing, but build or environment prevented a verdict | Codex bug-18 [2–6] |
| | `reproduction_not_reproduced` | the test ran and **passed** on unfixed code | — |
| **Environment** | `toolchain_wrestling` | changing JDK/SDK/Gradle/sandbox settings to make things run | Codex bug-44 [21–27]: SDK symlink farm, rebuild |
| **Fix** | `fix_attempt_passed` | source edit(s) → run passes | — |
| | `fix_attempt_failed` | source edit(s) → test still fails | Claude bug-114 attempts in [32–85] |
| | `fix_attempt_breaks_build` | source edit(s) → compile error | — |
| | `fix_attempt_blocked_by_env` | source edit(s) → run blocked by environment, no verdict on the fix | Codex bug-18 [19–25] (`jenv: version 11 not installed`) |
| | `unverified_edit` | source edit with no run after it | — |
| | `delegated_edit` | a subagent made the edit | Gemini `generalist` edits |
| **Validate** | `validation_passed` | run after the fix, without a new edit, passes | `run_pipeline.sh all` → 5 passed |
| | `validation_failed` | run after the fix fails (test or build) | Gemini bug-123451: suite 4 passed / 1 failed |
| | `validation_blocked_by_env` | run after the fix blocked by environment | — |
| **Test / harness** | `test_or_harness_modification` | edits to the test oracle (`Script*.java`) or `run_pipeline.sh` | Gemini bug-1446 changes `assertEquals(1, …)` to `assertEquals(0, …)` |
| **Inefficiency** | `stuck_repeating_failure` | the same command fails the same way ≥2× with nothing changed in between | — |
| **Review** | `review_patch` | re-reading own edits or `git diff` after the last edit | Codex bug-18 [33–37] |

Use `…_other` (`reproduction_other`, `fix_attempt_other`, `validation_other`) only when
none of these fit, and say why in `manual_notes`.

### 4.4 Segment outcome

One outcome per segment:

| Outcome | Meaning |
|---|---|
| `succeeded` | the immediate goal was reached. A failing test **before** the fix counts here as `reproduced` |
| `failed` | the goal was not reached (test still fails, build broken, blocked) |
| `looped` | the segment is a stuck repetition |
| `unverified` | an edit that was never run |
| `completed` | exploration or review that has no pass/fail (reads, searches, diffs) |
| `no_verdict` | a run whose output gives no result |

**Context matters.** The same event, "the test fails", is `succeeded` (reproduced) before
the first source edit and `failed` (fix does not work) after it. Every annotator must check
which side of the first source edit a segment is on.

### 4.5 Flags (tick all that apply)

| Flag | Meaning |
|---|---|
| `stuck_repeating_command` | identical command, identical error, nothing changed in between |
| `env_wrestling` | successive environment workarounds (changing env vars, JDK, sandbox) |
| `edits_test_script` | edits a test oracle file |
| `edits_harness` | edits `run_pipeline.sh` |
| `edits_toolchain` | edits build config |
| `off_patch_exploration` | ≥3 actions reading app files the agent never edits |
| `rereads_same_file` | the same file range read again with no edit in between |
| `abandoned` | the segment failed and the agent moved on without retrying |
| `retried_immediately` / `retried_after_detour` | how a failure was followed up |
| `recovered_after_repeats` | eventually succeeded after several failed tries |

---

## 5. L3 — purposes (7)

A purpose is a contiguous run of segments serving one stage of the repair. Purposes are
**state-based**: the anchor is the **first edit to application source**, not the first
edit of any file.

| Purpose | Definition | Contains, typically |
|---|---|---|
| `orientation` | getting bearings in the workspace | `orientation_planning` |
| `localization` | finding where the fault is | lookups, sweeps, delegated exploration |
| `reproduction` | making the failure observable **before** the first source edit | reproduction segments; environment and test-script work done to get the test running |
| `environment` | making the toolchain work, when that is the main activity | `toolchain_wrestling` |
| `repair` | changing source to fix the bug, including fix–verify loops | fix attempts; short lookups between attempts |
| `validation` | checking the fix **after** the first source edit | validation segments |
| `review` | inspecting the final patch | `review_patch` |

**Nesting rule for annotators.** A short segment (≤3 actions) that interrupts a purpose and
then returns to it belongs to that purpose. Example: one lookup between two fix attempts
stays inside `repair`.

---

## 6. Manual verification protocol

### 6.1 Sample

| Set | Trajectories | Actions | Use |
|---|---|---|---|
| **Pilot** | bug-18 × {claude, codex, gemini} | 99 | rater calibration; disagreements are discussed and the codebook is updated |
| **Test** | bugs 1138, 1563, 1299, 1446, 1202 × 3 agents | 708 | the reference set; **no rule or codebook change after test labelling starts** |

The test set covers:

- 7 passing and 8 failing runs;
- lengths from 7 to 97 actions;
- a bug that every agent fails (1202);
- an oracle-edit case (1446 Gemini);
- long fix–verify loops (1299, 1138).

### 6.2 Procedure

1. **Two raters, blind.** Each rater labels from a sheet that shows L0 and L1 but **hides
   the automatic segment, purpose and type columns**, so boundaries are not anchored on the
   tool's answer.
2. **Per action row:**
   - `auto_mid_correct`: y/n. Fill `manual_mid_level` only when correcting.
   - `manual_segment_id`: the same integer on every row of a segment, starting at 1.
3. **Per segment** (on its first row):
   - `manual_segment_type` (§4.3);
   - `manual_segment_outcome` (§4.4);
   - `manual_flags` (§4.5), separated by `;`;
   - `manual_purpose` (§5).
4. `manual_notes`: anything unusual, especially *why* the agent did something and whether
   it was wasted effort.
5. **Adjudication.** After both raters finish a trajectory, a third pass resolves
   disagreements into `adjudicated_*` columns. The tool is scored against the adjudicated
   labels; the raters' agreement with each other is the ceiling.

### 6.3 What gets measured

| Level | Metric |
|---|---|
| L0 verdict | accuracy of `verdict` / `fail_kind` against the rater |
| L1 | accuracy and Cohen's κ of `mid_level` |
| L2 boundaries | boundary P/R/F1 with **one-to-one** matching at tolerance 0 and ±1, plus WindowDiff |
| L2 types | Cohen's κ on segments both sides agree exist (IoU ≥ 0.5) |
| L2 outcome | Cohen's κ of outcome on the same matched segments |
| L2 flags | precision and recall per flag (the "surfaces inefficiency" claim) |
| L3 | per-action Cohen's κ of purpose |

The baselines (Graphectory-style phase runs, BPE K = 10/20/40, fixed windows,
mid-level run-length) are scored with the same metrics.

---

## 7. Known limits while labelling

- **Thought is missing for most actions.** Codex encrypts it, Gemini logs none, and Claude
  only sometimes logs it. Label what was *done*, not what you imagine the agent intended.
- **Claude Code rows have no timestamps.**
- **Gemini `generalist` delegation is opaque.** The subagent's actions never reach the log,
  so one `delegate` row can stand for a lot of hidden work.
- **Each agent ran on a different machine**, with a different JDK, sandbox and emulator.
  Codex hits many sandbox and JDK errors because of its host, not only its own choices.
  Record such failures as `env`.
- **Do not edit** the ATIF files or the reading views. They are regenerated by
  `python3 -m atif.cli convert`. Only the annotation sheets are written by hand.
