"""Semantic outcome of an execution action, read from its result text.

The corpus `failed` flag is exit-code based; run_pipeline.sh exits 0 even when the
instrumented test FAILS, so `failed` misses most test failures.  This module adds a
text-based verdict for build/run_test/device_ops/run_shell/wait_process/env_setup, and
a failure KIND, because "the test ran and failed" (for a reproduction: the bug was
reproduced) is a very different event from "the build/toolchain never let the test run".

verdict(a)       -> pass | fail | running | unknown | None (non-execution action)
verdict_kind(a)  -> (verdict, kind) with kind in
                    test   the instrumented/unit test executed and failed or crashed
                    build  compilation / gradle task failure of the project itself
                    env    sandbox denial, JDK/SDK/device/permission problem, missing tool
                    exit   non-zero exit with no recognisable signature
                    None   when verdict != fail
"""
import re
EXEC = {"build", "run_test", "device_ops", "run_shell", "wait_process", "env_setup"}
RE_RESULTS = re.compile(r"Results:\s*(\d+)\s+passed,\s*(\d+)\s+failed")
RE_SCRIPT = re.compile(r">>>\s*\S+:\s*(PASSED|FAILED)")
RE_JUNIT_FAIL = re.compile(r"FAILURES!!!|Tests run:\s*\d+,\s*Failures:\s*[1-9]|INSTRUMENTATION_(FAILED|RESULT: shortMsg=Process crashed)|Process crashed")
RE_JUNIT_OK = re.compile(r"\bOK \(\d+ tests?\)")
RE_BUILD_FAIL = re.compile(r"BUILD FAILED|FAILURE: Build failed|Compilation failed|: error: |error: cannot find symbol|Execution failed for task")
RE_BUILD_OK = re.compile(r"BUILD SUCCESSFUL")
RE_ENV_FAIL = re.compile(r"blocked by policy|JAVA_HOME is set to an invalid|SandboxDenied|Operation not permitted|command not found|No such file or directory|Permission denied|not installed|Unable to locate a Java Runtime|Could not (find|resolve|determine)|Unsupported class file major version|requires Java|Error: Could not|device (offline|not found)|no devices/emulators found")
#: signatures that make a gradle "BUILD FAILED" an environment problem rather than a code problem
RE_ENV_IN_BUILD = re.compile(r"Operation not permitted|Could not determine java version|Unsupported class file major version|requires Java|JAVA_HOME|\.lock|SDK location not found|failed to find target|Could not (?:resolve|download|GET|HEAD)|license(?:s)? (?:for|have not been accepted)|NDK|Unable to (?:start|find) the daemon|Permission denied|java\.net\.|UnknownHost|timed? ?out")
RE_WRONG = re.compile(r"What went wrong:\s*(.{0,500})", re.S)
RE_RUNNING = re.compile(r"Process running with session ID")
RE_EXIT = re.compile(r"(?:Process exited with code|exited with code|exit_code:)\s*(\d+)")


def _text(a):
    return a.get("result") or a.get("result_preview") or ""


RE_TESTS_FAILED = re.compile(r"There were failing tests")
#: a gradle failure counts as a CODE build failure only with a compiler-error signature;
#: plugin/keystore/JDK/SDK/lock/daemon failures are toolchain (env) failures
RE_COMPILE = re.compile(r"Compilation failed|Compilation error|\.(?:java|kt):\d+: error:|error: cannot find symbol|^e: .*\.kt", re.M)
RE_COMPILE_BUT_ENV = re.compile(r"javax/xml/bind|JAXBException|Unable to make field|Unsupported class file major version")


def _build_kind(r):
    m = RE_WRONG.search(r)
    ctx = m.group(1) if m else r[-1500:]
    if RE_TESTS_FAILED.search(ctx):
        return "test"
    if RE_COMPILE_BUT_ENV.search(ctx) or RE_ENV_IN_BUILD.search(ctx):
        return "env"
    if RE_COMPILE.search(ctx) or (not m and RE_COMPILE.search(r)):
        return "build"
    return "env"


def verdict_kind(a):
    mid = a["mid_level"]
    if mid not in EXEC:
        return None, None
    r = _text(a)
    failed = a.get("failed") == "true"
    m = RE_RESULTS.findall(r)
    if m:
        p, f = map(int, m[-1])
        if f > 0:
            return "fail", "test"
        return ("fail", "env") if p == 0 else ("pass", None)   # 0 passed 0 failed: nothing ran
    s = RE_SCRIPT.findall(r)
    if s:
        return ("fail", "test") if "FAILED" in s else ("pass", None)
    if RE_JUNIT_FAIL.search(r):
        return "fail", "test"
    if RE_BUILD_FAIL.search(r):
        return "fail", _build_kind(r)
    if failed:
        return "fail", ("env" if RE_ENV_FAIL.search(r) else "exit")
    if RE_JUNIT_OK.search(r):
        return "pass", None
    if RE_RUNNING.search(r) and not RE_EXIT.search(r):
        return "running", None
    if RE_BUILD_OK.search(r):
        return "pass", None
    if RE_ENV_FAIL.search(r[:400]) and "logcat" not in (a.get("cmd") or ""):
        return "fail", "env"   # environment errors surface at the head of the output
    e = RE_EXIT.findall(r)
    if e:
        return ("fail", "exit") if int(e[-1]) != 0 else ("pass", None)
    return "unknown", None


def verdict(a):
    """Return one of pass|fail|running|unknown for execution actions, None otherwise."""
    return verdict_kind(a)[0]
