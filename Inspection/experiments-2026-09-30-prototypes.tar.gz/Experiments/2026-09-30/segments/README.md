# Experiment "segments": step → higher-level action (segment) → purpose

Prototype of the core novelty: automatically partition every APR agent trajectory into
contiguous multi-step **segments** ("steps 2-6 = one blocked reproduction attempt") nested
strictly inside task-level **purposes**, then test whether **clustering** discovers segment
*types*. Corpus: 50 Android bugs × {Claude Code, Codex, Gemini CLI} = 150 trajectories,
5,400 actions (subagent actions already spliced in).

Every number below was printed by one of the scripts in this directory (file named next to it).

## How to run

```
python3 granularity.py      > granularity_report.txt     # invariants + step 2 statistics + R9b sweep + boundary agreement
python3 verify_repro.py     > verify_repro.txt           # sanity checks for two agent-level claims
python3 export_hierarchy.py > export_report.txt          # step 5: bug-18_hierarchy.json, all_hierarchy.json (+ validation)
uv run --no-project --with scikit-learn --with scipy --with rapidfuzz python3 cluster.py > cluster_report.txt   # step 3
uv run --no-project --with scikit-learn python3 codebook.py > codebook_report.txt                             # codebook v0 vs clusters
python3 segmenter.py <bug> <agent>                       # print one trajectory's hierarchy
```

Files: `seglib_load.py` joins annotation rows with the full ATIF tool arguments/results by
`call_id`. `seglib_verdict.py` reads a pass/fail verdict **and a failure kind** out of result
text. `segmenter.py` holds the rules. `segments_table.csv` has one row per segment with the rule
labels and cluster ids.

## The segmenter (deterministic, rule-based)

Invariants (checked in `granularity.py` and again on the exported JSON in `export_hierarchy.py`):
every action is in exactly one segment, segments are contiguous, every segment is in exactly
one purpose, and purposes are contiguous. **0 violations over 150 trajectories**, and 0 again
after reloading `all_hierarchy.json` from disk.

Per-action enrichment
* **Verdict + failure kind** (`seglib_verdict.py`). The corpus `failed` flag is exit-code based, and
  `run_pipeline.sh` exits 0 when the instrumented test fails, so result text is parsed:
  `Results: N passed, M failed`, `>>> Script: FAILED`, JUnit/instrumentation markers,
  `BUILD FAILED`, sandbox/JDK errors. Each failure gets a kind: `test` (the test ran and failed),
  `build` (a compiler error in project code), `env` (sandbox denial, JDK/SDK/keystore/plugin/lock
  problem, blocked-by-policy) or `exit` (other non-zero exit). A Gradle failure counts as `build`
  only with a compiler signature. Of the Gradle failures first matched as build errors, most
  were really plugin, keystore or JDK problems. After the rule, only 17 compile errors remain
  in the whole corpus.
* **Edit role** (R2b): an edited file is `toolchain` (`*.gradle`, `*.properties`,
  `run_pipeline.sh`, ...), `test` (`reproducing_script_project/`, `androidTest`, `/test/`) or
  `source`.
* **Phase anchor** (R2c): the **first edit to application source**. Runs before it are
  reproduction, runs after it are validation.
* **Background runs**: a `wait_process` is attributed to the command that *started* the session,
  so a test failure reported by the wait counts for that command.

Segmentation rules
* **R1 macro-classes**: EXEC (build/run_test/device_ops/run_shell/env_setup/wait_process),
  EDIT, VCS, EXPL (read/search/orient/plan/web), DELEG.
* **R2 harness reads are execution work**: reading `run_pipeline.sh`, logs or build outputs, or
  probing JDK/SDK paths outside the repo, is classed EXEC (an `env_probe`).
* **R3 micro-units**: maximal runs of one class. R3a: a delegate call plus its spliced sub-agent
  actions is one unit. R3b absorbs blips to a fixed point: ≤1 EXPL action between two EXEC
  blocks, ≤2 EXPL between two EDIT blocks, ≤1 VCS between EDIT/EXEC blocks, and a single
  orient/wait/plan anywhere. R3c (v2): ≤2 VCS actions between an EDIT block and the EXEC block
  after it join the edit, because a `git diff` before running is part of the attempt.
* **R4 localization focus**: an EXPL unit is split where the code *area* in focus changes (test
  scripts, harness, build config, manifest, `res/<type>`, or the source package directory).
  One-off areas join the previous run.
* **R5 attempts**: an EDIT unit plus its following EXEC unit, up to the **first decisive run**
  (a failing build/test, or a passing test), forms one attempt. Its kind is `fix_attempt`
  (source), `toolchain_fix` (toolchain only) or `test_edit` (test scripts only). The rest of
  the EXEC unit is cut after each passing test, and after a passing build that ends a streak of
  failed builds.
* **R6 stuck merge** (v2): two execution segments with the same purpose that end in the *same*
  normalized failing command and the same failure kind are merged into one `stuck` segment.
  At most one explore/exec segment of ≤3 actions may sit between them.
* **R7 outcome** (`outcome` + `outcome_detail`):
  * *reproduction* (and toolchain fixes before the anchor): a test that runs and **fails** →
    `succeeded / reproduced`; a build/env/exit failure → `failed / blocked_<kind>`; a test pass →
    `failed / not_reproduced`; a build pass only → `succeeded / builds`.
  * *repair and validation*: pass → `succeeded / tests_pass | builds`; failure →
    `failed / tests_fail | patch_breaks_build | blocked_env`.
  * `looped`: the segment repeats an identical failing command.
  * Other outcomes: `unverified` (an edit with no run after it), `no_verdict`, `completed`
    (explore/vcs), `failed / tool_errors` (explore segment where most calls error).
* **R8 flags**: `retried_immediately`, `retried_after_detour` and `abandoned` (for failed and
  looped segments), `ends_trajectory_unresolved`, `stuck_repeating_command`, `env_wrestling`,
  `edits_toolchain`, `edits_harness`, `edits_test_script`, `reverts_changes`,
  `off_patch_exploration` (a ≥3-action sweep of app files the agent never edits),
  `rereads_same_file`, `tool_errors`, `recovered_after_repeats`.
* **R9 purposes**: maximal runs of segments with the same *host* purpose, after three nesting
  rules. A nested segment keeps its own `purpose` field.
  * (a) A segment of ≤3 actions sandwiched between two segments of the same purpose nests in
    it, for fixed (segment, host) pairs such as localization→repair, validation→repair and
    environment→reproduction.
  * (b) Fix-verify loop: localization, validation, environment, orientation and review
    segments between two repair segments nest in `repair` when they total ≤ `REPAIR_GAP_MAX`
    = 10 actions (swept below).
  * (c) Reproduction effort: before the first source edit, environment segments within 2
    segments of a reproduction segment nest in `reproduction`.
* **R10 patch review** (v2): after the last edit, an explore segment that reads only files the
  agent edited is `review`.
* **R11 loop overlay**: `fix_verify_loop` (a repair purpose with ≥2 attempts, at least one
  failed), `reproduction_loop` (≥2 failed reproduction/env runs before the first source edit),
  `stuck_segment`.

### Changes after reading bug-18 (v1 → v2)

The first version (same file names, earlier run of this experiment) was checked against the
bug-18 transcripts for all three agents and corrected where it was wrong:
1. **Gemini bug-18, actions 1-7.** v1 called actions 6-7 a failed repair "fix attempt". In fact
   Gemini disabled `allWarningsAsErrors` in `build.gradle`, and the re-run printed
   `Results: 0 passed, 1 failed`, so the bug was reproduced. The positional rule ("reproduction
   ends at the first edit of anything") caused this. 9 of 50 Gemini trajectories start by
   editing toolchain (5) or test-script (4) files, and none of the Claude or Codex ones do
   (`verify_repro.txt`). v2 anchors
   on the first **source** edit, and the segment is now
   `Toolchain fix: edit build.gradle -> 1 run(s): bug reproduced (test fails)`, nested in a
   `reproduction` purpose [1-7].
2. **Codex bug-18, actions 19-25.** v1 split the edits at 19-21 from their verification at 23-25
   because of a `git diff` at 22, and reported the edits as "unverified". v2 (R3c) makes 19-25
   one fix attempt, `blocked by toolchain/env` (`jenv: version 11 not installed`). The recovery
   runs at 26-30 then pass.
3. **Codex bug-18, actions 33-36** (the agent reading back its own edited lines with `nl -ba`)
   were "localization" in v1. They are now `Re-read own patch` → review (R10).
4. **Failure kinds**: a failing test before the fix is a *reproduction success*. v1 counted
   every failure as a failure.
5. **Codex bug-114**: v1 resolved a `wait_process` to the previous wait instead of the command
   that started the session, so the test failure at 58 was missed. The segment [35-58] now
   reads `bug reproduced`.
6. Deciding verdicts now prefer build/run_test over trailing shell commands. v1 turned
   segments that ended in an exit-0 `echo $JAVA_HOME` into "not_reproduced".

`verify_repro.txt` confirms two agent-level facts used below. Claude runs no build or test
before its first source edit in any of its 50 trajectories. The common blocking signatures in
Codex reproduction segments are genuine environment failures (plugin application, a JDK
version it cannot parse, debug keystore, SandboxDenied).

## Step 2: granularity (`granularity_report.txt`)

| | claude | codex | gemini | ALL |
|---|---|---|---|---|
| actions (median/traj) | 18.5 | 35.5 | 35.5 | 33 |
| LLM steps (median/traj) | 17.5 | 29 | 33.5 | 28 |
| raw positional phase-runs (median) | 5 | 13 | 16 | 12 |
| **segments** (total / median per traj) | 374 / 5 | 558 / 10 | 774 / 13 | **1706 / 10** |
| **purposes** (total / median per traj) | 191 / 3 | 333 / 6 | 367 / 6.5 | **891 / 6** |
| mean actions per segment | 3.53 | 3.56 | 2.70 | 3.17 |
| mean segments per purpose | 1.96 | 1.68 | 2.11 | 1.91 |
| segments with >1 action | 0.70 | 0.78 | 0.70 | 0.73 |
| single-segment purposes | 0.65 | 0.69 | 0.65 | 0.66 |
| trajs with fix-verify loop | 8 | 8 | 21 | 37/150 |
| trajs with stuck segment | 3 | 31 | 6 | 40/150 |
| trajs that attempted reproduction | 0 | 46 | 46 | 92/150 |
| trajs that reproduced before fixing | 0 | 4 | 46 | 50/150 |

* Segments sit between steps and purposes: 28 LLM steps → 10 segments → 6 purposes (medians).
  They are **not** a relabelling of the raw positional phase-runs. Of those runs, 55% are a
  single action. Only 0.49 of raw phase changes become segment boundaries, 0.61 of segment
  boundaries are raw phase changes, and 0.34 of segments span more than one raw phase tag,
  because a fix attempt deliberately joins an edit with its verification run.
* **Weakness**: the purpose layer compresses little. 66% of purposes hold a single segment.
  Raising `REPAIR_GAP_MAX` from 0 to ∞ moves segments per purpose from 1.59 to 2.17 and the
  single-segment share from 0.72 to 0.65. So the three-level hierarchy is mostly two levels
  for short Claude runs (median 3 purposes, 5 segments).
* Segment length by kind (median): explore 3, exec 2, fix_attempt 3, toolchain_fix 2,
  test_edit 2, delegate 10.5, vcs 1.
* The segment layer surfaces clear agent differences. Codex tries to reproduce in 46/50 runs but
  gets a failing test only 4 times: 39 of its reproduction segments are `blocked_env`, and 31/50
  trajectories contain a stuck segment. Gemini reproduces in 46/50. Claude never reproduces.

**In-trajectory success is not ground truth.** Codex is the only agent with a harness verdict.
Its last in-trajectory run *passed* in 43/50 trajectories, and the harness says 0/50 pass
(31 `test_fail`, 12 `compile_fail`; `export_report.txt`). The `succeeded` outcome therefore means
"the agent saw a pass", nothing more.

## Step 3: clustering (`cluster_report.txt`, `cluster_results.json`)

Features per segment (agent excluded): the mid-level histogram normalized by length (15 values),
log length, log #failed actions, failed share, ends-in-failure, repetition ratio, log #distinct
targets, relative start position, and optionally the one-hot of the segment's own purpose (8).
There are 1,706 segments. 27% have a single action, 55% have ≤2 and 83% have ≤4.

| method | best setting | silhouette | stability | what the clusters track |
|---|---|---|---|---|
| rule labels (kind/purpose), scored in feature space | 13 labels | 0.230 | n/a | baseline |
| (a) K-means **with** purpose one-hot | k=12 | 0.392 | ARI 0.859 (min 0.688), 20×80% subsamples | NMI with purpose **0.912**: it re-finds the input one-hot |
| (a) K-means **without** purpose | k=12 | 0.337 | ARI 0.697 (min 0.458) | purpose 0.623, dominant mid-level 0.677, agent 0.043 |
| (b) agglomerative, avg linkage, normalized Levenshtein, RLE sequences (largest cluster ≤60%) | k=5 | 0.386 | n/a | sizes 836/768/93/8/1: "exec-ish" vs "read/search" vs "vcs" |
| (c) HDBSCAN on edit distance | mcs=20 | 0.580 (non-noise) | n/a | 25 clusters, 13 of them one exact sequence; 20% noise; noise median length 5 vs 2 |
| (c) HDBSCAN on features | mcs=20 | 0.552 (non-noise) | n/a | 19 clusters, 36% noise; NMI with length bin 0.343 |

Diagnostics that explain these numbers:
* **Order blindness (K-means)**: 444 distinct mid-level sequences collapse to 356 multisets.
  510 segments (30%) share their exact multiset with a differently ordered segment, and the
  histogram cannot tell those orderings apart.
* **Context conflation**: a failing test before the fix means "bug reproduced" (success), and
  after it means "fix does not work". With purpose features removed, 48/59 reproduced segments
  land in clusters where ≥20% of members are `tests_fail` (NMI 0.081). The count is 59/59 for
  agglomerative and 40/59 for HDBSCAN. With the purpose one-hot it drops to 6/59, but that
  information *is* the rule label.
* **HDBSCAN's high silhouettes are exact duplicates**: many clusters are a single sequence (e.g.
  `run_test` ×185), and it drops the long, interesting segments as noise.

### Named clusters, best two methods (2 examples each; bug, agent, [action range])

**K-means without purpose features, k=12** (the honest "behaviour only" clustering):

| cluster | size | proposed name | examples |
|---|---|---|---|
| C0 | 668 | **file-by-file localization / targeted lookup** (69% targeted lookup, 16% sweep) | bug-1202 gemini [21-23] `read read search`, Script1202.java, strings.xml, completed; bug-1130 codex [26-28] `search read read`, QueueRecyclerAdapter.java, AllEpisodesRecycleAdapter.java, completed |
| C4 | 317 | **edit→run attempt (pass or fail mixed)** (33% passed, 26% failed, 14% test/harness edits, 13% blocked by env) | bug-1138 gemini [38-40] `edit edit run_test`, Script1138.java, failed/patch_breaks_build; bug-8 codex [26-28] `edit edit run_test`, TrickyTripperActivity.java + build.gradle, failed/blocked_env |
| C7 | 205 | single passing validation run | bug-275 codex [18-18] `run_test`, tests pass; bug-1568 gemini [32-32] `run_test`, tests pass |
| C6 | 131 | **environment/toolchain wrestling / stuck execution** (median length 6, repetition 0.18, 90 of 131 Codex; 23% stuck, 14% blocked reproduction, 12% failed validation) | bug-2677 codex [2-8] `run_test run_test wait env_setup run_test wait read`, failed/blocked_env; bug-136 gemini [2-7] `run_test orient read read run_test run_test`, looped/tests_fail |
| C2 | 113 | **single failing test run (reproduced OR failed fix: conflated)** | bug-275 gemini [7-7] `run_test`, succeeded/reproduced; bug-171 claude [23-23] `run_test`, failed/tests_fail |
| C1 | 94 | review diff / git state | bug-92 codex [24-24] `vcs`; bug-273 gemini [25-25] `vcs` |
| C9 | 73 | orient-then-read opening | bug-1151 gemini [6-7] `orient read`, Script1151.java; bug-271 claude [3-4] `orient read`, TotpProgressBar.java |
| C3 | 65 | build-only verification / toolchain | bug-1205 gemini [70-72] `edit build env_setup`, builds; bug-8 codex [33-37] `build build env_setup build wait`, builds |
| C10 | 30 | device-driven validation | bug-1202 gemini [38-40] `device_ops device_ops run_test`; bug-8 codex [38-40] same |
| C8 / C5 / C11 | 8 / 1 / 1 | delegated edit (Gemini only); two web-search singletons | bug-1138 gemini [41-41]; bug-171 claude [40-46]; bug-1130 codex [35-38] |

**Within-purpose K-means** (no purpose features; the open-coding use). For reproduction and
environment execution segments (n=230), best k=8, silhouette 0.345, NMI with outcome detail
0.391, with agent **0.214**:

| cluster | size | proposed name | examples |
|---|---|---|---|
| C0 | 67 | **failed/blocked reproduction attempt with env wrestling** (54% blocked_env, median length 5, repetition 0.17, 47 of 67 Codex) | bug-1138 codex [4-8] `run_test run_test wait read env_setup`, failed/blocked_env; bug-382 gemini [3-10] `run_test read env_setup env_setup read read run_test run_test`, succeeded/reproduced |
| C1 | 59 | single-shot reproduction run (61% reproduced, 15 of 59 blocked) | bug-44 gemini [5-5] `run_test`, reproduced; bug-171 codex [14-14] `run_test`, blocked_env |
| C2 | 47 | harness/toolchain inspection without a run | bug-171 gemini [71-73] `read env_setup read`; bug-191 codex [27-28] `read env_setup` |
| C4 | 27 | **toolchain or test-script edit then re-run** (25 of 27 Gemini; flags edits_toolchain/harness/test_script) | bug-382 gemini [14-15] `edit run_test`, Script382.java, reproduced; bug-123451 claude [15-16] `edit run_test`, run_pipeline.sh, toolchain now works |

For repair and validation execution segments (n=657), best k=8, silhouette 0.307: C0 (186)
**failed fix attempt** (77% tests_fail), C1 (164) successful fix attempt, C7 (114) single passing
validation run, C3 (83) **long fix-verify struggle** (median length 7, env wrestling), C6 (72)
"background-run validation", which is 70 of 72 Codex, i.e. a tool style rather than a behaviour.

Mapping to the types you asked about:
* **failed reproduction attempt**: within-purpose C0, and the global C6 in part.
* **environment/toolchain wrestling**: global C6 and C3, within-purpose C0/C2.
* **fix-verify loop**: repair/validation C0 + C3 at segment level. The *loop* itself spans
  several segments, so no single-segment clustering can find it. It comes from R11 (41 loops in
  37 trajectories).
* **file-by-file localization sweep**: global C0 (mixed with targeted lookups).

### Codebook v0 vs clusters (`codebook_report.txt`)

A fixed, deterministic typing from the rule fields gives 24 types, covering all 1,706 segments.
The main counts:

| type | segments | trajectories claude / codex / gemini |
|---|---|---|
| targeted_lookup | 511 | 45 / 47 / 49 |
| file_by_file_localization_sweep | 105 | 13 / 31 / 27 |
| fix_attempt_passed | 109 | 40 / 17 / 39 |
| fix_attempt_failed | 85 | 12 / 5 / 15 |
| fix_attempt_blocked_by_env | 44 | 2 / 35 / 5 |
| toolchain_wrestling | 83 | 18 / 25 / 23 |
| stuck_repeating_failure | 36 | 3 / 24 / 3 |
| reproduction_succeeded | 49 | 0 / 4 / 41 |
| reproduction_blocked | 26 | 0 / 21 / 5 |
| test_or_harness_modification | 48 | 2 / 0 / 16 |

Clusters recover this codebook only partly (NMI / purity): K-means with purpose 0.747 / 0.683,
without purpose 0.618 / 0.596, agglomerative 0.468 / 0.480, HDBSCAN 0.517 / 0.622 (non-noise).
The biggest no-purpose cluster merges passed, failed and env-blocked fix attempts (cluster 4),
and cluster 2 merges `validation_failed` (38%) with `reproduction_succeeded` (32%).

## Step 4: judgement

**Does clustering produce interpretable segment types?** Partly, and mostly for reasons we put
in ourselves.
* With the purpose one-hot, K-means clusters are stable (ARI 0.86) and nameable, but they
  re-find the rule labels (NMI with purpose 0.91), so this is circular.
* Without it, silhouettes are 0.23-0.34 and stability drops (ARI 0.70, min 0.46). The clusters
  track the dominant mid-level tool plus the ends-in-failure feature.
* Edit-distance methods mostly separate "exec-like" from "read-like" sequences, or collect
  exact duplicates of short segments.

Clustering did surface two useful, cross-purpose behavioural types, "long repetitive toolchain
wrestling" (C6) and "toolchain/test edit then re-run" (within-purpose C4). It also showed which
clusters are really agent tooling styles (Codex background runs). That is open-coding value,
not a typing mechanism.

**Recommended pipeline: segment-first, then type.**
1. Segment with rules. An LLM can be added later for the boundaries the rules cannot see
   (intent shifts inside long localization runs).
2. Run clustering *within* each purpose as an open-coding aid, together with n-gram/BPE motif
   mining over segment kinds (see `../bpe`), to propose candidate types.
3. Freeze a codebook (v0 above) with written definitions.
4. Label a stratified sample by hand (≥2 raters, report κ).
5. Train or prompt a classifier and measure it against those labels.

Cluster-first fails for two structural reasons measured above:
* The *same observed behaviour has opposite meaning depending on context*. A failing test is
  a success before the fix and a failure after it: 48/59 conflated without the context feature.
* Clusters cannot cross segment boundaries, and the most interesting units (fix-verify loops,
  reproduction loops) span several segments.

**Why K-means specifically is a weak fit for variable-length step sequences.**
1. It needs fixed-length vectors, so the sequence becomes a bag of mid-levels. That makes it
   order-blind: 30% of segments collide with a differently ordered one.
2. Its spherical, equal-variance assumption clashes with the length distribution (27% of
   segments are one action, so their histograms are one-hot corners of the simplex and dominate
   the clustering).
3. It assigns every point to a cluster, so rare but important long struggles get absorbed into
   big clusters rather than flagged.
4. Chosen by silhouette, k is driven by those one-hot corners (best k = 12, the top of the range).

It is a *reasonable* fit only for cheap summary features inside one purpose. For sequences,
prefer edit-distance/DTW with medoid clustering, or motif/grammar induction. For outcome-bearing
types, prefer a codebook plus a classifier.

## Step 5: output contract for the viewer (`bug-18_hierarchy.json`, `all_hierarchy.json`)

```
bug-18_hierarchy.json : { agent: {schema, bug, agent, n_actions, first_source_edit, last_run_verdict, harness_verdict,
                                   purposes:[{id, label, start, end, n_actions,
                                              segments:[{id, label, outcome, start, end, steps:[action_index...], flags:[...],
                                                         kind, purpose, outcome_detail, n_actions, mid_seq, files,
                                                         failed_steps, fail_kinds, nested}]}],
                                   loops:[{type, start, end, iterations, failed_iterations, ended, segment_id|purpose_id, segment_ids}]} }
all_hierarchy.json    : { bug_id: { agent: <same object> } }   # 50 bugs × 3 agents
```

The required fields are exactly the task's `{label, start, end, segments:[{id, label, outcome,
start, end, steps, flags}]}`, and everything else is additive. `purpose` on a segment is its own
purpose, and `nested:true` marks a segment hosted by a different purpose, which the viewer can
use to show "localization inside repair". `steps` join back to
`corpus/annotation/bug-<id>_actions.jsonl` by `action_index`. `harness_verdict` is only
available for Codex.

bug-18 outline (`export_report.txt`):
* claude: localization [1-16] → repair [17-24] → validation [25].
* codex: localization [1] → reproduction [2-6] (stuck, blocked) → localization [7-18] →
  repair [19-25] (blocked by env) → validation [26-30] → environment [31-32] →
  review [33-37]. Harness: test_fail.
* gemini: reproduction [1-7] (blocked → toolchain fix → reproduced) → localization [8-21] →
  repair [22-30] → localization [31] → validation [32] → environment [33-37].

## Caveats (read before citing any number)

* **By construction**:
  * Purpose labels come from rules applied to rule-based mid-levels. "Reproduction" is defined
    as execution before the first source edit, so Claude's 0/50 reproduction is a fact about
    ordering (verified: no build/test before its first source edit), not a judgement about
    intent.
  * Outcome features (ends_fail, #failed) feed the clustering, so outcome-aligned clusters are
    partly by construction.
  * The codebook is derived from the same rule fields, so cluster–codebook agreement measures
    how much of the rules the features re-encode.
* **Outcomes**: `succeeded` means the agent's own run passed. Codex's in-trajectory passes (43/50)
  never match the harness (0/50 pass). Claude and Gemini have no harness verdict here.
* **Small n**: 50 bugs, one run per agent. Agent-level contrasts such as Codex's blocked
  reproductions reflect *this* harness and sandbox (Codex hit SandboxDenied/JDK/keystore errors)
  as much as the model. Cluster counts with fewer than 30 members are anecdotes.
* **Gemini sub-agents**: Gemini delegate calls have no spliced sub-agent actions in the corpus
  ("0 sub-agent actions"), so delegated Gemini edits are invisible below the delegate step.
* **Rule tuning**: thresholds (`ABSORB_MAX` 3, `REPAIR_GAP_MAX` 10, the R6 gap of ≤3 actions,
  `REPRO_REACH` 2) were set by reading bug-18 and spot-checking bug-114 (claude, codex) and
  bug-1138 (gemini). They are not validated against manual segment labels, and no inter-rater
  agreement exists yet. The `manual_segment_label` column in the annotation CSVs is the place
  to collect them.
* Mid-level labels themselves are rule-based and noisy (e.g. `ls -la && rg --files` is
  `search_code`, and a shell string test in bug-365 codex is `run_test`).
