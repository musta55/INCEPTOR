"""Deterministic rule-based segmenter (v2): action -> segment (higher-level action) -> purpose.

Every action lands in exactly one segment; segments are contiguous; every segment lands
in exactly one purpose; purposes are contiguous.  Rule ids R1..R11 refer to README.md.

v2 changes vs. v1 (see README "Changes after reading bug-18"):
  * the reproduction/validation boundary is the first edit to APP SOURCE, not the first
    edit of any file (toolchain edits such as build.gradle / run_pipeline.sh and test-script
    edits no longer end "reproduction");
  * every failing run carries a failure kind (test | build | env | exit) and reproduction
    segments get reproduction semantics (a test that runs and FAILS before the fix =
    reproduced = success; a build/toolchain failure = blocked);
  * a short git diff/status between an edit and its verification run no longer splits the
    fix attempt; identical failing runs separated by a short look are merged ("stuck");
    reading back one's own patch after the last edit is review, not localization;
    fix-verify nesting (R9b) is capped at REPAIR_GAP_MAX actions.
"""
import re, os, json, collections
from seglib_load import load_all
from seglib_verdict import verdict_kind

# ----------------------------------------------------------------------------- classes
EXEC = {"build", "run_test", "device_ops", "run_shell"}
VERIFY = {"build", "run_test"}                      # actions that can decide an attempt
ORIENT = {"orient", "plan", "other"}

PATH_RE = re.compile(r"(?:~|/)?(?:[\w.\-+]+/)*[\w.\-+]+\.(?:java|kt|xml|gradle|kts|sh|properties|json|pro|txt|md|png|log|yml|yaml|py|csv|trt|cfg|toml)\b")
PATCH_FILE_RE = re.compile(r"\*\*\* (?:Update|Add|Delete) File: (\S+)")
HARNESS_FILES = {"run_pipeline.sh", "local.properties", "gradle.properties", "gradle-wrapper.properties"}
ENV_HINT = re.compile(r"JavaVirtualMachines|java_home|\.gradle(?:-local|-home)?/|jdk|/tmp/|\.android(?:-home|-local)?|ANDROID_(?:SDK|HOME)|sdkmanager|/Library/|/opt/|brew")
GENERIC_DIRS = {"java", "main", "src", "app", "res", "", ".", "kotlin"}
TEST_PATH = re.compile(r"reproducing_script_project|androidTest|/test/|^test/")


def repo_rel(path, bug):
    """Path relative to the bug checkout, or None if it lies outside it."""
    m = re.search(r"/bug-%s(?:/(.*)|/?$)" % re.escape(bug), path)
    if m:
        return m.group(1) or "."
    if path.startswith(("/", "~")):
        return None                                   # absolute path outside the repo
    return path[2:] if path.startswith("./") else path


def action_paths(a):
    """(inside-repo paths, outside-repo paths) touched by the action."""
    bug = a["bug_id"]
    raw = []
    args = a.get("args") or {}
    if a["tool"] == "apply_patch":
        raw += PATCH_FILE_RE.findall(args.get("input", ""))
    else:
        for k in ("file_path", "path", "dir_path", "absolute_path"):
            v = args.get(k)
            if isinstance(v, str) and v:
                raw.append(v)
        text = a.get("cmd") or ""
        if text:
            raw += PATH_RE.findall(text)
            for tok in re.findall(r"(?<![\w$])(/[\w.\-/+ ]+?)(?=[\s'\"]|$)", text):
                if tok.count("/") >= 2:
                    raw.append(tok.strip())
        if a["mid_level"] == "search_code" and isinstance(args.get("pattern"), str) and "/" in args["pattern"]:
            raw.append(args["pattern"])
    inside, outside = [], []
    for p in raw:
        r = repo_rel(p, bug)
        (inside if r is not None else outside).append(r if r is not None else p)
    return inside, outside


def norm_cmd(a):
    """Core of a shell command, for 'identical repeated command' detection (R6)."""
    if a["mid_level"] in ("wait_process",):
        return "wait"
    c = a.get("cmd") or ""
    if not c or a["tool"] == "apply_patch":
        return a["tool"] + ":" + (a.get("target") or "")[:120]
    parts = []
    for seg in re.split(r"&&|;|\n", c):
        seg = seg.strip()
        seg = re.split(r"\|\s*(?:tail|head|grep|sed|tee|awk|cut|sort|uniq|wc)\b", seg)[0]
        seg = seg.replace("2>&1", "").strip()
        toks = seg.split()
        while toks and (re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", toks[0]) or toks[0] in ("export", "env", "time", "nohup")):
            toks.pop(0)
        if not toks or toks[0] in ("cd", "export", "set", "mkdir", "echo", "true", "source", "pushd", "popd", "sleep"):
            continue
        parts.append(" ".join(toks))
    return " && ".join(parts)[:300] or c[:120]


def area(path):
    """Coarse code area used as the localization focus key (R4)."""
    if path is None:
        return None
    base = os.path.basename(path)
    if TEST_PATH.search(path):
        return "test-scripts"
    if base in HARNESS_FILES:
        return "harness"
    if base.endswith((".gradle", ".kts", ".pro")):
        return "build-config"
    if base == "AndroidManifest.xml":
        return "manifest"
    if "/res/" in "/" + path:
        m = re.search(r"res/([\w\-]+)", path)
        return "res/" + (m.group(1).split("-")[0] if m else "")
    d = os.path.dirname(path)
    last = os.path.basename(d)
    if last in GENERIC_DIRS:
        last = os.path.basename(os.path.dirname(d)) if last else ""
        if last in GENERIC_DIRS:
            return None
    return "src/" + last if last else None


def file_role(path):
    """R2b: role of an edited file: toolchain (build config / harness), test, or source."""
    base = os.path.basename(path)
    if base in HARNESS_FILES or base.endswith((".gradle", ".kts", ".pro", ".properties")):
        return "toolchain"
    if TEST_PATH.search(path):
        return "test"
    return "source"


def edit_role(a):
    roles = {file_role(f) for f in a["files"]}
    if not roles or "source" in roles:
        return "source"                               # unknown target: assume source (conservative)
    return "test" if "test" in roles else "toolchain"


# ----------------------------------------------------------------------------- per-action enrichment
def enrich(acts):
    sessions = {}
    for i, a in enumerate(acts):
        a["_i"] = i
        a["verdict"], a["fail_kind"] = verdict_kind(a)
        ins, outs = action_paths(a)
        a["files"] = sorted(set(p for p in ins if "*" not in p and (PATH_RE.fullmatch(p) or "." in os.path.basename(p))))
        a["outside"] = outs
        a["key"] = norm_cmd(a) if (a.get("cmd") and a["tool"] != "apply_patch") else \
            a["tool"] + ":" + json.dumps(a.get("args", {}), sort_keys=True)[:300]
        m = re.search(r"session ID (\d+)", a.get("result") or "")
        if m and a["mid_level"] != "wait_process":     # register the command that STARTED the session
            sessions[m.group(1)] = i
        mid = a["mid_level"]
        # R1: macro-class used for segmentation
        if mid in EXEC or mid == "env_setup":
            cls = "EXEC"
        elif mid == "wait_process":
            cls = "EXEC"
            a["waits_on"] = sessions.get(str(a.get("target", "")).strip())
        elif mid == "edit_file":
            cls = "EDIT"
            a["edit_role"] = edit_role(a)
        elif mid == "vcs":
            cls = "VCS"
        else:
            cls = "EXPL"
            # R2: exploration of the harness / toolchain is part of execution work
            harness = any(os.path.basename(p) in HARNESS_FILES or p.startswith("build/") or "/build/outputs" in p
                          or p.endswith((".log", ".png")) for p in ins)
            env_only = bool(outs) and not ins and (any(ENV_HINT.search(o) for o in outs) or not any(o.endswith((".java", ".kt", ".xml")) for o in outs))
            if harness or env_only or (mid in ("orient", "search_code") and ENV_HINT.search(a.get("cmd") or "")):
                cls = "EXEC"
                a["env_probe"] = True
        a["cls"] = cls
        fa = [area(p) for p in ins if "*" not in p]
        fa = [x for x in fa if x]
        a["area"] = collections.Counter(fa).most_common(1)[0][0] if fa else None
    # R2c: phase anchor = first edit of application source
    first_src = next((i for i, a in enumerate(acts) if a["mid_level"] == "edit_file" and a["edit_role"] == "source"), len(acts))
    last_edit = max((i for i, a in enumerate(acts) if a["mid_level"] == "edit_file"), default=-1)
    return first_src, last_edit


def runs(seq, keyf):
    out = []
    for i, x in enumerate(seq):
        k = keyf(x)
        if out and out[-1][0] == k:
            out[-1][1].append(i)
        else:
            out.append([k, [i]])
    return out


# ----------------------------------------------------------------------------- segmentation
def micro_units(acts):
    """R1-R3: runs of the same macro-class, with delegation blocks and blip absorption."""
    blocks = []
    i = 0
    while i < len(acts):
        a = acts[i]
        if a["mid_level"] == "delegate":                 # R3a: delegate call + spliced sub-agent actions
            j = i + 1
            while j < len(acts) and acts[j]["scope"] == "sub-" + a["call_id"]:
                j += 1
            blocks.append(["DELEG", list(range(i, j))])
            i = j
            continue
        if blocks and blocks[-1][0] == a["cls"]:
            blocks[-1][1].append(i)
        else:
            blocks.append([a["cls"], [i]])
        i += 1
    changed = True                                       # R3b: blip absorption to a fixed point
    while changed:
        changed = False
        for k in range(1, len(blocks) - 1):
            c, idx = blocks[k]
            left, right = blocks[k - 1][0], blocks[k + 1][0]
            n = len(idx)
            mids = {acts[x]["mid_level"] for x in idx}
            # R3c (v2): a short git diff/status between an edit and its verification run
            # belongs to the fix attempt -> fold it into the EDIT block
            if c == "VCS" and left == "EDIT" and right == "EXEC" and n <= 2:
                blocks[k - 1][1] += idx
                for x in idx:
                    acts[x]["absorbed_into"] = "EDIT"
                del blocks[k]
                changed = True
                break
            if left != right or c == left or c == "DELEG" or left == "DELEG":
                continue
            absorb = False
            if c == "EXPL" and left == "EXEC" and n <= 1:
                absorb = True                       # glance at code/output between runs
            elif c == "EXPL" and left == "EDIT" and n <= 2:
                absorb = True                       # look-up while patching
            elif c == "VCS" and left in ("EDIT", "EXEC") and n <= 1:
                absorb = True                       # git diff/checkout between edits or runs
            elif mids <= {"orient", "wait_process", "plan"} and n <= 1:
                absorb = True                       # ls / wait / todo blip anywhere
            if absorb:
                blocks[k - 1][1] += idx + blocks[k + 1][1]
                for x in idx:
                    acts[x]["absorbed_into"] = left
                del blocks[k:k + 2]
                changed = True
                break
    return blocks


def eff_mid(acts, a):
    w = a.get("waits_on")
    return acts[w]["mid_level"] if w is not None else a["mid_level"]


def split_exec(acts, idx):
    """R5: cut an execution unit after a passing run_test, or after a passing build that
    ended a streak of failed builds, when more execution follows."""
    parts, cur, failed_builds = [], [], 0
    for x in idx:
        a = acts[x]
        cur.append(x)
        v = a.get("verdict")
        m = eff_mid(acts, a)
        if m == "build" and v == "fail":
            failed_builds += 1
        if v == "pass" and (m == "run_test" or (m == "build" and failed_builds > 0)):
            parts.append(cur)
            cur, failed_builds = [], 0
    if cur:
        if parts and len(cur) == 1 and acts[cur[0]]["mid_level"] in ("wait_process", "orient"):
            parts[-1] += cur
        else:
            parts.append(cur)
    return parts


def first_decisive(acts, idx):
    """R5b: position (in idx) of the first run that decides a fix attempt: a failing
    build/run_test, or a passing run_test.  A passing build alone does not decide it."""
    for k, x in enumerate(idx):
        a = acts[x]
        m = eff_mid(acts, a)
        if m in VERIFY and a["verdict"] == "fail":
            return k
        if m == "run_test" and a["verdict"] == "pass":
            return k
    return None


def split_explore(acts, idx):
    """R4: split a localization unit where the code area in focus changes."""
    ar = [acts[x]["area"] for x in idx]
    nxt = None                                           # unknown targets bind forward, then backward
    for k in range(len(ar) - 1, -1, -1):
        if ar[k] is None:
            ar[k] = nxt
        else:
            nxt = ar[k]
    prv = None
    for k in range(len(ar)):
        if ar[k] is None:
            ar[k] = prv
        else:
            prv = ar[k]
    rr = runs(list(range(len(idx))), lambda k: ar[k])
    merged = []                                          # singleton areas join the previous run
    for key, ks in rr:
        if merged and (len(ks) == 1 or key == merged[-1][0]):
            merged[-1][1] += ks
        else:
            merged.append([key, ks])
    if len(merged) > 1 and len(merged[0][1]) == 1:
        merged[1][1] = merged[0][1] + merged[1][1]
        merged.pop(0)
    return [([idx[k] for k in ks], key) for key, ks in merged]


def block_role(acts, idx):
    roles = {acts[x]["edit_role"] for x in idx if acts[x]["mid_level"] == "edit_file"}
    if "source" in roles or not roles:
        return "source"
    return "test" if "test" in roles else "toolchain"


def segment_trajectory(acts):
    first_src, last_edit = enrich(acts)
    blocks = micro_units(acts)
    segs = []
    k = 0
    while k < len(blocks):
        c, idx = blocks[k]
        if c == "EDIT":
            role = block_role(acts, idx)
            kind = {"source": "fix_attempt", "test": "test_edit", "toolchain": "toolchain_fix"}[role]
            if k + 1 < len(blocks) and blocks[k + 1][0] == "EXEC":   # R5b: edits + their verification run
                ex = blocks[k + 1][1]
                cut = first_decisive(acts, ex)
                head, rest = (ex, []) if cut is None else (ex[:cut + 1], ex[cut + 1:])
                segs.append({"kind": kind, "idx": idx + head, "edit_role": role})
                for p in (split_exec(acts, rest) if rest else []):
                    segs.append({"kind": "exec", "idx": p})
                k += 2
                continue
            segs.append({"kind": kind, "idx": idx, "edit_role": role, "unverified": True})
        elif c == "EXEC":
            for p in split_exec(acts, idx):
                segs.append({"kind": "exec", "idx": p})
        elif c == "EXPL":
            for p, ar in split_explore(acts, idx):
                segs.append({"kind": "explore", "idx": p, "area": ar})
        elif c == "DELEG":
            segs.append({"kind": "delegate", "idx": idx})
        elif c == "VCS":
            segs.append({"kind": "vcs", "idx": idx})
        k += 1
    ctx = {"first_src": first_src, "last_edit": last_edit}
    for s in segs:
        describe(acts, s, ctx)
    segs = merge_stuck(acts, segs, ctx)
    assign_outcomes(acts, segs, ctx)
    purposes = build_purposes(acts, segs, ctx)
    loops = detect_loops(purposes, segs)
    return segs, purposes, loops, first_src


# ----------------------------------------------------------------------------- description
EXPLORE_ASK = re.compile(r"^\s*(find|read|search|explore|quickly explore|i need to understand|i'm investigating|in .{0,120}?find and read)", re.I)
EDIT_ASK = re.compile(r"\b(replace|fix|make|modify|change|update|implement|add|remove|rewrite|refactor|apply)\b", re.I)


def delegated_edit(a):
    """R3a: a delegation is an edit delegation when its instruction asks for a change."""
    args = a.get("args") or {}
    t = next((v for k in ("request", "prompt", "description", "objective", "task") for v in [args.get(k)] if isinstance(v, str) and v),
             a.get("target") or "")
    return not EXPLORE_ASK.search(t) and bool(EDIT_ASK.search(t[:600]))


def seg_purpose(acts, s, ctx):
    idx, first_src = s["idx"], ctx["first_src"]
    mids = [acts[x]["mid_level"] for x in idx]
    pre = idx[0] < first_src
    if s["kind"] == "fix_attempt":
        return "repair"
    if s["kind"] == "toolchain_fix":
        return "environment"
    if s["kind"] == "test_edit":
        return "reproduction" if pre else "repair"
    if s["kind"] == "vcs":
        return "review"
    if s["kind"] == "delegate":
        return "repair" if ("edit_file" in mids or delegated_edit(acts[idx[0]])) else "localization"
    if s["kind"] == "explore":
        if all(m in ORIENT for m in mids):
            return "planning" if all(m == "plan" for m in mids) else "orientation"
        # R10 (v2): after the last edit, reading back only files one has edited = reviewing the patch
        if idx[0] > ctx["last_edit"] >= 0 and s["files"] and set(s["files"]) <= ctx["edited"]:
            s["reads_own_patch"] = True
            return "review"
        return "localization"
    # exec
    if all(acts[x]["mid_level"] == "wait_process" for x in idx) and acts[idx[0]].get("waits_on") is not None:
        return "reproduction" if acts[idx[0]]["waits_on"] < first_src else "validation"
    env = sum(1 for x in idx if acts[x]["mid_level"] == "env_setup" or acts[x].get("env_probe"))
    verif = [x for x in idx if acts[x]["mid_level"] in VERIFY]
    if env * 2 >= len(idx) and not any(acts[x]["verdict"] == "pass" and acts[x]["mid_level"] == "run_test" for x in idx):
        return "environment"
    if not verif and all(acts[x]["mid_level"] in ("orient", "wait_process") or acts[x].get("env_probe") for x in idx):
        return "environment"
    return "reproduction" if pre else "validation"


def decisive(acts, idx):
    """Verdict that decides the segment: the last pass/fail of a build/run_test (or of a wait on
    one); only if there is none, the last pass/fail of device_ops/run_shell.
    Returns (verdict, fail_kind, action position)."""
    for tier in (VERIFY, {"device_ops", "run_shell"}):
        for x in reversed(idx):
            a = acts[x]
            if eff_mid(acts, a) in tier and a["verdict"] in ("pass", "fail"):
                return a["verdict"], a["fail_kind"], x
    return None, None, None


def describe(acts, s, ctx):
    idx = s["idx"]
    if "edited" not in ctx:
        ctx["edited"] = set(f for a in acts if a["mid_level"] == "edit_file" for f in a["files"])
    s["start"] = acts[idx[0]]["action_index"]
    s["end"] = acts[idx[-1]]["action_index"]
    s["steps"] = [acts[x]["action_index"] for x in idx]
    s["mid_seq"] = [acts[x]["mid_level"] for x in idx]
    s["n"] = len(idx)
    files = []
    for x in idx:
        for f in acts[x]["files"]:
            if f not in files:
                files.append(f)
    s["files"] = files
    s["purpose"] = seg_purpose(acts, s, ctx)
    s["raw_failed"] = [acts[x]["action_index"] for x in idx if acts[x]["failed"] == "true"]
    s["verdict_failed"] = [acts[x]["action_index"] for x in idx if acts[x]["verdict"] == "fail"]
    s["failed_steps"] = sorted(set(s["raw_failed"]) | set(s["verdict_failed"]))
    keys = [acts[x]["key"] for x in idx]
    s["distinct_targets"] = len(set(keys))
    s["repetition_ratio"] = 1 - len(set(keys)) / len(keys)
    fail_keys = collections.Counter(acts[x]["key"] for x in idx if acts[x]["verdict"] == "fail" or acts[x]["failed"] == "true")
    s["repeated_failing"] = {k: v for k, v in fail_keys.items() if v >= 2 and k != "wait"}
    s["env_actions"] = sum(1 for x in idx if acts[x]["mid_level"] == "env_setup" or acts[x].get("env_probe"))
    s["verdict"], s["fail_kind"], s["verdict_at"] = decisive(acts, idx)
    s["decisive_mid"] = eff_mid(acts, acts[s["verdict_at"]]) if s["verdict_at"] is not None else None
    s["fail_kinds"] = dict(collections.Counter(acts[x]["fail_kind"] for x in idx if acts[x]["fail_kind"]))


def merge_stuck(acts, segs, ctx):
    """R6 (v2): two execution segments of the same purpose that both end in the same failing
    command with the same failure kind, separated by at most one explore/env segment of
    <= 3 actions, are one 'stuck' segment (the agent re-ran the same thing and got the same
    failure)."""
    def last_fail_key(s):
        if s["kind"] != "exec" or s["verdict"] != "fail":
            return None
        return (acts[s["verdict_at"]]["key"] if acts[s["verdict_at"]]["mid_level"] != "wait_process"
                else acts[acts[s["verdict_at"]]["waits_on"]]["key"], s["fail_kind"])
    changed = True
    while changed:
        changed = False
        for j in range(len(segs) - 1):
            a = segs[j]
            ka = last_fail_key(a)
            if ka is None:
                continue
            for gap in (0, 1):
                c = j + 1 + gap
                if c >= len(segs):
                    break
                if gap and not (segs[j + 1]["kind"] in ("explore", "exec") and segs[j + 1]["n"] <= 3):
                    break
                b = segs[c]
                if b["purpose"] == a["purpose"] and last_fail_key(b) == ka:
                    idx = [x for t in segs[j:c + 1] for x in t["idx"]]
                    new = {"kind": "exec", "idx": idx, "merged_stuck": True}
                    describe(acts, new, ctx)
                    new["purpose"] = a["purpose"]
                    segs[j:c + 1] = [new]
                    changed = True
                    break
            if changed:
                break
    return segs


# ----------------------------------------------------------------------------- outcome
#: which later purposes count as a retry of a failed segment
FAMILY = {"repair": {"repair", "validation", "environment"}, "validation": {"validation", "repair"},
          "reproduction": {"reproduction", "environment"},
          "environment": {"environment", "reproduction", "validation"}, "localization": {"localization"},
          "review": {"review"}, "orientation": {"orientation", "localization"}, "planning": {"planning"}}
EXEC_KINDS = ("exec", "fix_attempt", "toolchain_fix", "test_edit")


def eff_mid_of(s):
    return s.get("decisive_mid")


def exec_outcome(s, pre):
    """R7: outcome + detail of an execution-bearing segment."""
    v, fk = s["verdict"], s["fail_kind"]
    stuck = bool(s["repeated_failing"]) or s.get("merged_stuck")
    if s.get("unverified"):
        return "unverified", "edit_not_followed_by_run"
    if v is None:
        return "no_verdict", "no_decisive_run"
    if s["purpose"] == "reproduction" or (s["kind"] == "toolchain_fix" and pre):
        if v == "fail" and fk == "test":
            return "succeeded", "reproduced"            # test runs and fails before the fix
        if v == "fail":
            return ("looped" if stuck else "failed"), "blocked_" + (fk or "exit")
        # a pass before any source edit: either only a build, or the test does not fail
        ran_test = eff_mid_of(s) == "run_test"
        return ("failed", "not_reproduced") if ran_test else ("succeeded", "builds")
    if s["kind"] == "toolchain_fix":
        if v == "pass" or fk == "test":
            return "succeeded", "toolchain_fixed"
        return ("looped" if stuck else "failed"), "blocked_" + (fk or "exit")
    if v == "pass":
        return "succeeded", "tests_pass" if s["decisive_mid"] == "run_test" else ("builds" if s["decisive_mid"] == "build" else "ran_ok")
    detail = {"test": "tests_fail", "build": "patch_breaks_build", "env": "blocked_env"}.get(fk, "blocked_exit")
    return ("looped" if stuck else "failed"), detail


def assign_outcomes(acts, segs, ctx):
    """R7/R8: outcome and flags per segment."""
    for j, s in enumerate(segs):
        flags = []
        idx = s["idx"]
        last = acts[idx[-1]]
        nxt = segs[j + 1] if j + 1 < len(segs) else None
        pre = idx[0] < ctx["first_src"]
        if s["kind"] in EXEC_KINDS:
            outcome, detail = exec_outcome(s, pre)
            if outcome == "succeeded" and s["repeated_failing"]:
                flags.append("recovered_after_repeats")
        else:
            detail = None
            nf = len(s["raw_failed"])
            same = collections.Counter(acts[x]["key"] for x in idx)
            if nf and (last["failed"] == "true" or nf * 2 >= len(idx)):
                outcome, detail = "failed", "tool_errors"
            elif any(v >= 2 for v in same.values()) and s["kind"] == "explore" and s["repetition_ratio"] >= 0.34:
                outcome, detail = "looped", "repeats_same_lookup"
            else:
                outcome = "completed"
        if outcome in ("failed", "looped"):
            fam = FAMILY.get(s["purpose"], {s["purpose"]})
            later = [t for t in segs[j + 1:] if t["purpose"] in fam and t["kind"] in EXEC_KINDS + ("delegate",)] \
                if s["kind"] in EXEC_KINDS else [t for t in segs[j + 1:] if t["purpose"] in fam]
            if nxt is None:
                flags.append("ends_trajectory_unresolved")
            elif later and later[0] is nxt:
                flags.append("retried_immediately")
            elif later:
                flags.append("retried_after_detour")
            else:
                flags.append("abandoned")
        if s["repeated_failing"] or s.get("merged_stuck"):
            flags.append("stuck_repeating_command")
        if s["kind"] in EXEC_KINDS and s["fail_kinds"].get("env"):
            flags.append("env_wrestling")
        if s["kind"] == "toolchain_fix":
            flags.append("edits_toolchain")
            if any("run_pipeline.sh" in f for x in idx if acts[x]["mid_level"] == "edit_file" for f in acts[x]["files"]):
                flags.append("edits_harness")
        if s["kind"] == "test_edit" or (s["kind"] == "delegate" and s["purpose"] == "repair" and
                                        "reproducing_script_project" in (acts[idx[0]].get("target") or "")):
            flags.append("edits_test_script")
        if s["kind"] == "fix_attempt" and any(file_role(f) == "test" for x in idx if acts[x]["mid_level"] == "edit_file"
                                              for f in acts[x]["files"]):
            flags.append("edits_test_script")
        if any(acts[x]["mid_level"] == "vcs" and re.search(r"git (checkout|restore|stash|reset)", acts[x].get("cmd") or "") for x in idx):
            flags.append("reverts_changes")
        if s["kind"] == "explore" and s["n"] >= 3 and s["purpose"] == "localization":
            app_files = [f for f in s["files"] if area(f) and area(f).startswith(("src/", "res/"))]
            if app_files and not (set(app_files) & ctx["edited"]) and len(app_files) == len(s["files"]):
                flags.append("off_patch_exploration")
            reads = collections.Counter(f for x in idx if acts[x]["mid_level"] == "read_file" for f in acts[x]["files"])
            if any(v >= 3 for v in reads.values()):
                flags.append("rereads_same_file")
        if s["raw_failed"]:
            flags.append("tool_errors")
        s["outcome"], s["outcome_detail"], s["flags"] = outcome, detail, flags
        s["label"] = make_label(acts, s)


def short(p):
    return os.path.basename(p) if p else p


def _fs(names):
    u = []
    for x in names:
        if short(x) not in u:
            u.append(short(x))
    return ", ".join(u[:3]) + (" +%d" % (len(u) - 3) if len(u) > 3 else "")


DETAIL_TXT = {"reproduced": "bug reproduced (test fails)", "blocked_env": "blocked by toolchain/env",
              "blocked_build": "blocked: project does not compile", "blocked_exit": "blocked (non-zero exit)",
              "blocked_test": "test fails", "not_reproduced": "test passes before fix", "builds": "builds",
              "tests_pass": "tests pass", "tests_fail": "tests still fail", "patch_breaks_build": "patch breaks build",
              "toolchain_fixed": "toolchain now works", "ran_ok": "command succeeded", "no_decisive_run": "no verdict",
              "edit_not_followed_by_run": "not verified"}


def make_label(acts, s):
    k, p = s["kind"], s["purpose"]
    d = DETAIL_TXT.get(s["outcome_detail"], s["outcome_detail"] or "")
    stuck = " [stuck]" if s["outcome"] == "looped" else ""
    edited = [f for x in s["idx"] if acts[x]["mid_level"] == "edit_file" for f in acts[x]["files"]]
    nv = sum(1 for m in s["mid_seq"] if m in VERIFY)
    ne = s["mid_seq"].count("edit_file")
    if k == "explore":
        if p == "orientation":
            return "Orient in workspace"
        if p == "planning":
            return "Plan / update todo list"
        if p == "review":
            return f"Re-read own patch: {_fs(s['files'])}"
        ar = s.get("area") or "code"
        n_read, n_search = s["mid_seq"].count("read_file"), s["mid_seq"].count("search_code")
        verb = "Sweep" if n_read >= 3 and len(s["files"]) >= 3 else ("Search" if n_search > n_read else "Inspect")
        fs = _fs(s["files"])
        if not fs:                                   # pattern-only searches: show what was searched
            pats = []
            for x in s["idx"]:
                t = re.sub(r"\s+", " ", str((acts[x].get("args") or {}).get("pattern") or acts[x].get("target") or ""))[:40]
                if t and t not in pats:
                    pats.append(t)
            return f"{verb} for " + "; ".join("'%s'" % t for t in pats[:2]) + (" +%d" % (len(pats) - 2) if len(pats) > 2 else "") if pats else f"{verb} {ar}"
        return f"{verb} {ar}: {fs}"
    if k == "delegate":
        return f"Delegated {'edit' if p == 'repair' else 'exploration'} ({s['n'] - 1} sub-agent actions)"
    if k == "vcs":
        return "Review diff / git state"
    if k == "fix_attempt":
        if s.get("unverified"):
            return f"Edit {_fs(edited) or 'code'} (not verified)"
        return f"Fix attempt: {ne} edit(s) to {_fs(edited) or 'code'} -> {nv} run(s): {d}{stuck}"
    if k == "toolchain_fix":
        if s.get("unverified"):
            return f"Toolchain edit {_fs(edited)} (not verified)"
        return f"Toolchain fix: edit {_fs(edited)} -> {nv} run(s): {d}{stuck}"
    if k == "test_edit":
        if s.get("unverified"):
            return f"Edit test script {_fs(edited)} (not verified)"
        return f"Modify test script {_fs(edited)} -> {nv} run(s): {d}{stuck}"
    if all(m == "wait_process" for m in s["mid_seq"]):
        w = acts[s["idx"][0]].get("waits_on")
        return (f"Wait for background run from action {acts[w]['action_index']}" + (f": {d}" if s["verdict"] else "")) if w is not None else "Wait for process"
    if p == "environment":
        return f"Toolchain/environment setup ({s['env_actions']} env actions): {d}{stuck}"
    what = "Reproduce" if p == "reproduction" else "Validate"
    extra = " with env fixes" if s["env_actions"] else ""
    return f"{what}: {nv} run(s){extra}: {d}{stuck}"


# ----------------------------------------------------------------------------- purposes and loops
ABSORB_MAX = 3
REPRO_REACH = 2                   # R9c: how many segments away a reproduction segment may be
REPAIR_GAP_MAX = 10               # R9b cap in actions; swept in granularity.py
REPAIR_GAP_OK = {"localization", "validation", "environment", "orientation", "planning", "review"}
ABSORBABLE_ANYWHERE = {"orientation", "planning"}
#: (segment purpose, host purpose) pairs that may nest when sandwiched (R9a)
ABSORBABLE_INTO = {("localization", "repair"), ("validation", "repair"), ("environment", "reproduction"),
                   ("environment", "validation"), ("environment", "repair"), ("localization", "validation"),
                   ("environment", "localization"), ("localization", "reproduction"), ("review", "repair"),
                   ("localization", "environment")}


def build_purposes(acts, segs, ctx):
    """R9: purposes are maximal runs of segments with the same host purpose, where
      (a) a segment of <= ABSORB_MAX actions sandwiched between two segments of the same
          purpose nests in it, for the (segment, host) pairs in ABSORBABLE_*;
      (b) fix-verify loop: a run of localization / validation / environment / orientation /
          planning / review segments between two repair segments, with <= REPAIR_GAP_MAX
          actions in total, nests in one 'repair' purpose;
      (c) reproduction effort: before the first source edit, environment segments (toolchain
          fixes, env setup) adjacent to reproduction work nest in 'reproduction'.
    A nested segment keeps its own purpose label at segment level (field `purpose`)."""
    labels = [s["purpose"] for s in segs]
    host = labels[:]
    # (c) reproduction effort: pre-source-edit environment work within REPRO_REACH segments
    #     of a reproduction segment is hosted by reproduction
    changed = True
    while changed:
        changed = False
        for j, s in enumerate(segs):
            if host[j] == "environment" and s["idx"][0] < ctx["first_src"]:
                nb = [host[t] for t in range(j - REPRO_REACH, j + REPRO_REACH + 1) if 0 <= t < len(segs) and t != j]
                if "reproduction" in nb:
                    host[j] = "reproduction"
                    changed = True
    # (a) sandwich nesting
    for j in range(1, len(segs) - 1):
        h, me = host[j - 1], host[j]
        if h != host[j + 1] or me == h or segs[j]["n"] > ABSORB_MAX:
            continue
        if me in ABSORBABLE_ANYWHERE or (me, h) in ABSORBABLE_INTO:
            host[j] = h
    # (b) fix-verify loop
    rep = [j for j, l in enumerate(host) if l == "repair"]
    for a, b in zip(rep, rep[1:]):
        gap = range(a + 1, b)
        if gap and all(host[g] in REPAIR_GAP_OK for g in gap) and sum(segs[g]["n"] for g in gap) <= REPAIR_GAP_MAX:
            for g in gap:
                host[g] = "repair"
    purposes = []
    for j, s in enumerate(segs):
        s["purpose_host"] = host[j]
        if purposes and purposes[-1]["label"] == host[j]:
            purposes[-1]["seg_idx"].append(j)
        else:
            purposes.append({"label": host[j], "seg_idx": [j]})
    for p in purposes:
        ss = [segs[j] for j in p["seg_idx"]]
        p["start"], p["end"] = ss[0]["start"], ss[-1]["end"]
        p["n_actions"] = sum(s["n"] for s in ss)
    return purposes


def detect_loops(purposes, segs):
    """Loop overlay (R11).
    fix_verify_loop  : a repair purpose holding >= 2 fix attempts / edits where at least one
                       attempt or nested re-verification failed.
    reproduction_loop: >= 2 failed (blocked / not reproduced) reproduction or environment
                       execution segments before the first source edit (waits excluded).
    stuck_segment    : any segment that repeats an identical failing command."""
    loops = []
    for pi, p in enumerate(purposes):
        if p["label"] != "repair":
            continue
        ss = [segs[x] for x in p["seg_idx"]]
        att = [s for s in ss if s["kind"] in ("fix_attempt", "test_edit", "toolchain_fix") or (s["kind"] == "delegate" and s["purpose"] == "repair")]
        bad = [s for s in ss if s["outcome"] in ("failed", "looped") and s["kind"] in EXEC_KINDS]
        if len(att) >= 2 and bad:
            last_ok = ss[-1]["outcome"] == "succeeded" or (pi + 1 < len(purposes) and purposes[pi + 1]["label"] == "validation"
                                                           and segs[purposes[pi + 1]["seg_idx"][0]]["outcome"] == "succeeded")
            loops.append({"type": "fix_verify_loop", "purpose": pi, "start": p["start"], "end": p["end"],
                          "iterations": len(att), "failed_iterations": sum(1 for s in att if s["outcome"] in ("failed", "looped")),
                          "failed_segments": len(bad), "ended": "succeeded" if last_ok else "unresolved"})
    first_src_start = next((t["start"] for t in segs if t["kind"] == "fix_attempt"), 10 ** 9)
    pre = [s for s in segs if s["purpose"] in ("reproduction", "environment") and s["kind"] in EXEC_KINDS
           and not all(m == "wait_process" for m in s["mid_seq"]) and s["start"] < first_src_start]
    bad = [s for s in pre if s["outcome"] in ("failed", "looped")]
    if len(bad) >= 2:
        loops.append({"type": "reproduction_loop", "start": bad[0]["start"], "end": bad[-1]["end"],
                      "iterations": len(pre), "failed_iterations": len(bad),
                      "ended": "reproduced" if any(s["outcome_detail"] == "reproduced" for s in pre) else
                               ("succeeded" if any(s["outcome"] == "succeeded" for s in pre) else "unresolved")})
    for j, s in enumerate(segs):
        if "stuck_repeating_command" in s["flags"]:
            loops.append({"type": "stuck_segment", "segment": j, "start": s["start"], "end": s["end"],
                          "repeated": s["repeated_failing"], "ended": s["outcome"]})
    return loops


def run_all():
    T = load_all()
    out = {}
    for key, acts in sorted(T.items()):
        segs, purposes, loops, fe = segment_trajectory(acts)
        out[key] = (acts, segs, purposes, loops, fe)
    return out


if __name__ == "__main__":
    import sys
    R = run_all()
    bug, agent = (sys.argv[1], sys.argv[2]) if len(sys.argv) > 2 else ("18", "codex")
    acts, segs, purposes, loops, fe = R[(bug, agent)]
    for p in purposes:
        print(f"== PURPOSE {p['label']} [{p['start']}-{p['end']}] ({p['n_actions']} actions)")
        for j in p["seg_idx"]:
            s = segs[j]
            print(f"   - [{s['start']}-{s['end']}] {s['kind']:13s} {s['purpose']:12s} {s['outcome']:10s} {s['label']}  flags={s['flags']}")
            print(f"        {' '.join(s['mid_seq'])}")
    for l in loops:
        print("LOOP", l)
