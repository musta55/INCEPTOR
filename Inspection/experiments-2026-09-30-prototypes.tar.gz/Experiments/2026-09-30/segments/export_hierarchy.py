"""Task step 5: write the nested output contract for the viewer prototype.

  bug-18_hierarchy.json : {agent: {purposes:[{label,start,end,segments:[{id,label,outcome,start,end,steps,flags,...}]}], ...}}
  all_hierarchy.json    : {bug_id: {agent: <same object>}}  (all 150 trajectories)

Required contract fields are exactly those in the task; extra fields (kind, purpose, outcome_detail,
mid_seq, files, loops, ...) are additive so a viewer can filter without re-joining the corpus.
Then validates both files (strict nesting, partition, contiguity) and cross-checks the in-trajectory
"last run passed" signal against the only harness verdict in the corpus (Codex CSVs).
Run: python3 export_hierarchy.py > export_report.txt
"""
import json, csv, os, collections
from segmenter import run_all

OUT = os.path.dirname(os.path.abspath(__file__))
CODEX_CSV = "/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset/results-localization-codex/test_results_run_{bug}.csv"
SCHEMA_VERSION = "segments-v2"


def codex_verdict(bug):
    p = CODEX_CSV.format(bug=bug)
    if not os.path.exists(p):
        return None
    row = next(csv.DictReader(open(p)))
    return "pass" if row["pass"] == "Yes" else ("compile_fail" if row["compile_fail"] == "Yes" else
                                                 ("test_fail" if row["test_fail"] == "Yes" else "unknown"))


def trajectory_obj(bug, agent, acts, segs, purposes, loops, first_src):
    seg_id = {j: f"s{j + 1:02d}" for j in range(len(segs))}
    P = []
    for pi, p in enumerate(purposes):
        ss = []
        for j in p["seg_idx"]:
            s = segs[j]
            ss.append({"id": seg_id[j], "label": s["label"], "outcome": s["outcome"], "start": s["start"], "end": s["end"],
                       "steps": s["steps"], "flags": s["flags"],
                       # additive fields
                       "kind": s["kind"], "purpose": s["purpose"], "outcome_detail": s["outcome_detail"],
                       "n_actions": s["n"], "mid_seq": s["mid_seq"], "files": s["files"][:8],
                       "failed_steps": s["failed_steps"], "fail_kinds": s["fail_kinds"],
                       "nested": s["purpose"] != s["purpose_host"]})
        P.append({"id": f"p{pi + 1:02d}", "label": p["label"], "start": p["start"], "end": p["end"],
                  "n_actions": p["n_actions"], "segments": ss})
    L = []
    for l in loops:
        d = {k: v for k, v in l.items() if k not in ("segment", "purpose")}
        if "segment" in l:
            d["segment_id"] = seg_id[l["segment"]]
        if "purpose" in l:
            d["purpose_id"] = f"p{l['purpose'] + 1:02d}"
        d["segment_ids"] = [seg_id[j] for j, s in enumerate(segs) if s["start"] >= l["start"] and s["end"] <= l["end"]]
        L.append(d)
    exec_segs = [s for s in segs if s["kind"] in ("exec", "fix_attempt", "toolchain_fix", "test_edit") and s["verdict"]]
    return {"schema": SCHEMA_VERSION, "bug": bug, "agent": agent, "n_actions": len(acts),
            "first_source_edit": acts[first_src]["action_index"] if first_src < len(acts) else None,
            "last_run_verdict": exec_segs[-1]["verdict"] if exec_segs else None,
            "harness_verdict": codex_verdict(bug) if agent == "codex" else None,
            "purposes": P, "loops": L}


def validate(obj, acts_idx):
    """Contract + invariants for one trajectory object."""
    errs = []
    steps = [x for p in obj["purposes"] for s in p["segments"] for x in s["steps"]]
    if steps != acts_idx:
        errs.append("steps are not an ordered partition of the trajectory's action_index list")
    pos = {x: i for i, x in enumerate(acts_idx)}
    prev_end = None
    for p in obj["purposes"]:
        for k in ("label", "start", "end", "segments"):
            if k not in p:
                errs.append(f"purpose missing {k}")
        if not p["segments"] or p["start"] != p["segments"][0]["start"] or p["end"] != p["segments"][-1]["end"]:
            errs.append(f"purpose {p['id']} bounds do not match its segments")
        for s in p["segments"]:
            for k in ("id", "label", "outcome", "start", "end", "steps", "flags"):
                if k not in s:
                    errs.append(f"segment missing {k}")
            q = [pos[x] for x in s["steps"]]
            if q != list(range(q[0], q[-1] + 1)) or s["start"] != s["steps"][0] or s["end"] != s["steps"][-1]:
                errs.append(f"segment {s['id']} not contiguous / bounds wrong")
            if not (p["start"] <= s["start"] <= s["end"] <= p["end"]):
                errs.append(f"segment {s['id']} escapes purpose {p['id']}")
            if prev_end is not None and pos[s["start"]] != pos[prev_end] + 1:
                errs.append(f"gap/overlap before segment {s['id']}")
            prev_end = s["end"]
    return errs


R = run_all()
ALL = collections.defaultdict(dict)
n_err = 0
for (bug, agent), (acts, segs, purposes, loops, fs) in sorted(R.items(), key=lambda kv: (int(kv[0][0]), kv[0][1])):
    obj = trajectory_obj(bug, agent, acts, segs, purposes, loops, fs)
    e = validate(obj, [a["action_index"] for a in acts])
    if e:
        n_err += 1
        print("INVALID", bug, agent, e[:3])
    ALL[bug][agent] = obj
json.dump(ALL["18"], open(os.path.join(OUT, "bug-18_hierarchy.json"), "w"), indent=1)
json.dump(ALL, open(os.path.join(OUT, "all_hierarchy.json"), "w"))
print(f"validated {sum(len(v) for v in ALL.values())} trajectories over {len(ALL)} bugs: {n_err} invalid")
print(f"wrote bug-18_hierarchy.json ({os.path.getsize(os.path.join(OUT, 'bug-18_hierarchy.json'))} bytes) and "
      f"all_hierarchy.json ({os.path.getsize(os.path.join(OUT, 'all_hierarchy.json'))} bytes)")

# ---- reload + re-validate from disk (the viewer reads the file, not the Python objects)
disk = json.load(open(os.path.join(OUT, "all_hierarchy.json")))
bad = sum(1 for bug, ag in disk.items() for a, o in ag.items()
          if validate(o, [x["action_index"] for x in R[(bug, a)][0]]))
print(f"re-validated from disk: {bad} invalid")

# ---- in-trajectory evidence vs harness verdict (Codex only)
tab = collections.Counter()
for bug, ag in disk.items():
    o = ag.get("codex")
    if o:
        tab[(o["last_run_verdict"], o["harness_verdict"])] += 1
print("\nCodex: last in-trajectory run verdict  x  harness verdict (test_results_run_<bug>.csv)")
for k, v in sorted(tab.items(), key=str):
    print(f"  last_run={k[0]!s:8s} harness={k[1]!s:13s} {v}")
print("\nbug-18 outline:")
for agent, o in disk["18"].items():
    print(f"  {agent}: {len(o['purposes'])} purposes, {sum(len(p['segments']) for p in o['purposes'])} segments, "
          f"{o['n_actions']} actions, first source edit at {o['first_source_edit']}, harness={o['harness_verdict']}")
    for p in o["purposes"]:
        print(f"    [{p['start']}-{p['end']}] {p['label']}: " + " | ".join(f"{s['id']} {s['outcome']}" for s in p["segments"]))
