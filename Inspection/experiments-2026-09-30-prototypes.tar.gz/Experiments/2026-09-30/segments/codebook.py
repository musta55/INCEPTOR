"""Codebook v0: a FIXED, deterministic segment-type assignment from the rule fields
(kind, purpose, outcome_detail, flags), i.e. the 'segment-first, then type with a codebook'
pipeline recommended in README.md.  Also cross-tabulates the codebook against the
unsupervised clusters from cluster.py (segments_table.csv) to show what clustering adds.

Run: uv run --no-project --with scikit-learn python3 codebook.py > codebook_report.txt
"""
import csv, collections, json, os
from sklearn.metrics import normalized_mutual_info_score as NMI, adjusted_rand_score as ARI
from segmenter import run_all

OUT = os.path.dirname(os.path.abspath(__file__))
EXEC_KINDS = ("exec", "fix_attempt", "toolchain_fix", "test_edit")


def code(s):
    """First matching rule wins (precedence = order below)."""
    k, p, d, f = s["kind"], s["purpose"], s["outcome_detail"], set(s["flags"])
    if k in EXEC_KINDS and s["outcome"] == "looped":
        return "stuck_repeating_failure"
    if k == "test_edit" or "edits_harness" in f:
        return "test_or_harness_modification"
    if p == "reproduction" and k in EXEC_KINDS:
        if d == "reproduced":
            return "reproduction_succeeded"
        if d and d.startswith("blocked"):
            return "reproduction_blocked"
        if d == "not_reproduced":
            return "reproduction_not_reproduced"
        return "reproduction_other"
    if k == "toolchain_fix" or (p == "environment" and k == "exec"):
        return "toolchain_wrestling"
    if k == "fix_attempt":
        if s.get("unverified"):
            return "unverified_edit"
        return {"tests_pass": "fix_attempt_passed", "tests_fail": "fix_attempt_failed", "patch_breaks_build": "fix_attempt_breaks_build",
                "blocked_env": "fix_attempt_blocked_by_env"}.get(d, "fix_attempt_other")
    if p == "validation" and k == "exec":
        if d == "tests_pass":
            return "validation_passed"
        if d in ("tests_fail", "patch_breaks_build"):
            return "validation_failed"
        if d and d.startswith("blocked"):
            return "validation_blocked_by_env"
        return "validation_other"
    if k == "delegate":
        return "delegated_" + ("edit" if p == "repair" else "exploration")
    if k == "vcs" or p == "review":
        return "review_patch"
    if p in ("orientation", "planning"):
        return "orientation_planning"
    if k == "explore":
        if s["outcome"] == "failed":
            return "lookup_tool_errors"
        n_read = s["mid_seq"].count("read_file")
        if n_read >= 3 and len(s["files"]) >= 3:
            return "file_by_file_localization_sweep"
        return "targeted_lookup"
    return "other"


R = run_all()
rows = []
per_traj = collections.defaultdict(collections.Counter)
for (bug, agent), (acts, segs, purposes, loops, fe) in sorted(R.items()):
    for j, s in enumerate(segs):
        c = code(s)
        rows.append({"bug": bug, "agent": agent, "seg": j, "code": c, "n": s["n"]})
        per_traj[(bug, agent)][c] += 1
N = len(rows)
cnt = collections.Counter(r["code"] for r in rows)
by_agent = {a: collections.Counter(r["code"] for r in rows if r["agent"] == a) for a in ("claude", "codex", "gemini")}
act_share = collections.Counter()
for r in rows:
    act_share[r["code"]] += r["n"]
print(f"codebook v0: {len(cnt)} types over {N} segments (every segment typed; 'other' = {cnt.get('other', 0)})")
print(f"{'type':34s} {'segs':>5s} {'actions':>7s}  {'claude':>6s} {'codex':>6s} {'gemini':>6s}  trajectories(c/x/g)")
for c, v in cnt.most_common():
    tr = [sum(1 for (b, a), cc in per_traj.items() if a == ag and cc[c]) for ag in ("claude", "codex", "gemini")]
    print(f"{c:34s} {v:5d} {act_share[c]:7d}  {by_agent['claude'][c]:6d} {by_agent['codex'][c]:6d} {by_agent['gemini'][c]:6d}  {tr[0]}/{tr[1]}/{tr[2]}")

# ---- cross-tab with unsupervised clusters (segments_table.csv from cluster.py; same segment order)
tab = list(csv.DictReader(open(os.path.join(OUT, "segments_table.csv"))))
assert len(tab) == N and all(t["bug"] == r["bug"] and t["agent"] == r["agent"] and int(t["seg"]) == r["seg"] for t, r in zip(tab, rows))
codes = [r["code"] for r in rows]
res = {"n_segments": N, "counts": dict(cnt), "by_agent": {a: dict(v) for a, v in by_agent.items()}, "vs_clusters": {}}
print("\nagreement of unsupervised clusters with codebook v0")
for col in [c for c in tab[0].keys() if c.startswith(("kmeans", "agglo", "hdbscan"))]:
    lab = [t[col] for t in tab]
    m = [i for i, l in enumerate(lab) if l != "-1"]
    nmi = NMI([codes[i] for i in m], [lab[i] for i in m]); ari = ARI([codes[i] for i in m], [lab[i] for i in m])
    # purity: share of segments whose cluster's majority code equals their own code
    maj = {}
    for c in set(lab):
        maj[c] = collections.Counter(codes[i] for i in m if lab[i] == c).most_common(1)[0][0] if c != "-1" else None
    pur = sum(1 for i in m if maj[lab[i]] == codes[i]) / len(m)
    res["vs_clusters"][col] = {"NMI": round(nmi, 3), "ARI": round(ari, 3), "purity": round(pur, 3), "n_scored": len(m)}
    print(f"  {col:26s} NMI={nmi:.3f} ARI={ari:.3f} purity={pur:.3f} (n={len(m)})")
    # which codebook types does each cluster merge? (only for the no-phase K-means)
    if col.startswith("kmeans_no_phase"):
        print(f"  {col}: codebook composition of each cluster")
        for c in sorted(set(lab), key=lambda c: -lab.count(c)):
            comp = collections.Counter(codes[i] for i in range(N) if lab[i] == c)
            tot = sum(comp.values())
            print(f"    cluster {c:>2s} n={tot:4d}: " + ", ".join(f"{k} {v/tot:.0%}" for k, v in comp.most_common(4)))
json.dump(res, open(os.path.join(OUT, "codebook_results.json"), "w"), indent=1)
