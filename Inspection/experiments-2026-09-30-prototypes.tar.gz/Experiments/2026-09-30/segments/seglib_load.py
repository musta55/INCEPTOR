"""Corpus loader: joins annotation rows with full ATIF tool-call arguments/results (by call_id)."""
import json, glob, os, re
SP = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad"
ANN = SP + "/corpus/annotation"
ATIF = SP + "/corpus/atif"
SHELL_KEYS = ("cmd", "command", "input", "shell_command", "script")

def _walk_calls(traj, out):
    for step in traj.get("steps", []):
        res = {r.get("source_call_id"): r for r in (step.get("observation") or {}).get("results", [])}
        for c in step.get("tool_calls") or []:
            r = res.get(c.get("tool_call_id")) or {}
            content = r.get("content")
            if not isinstance(content, str):
                content = json.dumps(content) if content is not None else ""
            out[c.get("tool_call_id")] = {"args": c.get("arguments") or {}, "result": content,
                                          "extra": r.get("extra") or {}}
    for sub in traj.get("subagent_trajectories") or []:
        _walk_calls(sub, out)

def shell_cmd(args):
    for k in SHELL_KEYS:
        v = args.get(k)
        if isinstance(v, str) and v:
            return v
        if isinstance(v, list):
            return " ".join(map(str, v))
    return ""

def load_all():
    """Return {(bug, agent): [action dicts sorted by action_index]}."""
    trajs = {}
    for f in sorted(glob.glob(ANN + "/bug-*_actions.jsonl")):
        rows = [json.loads(l) for l in open(f)]
        by_agent = {}
        for r in rows:
            by_agent.setdefault(r["agent"], []).append(r)
        bug = rows[0]["bug_id"] if rows else os.path.basename(f).split("_")[0][4:]
        for agent, acts in by_agent.items():
            calls = {}
            p = f"{ATIF}/bug-{bug}_{agent}.atif.json"
            if os.path.exists(p):
                _walk_calls(json.load(open(p)), calls)
            for a in acts:
                c = calls.get(a["call_id"], {})
                a["cmd"] = shell_cmd(c.get("args", {}))
                a["result"] = c.get("result", "")
                a["args"] = c.get("args", {})
                a["action_index"] = int(a["action_index"])
            acts.sort(key=lambda a: a["action_index"])
            trajs[(bug, agent)] = acts
    return trajs
