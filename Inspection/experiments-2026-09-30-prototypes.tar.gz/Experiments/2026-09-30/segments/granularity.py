"""Invariant checks + granularity report for the rule-based segmenter (task step 2).
Run: python3 granularity.py > granularity_report.txt"""
import collections, statistics as st, json, sys
import segmenter
from segmenter import run_all

R = run_all()
# ---- invariants: partition, contiguity, nesting, purpose contiguity
bad = 0
for key, (acts, segs, purposes, loops, fe) in R.items():
    idx_all = [a["action_index"] for a in acts]
    covered = [x for s in segs for x in s["steps"]]
    if covered != idx_all:
        bad += 1; print("PARTITION FAIL", key)
    pos = {x: i for i, x in enumerate(idx_all)}
    for s in segs:
        p = [pos[x] for x in s["steps"]]
        if p != list(range(p[0], p[-1] + 1)):
            bad += 1; print("CONTIG FAIL", key, s["start"])
    seg_in_p = [j for p in purposes for j in p["seg_idx"]]
    if seg_in_p != list(range(len(segs))):
        bad += 1; print("NEST FAIL", key)
    for p in purposes:
        if len({segs[j]["purpose_host"] for j in p["seg_idx"]}) != 1:
            bad += 1; print("HOST FAIL", key)
print("invariant violations:", bad, "over", len(R), "trajectories")


def phase_runs(acts):
    n, prev = 0, None
    for a in acts:
        if a["high_level"] != prev:
            n += 1; prev = a["high_level"]
    return n


def q(v):
    v = sorted(v)
    return f"median {st.median(v):g} (IQR {v[len(v)//4]:g}-{v[(3*len(v))//4]:g}, range {v[0]:g}-{v[-1]:g})"


rows = collections.defaultdict(lambda: collections.defaultdict(list))
C = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
seglen_by_kind = collections.defaultdict(list)
for (bug, agent), (acts, segs, purposes, loops, fe) in R.items():
    for g in (agent, "ALL"):
        r = rows[g]
        r["steps"].append(len(acts))
        r["llm_steps"].append(len({(a["scope"], a["step_id"]) for a in acts}))
        r["phase_runs"].append(phase_runs(acts))
        r["segments"].append(len(segs))
        r["purposes"].append(len(purposes))
        for s in segs:
            r["segment_len"].append(s["n"])
            C[g]["kind"][s["kind"]] += 1
            C[g]["outcome"][s["outcome"]] += 1
            C[g]["kind/outcome_detail"][f"{s['kind']}:{s['outcome_detail']}"] += 1
            C[g]["segments_per_host_purpose"][s["purpose_host"]] += 1
            C[g]["segment_purpose"][s["purpose"]] += 1
            C[g]["flags"].update(s["flags"])
            seglen_by_kind[(g, s["kind"])].append(s["n"])
            if s["purpose"] != s["purpose_host"]:
                C[g]["nested (own purpose->host)"][f"{s['purpose']}->{s['purpose_host']}"] += 1
        for p in purposes:
            r["purpose_len_segments"].append(len(p["seg_idx"]))
            r["purpose_len_actions"].append(p["n_actions"])
            C[g]["purpose_label"][p["label"]] += 1
        for l in loops:
            C[g]["loops"][l["type"]] += 1
            C[g]["loops"][l["type"] + ":ended_" + l["ended"]] += 1
        r["has_fix_verify_loop"].append(int(any(l["type"] == "fix_verify_loop" for l in loops)))
        r["has_repro_loop"].append(int(any(l["type"] == "reproduction_loop" for l in loops)))
        r["has_stuck"].append(int(any(l["type"] == "stuck_segment" for l in loops)))
        r["reproduced_before_fix"].append(int(any(s["outcome_detail"] == "reproduced" for s in segs)))
        r["attempted_reproduction"].append(int(any(s["purpose"] == "reproduction" and s["kind"] in segmenter.EXEC_KINDS for s in segs)))

summary = {}
for g in ("claude", "codex", "gemini", "ALL"):
    r = rows[g]
    n = len(r["steps"])
    print(f"\n=== {g}  (n={n} trajectories, {sum(r['steps'])} actions, {sum(r['llm_steps'])} LLM steps, "
          f"{sum(r['segments'])} segments, {sum(r['purposes'])} purposes)")
    for k in ("steps", "llm_steps", "phase_runs", "segments", "purposes", "segment_len", "purpose_len_segments", "purpose_len_actions"):
        print(f"  {k:22s} {q(r[k])}")
    print(f"  mean actions/segment   {sum(r['steps'])/sum(r['segments']):.2f}   mean segments/purpose {sum(r['segments'])/sum(r['purposes']):.2f}")
    print(f"  share of segments with >1 action: {sum(1 for x in r['segment_len'] if x > 1)/len(r['segment_len']):.2f}")
    print(f"  single-segment purposes: {sum(1 for x in r['purpose_len_segments'] if x == 1)/len(r['purpose_len_segments']):.2f}")
    print(f"  trajectories: fix-verify loop {sum(r['has_fix_verify_loop'])}/{n}; reproduction loop {sum(r['has_repro_loop'])}/{n}; "
          f"stuck segment {sum(r['has_stuck'])}/{n}; attempted reproduction {sum(r['attempted_reproduction'])}/{n}; "
          f"reproduced before fix {sum(r['reproduced_before_fix'])}/{n}")
    for k in ("kind", "outcome", "kind/outcome_detail", "purpose_label", "segments_per_host_purpose", "segment_purpose",
              "nested (own purpose->host)", "flags", "loops"):
        print(f"  {k}: {dict(C[g][k].most_common())}")
    summary[g] = {"trajectories": n, "actions": sum(r["steps"]), "segments": sum(r["segments"]), "purposes": sum(r["purposes"]),
                  "median_segments": st.median(r["segments"]), "median_purposes": st.median(r["purposes"]),
                  "median_phase_runs": st.median(r["phase_runs"]), "median_llm_steps": st.median(r["llm_steps"]),
                  "actions_per_segment": round(sum(r["steps"]) / sum(r["segments"]), 2),
                  "segments_per_purpose": round(sum(r["segments"]) / sum(r["purposes"]), 2),
                  **{k: dict(v) for k, v in C[g].items()}}
print("\nsegment length by kind (ALL):")
for k in ("explore", "exec", "fix_attempt", "toolchain_fix", "test_edit", "delegate", "vcs"):
    v = seglen_by_kind[("ALL", k)]
    if v:
        print(f"  {k:14s} n={len(v):4d} {q(v)}")

# ---- sensitivity of the purpose layer to the fix-verify nesting cap (R9b)
print("\nR9b sweep (REPAIR_GAP_MAX): purposes/traj median, segments/purpose mean, single-segment purpose share")
default = segmenter.REPAIR_GAP_MAX
for gap in (0, 5, 10, 20, 10 ** 9):
    segmenter.REPAIR_GAP_MAX = gap
    RR = segmenter.run_all()
    for g in ("claude", "codex", "gemini", "ALL"):
        P = [len(v[2]) for k, v in RR.items() if g in ("ALL", k[1])]
        S = [len(v[1]) for k, v in RR.items() if g in ("ALL", k[1])]
        single = [len(p["seg_idx"]) == 1 for k, v in RR.items() if g in ("ALL", k[1]) for p in v[2]]
        print(f"  gap<={gap if gap < 10**9 else 'inf':>4} {g:7s} purposes median {st.median(P):4g}  seg/purpose {sum(S)/sum(P):.2f}  single-seg purposes {sum(single)/len(single):.2f}")
segmenter.REPAIR_GAP_MAX = default
json.dump(summary, open("granularity_summary.json", "w"), indent=1)

# ---- how do segment boundaries relate to the raw positional phase tags?
print("\nBoundary agreement between segments and raw high_level phase-runs (per agent)")
for g in ("claude", "codex", "gemini", "ALL"):
    seg_b = phase_b = both = 0
    mixed_segs = total_segs = 0
    blip_runs = total_runs = 0
    for (bug, agent), (acts, segs, purposes, loops, fe) in R.items():
        if g not in ("ALL", agent):
            continue
        starts = {s["steps"][0] for s in segs}
        for i in range(1, len(acts)):
            sb = acts[i]["action_index"] in starts
            pb = acts[i]["high_level"] != acts[i - 1]["high_level"]
            seg_b += sb; phase_b += pb; both += sb and pb
        pos = {a["action_index"]: a for a in acts}
        for s in segs:
            total_segs += 1
            mixed_segs += len({pos[x]["high_level"] for x in s["steps"]}) > 1
        prev, run = None, 0
        runs_ = []
        for a in acts:
            if a["high_level"] != prev:
                if prev is not None:
                    runs_.append(run)
                prev, run = a["high_level"], 0
            run += 1
        runs_.append(run)
        total_runs += len(runs_); blip_runs += sum(1 for r in runs_ if r == 1)
    print(f"  {g:7s} segment boundaries {seg_b}, raw phase boundaries {phase_b}, shared {both} "
          f"({both/seg_b:.2f} of segment boundaries are phase changes; {both/phase_b:.2f} of phase changes are segment boundaries); "
          f"segments spanning >1 raw phase tag {mixed_segs}/{total_segs} ({mixed_segs/total_segs:.2f}); "
          f"1-action raw phase runs {blip_runs}/{total_runs} ({blip_runs/total_runs:.2f})")
