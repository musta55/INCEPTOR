"""Print 6 random Codex stuck-flagged segments that verify/stuck_check2.py classes as 'progressing',
with raw cmd + error signature of each repeated failing action, for manual inspection.
Run from the experiment dir: python3 verify/stuck_eyeball.py"""
import sys, os, re, random, collections, io, contextlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
with contextlib.redirect_stdout(io.StringIO()):
    from stuck_check import sig, R
    from stuck_check2 import core
random.seed(1)
cand = []
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    if ag != "codex": continue
    for s in segs:
        if "stuck_repeating_command" not in s["flags"]: continue
        fail = [acts[x] for x in s["idx"] if (acts[x]["verdict"] == "fail" or acts[x]["failed"] == "true") and acts[x]["key"] != "wait"]
        g = collections.defaultdict(list)
        for a in fail: g[a["key"]].append(a)
        pairs = [(core(a["cmd"]) == core(b["cmd"]), sig(a) == sig(b)) for v in g.values() for a, b in zip(v, v[1:])]
        if pairs and not any(e for _, e in pairs):
            cand.append((bug, s, [a for v in g.values() if len(v) > 1 for a in v]))
for bug, s, rep in random.sample(cand, 6):
    print(f"bug-{bug} codex [{s['start']}-{s['end']}] {s['outcome']}/{s['outcome_detail']}")
    for a in rep:
        print(f"   {a['action_index']:3d} {re.sub(chr(10),' ',a['cmd'])[:75]!r}\n        -> {sig(a)}")
print(f"\n{len(cand)} codex stuck-flagged segments where no repeated failure hit the same error signature")
