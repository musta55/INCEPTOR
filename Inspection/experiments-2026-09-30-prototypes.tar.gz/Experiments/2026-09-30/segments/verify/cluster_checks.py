"""Reviewer checks on cluster.py:
 (1) is best k=12 an edge-of-grid artifact? extend K-means to k=4..30 in both spaces;
 (2) do order-blindness collisions ever mix semantically different segments (different kind / purpose /
     outcome_detail)?  If not, order blindness costs K-means nothing here;
 (3) how many feature vectors are exact duplicates (inflates silhouette)?
Run from the experiment dir:
  uv run --no-project --with scikit-learn --with scipy --with rapidfuzz python3 verify/cluster_checks.py"""
import sys, os, collections, math
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import io, contextlib
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    import cluster as C            # re-runs cluster.py (writes into ../ -> we only need its in-memory S, X, X_np)
S, X, X_np = C.S, C.X, C.X_np
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
for tag, XX in (("with_phase", X), ("no_phase", X_np)):
    row = []
    for k in list(range(10, 31, 2)):
        km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(XX)
        row.append((k, round(float(silhouette_score(XX, km.labels_)), 3), sum(1 for v in collections.Counter(km.labels_).values() if v <= 2)))
    print(tag, "(k, silhouette, #clusters with <=2 members):", row)
# (3) duplicates
for tag, XX in (("with_phase", X), ("no_phase", X_np)):
    u = np.unique(np.round(XX, 6), axis=0)
    print(f"{tag}: {len(XX)} segments -> {len(u)} distinct feature vectors")
# (2) order-blindness collisions: do differently ordered same-multiset segments differ in meaning?
by = collections.defaultdict(list)
for s in S:
    by[tuple(sorted(collections.Counter(s["mid_seq"]).items()))].append(s)
coll = [v for v in by.values() if len({tuple(s["mid_seq"]) for s in v}) > 1]
n_seg = sum(len(v) for v in coll)
mix_kind = sum(len(v) for v in coll if len({s["kind"] for s in v}) > 1)
mix_kp = sum(len(v) for v in coll if len({(s["kind"], s["purpose"]) for s in v}) > 1)
mix_det = sum(len(v) for v in coll if len({s["detail"] for s in v}) > 1)
explore_only = sum(len(v) for v in coll if all(s["kind"] == "explore" for s in v))
# stricter: collisions where DIFFERENT ORDERS carry different kind/purpose (not just different members of one order)
cross = 0
for v in coll:
    order_kp = collections.defaultdict(set)
    for s in v:
        order_kp[tuple(s["mid_seq"])].add((s["kind"], s["purpose"]))
    sets = list(order_kp.values())
    if any(not (a & b) for i, a in enumerate(sets) for b in sets[i + 1:]):
        cross += len(v)
print(f"order collisions: {n_seg} segments in {len(coll)} multisets; all-explore multisets hold {explore_only} ({explore_only/n_seg:.0%}); "
      f"multisets mixing kind {mix_kind}, kind/purpose {mix_kp}, outcome_detail {mix_det}; "
      f"multisets where two orders have disjoint kind/purpose sets {cross}")
