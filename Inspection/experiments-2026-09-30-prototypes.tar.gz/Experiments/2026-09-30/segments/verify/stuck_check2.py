"""Refined stuck check: for each stuck-flagged segment, pair consecutive repeated failing actions
(same normalized key) and classify each pair by
  exec  : 'same' if the command is identical after removing only output filters (| tail/grep/head..., 2>&1),
          else 'changed' (env prefix / exports / flags differ)
  error : 'same' / 'changed' error signature (verify/stuck_check.py:sig)
A segment is 'strict stuck' if any pair is (same exec, same error); 'stuck despite changes' if any pair is
(changed exec, same error) and none strict; otherwise 'progressing' (every repeat hit a different error).
Run from the experiment dir: python3 verify/stuck_check2.py"""
import sys, os, re, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from segmenter import run_all
from stuck_check import sig, R

def core(c):
    c = re.sub(r"\|\s*(?:tail|head|grep|sed|tee|awk|cut|sort|uniq|wc)\b[^|&;]*", "", c or "")
    return re.sub(r"\s+", " ", c.replace("2>&1", "")).strip()

seg_cls = collections.Counter(); ag_cls = collections.defaultdict(collections.Counter)
traj = collections.defaultdict(lambda: collections.defaultdict(set))
pair_cls = collections.Counter()
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    for s in segs:
        if "stuck_repeating_command" not in s["flags"]:
            continue
        fail = [acts[x] for x in s["idx"] if (acts[x]["verdict"] == "fail" or acts[x]["failed"] == "true") and acts[x]["key"] != "wait"]
        g = collections.defaultdict(list)
        for a in fail: g[a["key"]].append(a)
        pairs = []
        for k, v in g.items():
            for a, b in zip(v, v[1:]):
                pairs.append(("same" if core(a["cmd"]) == core(b["cmd"]) else "changed", "same" if sig(a) == sig(b) else "changed"))
        if not pairs and len(fail) >= 2:       # merged_stuck across segments: compare their last failing actions
            pairs.append(("same" if core(fail[-2]["cmd"]) == core(fail[-1]["cmd"]) else "changed", "same" if sig(fail[-2]) == sig(fail[-1]) else "changed"))
        pair_cls.update(pairs)
        if ("same", "same") in pairs: c = "strict_stuck"
        elif ("changed", "same") in pairs: c = "stuck_despite_changes"
        else: c = "progressing"
        seg_cls[c] += 1; ag_cls[ag][c] += 1; traj[ag][c].add(bug)
print("pairs (exec, error):", dict(pair_cls))
print("segments:", dict(seg_cls))
for ag in ("claude", "codex", "gemini"):
    print(f"  {ag}: segs {dict(ag_cls[ag])}; trajectories strict {len(traj[ag]['strict_stuck'])}, "
          f"strict-or-same-error {len(traj[ag]['strict_stuck'] | traj[ag]['stuck_despite_changes'])}, "
          f"any flagged {len(set().union(*traj[ag].values()))} of 50")
