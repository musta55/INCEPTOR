"""Sanity checks for two agent-level claims from granularity_report.txt:
(1) Claude never executes build/run_test before its first source edit;
(2) Codex reproduction runs are mostly blocked by the environment (the test never ran).
Run: python3 verify_repro.py > verify_repro.txt"""
import collections, re, random
from segmenter import run_all
R = run_all()
pre_exec = collections.Counter(); tot = collections.Counter()
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    tot[ag] += 1
    if any(a["mid_level"] in ("build", "run_test") for a in acts[:fs]):
        pre_exec[ag] += 1
print("trajectories with a build/run_test before the first source edit:", dict(pre_exec), "of", dict(tot))
first_edit_pos = collections.defaultdict(list)
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    first_edit_pos[ag].append(round(fs / len(acts), 2))
for ag, v in first_edit_pos.items():
    v.sort(); print(f"  {ag}: relative position of first source edit, median {v[len(v)//2]}")
# (2) codex reproduction segments: what did the decisive run say?
random.seed(0)
rows = []
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    for s in segs:
        if ag == "codex" and s["purpose"] == "reproduction" and s["kind"] == "exec" and s["verdict_at"] is not None:
            a = acts[s["verdict_at"]]
            txt = a["result"].replace("\\n", "\n")
            m = re.search(r"What went wrong:\s*(.{0,120})", txt, re.S)
            sig = (m.group(1) if m else txt[:160])
            rows.append((s["outcome_detail"], bug, s["start"], s["end"], re.sub(r"\s+", " ", sig)[:130]))
print("\ncodex reproduction exec segments by detail:", dict(collections.Counter(r[0] for r in rows)))
sig = collections.Counter()
for r in rows:
    if r[0].startswith("blocked"):
        sig[re.sub(r"\d+", "N", r[4])[:70]] += 1
print("most common blocking signatures:")
for k, v in sig.most_common(12):
    print(f"  {v:3d} {k}")
print("\nrandom sample of 8 blocked codex reproduction segments:")
for r in random.sample([r for r in rows if r[0].startswith("blocked")], 8):
    print("  ", r)
print("\nall not_reproduced / reproduced codex segments:")
for r in rows:
    if r[0] in ("not_reproduced", "reproduced"):
        print("  ", r)

# (3) role of the FIRST edit of each trajectory (motivates anchoring phases on the first SOURCE edit)
from segmenter import file_role
roles = collections.Counter()
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    e = next((a for a in acts if a["mid_level"] == "edit_file"), None)
    roles[(ag, e["edit_role"] if e else "no_edit")] += 1
print("\nrole of the first edit per trajectory:", {f"{a}:{r}": v for (a, r), v in sorted(roles.items())})
