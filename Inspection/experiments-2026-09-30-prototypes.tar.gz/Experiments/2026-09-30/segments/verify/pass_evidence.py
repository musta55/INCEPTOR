"""What evidence backs a 'pass' verdict on run_test actions, and how many segments labelled tests_pass
rest on a decisive run_test whose pass has NO test evidence (only BUILD SUCCESSFUL / exit 0)?
Run from the experiment dir: python3 verify/pass_evidence.py"""
import sys, os, re, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from segmenter import run_all, eff_mid
from seglib_verdict import RE_RESULTS, RE_SCRIPT, RE_JUNIT_OK, RE_BUILD_OK, RE_EXIT
R = run_all()

def basis(a):
    r = a["result"] or a.get("result_preview") or ""
    if RE_RESULTS.search(r): return "test:Results"
    if RE_SCRIPT.search(r): return "test:>>>PASSED"
    if RE_JUNIT_OK.search(r): return "test:OK(n tests)"
    if RE_BUILD_OK.search(r): return "nontest:BUILD SUCCESSFUL"
    if RE_EXIT.search(r): return "nontest:exit 0"
    return "other"
acts_c = collections.Counter(); seg_c = collections.Counter(); ex = []
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    for a in acts:
        if eff_mid(acts, a) == "run_test" and a["verdict"] == "pass":
            acts_c[(ag, basis(a))] += 1
    for s in segs:
        if s["outcome_detail"] == "tests_pass":
            b = basis(acts[s["verdict_at"]])
            seg_c[(ag, b.split(":")[0])] += 1
            if b.startswith("nontest") and len(ex) < 6:
                ex.append((bug, ag, s["start"], s["end"], acts[s["verdict_at"]]["action_index"], acts[s["verdict_at"]]["cmd"][:70], b))
print("run_test actions judged pass, by evidence:")
for k, v in sorted(acts_c.items()): print("  ", k, v)
tot = sum(seg_c.values()); nt = sum(v for k, v in seg_c.items() if k[1] == "nontest")
print(f"segments with outcome_detail tests_pass: {tot}; decisive pass without test evidence: {nt} ({nt/tot:.0%})")
for k, v in sorted(seg_c.items()): print("  ", k, v)
for e in ex: print("   ex", e)
