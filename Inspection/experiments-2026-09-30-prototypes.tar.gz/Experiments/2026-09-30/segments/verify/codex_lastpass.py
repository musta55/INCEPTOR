"""What does Codex's 'last in-trajectory run passed' (export_hierarchy.py last_run_verdict) rest on?
Run from the experiment dir: python3 verify/codex_lastpass.py"""
import sys, os, re, collections, csv
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from segmenter import run_all
from seglib_verdict import RE_RESULTS, RE_SCRIPT, RE_JUNIT_OK, RE_BUILD_OK, RE_EXIT
R = run_all()
CSV = "/Users/mustahidhasan/Downloads/3rd Semester/Trajectory Analysis/Inspection/Dataset/results-localization-codex/test_results_run_{bug}.csv"
tab = collections.Counter(); why = collections.Counter(); ex = []
harn = collections.Counter()
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    if ag != "codex":
        continue
    row = next(csv.DictReader(open(CSV.format(bug=bug))))
    harn[(row["pass"], row["test_fail"], row["compile_fail"])] += 1
    es = [s for s in segs if s["kind"] in ("exec", "fix_attempt", "toolchain_fix", "test_edit") and s["verdict"]]
    if not es:
        continue
    s = es[-1]
    a = acts[s["verdict_at"]]
    tgt = acts[a["waits_on"]] if a.get("waits_on") is not None else a
    r = a["result"]
    basis = ("Results:N passed" if RE_RESULTS.search(r) else ">>> Script: PASSED" if RE_SCRIPT.search(r) else
             "JUnit OK (n tests)" if RE_JUNIT_OK.search(r) else "BUILD SUCCESSFUL" if RE_BUILD_OK.search(r) else
             "exit code 0" if RE_EXIT.search(r) else "other")
    if s["verdict"] == "pass":
        why[(s["decisive_mid"], basis)] += 1
        if len(ex) < 4 and s["decisive_mid"] == "run_test":
            ex.append((bug, a["action_index"], tgt["cmd"][:80], re.sub(r"\s+", " ", r[-200:])))
print("harness rows (pass,test_fail,compile_fail):", dict(harn))
print("codex last verdict = pass, by decisive mid-level and evidence:", dict(why))
for e in ex:
    print("  ", e)
