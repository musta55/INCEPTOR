"""Independent (no segmenter) check of 'Claude never executes before its first source edit'.
Reads the jsonl rows only. Run: python3 verify/claude_repro.py"""
import json, glob, collections, re
ANN = "/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/corpus/annotation"
EXEC = {"build", "run_test", "device_ops", "run_shell"}
res = collections.defaultdict(collections.Counter)
for f in sorted(glob.glob(ANN + "/bug-*_actions.jsonl")):
    rows = [json.loads(l) for l in open(f)]
    by = collections.defaultdict(list)
    for r in rows:
        by[r["agent"]].append(r)
    for ag, acts in by.items():
        acts.sort(key=lambda r: int(r["action_index"]))
        fe = next((i for i, r in enumerate(acts) if r["mid_level"] == "edit_file"), len(acts))
        pre = acts[:fe]
        res[ag]["n"] += 1
        res[ag]["exec_mid_before_first_edit"] += any(r["mid_level"] in EXEC for r in pre)
        res[ag]["pipeline_or_gradle_cmd_before_first_edit"] += any(re.search(r"run_pipeline|gradlew|adb |am instrument", r["target"] or "") for r in pre)
        res[ag]["raw_high_level_reproduction_any"] += any(r["high_level"] == "reproduction" for r in acts)
        res[ag]["subagent_actions"] += sum(1 for r in acts if r["scope"] != "main")
for ag, c in res.items():
    print(ag, dict(c))
