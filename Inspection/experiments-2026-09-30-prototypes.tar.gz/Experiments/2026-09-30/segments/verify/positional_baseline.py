"""Does segmentation add anything to 'reproduced vs blocked', or does the per-action verdict parser do
all the work?  Baseline = per-action verdict_kind (seglib_verdict) on actions before the first SOURCE edit
(the segmenter's anchor) and, separately, before the first edit of any file (raw positional rule),
with no segments at all.  Also compares the baseline stuck signal (same raw command failing twice in a row).
Run from the experiment dir: python3 verify/positional_baseline.py"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from segmenter import run_all
R = run_all()
EXE = {"build", "run_test", "device_ops", "run_shell", "wait_process", "env_setup"}
out = collections.defaultdict(collections.Counter)
agree = collections.Counter()
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    fe_any = next((i for i, a in enumerate(acts) if a["mid_level"] == "edit_file"), len(acts))
    seg_rep = any(s["outcome_detail"] == "reproduced" for s in segs)
    for name, cut in (("before_first_source_edit", fs), ("before_first_any_edit", fe_any)):
        pre = [a for a in acts[:cut] if a["mid_level"] in EXE]
        rep = any(a["verdict"] == "fail" and a["fail_kind"] == "test" for a in pre)
        out[(ag, name)]["attempted"] += bool([a for a in pre if a["mid_level"] in ("build", "run_test", "device_ops", "run_shell")])
        out[(ag, name)]["reproduced(test ran & failed)"] += rep
        if name == "before_first_source_edit":
            agree[(ag, rep == seg_rep)] += 1
    out[(ag, "segmenter")]["reproduced"] += seg_rep
for k in sorted(out):
    print(k, dict(out[k]))
print("per-trajectory agreement baseline(before first source edit) vs segmenter 'reproduced':", dict(agree))
