"""Rule-consistency check: segments that START before the first source edit but are labelled
'tests_fail' (the post-fix meaning) instead of 'reproduced'.  Also: validation/repair outcomes before the
first source edit and 'reproduced' after it.  Run from the experiment dir: python3 verify/pre_fix_tests_fail.py"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from segmenter import run_all
R = run_all()
c = collections.Counter(); ex = []
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    for s in segs:
        pre = s["idx"][0] < fs
        if pre and s["outcome_detail"] == "tests_fail":
            c[(ag, s["purpose"], s["kind"], s["outcome"])] += 1
            ex.append((bug, ag, s["start"], s["end"], s["purpose"], s["outcome"], s["label"]))
        if not pre and s["outcome_detail"] == "reproduced":
            c[("POST-EDIT reproduced", ag)] += 1
print("pre-first-source-edit segments labelled tests_fail:", sum(v for k, v in c.items() if k[0] != "POST-EDIT reproduced"))
for k, v in c.items():
    print("  ", k, v)
for e in ex:
    print("   ", e)
