"""Reviewer check: how many 'stuck_repeating_command' segments are really identical repeated failures?

For every segment flagged stuck, take the failing actions whose normalized key repeats (the
evidence for 'stuck'), and compare (a) their RAW command strings and (b) an error signature
extracted from the result text.  A segment is
  truly_stuck      : some repeated key has >=2 failing actions with the same raw cmd AND the same error signature
  same_cmd_new_err : same raw cmd, but the error changed (progress / different blocker)
  env_prefix_only  : raw cmds differ (env-var prefix, export, mkdir ...) -> only equal after norm_cmd
Run from the experiment dir:  python3 verify/stuck_check.py
"""
import sys, os, re, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from segmenter import run_all

R = run_all()


def sig(a):
    r = (a.get("result") or "").replace("\\n", "\n")
    r = re.sub(r"Chunk ID: \w+|Wall time: [\d.]+ seconds|Original token count: \d+", "", r)
    m = re.search(r"What went wrong:\s*(.{0,160})", r, re.S)
    if m:
        s = m.group(1)
    else:
        m = re.search(r"(SandboxDenied|Exception[^\n]{0,100}|error:[^\n]{0,100}|FAILED[^\n]{0,60}|Could not[^\n]{0,100})", r)
        s = m.group(1) if m else r[:160]
    s = re.sub(r"/[\w./\-]+", "P", s)
    s = re.sub(r"\d+", "N", s)
    return re.sub(r"\s+", " ", s).strip()[:90]


cls = collections.Counter()
by_agent = collections.defaultdict(collections.Counter)
traj_true = collections.defaultdict(set)
traj_any = collections.defaultdict(set)
examples = collections.defaultdict(list)
for (bug, ag), (acts, segs, P, L, fs) in R.items():
    for s in segs:
        if "stuck_repeating_command" not in s["flags"]:
            continue
        traj_any[ag].add(bug)
        fail = [acts[x] for x in s["idx"] if (acts[x]["verdict"] == "fail" or acts[x]["failed"] == "true") and acts[x]["key"] != "wait"]
        groups = collections.defaultdict(list)
        for a in fail:
            groups[a["key"]].append(a)
        rep = {k: v for k, v in groups.items() if len(v) >= 2}
        if not rep and s.get("merged_stuck"):
            rep = {"merged": fail}
        label = "env_prefix_only"
        for k, v in rep.items():
            raw = collections.Counter(a["cmd"] for a in v)
            if raw.most_common(1)[0][1] >= 2:
                same = [a for a in v if a["cmd"] == raw.most_common(1)[0][0]]
                sigs = collections.Counter(sig(a) for a in same)
                if sigs.most_common(1)[0][1] >= 2:
                    label = "truly_stuck"
                    break
                label = "same_cmd_new_err"
        cls[label] += 1
        by_agent[ag][label] += 1
        if label == "truly_stuck":
            traj_true[ag].add(bug)
        if len(examples[label]) < 4:
            examples[label].append((bug, ag, s["start"], s["end"], [(a["action_index"], a["cmd"][:70], sig(a)[:60]) for v in rep.values() for a in v][:4]))

print("stuck-flagged segments by evidence class:", dict(cls))
for ag in ("claude", "codex", "gemini"):
    print(f"  {ag}: {dict(by_agent[ag])}; trajectories flagged {len(traj_any[ag])}/50, with a truly identical repeated failure {len(traj_true[ag])}/50")
for k, v in examples.items():
    print("\n", k)
    for e in v:
        print("  bug-%s %s [%d-%d]" % e[:4])
        for x in e[4]:
            print("      ", x)
