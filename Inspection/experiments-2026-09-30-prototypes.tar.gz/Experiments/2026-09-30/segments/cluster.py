"""Task step 3: do clustering methods discover interpretable segment TYPES?

Run with:  uv run --no-project --with scikit-learn --with scipy --with rapidfuzz python3 cluster.py > cluster_report.txt
Outputs: cluster_report.txt (stdout), cluster_results.json, segments_table.csv

Feature vector per segment (agent deliberately excluded):
  mid_level histogram normalised by length (15), log1p(length), log1p(#failed actions),
  failed share, ends_in_failure, repetition ratio, log1p(distinct targets), relative start
  position in the trajectory, [+ one-hot of the segment's own purpose (8) in the "with_phase" space]
"""
import json, csv, collections, math, os
import numpy as np
from segmenter import run_all
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, HDBSCAN
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score as NMI
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from rapidfuzz.distance import Levenshtein
from rapidfuzz.process import cdist

OUT = os.path.dirname(os.path.abspath(__file__))
MIDS = ["read_file", "search_code", "orient", "edit_file", "build", "run_test", "device_ops", "env_setup",
        "vcs", "plan", "delegate", "wait_process", "web", "run_shell", "other"]
PURPOSES = ["orientation", "planning", "localization", "reproduction", "environment", "repair", "validation", "review"]
CH = {m: chr(65 + i) for i, m in enumerate(MIDS)}

R = run_all()
S = []
for (bug, agent), (acts, segs, purposes, loops, fe) in sorted(R.items()):
    L = len(acts)
    for j, s in enumerate(segs):
        last = acts[s["idx"][-1]]
        ends_fail = int(last["failed"] == "true" or last.get("verdict") == "fail")
        S.append({"bug": bug, "agent": agent, "seg": j, "start": s["start"], "end": s["end"], "n": s["n"],
                  "kind": s["kind"], "purpose": s["purpose"], "host": s["purpose_host"], "outcome": s["outcome"],
                  "detail": s["outcome_detail"] or "-", "flags": s["flags"],
                  "mid_seq": s["mid_seq"], "files": s["files"][:4], "label": s["label"],
                  "n_failed": len(s["failed_steps"]), "ends_fail": ends_fail,
                  "rep": s["repetition_ratio"], "distinct": s["distinct_targets"],
                  "relpos": s["idx"][0] / max(1, L - 1)})
N = len(S)
print(f"segments: {N}")
lens = np.array([s["n"] for s in S])
print(f"segment length: share n=1 {np.mean(lens == 1):.2f}, n<=2 {np.mean(lens <= 2):.2f}, n<=4 {np.mean(lens <= 4):.2f}, max {lens.max()}")


def features(s, with_phase=True):
    h = collections.Counter(s["mid_seq"])
    f = [h[m] / s["n"] for m in MIDS]
    f += [math.log1p(s["n"]), math.log1p(s["n_failed"]), s["n_failed"] / s["n"], s["ends_fail"], s["rep"],
          math.log1p(s["distinct"]), s["relpos"]]
    if with_phase:
        f += [1.0 if s["purpose"] == p else 0.0 for p in PURPOSES]
    return f


X = StandardScaler().fit_transform(np.array([features(s) for s in S]))
X_np = StandardScaler().fit_transform(np.array([features(s, False) for s in S]))
rule_k = [s["kind"] for s in S]
rule_kp = [s["kind"] + "/" + s["purpose"] for s in S]
rule_kpd = [s["kind"] + "/" + s["purpose"] + "/" + s["detail"] for s in S]
outc = [s["outcome"] for s in S]
purp = [s["purpose"] for s in S]
agent = [s["agent"] for s in S]
lenbin = [min(s["n"], 6) for s in S]
dominant = [collections.Counter(s["mid_seq"]).most_common(1)[0][0] for s in S]


def enc(lbls):
    u = {l: i for i, l in enumerate(sorted(set(lbls)))}
    return np.array([u[l] for l in lbls])


def agree(lab, idx=None):
    pick = (lambda v: v) if idx is None else (lambda v: [v[i] for i in idx])
    return {"NMI_purpose": round(NMI(pick(purp), lab), 3), "NMI_kind_purpose": round(NMI(pick(rule_kp), lab), 3),
            "NMI_kind_purpose_detail": round(NMI(pick(rule_kpd), lab), 3), "NMI_outcome": round(NMI(pick(outc), lab), 3),
            "NMI_dominant_mid": round(NMI(pick(dominant), lab), 3), "NMI_lengthbin": round(NMI(pick(lenbin), lab), 3),
            "NMI_agent": round(NMI(pick(agent), lab), 3)}


results = {"n_segments": N, "share_len1": round(float(np.mean(lens == 1)), 3), "share_len_le2": round(float(np.mean(lens <= 2)), 3)}

# ------------------------------------------------------------------ K-means diagnostics: order blindness
# Two different orderings of the SAME multiset of mid-levels (same length) get identical
# histogram + length features, so K-means cannot tell "edit run" from "run edit".
seqs = [tuple(s["mid_seq"]) for s in S]
by_multiset = collections.defaultdict(set)
for q in seqs:
    by_multiset[tuple(sorted(collections.Counter(q).items()))].add(q)
coll = {k: v for k, v in by_multiset.items() if len(v) > 1}
seg_in_coll = sum(1 for q in seqs if tuple(sorted(collections.Counter(q).items())) in coll)
print(f"\norder blindness: {len(set(seqs))} distinct mid-level sequences -> {len(by_multiset)} distinct multisets; "
      f"{len(coll)} multisets occur in >1 order; {seg_in_coll} segments ({seg_in_coll/N:.2f}) share their exact multiset with a differently-ordered segment")
for v in sorted(coll.values(), key=lambda v: -len(v))[:3]:
    print("   e.g.", [" ".join(q) for q in list(v)[:3]])
ex_pairs = [("edit_file", "run_test"), ("run_test", "edit_file")]
n_er = sum(1 for q in seqs if q == ("edit_file", "run_test")); n_re = sum(1 for q in seqs if q == ("run_test", "edit_file"))
print(f"   'edit_file run_test' occurs {n_er}x, 'run_test edit_file' {n_re}x -> identical feature vectors apart from position/outcome")
results["order_blindness"] = {"distinct_sequences": len(set(seqs)), "distinct_multisets": len(by_multiset),
                              "multisets_with_several_orders": len(coll), "segments_in_collision": seg_in_coll,
                              "share_segments_in_collision": round(seg_in_coll / N, 3)}

# ------------------------------------------------------------------ baselines: rule labels scored in the same spaces
print("\n== Baseline: rule-based labels scored in the feature space")
results["baseline"] = {}
for name, lab in (("kind", rule_k), ("kind/purpose", rule_kp), ("kind/purpose/detail", rule_kpd)):
    sil = silhouette_score(X, enc(lab))
    results["baseline"][name] = {"n_labels": len(set(lab)), "silhouette_features": round(float(sil), 3)}
    print(f"  {name:22s} labels={len(set(lab)):3d} silhouette(features)={sil:.3f}")

# ------------------------------------------------------------------ (a) K-means
print("\n== (a) K-means on standardized features (k=4..12, n_init=20)")
results["kmeans"] = {}
best = {}
for tag, XX in (("with_phase", X), ("no_phase", X_np)):
    results["kmeans"][tag] = {}
    for k in range(4, 13):
        km = KMeans(n_clusters=k, n_init=20, random_state=0).fit(XX)
        sil = silhouette_score(XX, km.labels_)
        sizes = sorted(collections.Counter(km.labels_).values(), reverse=True)
        results["kmeans"][tag][k] = {"silhouette": round(float(sil), 3), "sizes": sizes, **agree(km.labels_)}
        print(f"  {tag:10s} k={k:2d} sil={sil:.3f} sizes={sizes} {agree(km.labels_)}")
        if tag not in best or sil > best[tag][0]:
            best[tag] = (sil, k, km)
for tag in best:
    sil, k_best, km = best[tag]
    XX = X if tag == "with_phase" else X_np
    rng = np.random.default_rng(0)
    aris = []
    for r in range(20):
        sub = rng.choice(N, int(0.8 * N), replace=False)
        km2 = KMeans(n_clusters=k_best, n_init=10, random_state=r).fit(XX[sub])
        aris.append(adjusted_rand_score(km.labels_[sub], km2.labels_))
    results["kmeans"][tag]["best"] = {"k": k_best, "silhouette": round(float(sil), 3),
                                      "stability_ARI_mean": round(float(np.mean(aris)), 3), "stability_ARI_min": round(float(np.min(aris)), 3)}
    print(f"  -> {tag}: best k={k_best} sil={sil:.3f}; stability over 20x80% subsamples ARI mean {np.mean(aris):.3f} min {np.min(aris):.3f}")

# ------------------------------------------------------------------ (b) agglomerative on edit distance
print("\n== (b) Agglomerative (average/complete linkage) on normalized Levenshtein distance of mid-level sequences")
strs = ["".join(CH[m] for m in s["mid_seq"]) for s in S]


def rle(sq):
    out = []
    for c in sq:
        if not out or out[-1] != c:
            out.append(c)
    return "".join(out)


def dmat(ss):
    D = cdist(ss, ss, scorer=Levenshtein.normalized_distance, workers=-1).astype(float)
    np.fill_diagonal(D, 0.0)
    return (D + D.T) / 2


D, D_rle = dmat(strs), dmat([rle(x) for x in strs])
print(f"  distinct mid-level sequences: {len(set(strs))} (RLE: {len(set(rle(x) for x in strs))}) of {N} segments")
results["agglomerative"] = {}
best_ag = None
for dname, DD in (("raw", D), ("rle", D_rle)):
    cc = squareform(DD, checks=False)
    for method in ("average", "complete"):
        Z = linkage(cc, method=method)
        for k in range(4, 13):
            lab = fcluster(Z, k, criterion="maxclust")
            if len(set(lab)) < 2:
                continue
            sil = silhouette_score(DD, lab, metric="precomputed")
            sizes = sorted(collections.Counter(lab).values(), reverse=True)
            key = f"{dname}/{method}/k={k}"
            results["agglomerative"][key] = {"silhouette": round(float(sil), 3), "sizes": sizes, **agree(lab)}
            if k in (4, 6, 8, 10, 12):
                print(f"  {key:22s} sil={sil:.3f} sizes={sizes[:8]}{'...' if len(sizes) > 8 else ''} {agree(lab)}")
            if sizes[0] <= 0.6 * N and (best_ag is None or sil > best_ag[0]):
                best_ag = (sil, key, lab, DD)
print(f"  -> best agglomerative with largest cluster <=60% of segments: {best_ag[1]} sil={best_ag[0]:.3f}")
for name, lab in (("kind", rule_k), ("kind/purpose", rule_kp)):
    sil = silhouette_score(D, enc(lab), metric="precomputed")
    results["baseline"][name]["silhouette_editdist"] = round(float(sil), 3)
    print(f"  baseline {name} silhouette(edit distance)={sil:.3f}")

# ------------------------------------------------------------------ (c) HDBSCAN
print("\n== (c) HDBSCAN")
results["hdbscan"] = {}
hd_keep = {}
for space, XX, metric in (("features", X, "euclidean"), ("editdist", D, "precomputed")):
    for mcs in (10, 20, 40):
        lab = HDBSCAN(min_cluster_size=mcs, metric=metric, copy=True).fit(XX.copy()).labels_
        ncl = len(set(lab) - {-1})
        m = lab != -1
        sil = silhouette_score(XX[m][:, m] if metric == "precomputed" else XX[m], lab[m], metric=metric) if ncl >= 2 else float("nan")
        sizes = sorted(collections.Counter(lab[m]).values(), reverse=True)
        idx = list(np.where(m)[0])
        seqc = [len({" ".join(S[i]["mid_seq"]) for i in np.where(lab == c)[0]}) for c in set(lab) - {-1}]
        results["hdbscan"][f"{space}/mcs={mcs}"] = {"n_clusters": ncl, "noise_frac": round(float(np.mean(~m)), 3),
                                                  "silhouette_non_noise": round(float(sil), 3), "sizes": sizes,
                                                  "clusters_with_single_sequence": int(sum(1 for x in seqc if x == 1)),
                                                  "median_len_noise": float(np.median(lens[~m])) if (~m).any() else None,
                                                  "median_len_clustered": float(np.median(lens[m])),
                                                  **agree(lab[m], idx)}
        print(f"  {space:9s} mcs={mcs:2d} clusters={ncl:2d} noise={np.mean(~m):.2f} sil(non-noise)={sil:.3f} "
              f"single-sequence clusters={sum(1 for x in seqc if x == 1)} median len noise/clustered="
              f"{results['hdbscan'][f'{space}/mcs={mcs}']['median_len_noise']}/{np.median(lens[m])} sizes={sizes[:10]} {agree(lab[m], idx)}")
        hd_keep[(space, mcs)] = lab

# ------------------------------------------------------------------ (d) within-purpose clustering (open-coding use)
print("\n== (d) Within-purpose K-means (no phase features): do sub-types emerge inside one purpose?")
results["within_purpose"] = {}
groups = {"reproduction+environment exec-bearing": lambda s: s["purpose"] in ("reproduction", "environment") and s["kind"] in ("exec", "toolchain_fix", "test_edit"),
          "repair+validation exec-bearing": lambda s: s["purpose"] in ("repair", "validation") and s["kind"] in ("exec", "fix_attempt", "test_edit"),
          "localization explore": lambda s: s["purpose"] == "localization" and s["kind"] == "explore"}
within_best = {}
for gname, pred in groups.items():
    idx = [i for i, s in enumerate(S) if pred(s)]
    XX = StandardScaler().fit_transform(np.array([features(S[i], False) for i in idx]))
    XX = np.nan_to_num(XX)
    rows = {}
    bestg = None
    for k in range(2, 9):
        km = KMeans(n_clusters=k, n_init=20, random_state=0).fit(XX)
        sil = silhouette_score(XX, km.labels_)
        det = [S[i]["detail"] for i in idx]
        rows[k] = {"silhouette": round(float(sil), 3), "sizes": sorted(collections.Counter(km.labels_).values(), reverse=True),
                   "NMI_outcome_detail": round(NMI(det, km.labels_), 3), "NMI_agent": round(NMI([agent[i] for i in idx], km.labels_), 3),
                   "NMI_lengthbin": round(NMI([lenbin[i] for i in idx], km.labels_), 3)}
        if bestg is None or sil > bestg[0]:
            bestg = (sil, k, km.labels_, km.cluster_centers_, XX)
    results["within_purpose"][gname] = {"n": len(idx), "by_k": rows, "best_k": bestg[1]}
    within_best[gname] = (idx, bestg)
    print(f"  {gname} (n={len(idx)}): " + "; ".join(f"k={k} sil={v['silhouette']} NMI(detail)={v['NMI_outcome_detail']} NMI(agent)={v['NMI_agent']}" for k, v in rows.items()))


# ------------------------------------------------------------------ (e) context conflation
# A failing test BEFORE the first source edit means "bug reproduced" (success); AFTER it,
# "fix does not work" (failure).  Can context-free clustering keep them apart?
print("\n== (e) Context conflation: 'reproduced' vs 'tests_fail' segments")
results["context_conflation"] = {}
pair_idx = [i for i, s in enumerate(S) if s["detail"] in ("reproduced", "tests_fail")]
y = [S[i]["detail"] for i in pair_idx]
for name, lab in (("kmeans_no_phase", best["no_phase"][2].labels_), ("kmeans_with_phase", best["with_phase"][2].labels_),
                  ("agglomerative_best", best_ag[2]), ("hdbscan_editdist_mcs20", hd_keep[("editdist", 20)])):
    l = [int(lab[i]) for i in pair_idx]
    tab = collections.Counter(zip(l, y))
    mixed = 0
    for c in set(l):
        r, t = tab[(c, "reproduced")], tab[(c, "tests_fail")]
        if min(r, t) >= 0.2 * (r + t):
            mixed += r
    nr = y.count("reproduced")
    results["context_conflation"][name] = {"NMI": round(NMI(y, l), 3), "reproduced_in_mixed_clusters": mixed, "n_reproduced": nr}
    print(f"  {name:24s} NMI(cluster; reproduced-vs-tests_fail)={NMI(y, l):.3f}; {mixed}/{nr} reproduced segments sit in clusters with >=20% tests_fail")

# ------------------------------------------------------------------ cluster profiles + draft names
def draft_name(mem):
    p = collections.Counter(s["purpose"] for s in mem).most_common(1)[0][0]
    k = collections.Counter(s["kind"] for s in mem).most_common(1)[0][0]
    d = collections.Counter(s["detail"] for s in mem).most_common(1)[0]
    ln = np.median([s["n"] for s in mem])
    return f"{p}/{k}, mostly {d[0]} ({d[1]/len(mem):.0%}), median len {ln:g}"


def profile(lab, centers=None, XX=None, DD=None, members=None, n_ex=2):
    members = np.arange(N) if members is None else np.array(members)
    lab = np.asarray(lab)
    out = []
    for c in sorted(set(lab) - {-1}, key=lambda c: -np.sum(lab == c)):
        pos = np.where(lab == c)[0]
        idx = members[pos]
        mem = [S[i] for i in idx]
        if centers is not None:
            order = idx[np.argsort(np.linalg.norm(XX[pos] - centers[c], axis=1))]
        elif DD is not None:
            sub = DD[np.ix_(idx, idx)]
            order = idx[np.argsort(sub.sum(axis=1))]
        else:
            order = idx
        ex, seen = [], set()
        for i in order:                               # nearest to centre, preferring different agents
            if S[i]["agent"] not in seen or len(order) < 5:
                ex.append(i); seen.add(S[i]["agent"])
            if len(ex) == n_ex:
                break
        mc = collections.Counter(m for s in mem for m in s["mid_seq"])
        tot = sum(mc.values())
        out.append({"cluster": int(c), "size": int(len(idx)), "draft_name": draft_name(mem),
                    "median_len": float(np.median([s["n"] for s in mem])),
                    "purposes": collections.Counter(s["purpose"] for s in mem).most_common(3),
                    "kinds": collections.Counter(s["kind"] for s in mem).most_common(3),
                    "outcome_details": collections.Counter(s["detail"] for s in mem).most_common(4),
                    "agents": dict(collections.Counter(s["agent"] for s in mem)),
                    "top_mid": [(m, round(v / tot, 2)) for m, v in mc.most_common(4)],
                    "ends_fail_rate": round(float(np.mean([s["ends_fail"] for s in mem])), 2),
                    "mean_failed_steps": round(float(np.mean([s["n_failed"] for s in mem])), 2),
                    "mean_repetition": round(float(np.mean([s["rep"] for s in mem])), 2),
                    "mean_relpos": round(float(np.mean([s["relpos"] for s in mem])), 2),
                    "top_flags": collections.Counter(f for s in mem for f in s["flags"]).most_common(4),
                    "examples": [{k: S[i][k] for k in ("bug", "agent", "start", "end", "mid_seq", "files", "outcome", "detail", "label", "flags")}
                                 for i in ex]})
    return out


kb = best["with_phase"]; kn = best["no_phase"]
results["profiles"] = {
    f"kmeans_with_phase_k{kb[1]}": profile(kb[2].labels_, kb[2].cluster_centers_, X),
    f"kmeans_no_phase_k{kn[1]}": profile(kn[2].labels_, kn[2].cluster_centers_, X_np),
    "agglomerative_best": profile(best_ag[2], DD=best_ag[3]),
    "hdbscan_editdist_mcs20": profile(hd_keep[("editdist", 20)], DD=D),
}
for gname, (idx, (sil, k, lab, cen, XXg)) in within_best.items():
    results["profiles"][f"within[{gname}]_k{k}"] = profile(lab, centers=cen, XX=XXg, members=idx)
results["best"] = {"kmeans_with_phase": {"k": kb[1], "sil": round(float(kb[0]), 3)},
                   "kmeans_no_phase": {"k": kn[1], "sil": round(float(kn[0]), 3)},
                   "agglomerative": best_ag[1], "agglomerative_sil": round(float(best_ag[0]), 3)}
for key, prof in results["profiles"].items():
    print(f"\n== PROFILE {key}")
    for r in prof:
        print(f"  C{r['cluster']:<2d} n={r['size']:4d} [{r['draft_name']}] kinds={r['kinds']} details={r['outcome_details']} "
              f"endsfail={r['ends_fail_rate']} rep={r['mean_repetition']} pos={r['mean_relpos']} agents={r['agents']}\n"
              f"      mid={r['top_mid']} flags={r['top_flags']}")
        for e in r["examples"]:
            print(f"      ex: bug-{e['bug']} {e['agent']} [{e['start']}-{e['end']}] {' '.join(e['mid_seq'][:12])}"
                  f"{' ...' if len(e['mid_seq']) > 12 else ''} | files={[os.path.basename(f) for f in e['files'][:3]]} | {e['outcome']}/{e['detail']} | {e['label']}")

json.dump(results, open(os.path.join(OUT, "cluster_results.json"), "w"), indent=1, default=str)
with open(os.path.join(OUT, "segments_table.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["bug", "agent", "seg", "start", "end", "n", "kind", "purpose", "host_purpose", "outcome", "outcome_detail",
                "flags", "mid_seq", "label", f"kmeans_with_phase_k{kb[1]}", f"kmeans_no_phase_k{kn[1]}", "agglo_best", "hdbscan_editdist_mcs20"])
    for i, s in enumerate(S):
        w.writerow([s["bug"], s["agent"], s["seg"], s["start"], s["end"], s["n"], s["kind"], s["purpose"], s["host"], s["outcome"],
                    s["detail"], "|".join(s["flags"]), " ".join(s["mid_seq"]), s["label"], int(kb[2].labels_[i]),
                    int(kn[2].labels_[i]), int(best_ag[2][i]), int(hd_keep[("editdist", 20)][i])])
print("\nwrote cluster_results.json, segments_table.csv")
