# HANDOFF — APR Trajectory Analysis session (2026-09-29/30)

> Saved 2026-10-01 from the compacted session log. Scratchpad paths below are now copied to `Experiments/2026-09-30/` (bpe, loops, outcomes, segments, viewer-dev). See the status check at the end.

## 1. Primary request and intent

The project is a CSCI-775 research project at W&M (user mhasan02@wm.edu). It analyses APR coding-agent trajectories at multiple levels of granularity.

**Request 1.** Review the "Existing Tools" sheet only, not "Related Paper", in `Related works/Related work for Trajectory Analysis.xlsx` (19 tools). Visit every demo, GitHub page and paper. Report on:
- our current novelty;
- what to incorporate from existing tools;
- the most interesting features.

The prototype must be ready this week. The user observed that every tool offers timelines, Gantt charts and collapsible blocks, and none claims high-level granularity while doing nearly the same. They want the novelty written so it gets approved clearly.

**Request 2.**
- Save the related study as a Markdown file.
- Detect loops from the high-level phases.
- Add another split feature for the phase Sankey.
- Check whether BPE/procedure pattern learning (ProcGrep, idea 3.4) works on the small 50-bug dataset as an RQ2 baseline.

User feedback on novelty:
- C3 (mining) and C4 (ATIF) are not novel, unless failure and inefficient steps are explicitly visualized.
- C2 (agreement metrics) is evaluation, not tool novelty.
- The only real novelty is C1 (e.g. "steps 4–9 = one failed reproduction").
- How do we cluster — K-means?
- We need stronger claims showing the tool outperforms existing ones.

Visualization wishes:
- phase Sankey;
- timeline;
- collapsible top-down blocks;
- classification and statistics;
- filtering, showing only high-level segments by default and mid-level when the filter allows.

Keep the ATIF implementation (validated with Harbor), and propose a solid plan forward.

**Request 3 (latest).**
1. Final outcome CSVs exist: `Inspection/Dataset/APR_results/test_results_claude.csv`, `test_results_codex.csv` and `test_results_gemini.csv`.
2. "I like all 5 visualization ideas, let's implement all."
3. Define how high-level segments and phases are created.
4. For manual verification, define the plausible low-, mid- and high-level actions.

On RQ1: "yes, we are doing on the new plan.. change the plan along the way." The Bouzenia RQ1 is dropped.

**Final instruction.** Summarize and save as a handoff for another session.

## 2. Key technical concepts

**Corpus**
- 50 Android APR bugs × Claude Code, Codex and Gemini CLI = 150 trajectories, about 5,400 tool calls.
- Normalized to ATIF v1.7 (Harbor framework), validated by our validator and Harbor's.
- Per-agent action totals: Claude 1,322, Codex 1,985, Gemini 2,093. Median lengths 18.5 / 35.5 / 35.5.

**Outcome ground truth**
- `APR_results`, config `code_localization_tests`. Columns: config, bug, base_pass, all_pass, n_passed. base_pass always equals all_pass, and n_passed is empty.
- Pass counts: Claude 40/50, Codex 45/50, Gemini 39/50. Bugs 1198, 1202 and 1205 fail for every agent.
- This config is the best match to the agents' own pass claims: Codex 49/50, Claude 39, Gemini 36.
- Failing bugs per agent:
  - Claude: 1202, 1441, 44, 123451, 1198, 160, 1205, 1255, 1563, 1138.
  - Codex: 1205, 1198, 1202, 1130, 1299.
  - Gemini: 1446, 1151, 192, 18, 1198, 1202, 1138, 1205, 1130, 136, 171.
- The old `results-localization-codex/test_results_run_*.csv` (0/50 pass) is not an outcome. On the Codex host, `run_pipeline.sh` dies at `jenv local 11` before printing results.

**Existing Parser** (`Parser/atif`, Python 3.9, standard library only)
- Mid-level: 15 categories, classified by tool name plus the shell program actually executed.
- Old high level: a positional phase rule (reproduction before the first edit, validation after).
- Subagent actions are spliced in at the delegating call.
- Thought text is missing for about 75% of actions; Codex encrypts its reasoning.

**Survey findings**
- Existing hierarchies are either structural or a per-step phase tag from fixed rules.
- Graphectory (OOPSLA'26 / ASE'26) is the closest prior work: per-command L/P/V tags, compressed phase strings, GSP mining of resolved vs unresolved runs, and a Phase Sankey.
- Inspect Scout imports ATIF and validates labels against humans.
- Nobody produces contiguous multi-step segments with outcomes.

**Experiment results (each re-checked by a verifier)**

*BPE*
- Feasible at K ≈ 10–40 merges. At K = 192, 43% of merges never fire in held-out data, and split-half Jaccard is 0.23 (0.54 / 0.54 / 0.47 at K = 10/20/40).
- ProcGrep's own V-measure criterion peaks at K = 10 on our data.
- As a segmenter it is only a floor: at or below the trivial run-length baseline (boundary F1 0.66 vs 0.72).
- Use one-to-one boundary matching (random baseline 0.60 vs BPE 0.73 at ±1).

*Defects in the current Parser*
- The `failed` flag only works for Codex: run_test failures recorded for Claude 1/173 and Gemini 0/349.
- The positional rule mislabels Gemini runs where the first edit is to a toolchain or test file (10/50, 89 actions).
- Codex `apply_patch` heredocs inside exec_command are labelled run_shell.
- Gradle unit-test runs are labelled `build` (e.g. Claude bug-44, action 11).

*Loops*
- Fix–verify cycles affect Claude 22%, Codex 20%, Gemini 66% of runs.
- Codex has environment and retry chains.
- Claude re-runs the pipeline only to read a different slice of the output.
- The AgentDiff stagnant detector fires in 0/6/0% of runs; EditsAfterLastVerify in 0/0/4%.
- Verifier caveats:
  - The rerun detector strips env vars.
  - "Never recovered" is mislabeled: 49/50 runs reach a verdict by another route.
  - Identical-rerun hits mostly have an edit in between.
  - The non-product fix-verify count is 42/116, not 58.

*Sankey*
- Agent identity dominates the shape, about 10× more than any other split.
- The `fail_heavy` split (failed actions per action above the agent's median) works best, but is significant within Claude and Codex only.

*Segments (prototype in the scratchpad)*
- 1,706 segments in 891 purposes, 0 invariant violations. Median per trajectory: 28 steps → 10 segments → 6 purposes.
- 66% of purposes contain a single segment.
- K-means rejected:
  - It is order-blind: 30% of segments collide with a differently ordered segment.
  - It conflates reproduced with failed fixes: 48/59.
  - With phase features it is circular (NMI 0.91).
  - Silhouette has no peak for k = 4–30.
- Pipeline: segment first, use clustering within a purpose only to suggest types, then a codebook, human labels, and a classifier.
- Verifier defects:
  - The stuck detector is too loose (strict stuck: only 4 Codex segments, not 31).
  - 4 Gemini pre-fix reproductions are mislabelled as tests_fail: bug-136 [2-7], bug-2587 [3-10], bug-2677 [2-8], bug-271 [6-7].
  - "Pass" is accepted from BUILD SUCCESSFUL or exit 0 (8/320; e.g. bug-114 Claude action 19).
  - `norm_cmd` does not handle `$(...)`.

*Process observations*
- Gemini reproduces before fixing in about 43–46/50 runs; Codex tries in 46/50 but is mostly blocked by the environment; Claude never runs a test before its first source edit (0/50).
- Gemini edited Script*.java oracles in 12/50 runs. Most changes add robustness; bugs 1446 and 171 change expected values.
- Each agent ran on a different machine: Codex /Users/sagelab, Claude /Volumes/Dumpy, Gemini /Users/jingjingwu.

**Novelty (final framing, accepted by the user)**
- C1: automatic, outcome-aware, strictly nested segmentation.
- C2: failure and inefficiency spans surfaced and made visible, including process-integrity flags.
- C3: beats re-implemented baselines on human ground truth (evidence for C1 and C2).
- Not novel: ATIF ingestion, mining in itself, agreement metrics.

## 3. Files and code sections

**Created**

- **`Related works/Related study - existing tools.md`** — the full 19-tool survey: summary, comparison matrix, per-tool notes, features to incorporate, sheet corrections, sources.
- **`Parser/View data contract.md`** — the `trajview/1` schema that both the producer and the viewer use. Key points:
  - Producer command: `python3 -m atif.cli view --all`, which writes `Parser/viewer/data/corpus.js` containing `window.TRAJ_DATA = {...};` (so it works over `file://`).
  - Top-level fields: schema, generated_by, outcome_config = "code_localization_tests", vocab {mid (15), purposes [orientation, localization, reproduction, environment, repair, validation, review], segment_types, flags}.
  - Each trajectory: {id "bug-18/codex", bug, agent, app, n_actions, n_steps, outcome {pass, by_config}, badges, stats, actions, purposes, loops}.
    - badges: self_claims_pass, reproduced_before_fix, edits_test_script, edits_harness, env_blocked_runs, last_test_verdict.
    - stats: n_segments, n_purposes, n_failed_actions, n_fix_attempts, n_failed_fix_attempts, n_loops, n_stuck_segments, env_share, first_source_edit, duration_s.
    - actions: [{i, step, scope, tool, mid, phase, target ≤200, verdict pass|fail|none, fail_kind test|build|env|exit|null, failed_raw, ts, thought ≤300, result ≤300, call_id}].
    - purposes: [{id, label, start, end, segments: [{id, type, kind, label, purpose, nested, outcome, outcome_detail, start, end, steps, flags}]}].
    - loops: [{type fix_verify_loop|reproduction_loop|stuck_segment, start, end, iterations, failed_iterations, ended, segment_ids}].
  - Invariants: `actions[k].i == k+1`; purposes contiguous and covering 1..n; segments contiguous and covering their purpose; `steps == range(start, end+1)`; `segment_ids` resolve; every value is in vocab.
- **`Parser/Annotation codebook.md`** — fully rewritten; answers request 3.4.
  - Levels:
    - L0: tool call, with lists of the actions seen in this corpus.
    - L1: 15 categories, with the priority order and the confusion rules.
    - L2: segments. Boundary rules: goal switch; an attempt includes its judging run; a retry with no change is stuck; localization splits by code area; ignore blips; patch review is its own segment.
    - L3: 7 state-based purposes, anchored on the first application-source edit, with a nesting rule for segments of ≤3 actions.
  - Codebook v1 types in 7 families:
    - targeted_lookup, file_by_file_localization_sweep, lookup_tool_errors, orientation_planning, delegated_exploration;
    - reproduction_succeeded / blocked / not_reproduced;
    - toolchain_wrestling;
    - fix_attempt_passed / failed / breaks_build / blocked_by_env, unverified_edit, delegated_edit;
    - validation_passed / failed / blocked_by_env;
    - test_or_harness_modification;
    - stuck_repeating_failure;
    - review_patch;
    - plus …_other.
  - Outcomes: succeeded, failed, looped, unverified, completed, no_verdict.
  - Flags: stuck_repeating_command, env_wrestling, edits_test_script, edits_harness, edits_toolchain, off_patch_exploration, rereads_same_file, abandoned, retried_immediately / retried_after_detour, recovered_after_repeats.
  - Protocol:
    - Pilot: bug-18 × 3 agents (99 actions).
    - Test: bugs 1138, 1563, 1299, 1446, 1202 × 3 agents (708 actions; 7 pass / 8 fail).
    - Two blind raters; the automatic segment columns are hidden.
    - Columns: auto_mid_correct, manual_mid_level, manual_segment_id, manual_segment_type, manual_segment_outcome, manual_flags, manual_purpose, manual_notes, adjudicated_*.
    - Metrics: L1 κ; L2 boundary F1 with one-to-one matching at tol 0 and ±1, plus WindowDiff; type and outcome κ on matched segments (IoU ≥ 0.5); flag precision and recall; L3 per-action κ.
- **`Project plan v2.md`** (project root) — replaces the proposal's methodology.
  - Data facts; claims C1–C3 and the "not claimed" list.
  - RQs:
    - RQ1: segmentation validity vs baselines and the human ceiling.
    - RQ2: precision of failure/inefficiency surfacing vs existing detectors.
    - RQ3: pass/fail and agent behaviour at each level (exploratory, 26 failures).
    - RQ4: analyst study vs a step-list baseline.
  - Method: pipeline, optional LLM pass with step-id citations, baselines, a six-view viewer.
  - Evidence so far.
  - Milestones:
    - M2: Sep 30–Oct 5, prototype.
    - M3: Oct 6–19, ground truth.
    - M4: Oct 20–Nov 9, baselines and RQ1/RQ2.
    - M5: Nov 10–23, RQ3.
    - M6: Nov 24–Dec 7, RQ4 and packaging.
  - Freeze rule: no rule or codebook changes after test labelling starts.
  - Risks table.
- **Memory files** in `/Users/mustahidhasan/.claude/projects/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/memory/`: `apr-corpus-outcomes.md`, `project-plan-v2.md`, plus index lines appended to `MEMORY.md`.

**Scratchpad artifacts**

Scratchpad root: `/private/tmp/claude-501/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269/scratchpad/`. It is temporary, so move anything needed.

- `corpus/{atif,annotation,reading}` — all 50 bugs converted.
- `experiments/bpe/` — bpe_core.py, run_bpe.py, run_bpe_extra.py, vmeasure.py, results, verify/.
- `experiments/loops/` — loops.py, sankey.json, sankey_split_failheavy.json and other splits, loop_instances.jsonl, rule_v2.py, common.py, verify/.
- `experiments/segments/` — **the reference prototype to port**:
  - README.md documents rules R1–R11. Constants: ABSORB_MAX 3, REPAIR_GAP_MAX 10, stuck-merge gap ≤3, REPRO_REACH 2.
  - Code: segmenter.py (786 lines), seglib_load.py, seglib_verdict.py, codebook.py (`code(s)`, 24 types), export_hierarchy.py, cluster.py.
  - Outputs: all_hierarchy.json, bug-18_hierarchy.json.
- `experiments/outcomes/` — 01–08 scripts and `out/*.csv` (proxy outcomes, self-report classifier 03b, tamper evidence, patch recoverability).
- **`backup-Parser-2026-09-30/`** — a full copy of `Parser/` taken before the agents ran. 24 tests were passing at that point.
- Workflow journal: `/Users/mustahidhasan/.claude/projects/.../subagents/workflows/wf_8eece787-7a9/journal.jsonl`.

**Existing Parser files (read, not modified by me)**
- `atif/taxonomy.py` — MID_LEVEL, HIGH_LEVEL, PROGRAM_KIND, KIND_PRIORITY, `_TEST_TASK` regex.
- `atif/tar.py` — `iterations()`, `write_csv`, `write_jsonl`, `write_reading_view`.
- `atif/cli.py` — commands: convert, validate, actions, audit, output, list; options `--out` and `--dataset`.
- `tests/test_parsers.py` — 24 tests.

## 4. Errors and fixes

- **zsh `echo ====X` failed** with "not found", because of `=` expansion. Fixed by using `---` markers.
- **Large tool outputs were persisted to files.** I read them with the Read tool instead.
- **Journal parsing hit a KeyError on 'key'.** Fixed by using `.get()`.
- **I miscounted running agents twice** (said 2 when 3 remained, then said one had finished when it hadn't). Corrected in follow-up messages.
- **The workflow's claims adversarial-review agent failed** on the session limit. The claims in the plan are therefore not adversarially reviewed.
- **Both background agents failed on the session limit** (resets 1:30am America/New_York), after partial work.
- **User correction:** the outcomes do exist (APR_results). This superseded my "no trustworthy outcomes" conclusion and the old Codex CSV.

## 5. Problem solving

- Determined the matching config by comparing each config with the in-trajectory proxy and the self-report; `code_localization_tests` matched best.
- Designed the decoupled producer/viewer contract so the two tracks could run in parallel.
- Selected a stratified annotation sample.

## 6. All user messages

1. Initial request (pasted): "for this project, you already know what we are supposed to do, but yesterday it took me almost 8 hours to make a registry of existing tools. Please have a look at this existing tool and give me a summary report on: What is the current novelty in our own project? What can we incorporate by looking into the existing tools? What are the fascinating features that we could incorporate? Give me a brief summary for this, and also this week we need to make our prototype ready for this tool."

   Plus: "Take a lot of time and details into the existing tools sub-sheet, not the related papers sub-sheet. Look and go to each of the demos, like the GitHub pages, descriptions, and papers that I have listed down. So far, though, all these visualizations have the timeline views, some Gantt chart timelines, and also the collapsible block approaches. Nobody claimed to meet high-level granularities, but eventually they do almost the same. We need to write in such a way that our novelty gets approved in a clearer way, so we need to work on that portion, obviously."
2. (Tool-loaded acknowledgement only.)
3. "Great. Now, at first, save in a Markdown file as the related study. So far, you have analyzed from our spreadsheet and your observation. Also, if are able to mine pattern, we should detect loops from the high level phases. We need another feature for phase sankey split. I really want to have the most interesting feature 3.4, the progress pattern learning, as a baseline for our Q2, but I am just worried about whether we have the 50 bug localization APR patches or the trajectories. Is it sufficient to do that sort of PP tokenization in some such small dataset?"

   Pasted: "for our claims, I think C3 and C4 are not meaningful because the mining pattern, I don't think, is useful. It's fully novel for an API task or other transaction analysis. If we can clearly or explicitly visualize it in such a way that we can show the failure steps or the inefficient steps, it could be impactful. Then we can claim this. For C2, I think it's a part of evaluation, so it's not fully tool-level or automated-level novelty here. I think the only novelty I got so far from C1 is the failure reproductions from step 4 to step 9. In that way, how can we cluster them? Are we going to use the K-means clustering algorithm, or what's the plan for the implementation for that? I need to know and brainstorm accordingly. Also, I need to make stronger claims so that our automated tool can outperform and be better than the existing tools."

   Plus: "as per the visualization plan, I want to have the following: the phase sankey structure, the timeline structure, the collapsible blocks for top-down structure. We also need to have the classification or the statistics and the filtering mechanisms to filter out some. We want to only show the high-level features or the segments from the API trajectories, and also the mid-level segments if our filter allows it. You need to visualize in that way."

   Plus: "for each of the agent trajectories we have a common format called the AT[IF] format and we also validated it with Harbor that's fine with that, we want to keep the implementation and then you need to propose me the next steps … I need you to propose a solid plan to move forward based on the conversation."
4. "do you have answers now?"
5. "1. We have the final outcome CSV. all tests results saved in the @APR_results folder in the @Inspection/Dataset/APR_results/test_results_claude.csv @Inspection/Dataset/APR_results/test_results_codex.csv @Inspection/Dataset/APR_results/test_results_gemini.csv files with the bug names. 2. I like all 5 visualization ideas, let's implement all. 3. We need to define how our high level segments or phases are created. 4. For manual verification, we need to define what are the plausible low,mid and high level actions we are envisioning for.. Also to decide: the proposal's M2 (RQ1 on Bouzenia's 120 labelled trajectories, due Oct 5) doesn't match the Android corpus we're working on. We should settle whether RQ1 still stands as written. -> yes, we are doing on the new plan.. change the plan along the way."
6. Final: summarize, "and save this summarized version of the session as handoff for another session."

No security-specific constraints were stated by the user. Standing guidance from the environment: never send the user's email to external services; confirm before outward-facing or destructive actions.

## 7. Pending tasks

**A. Parser port** (the agent failed midway; redo or finish), in `Parser/atif/`, standard library only, matching the existing style.

New modules:
- `verdict.py`
- `segment.py` — segmenter R1–R11, codebook `type`, loop overlay, `check_hierarchy()`
- `outcomes.py` — APR_results, `code_localization_tests` plus `by_config`, and the badges
- `view.py` — writes `viewer/data/corpus.js` per the contract

Taxonomy fixes:
- Codex `apply_patch` heredoc → `edit_file`, with file paths taken from `*** Update File:` / `*** Add File:`.
- Gradle unit-test tasks → `run_test` (Claude bug-44, action 11).
- Phase rule v2 (state-based):
  - Anchor on the first application-source edit.
  - Edit roles:
    - source: everything else;
    - toolchain: *.gradle, *.properties, gradle wrapper, run_pipeline.sh;
    - test: reproducing_script_project/, androidTest/, /test/.
  - source → repair; toolchain → environment; test → reproduction before the anchor, validation after.
  - Drop `planning` from the purposes.
  - Keep the old `high_level` column and add `phase`.

Defect fixes, each with a regression test:
- Strict stuck: same full command with env vars kept (only output filters stripped), same error signature, ≥2 failures, and no edit or env_setup in between. Anything else is env_wrestling.
- Handle `$(...)` and quotes when splitting commands.
- Apply reproduction semantics to all execution segments before the first source edit (Gemini 136, 2587, 2677, 271).
- A run_test pass requires real test evidence (bug-114 Claude action 19 must be `none`).
- Parse verdicts only for build/run_test/device_ops/run_shell/env_setup/wait_process.

CLI and checks:
- New `segment <bug|--all>` and `view --all`.
- `convert` adds phase, verdict, fail_kind and edit_role columns.
- Run `convert --all`, the tests, and `validate --harbor`.
- Write a changelog for the Technical report.

First, inspect what the failed agent already changed:
- diff against `scratchpad/backup-Parser-2026-09-30`;
- run `python3 -m unittest discover -s tests -t .`.

**B. Viewer** (the agent failed midway, at "Several layout fixes needed"). Files are `Parser/viewer/index.html`, `viewer.css` and `viewer.js`. It must work offline with no CDN and use vanilla JS and SVG. Dev files: `scratchpad/viewer-dev/` (sample_corpus.js adapter, site/, shots/).

Six views over one shared state:
1. Collapsible top-down blocks, with a level selector: purposes only / + segments / + steps.
2. Timeline: purpose and segment bands, loop overlays, mid-level swim lanes, a failure rail, a playhead synced to the top-down view, and brushing.
3. Phase Sankey with a client-side layered layout. Split by agent, by outcome pass/fail, or by fail-heavy. Clicking a link filters the trajectory list.
4. Category × step fingerprint grid, with the 3 agents of a bug as small multiples.
5. Compare view: agents aligned by LCS over segment types.
6. Statistics and classification table, with per-agent aggregates.

Global filters: agent, outcome, purpose, segment type, segment outcome, flags, badges, and an "only failure & inefficiency" toggle. Filtered-out items are greyed by default, with a hide toggle. Also: light and dark mode, keyboard j/k and [ ], and screenshot testing with headless Chrome.

Inspect the partial files first.

**C. Write `Parser/Segmentation spec.md`** (answers request 3.3). Cover:
- how per-action phases, segments (R1–R11 with constants), types, outcomes, flags, purposes and loops are created;
- the invariants;
- known limits.

Write it once the port exists and the exact implemented constants are known.

**D. Update docs after the port.** Update `Technical report.md` and `README.md` with the changelog (the agent was told not to edit them).

**E. Remaining M2 items.**
- Generate blind annotation sheets for the pilot and test sets (the automatic segment columns hidden).
- Move the needed scratchpad artifacts into the project.

**F. Save this handoff summary** as a Markdown file in the project root.

## 8. Current work

Immediately before the summary, I had written the codebook, Project plan v2, the contract and the memory files. I had launched two background agents: "Port segmenter into Parser" and "Build trajectory viewer UI". Both terminated with the session-limit error (reset 1:30am America/New_York):

- The port agent's last words: "Now the segmenter. I'll first port it faithfully, verify it reproduces the prototype's output, and then apply the fixes." It had likely created `verdict.py` and/or `outcomes.py`, and possibly taxonomy changes, but not `segment.py` or `view.py`.
- The viewer agent's last words: "Several layout fixes needed. Let me apply them." The viewer files likely exist in `Parser/viewer/`, with sample data only in the scratchpad.

## 9. Next step

1. Save this summary as `Session handoff 2026-09-30.md` in the project root, as the user asked: "save this summarized version of the session as handoff for another session".
2. Then resume request 3 ("2. I like all 5 visualization ideas, let's implement all. 3. We need to define how our high level segments or phases are created."):
   - Inspect `Parser/` against the backup and run the tests.
   - Finish the parser port (task A) and the viewer (task B). Resume the agents via SendMessage if they are still available after the reset; otherwise relaunch them with the same prompts.
   - Write `Parser/Segmentation spec.md` from the implemented rules.
   - Generate `corpus.js` and verify the viewer end to end with screenshots.

If you need specific details from before compaction (like exact code snippets, error messages, or content you generated), read the full transcript at: /Users/mustahidhasan/.claude/projects/-Users-mustahidhasan-Downloads-3rd-Semester-Trajectory-Analysis/fbb9d7d3-c345-4144-a19e-be5615ddc269.jsonl

---

## 10. Status check — 2026-10-01

The handoff above was written assuming both agents died early. They got much further:

| Task | State |
|---|---|
| A. Parser port | **Done.** `verdict.py`, `segment.py` (R1–R11, codebook types, loops, `check_hierarchy`), `outcomes.py`, `view.py`; taxonomy fixes; CLI `segment` and `view`. 51/51 tests pass (was 24), including every listed regression. `validate`: 150/150. Corpus: 1,711 segments, 899 purposes; outcomes 40/45/39. |
| B. Viewer | **Works on the real corpus**, with all 6 views and no console errors. Unfinished: the interaction self-test (`Experiments/2026-09-30/viewer-dev/selftest.js`). Deep links work (`#v=sankey&t=bug-18%2Fgemini`). All 6 views screenshotted on real data 2026-10-01. Open defect (rule order, not the badge): in 5 Gemini runs (bug-18, 92, 114, 1130, 1446) the test first fails inside a toolchain/test-edit segment, so its outcome is `reproduced` but the type says toolchain or test modification. See `Parser/Technical report v2 (draft).md` §16. |
| C. `Parser/Segmentation spec.md` | Covered by `Parser/Technical report v2 (draft).md` §6–§11 (2026-10-01). |
| D. Technical report / README changelog | Not done. |
| E. Blind annotation sheets | Not generated. Current sheets still have the old manual columns, not the codebook's. |
| E. Scratchpad artifacts | Copied to `Experiments/2026-09-30/` (2026-10-01). |
| `validate --harbor` | Re-run 2026-10-01: 150/150 valid. |
