# Segmentation and classification plan: from hand rules to a general, defensible method

**Status.** Proposal, 2026-10-01. It changes how L1–L3 are computed before any human
labels are used. It does not change the RQs in [Project plan v2.md](Project%20plan%20v2.md).
The current implementation is described in
[Parser/Technical report v2 (draft).md](Parser/Technical%20report%20v2%20(draft).md).

---

## 1. Where the current method stands (measured 2026-10-01)

| Concern | Fact | Consequence |
|---|---|---|
| Tool-name dependence | 2,785 of 5,400 actions (52%) are shell commands, labelled by the program they run. This does not depend on the agent. The other 2,615 (48%) come from `TOOL_MAP`: 18 tool names of 3 agents | A fourth agent loses about half its labels to `other` until someone extends the table |
| Segmentation layer | R1–R11 read mid-level categories, verdicts and file roles. They read tool names only to special-case `apply_patch` | The segmenter is already agent-agnostic. Its inputs are not |
| Domain dependence | Verdict markers (`run_pipeline.sh`, AndroidJUnitRunner, Gradle) and file roles (`androidTest/`, `*.gradle`) are Android-APR specific | A bigger obstacle to generality than `TOOL_MAP` |
| ATIF support | ATIF v1.7 has an optional `agent.tool_definitions` field. Only our Claude converter fills it, and only with names. Every call carries its arguments | A tool's role can be inferred from its argument names (`old_string`, `pattern`, `command`, `session_id`) without knowing the tool |
| Method status | Rules and constants were hand-tuned on the same 150 runs they describe. No formal model, no sensitivity analysis, no generalization test | This, not "being rule-based", is the legitimacy problem |
| Prior tools | Graphectory, Agent ATO, Coding Agent Trajectory Viewer and Mindwalk tag steps with fixed rules. ProcGrep starts from 16 hand-defined atoms. None validates its labels against humans | Rules are the norm in this area. Validated, general rules would not be |

---

## 2. Two claims to add, both testable before human labels exist

**N1. Outcome-anchored, state-conditioned segmentation.**
- **What:** segment boundaries and segment types depend on two things:
  - the *result* of each run, parsed from its output (pass, fail, and why);
  - the trajectory's *state*: before or after the first source edit.
- **Prior art:** Graphectory segments by command type and ProcGrep by token frequency;
  neither reads results.
- **How it is tested:** ablation. Remove the result signal, then the state signal, and
  measure how many boundaries and types change (before labels) and how much accuracy
  drops (after labels).

**N2. Agent-agnostic action frames.**
- **What:** each tool call is described as *(operation, object, effect)*, inferred from
  its arguments and its result rather than from its tool name. The 15 mid-level
  categories become a fixed function of the frame.
- **How it is tested:**
  - leave-one-agent-out on our corpus;
  - running on a corpus from agents we never tuned for.

What we borrow, so that the method can be cited instead of defended from scratch:

| Part | Borrowed from |
|---|---|
| Low-level → high-level event mapping | event abstraction in process mining (van Zelst et al. 2021, survey); pattern-based abstraction (Mannhardt et al. 2018) |
| Optimal partition by dynamic programming over a segment score | text segmentation (Utiyama & Isahara 2001); cohesion-based boundaries (Hearst 1997, TextTiling) |
| Boundary metrics | Pevzner & Hearst 2002 (WindowDiff), plus boundary F1 |
| Learned sequence-labelling baseline | supervised event abstraction with CRFs (Tax et al. 2016; Lafferty et al. 2001) |
| Typed, agent-agnostic action vocabulary | OpenHands' typed actions (Wang et al. 2025); SWE-agent's agent–computer interface (Yang et al. 2024); Bouzenia & Pradel 2025 action categories |
| Per-harness result parsers | SWE-bench's per-repository log parsers (Jimenez et al. 2024) |

DP segmentation and CRFs are not new. The new part is the signals they score (N1) and
the input representation (N2), and both are tested.

---

## 3. Step 1: action frames replace `TOOL_MAP` as the primary classifier

Each action gets three fields, plus a record of how they were decided (`frame_source`):

| Field | Values |
|---|---|
| operation | read, search, list, write, execute, wait, delegate, plan, fetch, communicate |
| object | app_source, test, build_config, harness, environment, vcs, external, unknown |
| effect | pass, fail:test / build / env / exit, none (the existing verdict) |

**Operation**, resolved in this order:

1. **Format-level facts.** A call with a sub-agent reference → delegate. A call carrying
   a session id from an earlier result → wait. ATIF records both regardless of agent.
2. **Argument signature.** For example:

   | Arguments include | Operation |
   |---|---|
   | old and new text, or a patch body | write |
   | content plus a path | write |
   | a pattern or query | search |
   | only a path to a file | read |
   | only a path to a directory | list |
   | a command or cmd string | execute, then 3 |
   | a url | fetch |

   The signatures are written once over argument names, not tool names, and logged per
   tool.
3. **Shell program parsing** for execute, as today (`split_commands`, priority list).
4. **Tool-name table**, only as a tie-break for signatures that are genuinely ambiguous.
5. **Unknown tool.** One LLM call per *distinct tool*, not per action. The input is the
   tool's name, its argument schema aggregated over calls, and its description when
   `tool_definitions` has one. The answer is cached, shown in a report, and checked by a
   person. Cost: a handful of calls per new agent.

**Object** generalizes the current edit roles beyond Android:

| Object | Recognized by |
|---|---|
| test | the common test conventions of each ecosystem: `test/`, `tests/`, `__tests__/`, `androidTest/`, `*Test.java`, `test_*.py`, `*.spec.ts` |
| build_config | build files of each ecosystem: Gradle, Maven, npm, pyproject, Cargo, Make |
| harness | read from the **task prompt**, not hard-coded: the scripts and test files the first user message names as the way to check the fix. For our corpus this yields `run_pipeline.sh` and `Script*.java` |
| environment | paths outside the checkout, and toolchain locations |

**Effect.** Verdict parsing is split into generic parsers (JUnit, Gradle, pytest, jest,
go test) and a *harness adapter* per benchmark. The Android adapter holds today's
`run_pipeline.sh` markers. This follows the SWE-bench pattern, and it states plainly that
a new benchmark needs an adapter.

The mid-level category is derived from the frame. For example, execute + a test runner →
`run_test`; write + test → `edit_file` with role test. Old and new labels can then be
compared one-to-one.

**Checks:**
- **G0, audit.** Raters do not label L1. One author audits a stratified sample of about
  200 actions once, before the freeze ([codebook §6.4](Parser/Annotation%20codebook.md)),
  and reports precision per category and per verdict. Deterministic means reproducible,
  not correct.
- **G1, leave-one-agent-out.** Drop all tool-name entries for one agent, classify by
  steps 1–3 only, and measure agreement with the full classification. Target: ≥ 95% on
  each agent. Every disagreement is listed.
- **G2, unseen agents.** Run unchanged on trajectories from agents we did not tune for.
  First choice: ATIF exports from Harbor runs of other agents, if available. Fallback:
  convert 10–20 public SWE-agent or OpenHands trajectories (the SWE-bench experiments
  repository ships them).
  - Report the share of actions labelled `other` or `unknown`.
  - Label 200 actions by hand for accuracy.

## 4. Step 2: segmentation by exact optimal partitioning

### 4.1 Is the current segmenter heuristic? Yes.

Today's segmenter (`Parser/atif/segment.py`, rules R1–R11) runs a fixed series of passes:
1. group actions into blocks;
2. absorb short blocks until nothing changes;
3. split blocks;
4. merge stuck runs;
5. pick a type from a precedence list.

Each pass is greedy and local, and the result depends on the order the passes run in.
Nothing states what a *good* segmentation is, so we cannot ask whether the output is the
best one under our own definition. A boundary cannot be traced to the evidence that
caused it, and a sensitivity analysis is hard to interpret because the thresholds
interact through the pass order. The 5 mislabelled Gemini segments
(Technical report v2, §16) are an order effect: the toolchain rule is checked before the
reproduction rule.

### 4.2 What changes

We **state an objective and compute its exact optimum** with dynamic programming (DP).
- **The heuristic part** moves into the objective: which evidence counts, and how much.
  That evidence comes from the codebook (§3.2), and about eight weights express it.
- **The search** is exact, not heuristic: for the stated objective, the DP returns the
  best segmentation there is.

This is the standard structure of feature-based segmentation:
- **optimal partitioning:** Jackson et al. 2005; with pruning, PELT (Killick et al. 2012);
- **semi-Markov segmentation**, where each span also carries a label (Sarawagi & Cohen
  2004).

In our case, the label of a span is fixed by the decision table (§5), so semi-Markov
segmentation reduces to one-dimensional optimal partitioning. The span score depends on
that label.

### 4.3 Input

For actions a_1 … a_n, all computed deterministically by Step 1:

| Feature | Meaning |
|---|---|
| m_k | macro-class: **EXEC** (execution; harness and build-output reads count here), **EDIT**, **EXPL** (read, search, orient), **VCS**, **DELEG** (delegation and its sub-agent rows) |
| v_k, f_k | result (pass / fail / none) and failure kind |
| d_k | decisive run (codebook §2) |
| area_k | code area of a locate action |
| key_k, sig_k | normalised command and error signature, for repeats |
| A | the anchor: index of the first application-source edit |

### 4.4 Objective

A segmentation S is a list of contiguous spans covering 1 … n. A **cut** c lies between
a_c and a_{c+1}.

```
J(S) = Σ_{s ∈ S} φ(s)  +  Σ_{c ∈ cuts(S)} b(c)

φ(s) = − β                                   cost of opening a segment
       − λ · imp(s)                          imp(s) = |s| − (count of s's most frequent macro-class)
       − γ · [type(s) is a catch-all]        decision table (§5) found no specific type

b(c) = w_pass · PASS(c)                      a_c is a test run that passed            (codebook C1)
     + w_fail · FAIL(c) · SWITCH(c)          a_c is a decisive failure and the
                                             macro-class changes at c                 (C2, C4)
     + w_area · AREA(c)                      a_c, a_{c+1} are lookups in different
                                             code areas                               (C3)
     + w_anc  · [c + 1 = A]                  the cut falls right before the anchor     (state)
     − ∞      · HARD(c)                      the cut breaks K1–K4                      (K1–K4)
```

**HARD(c)** forbids a cut:
- between an edit and its first decisive run (K1);
- inside a delegation block (K2);
- between a poll and the run it polls (K3);
- between two runs of a strict repeat: the same command and the same error signature,
  with no edit and no environment change between them (K4).

K5 (ignore blips) is not a constraint. It *emerges* from the costs: cutting around a
one-row blip costs two segment openings (2β), while keeping it costs λ for one
off-class action. So the blip is absorbed whenever λ < 2β plus the boundary evidence.

### 4.5 Algorithm

```
F(0) = 0
for j = 1 … n:
    F(j) = max over i in 0 … j−1 of
           F(i) + φ(a_{i+1 … j}) + (b(i) if i > 0 else 0)
    back(j) = the i that attains the max
segmentation = follow back() from n down to 0
```

- **Exactness:** F(n) is the maximum of J over all 2^(n−1) segmentations; the recurrence
  is exact because J is a sum over spans and cuts.
- **Cost:** O(n²) spans. imp(s) takes O(1) with prefix counts per macro-class, and the
  decision table O(|s|), so the worst case is O(n³). The longest trajectory has 117
  actions: under 1.6 million elementary steps, well under a second in Python.
- **No length cap is needed.** The longest current segment has 40 actions (a
  delegation) and the median has 2.

### 4.6 Each term, and the rubric rule it encodes

| Term | Codebook rule | Today's rule |
|---|---|---|
| β, λ | K5 blips; one goal per segment | R1 macro-class runs, R3b absorption |
| w_pass | C1 goal reached | R5 split after a passing test |
| w_fail · SWITCH | C2 goal switch, C4 new attempt | R1 class change, R5b |
| w_area | C3 focus switch | R4 |
| w_anc | the pre/post-fix distinction | the anchor (rule v2) |
| HARD | K1–K4 | R5b, R3a, poll linking, R6 |
| γ | prefer spans with a specific type | none (new) |

### 4.7 Worked example: bug-18 / Gemini, rows 1–7

| Cut after row | Evidence | Decision |
|---|---|---|
| 1 | test run failed (compile error), but row 2 reads the harness script, which is EXEC: no class switch | no cut: a cut only adds −β |
| 3 | build failed **and** the class switches EXEC → EXPL | cut: w_fail > β |
| 5 | class switches EXPL → EDIT; keeping rows 4–7 together would cost λ · 2 off-class rows | cut, when 2λ > β |
| 6 | an edit, then its first decisive run at row 7 | forbidden (K1) |
| 7 | test executed and failed; class switches EXEC → EXPL | cut |

Result: [1–3] [4–5] [6–7], the rubric's answer (codebook §5). The decision table then
types [6–7] as `reproduction_succeeded` with flag `edits_toolchain` (Q4), which fixes
today's mislabel.

### 4.8 Purposes: Viterbi decoding over segments

The segments s_1 … s_K are labelled with the seven purposes by a first-order hidden
Markov model decoded with the Viterbi algorithm (Rabiner 1989), itself a DP:

```
maximise   Σ_k e(s_k, p_k)  −  δ · #{k : p_k ≠ p_{k−1}}

e(s, p) = 0                       if p = own(s)                      (codebook §4.1)
        = − c(own(s), p) · |s|    if s may nest in p                 (codebook §4.2)
        = − ∞                     otherwise, or if p = reproduction and s is post-fix,
                                  or p = validation and s is pre-fix
```

- **Cost:** O(K · 7²).
- **Why it reproduces the nesting rules:** nesting a sandwiched segment of m rows costs
  c · m; leaving it costs two purpose switches, 2δ. So it nests exactly when
  m < 2δ / c.
  - 2δ / c = 3.5 gives the codebook's "at most 3 rows" (P1).
  - A cheaper c_repair = 2δ / 10.5 gives "at most 10 rows" between repair segments (P2).
  - A cheap c(environment → reproduction) before the fix gives P3. Its "within two
    segments" reach is not reproduced exactly; reach becomes a matter of cost.
- **Parameters:** three numbers (c_default, c_repair, c_repro, with δ = 1 fixing the
  scale) replace R9a–c and their four constants.

### 4.9 Parameters, and how they are set

| Parameter | Set by |
|---|---|
| β = 1, δ = 1 | fixed; they set the scale |
| γ, w_pass | hand-set from the rubric: a passing test is a strong cue |
| λ, w_fail, w_area, w_anc | coordinate search on the **pilot labels only** (bug-18 × 3), maximising boundary F1 at ±1 |
| c_default, c_repair, c_repro | hand-set from the rubric's default sizes (§4.8), then checked on the pilot |

Then **freeze**. Four fitted weights on 99 labelled actions is small but not empty; S2
reports how fragile each one is.

### 4.10 Checks

- **S1, agreement with today's segmenter.** Hand-set the weights to mimic R1–R11 and
  report boundary F1 (±1) against the current 1,711 segments. Exact equality is not
  expected: R3b's order-dependent absorption has no exact counterpart in an objective.
  Every difference is listed and judged against the rubric.
- **S2, sensitivity.** Vary each weight by ±25% and ±50%, and report boundary agreement
  with the default.
- **S3, ablation (N1).** Set w_pass = w_fail = 0 (no outcome evidence), then w_anc = 0
  and drop the pre/post-fix conditions from the decision table (no state). Report how
  many boundaries and types change, per agent; after labelling, how much F1 and κ drop.
- **S4, attribution.** Every cut records which terms of b(c) fired. After labelling, this
  gives precision per term, i.e. which kind of evidence produces correct boundaries.

## 5. Step 3: classification as a decision table, not a precedence list

- **The decision table is codebook §3.3.** Raters and tool use the same questions:
  - the type says *what goal the segment served and what came of it*;
  - flags say *how*.
- **No hidden overlaps.** The questions are asked in a fixed order, but a checker also
  evaluates every question on every segment of the corpus. It reports any segment where
  two questions would give different types and the order alone decided.
  - Each such case is either confirmed as intended (e.g. stuck before fix attempt) or
    fixed.
  - Overlaps can then no longer hide behind rule order.
- **Learned comparison.** A linear-chain CRF over frame features with begin/inside
  boundary tags and type labels, trained leave-one-bug-out on the human labels, is a
  baseline in RQ1. With 708 labelled actions it will be weak, which is the honest answer
  to "why not just learn it".
- **Clustering** stays where it is useful: within one purpose, to propose types the
  codebook is missing, before the codebook is frozen.

## 6. Where an LLM fits, and how it is evaluated

An LLM is never a way around evaluation. It is either a cached, human-checked helper or a
competing condition scored on the same labels.

| Role | Input | Output | Evaluated by |
|---|---|---|---|
| Unknown-tool typing (step 1, item 5) | name, argument schema, description | operation, once per tool | G1 with tool names hidden; human check of every answer |
| Competing segmenter (RQ1 condition) | action frames + truncated results | segments with type and outcome, each citing step ids, in a fixed JSON schema | same boundary F1, WindowDiff and κ as every other method |
| Hybrid (RQ1 condition) | DP segments | relabelled types and short names, citing step ids | same metrics; does it beat the DP alone? |

All runs use temperature 0, a recorded model version and prompt, and their cost is
reported. Verdict parsing stays deterministic: it is auditable, and the result text
already contains the answer.

## 7. Schedule

The blind annotation sheets hide all automatic output, so human labels do not depend on
the algorithm. Labelling can therefore run in parallel with this work.

One constraint remains: the person building the method is also a rater, so the method
must be **frozen before that person sees the test-set trajectories**. Otherwise test
labels leak into the weights.

| Dates | Work | Exit check |
|---|---|---|
| Oct 2–6 | Step 1: frames, generalized object roles, harness from prompt, verdict adapters | G1 ≥ 95% per agent; old tests pass |
| Oct 6–10 | Pilot labelling (bug-18 × 3), both raters | pilot labels exist |
| Oct 7–13 | Step 2: DP segmenter and Viterbi purposes; Step 3: decision table + overlap checker | S1 agreement reported; overlap checker passes |
| Oct 13–15 | Fit weights on the pilot; S2, S3; G2 on an external corpus | sensitivity and ablation tables; **freeze** |
| Oct 15–26 | Test-set labelling (15 trajectories) and adjudication | reference set, human κ |
| Oct 27 – Nov 9 | Baselines (Graphectory-style, BPE, CRF, K-means) and LLM conditions; score all | RQ1 and RQ2 tables |

This moves test-set labelling from Oct 6–19 to Oct 15–26, a one-week shift of M3. M4
keeps its end date.

## 8. Risks

| Risk | Mitigation |
|---|---|
| Argument signatures are ambiguous for some tools | they fall back to the tool-name table, and each fallback is counted and reported |
| No external ATIF corpus is available | convert public SWE-agent/OpenHands trajectories; even 10 runs are enough for coverage |
| The pilot (99 actions) is too small to fit weights | fit only 4–5 weights; report S2 sensitivity; add one more pilot bug if needed (not from the test set) |
| The DP disagrees with today's segmenter | expected (§4.10, S1); each difference is judged against the rubric, and the current rules become a baseline |
| The CRF baseline is very weak | report it anyway; it answers the obvious reviewer question |

## References

Verify venues and years before citing.

- Hearst 1997. TextTiling: segmenting text into multi-paragraph subtopic passages. *Computational Linguistics* 23(1).
- Utiyama & Isahara 2001. A statistical model for domain-independent text segmentation. ACL.
- Pevzner & Hearst 2002. A critique and improvement of an evaluation metric for text segmentation. *Computational Linguistics* 28(1).
- Jackson et al. 2005. An algorithm for optimal partitioning of data on an interval. *IEEE Signal Processing Letters* 12(2).
- Killick, Fearnhead & Eckley 2012. Optimal detection of changepoints with a linear computational cost. *JASA* 107(500).
- Sarawagi & Cohen 2004. Semi-Markov conditional random fields for information extraction. NeurIPS.
- Rabiner 1989. A tutorial on hidden Markov models and selected applications in speech recognition. *Proc. IEEE* 77(2).
- Lafferty, McCallum & Pereira 2001. Conditional random fields. ICML.
- Tax, Sidorova, Haakma & van der Aalst 2016. Event abstraction for process mining using supervised learning techniques. IntelliSys.
- Mannhardt, de Leoni, Reijers, van der Aalst & Toussaint 2018. Guided process discovery – a pattern-based approach. *Information Systems* 76.
- van Zelst, Mannhardt, de Leoni & Koschmider 2021. Event abstraction in process mining: literature review and taxonomy. *Granular Computing* 6.
- Jimenez et al. 2024. SWE-bench. ICLR.
- Yang et al. 2024. SWE-agent: agent-computer interfaces enable automated software engineering. NeurIPS.
- Wang et al. 2025. OpenHands: an open platform for AI software developers as generalist agents. ICLR.
- Bouzenia & Pradel 2025. Understanding software engineering agents: a study of thought-action-result trajectories.
- Graphectory, ProcGrep, Agent ATO, Mindwalk: see [Related study - existing tools.md](Related%20works/Related%20study%20-%20existing%20tools.md).
