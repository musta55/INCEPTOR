# Technical report: from raw agent logs to annotated trajectories

**Purpose.** Document the pipeline precisely enough that you can validate it without
reading the code: what each stage does, why it was built that way, what is measured
rather than assumed, and where the design can be wrong.

**Scope.** Everything described here is deterministic. No language model and no agent is
involved at any point in the pipeline. §7 explains why, and states the one place where an
LLM would be defensible if we later decide we want it.

**Status.** Phases 1–4 of [Parsing plan.md](Parsing%20plan.md) are implemented and
tested; bug-8 and bug-18 are converted end to end. 22 tests pass. All six trajectories
validate against Harbor's official ATIF validator.

---

## 1. The problem, in one paragraph

Three coding agents (Claude Code, Codex, Gemini CLI) attempted the same 50 Android APR
tasks. Each wrote its log in its own format, with its own vocabulary of tools, its own
notion of a "step", and its own omissions. To compare them — or to annotate any of them
consistently — the three have to be expressed in one schema first, and the agent-specific
tool vocabularies have to be mapped onto one action vocabulary. That is the whole job:
**normalise the representation, then normalise the vocabulary.**

---

## 2. Design decisions taken before any automation

These are the choices that determine whether the output is trustworthy. Each is stated
with its rationale and its cost.

### 2.1 Why a predefined schema (ATIF v1.7) instead of our own

We adopted the **Agent Trajectory Interchange Format v1.7**, an external, versioned
specification from the Harbor framework ([full RFC](ATIF-v1.7-RFC.md)).

Rationale:

1. **It already encodes our analysis unit.** ATIF's step object carries
   `reasoning_content` (Thought), `tool_calls` (Action) and `observation.results`
   (Result). The TAR triple from the ASE'25 formulation is the schema's native shape, so
   nothing has to be bent to fit.
2. **It is external.** In a paper, "we normalised to ATIF v1.7 and validated with the
   reference validator" is a citation. "We invented a JSON schema" is a threat to
   validity that a reviewer will ask about.
3. **It has an independent validator.** Harbor ships
   `harbor.utils.trajectory_validator`, written by people who do not know our data. That
   gives us an oracle we did not author — see §5.
4. **It handles subagents natively.** v1.7 added `subagent_trajectories` plus
   `observation.results[].subagent_trajectory_ref`. Claude Code's Task/Agent delegation
   and Gemini's `generalist` tool map onto it without extension.
5. **It has a documented extension point.** Everything we add lives in `extra` objects,
   so our additions cannot make a file invalid.

Cost: we inherit someone else's vocabulary (`step`, `observation`, `source`) and its
constraints (step ids must be sequential from 1; `reasoning_content` only on agent steps).
That is a fair price for an external, checkable contract.

### 2.2 Why we wrote our own parsers instead of using an existing library

We evaluated `monperrus/trajectoriz`, which parses several agents' logs and exports
ATIF. Tested against our data:

| Our log | Result |
|---|---|
| Codex rollout JSONL | Parsed, but collapsed the entire run into **2 steps** and dropped all 30 reasoning items |
| Claude Code log | Unsupported — it expects Claude Code's native session JSONL; ours is an SDK `repr()` dump |
| Gemini log | Unsupported — no Gemini parser exists |

The 2-step result is the disqualifier: its step boundary is a *user turn*, and our runs
are single-turn `codex exec`, so the whole trajectory becomes one step. We kept its idea
(ATIF as the target) and wrote three parsers, ~1,100 lines total, dependency-free.

### 2.3 Why the analysis unit is "one LLM inference", not "one tool call"

ATIF's own convention is one step per LLM inference. We follow it for **storage**, and
derive the per-action view for **analysis** (§6). The reason is that the inference
boundary is real information that cannot be recovered once discarded: on bug-8 Codex
issues four tool calls from a single thought. If we stored one step per call, that fact
would be gone. Storing inferences and exploding to actions on demand loses nothing.

### 2.4 Why the annotation pipeline reads no thought text

Measured on this corpus: Codex encrypts its chain of thought (`summary: []`,
`encrypted_content` set) in **1,617 of 1,617** reasoning items; Gemini's log channel has
no thought events at all; Claude Code emits thinking sporadically (5/16 actions on bug-8,
2/25 on bug-18). Roughly three quarters of all actions have no recoverable thought.

A classifier that consulted thought text would therefore behave differently per agent —
it would have rich input for some Claude actions and nothing for Codex — and that
difference would show up as a false finding about agent behaviour. So the categorisation
uses only what all three agents record identically: **the tool called, its arguments, and
the result**. This is a deliberate restriction, not a limitation we failed to overcome.

---

## 3. Stage 1 — Format detection

`atif/detect.py` identifies the producing agent from **file content**, never from the
filename, because the three dataset folders use three unrelated naming conventions and a
mis-detected file would parse into silent nonsense.

It reads up to 400 lines and stops at the first decisive signal:

| Signal | Format |
|---|---|
| Line begins `SystemMessage(` / `AssistantMessage(` / `UserMessage(` / `ResultMessage(` | `claude_agent_sdk_repr` |
| JSON object with `type` in `session_meta`, `turn_context`, `response_item`, `event_msg` | `codex_rollout_jsonl` |
| JSON object with `type` in `init`, `message`, `tool_use`, `tool_result`, `result` | `gemini_stream_json` |

Unrecognised files raise rather than being skipped. `atif/corpus.py` separately knows the
three folder layouts and can list every bug and locate its three logs; it reports
50/50 bugs complete.

---

## 4. Stage 2 — ATIF conversion, per agent

The hard part of each parser is **recovering the step boundary**, because none of the
three formats states it.

### 4.1 Claude Code (`atif/claude.py`)

Source: a `repr()` dump of `claude-agent-sdk` objects, one message per line.

- **Parsed with `ast`, never `eval`.** Each line is parsed as a Python expression and a
  walker converts constructor calls into `{"__type__": ClassName, ...}`. A trajectory can
  therefore never execute anything, even though the file is Python source. 100% of lines
  parse across all 50 files (3,828 messages).
- **Step boundary: coalescing.** The SDK emits *one message per content block*, so one
  inference spans several consecutive `AssistantMessage` lines (thinking, then text, then
  each tool_use). We merge consecutive assistant messages and close the step when the
  next `UserMessage` (tool results) arrives.
  **This is checked, not assumed**: the log independently reports
  `ResultMessage.num_turns`, and a test asserts the coalesced count equals it. Without
  coalescing, bug-8 reads as 26 steps instead of 14.
- **Subagents.** Messages carry `parent_tool_use_id`. Each distinct value becomes an
  embedded `subagent_trajectories` entry with its own `trajectory_id`, and the delegating
  tool call gets a `subagent_trajectory_ref` pointing at it.
- **Nothing is dropped silently.** An unknown block type (the corpus contains one
  `SensorDataBlock`) is counted in `extra.unparsed_block_types`.
- Recorded gaps: `no_per_step_timestamps`, `no_per_step_token_metrics`,
  `no_initial_user_prompt`, `no_request_id_grouping`.

### 4.2 Codex (`atif/codex.py`)

Source: the native rollout JSONL — the richest of the three.

- **Step boundary: each `reasoning` response item starts a new inference.** The
  `function_call`s that follow belong to it, which correctly groups parallel calls. A
  test asserts `agent steps == reasoning items`.
- Tool results are matched by `call_id`; the shell wrapper's
  `Process exited with code N` line is parsed into `observation.results[].extra.exit_code`,
  which is what makes failure detection possible for Codex.
- Token metrics come from `token_count` events: per-step from `last_token_usage`,
  totals from the maximum `total_token_usage` (it is cumulative, so max is the total —
  asserted by a test).
- `extra.reasoning_encrypted` records why `reasoning_content` is absent.
- The parser declares which rollout schema it targets (`cli_version` 0.114.x, the whole
  corpus) and writes `extra.schema_warning` if it meets another. This matters: newer
  Codex CLIs use a different rollout shape (`event_msg/item_completed`).

### 4.3 Gemini CLI (`atif/gemini.py`)

Source: `--output-format stream-json`, captured **together with the process's stderr**.
One file interleaves ~700,000 stderr lines with ~1,400 JSON lines.

- Non-JSON lines are skipped, but **counted** in `extra.stderr_lines_skipped`, and lines
  matching known diagnostics (`Error executing tool X: ...`) are kept in
  `extra.stderr_diagnostics`. A test asserts the counts match an independent scan.
- **Step boundary:** assistant text arrives as many `delta` fragments; a new inference
  starts when text resumes after a `tool_use`.
- `tool_result.status`/`error` become `observation.results[].extra`.
- Recorded gaps: `no_reasoning_events`, `no_per_step_token_metrics`,
  `model_is_routing_alias` (the log says `auto-gemini-3`, so we do not know which model
  served each step), and `subagent_calls_not_in_stream`, raised automatically when
  `result.stats.tool_calls` exceeds the number of `tool_use` events — the `generalist`
  subagent's internal work never reaches the log.

### 4.4 Shared policies

- **Truncation.** Tool output over 200,000 characters is stored as head + tail with a
  marker, flagged `extra.truncated`, with the original length in `extra.original_chars`.
  The cap exists only because this corpus contains single Gradle/emulator logs of up to
  **24 million characters**; 96% of the corpus's 4,077 tool results are under it and are
  stored complete. Truncation **moves** text, it does not destroy it: the full output is
  always recoverable from the raw log by call id
  (`python3 -m atif.cli output <bug> <agent> <call_id>`), and `--full` disables the cap.
  No count in this report depends on truncated text.
- **Context blocks.** Codex is the only agent that logs the instructions it was given, so
  its system prompt (`session_meta.base_instructions`), its sandbox/permissions developer
  message, and the project `AGENTS.md` are carried as `system` / `user` steps tagged
  `extra.record_kind`. They are context the agent acted under, not metadata. They carry no
  `tool_calls`, so they never enter the action analysis. This was a real gap, found by
  auditing bug-8 after the conversion looked fine — see §5.3.
- **Provenance.** Every trajectory records `source_format`, `source_file`,
  `parser_version`, `bug_id`, and — for Codex only — the harness's `test_results_run_<id>.csv`
  verdict. It is attached to Codex alone because that CSV ships inside the Codex results
  folder and describes that run; attaching it to the other two would invent outcomes the
  corpus does not contain.
- **`extra.known_gaps`** on every trajectory names what its source format cannot express,
  so a later analysis can filter on it instead of silently averaging over missing data.

---

## 5. Stage 3 — Validation (two independent layers)

Validation answers "is the conversion correct?", which splits into two different
questions answered by two different mechanisms.

### 5.1 Is the output a legal ATIF document?

**Layer 1 — our validator** (`atif/schema.py:validate`, dependency-free, runs on every
conversion and fails the run on error): schema version; required agent fields; step ids
sequential from 1; `source` in `{system, user, agent}`; agent-only fields absent from
user/system steps; tool calls carry id + name + object arguments; no duplicate
`tool_call_id`; every observation references a declared call; every embedded subagent has
a unique `trajectory_id`; every `subagent_trajectory_ref` resolves; recursion into
subagent trajectories.

**Layer 2 — Harbor's official validator**, run via `python3 -m atif.cli validate --harbor`.
This is the important one: it was written by the schema's authors, not by us, so it
cannot share our misreadings. It checks the Pydantic schema, sequential step ids,
tool-call references, timestamps and image references.

Current result: **6/6 trajectories valid under both layers** (bug-8 and bug-18 × 3 agents).

### 5.2 Did the conversion lose anything?

A file can be perfectly valid and still be wrong, if the parser quietly dropped records.
So the test suite (`tests/test_parsers.py`, 22 tests) asserts counts in the ATIF output
against counts taken **independently from the raw log**:

| Invariant | What it catches |
|---|---|
| parsed tool calls == raw `ToolUseBlock` / `function_call` / `tool_use` count, per agent | any dropped action |
| Claude coalesced inferences == `ResultMessage.num_turns` | a wrong step-boundary rule |
| Codex agent steps == `reasoning` items | same, for Codex |
| Codex `total_prompt_tokens` == max raw `total_token_usage.input_tokens` | metric mis-aggregation |
| Gemini `stderr_lines_skipped` / `stderr_diagnostic_count` == independent rescan | stderr silently swallowed |
| every tool call has a matching observation or a subagent ref | orphaned actions |
| step ids sequential, sources valid, all trajectories validate | schema drift |
| every action gets a label in the declared vocabulary | taxonomy holes |
| unknown tool names fall back to `other`, not to a plausible-looking label | silent misclassification |
| subagent actions appear immediately after their delegating call | ordering bugs |
| annotation rows keep `parallel_calls_in_step` and blank manual columns | export regressions |
| 11 specific compound shell commands classify correctly | §6.2 regressions |
| every text-bearing raw block is found in the conversion (§5.3) | a whole record type being ignored |
| Codex's system prompt / sandbox / AGENTS.md steps exist and carry no tool calls | context silently dropped, or polluting action counts |
| truncated results declare `original_chars`, and the full text is still in the raw log | silent data destruction |

### 5.3 Did the conversion lose anything — measured per record type

Sections 5.1 and 5.2 check conformance and counts. Neither catches a whole *category* of
content being ignored: a parser that never looks at a record type produces a valid file
with correct action counts and no error.

`atif/audit.py` closes that hole. It re-reads the raw log with **its own inventory code**,
independent of the parsers, enumerates every text-bearing block, and checks whether that
text can be found in the converted trajectory:

```bash
python3 -m atif.cli audit 8
```

```
=== bug-8 / codex  (codex_rollout_jsonl)
  record type               blocks   found    raw chars         kept  trunc
  function_call_output          47      47      437,107      437,107      0
  session_meta                   1       1       12,342       12,342      0
  function_call                 45      45        6,575        6,575      0
  message[user]                  2       2        5,584        5,584      0
  agent_message                 10      10        3,368        3,368      0
  turn_context                   1       1        2,920        2,920      0
  message[developer]             1       1          639          639      0
  TOTAL                        120     120      476,092      476,092      0
  blocks preserved: 120/120  |  text kept: 100.0%
```

**This audit is why the pipeline changed.** Run against the first version, it showed
bug-8 Codex preserving only 104 of 120 blocks and 40.6% of tool-output text, with four
whole categories missing: the agent's system prompt (12,343 chars), the project AGENTS.md
instructions (3,294), the sandbox/permissions message (639) and `turn_context.user_instructions`
(2,920). All four are now captured, and the truncation cap was raised from 8,000 to
200,000 characters with a recovery path for the rest.

Current state, all three agents, both converted bugs: **100% of text-bearing blocks
preserved.** A test (`RetentionTests`) asserts this, so a future parser change that starts
ignoring a record type fails the suite.

One number in that table is worth reading carefully. For Gemini, *blocks* preserved is
100% but *text kept* is 9.4%, because five of its eight tool results on bug-8 exceed the
cap — one is 9.2 million characters of Gradle download spam. Head and tail are kept, so
the command and its final outcome survive; the middle is in the raw log. If any analysis
needs the full text, `atif.cli output` returns it, and `--full` converts without a cap.

---

## 6. Stage 4 — Automated categorisation (the three levels)

This is the "bag-of-words" part of the question, so it is documented literally: the word
lists are below, in full, as they exist in `atif/taxonomy.py`.

### 6.1 Low level — one tool call

The low level is not a classification at all; it is the raw unit. One ATIF `tool_call` =
one low-level action, carrying the agent's own tool name unmapped (`exec_command`,
`Read`, `grep_search`, …), its arguments, and its result. Everything else is derived from
it, and it is always kept in the output so any derived label can be re-checked against
the original.

### 6.2 Mid level — what the agent did (15 categories)

Vocabulary: `read_file`, `search_code`, `orient`, `edit_file`, `build`, `run_test`,
`device_ops`, `env_setup`, `vcs`, `plan`, `delegate`, `wait_process`, `web`, `run_shell`
(unclassified shell), `other` (unclassified tool).

Two lexicons feed it.

**(a) Tool-name lexicon** — maps each agent's tool vocabulary onto the shared one:

| Mid-level | Claude Code | Codex | Gemini CLI |
|---|---|---|---|
| `read_file` | `Read`, `NotebookRead` | — | `read_file`, `read_many_files` |
| `search_code` | `Grep`, `Glob` | — | `glob`, `grep_search`, `search_file_content` |
| `orient` | `LS` | — | `list_directory` |
| `edit_file` | `Edit`, `MultiEdit`, `Write`, `NotebookEdit` | `apply_patch` | `replace`, `write_file` |
| `plan` | `TodoWrite`, `ExitPlanMode`, `EnterPlanMode` | `update_plan` | — |
| `delegate` | `Agent`, `Task` | — | `generalist` |
| `wait_process` | `TaskOutput`, `TaskStop` | `write_stdin` | — |
| `web` | `WebFetch`, `WebSearch` | `web_search` | `google_web_search`, `web_fetch` |
| `other` | `AskUserQuestion`, `Skill`, `ToolSearch`, `SlashCommand` | `view_image` | `save_memory` |
| *(shell)* | `Bash` | `exec_command` | `run_shell_command` |

Anything not in this table becomes `other` — deliberately, so a new tool shows up as
unclassified instead of being absorbed into a neighbouring category.

**(b) Shell-program lexicon** — because the interesting agent, Codex, performs *every*
action through one tool (`exec_command`), classifying by tool name would collapse 80% of
its trajectory into a single category. So shell commands are classified by **the program
they run**:

| Mid-level | Programs |
|---|---|
| `read_file` | `sed` `cat` `head` `tail` `less` `more` `nl` `bat` `javap` |
| `search_code` | `rg` `grep` `egrep` `ag` `ack` `find` `fd` |
| `orient` | `ls` `pwd` `tree` `df` `du` `which` `whoami` `uname` `env` `printenv` `stat` `file` `wc` |
| `vcs` | `git` |
| `device_ops` | `adb` `emulator` `avdmanager` |
| `build` | `gradle` `gradlew` `mvn` `make` `javac` `ant` `ninja` `cmake` |
| `run_test` | `pytest` `junit` `ctest` `tox` |
| `env_setup` | `java_home` `sdkmanager` `brew` `apt-get` `chmod` `chown` `rm` `cp` `mv` `ln` `jenv` `npm` `pip` `pip3` `keytool` `unzip` `tar` `zip` `defaults` |
| `web` | `curl` `wget` |
| `wait_process` | `kill` `pkill` `pgrep` `ps` `sleep` `wait` `timeout` |

plus four context-sensitive rules that a flat word list cannot express:

| Rule | Why |
|---|---|
| `adb … instrument …` → `run_test`, otherwise `device_ops` | running the UI test vs managing the emulator |
| `gradle`/`gradlew`/`mvn`/`ant` with `test`/`check`/`androidTest`/`instrument` in the arguments → `run_test`, else `build` | the same binary does both |
| `*.sh` whose name matches `test|pipeline|script` → `run_test`, else `run_shell` | this benchmark drives its tests through `./run_pipeline.sh` |
| `cat > file` (redirect present) → `env_setup`, not `read_file` | writing a file, not reading one |

**Compound-command handling.** Real commands are compound, so the classifier:

1. tokenises with `shlex`, so a quoted path containing spaces
   (`"/Applications/Android Studio.app/…/java"`) stays one token;
2. splits on `&&`, `||`, `;`, `|` and newlines;
3. strips leading `VAR=value` assignments and wrappers (`sudo`, `time`, `nohup`, `nice`,
   `env`, `xargs`, `command`, `exec`);
4. ignores segments that are pure scaffolding (`cd`, `export`, `set`, `unset`, `source`,
   `.`, `mkdir`, `pushd`, `popd`, `true`, `eval`) when any other segment survives;
5. picks the surviving segment with the highest priority:
   `run_test > build > device_ops > env_setup > edit_file > vcs > search_code > read_file > web > wait_process > orient > run_shell`.

This is the part most likely to be wrong, and it *was* wrong in the first version — found
by reading bug-18's Codex trajectory by hand. Three real errors, all now regression tests:

- `sed -n '1,220p' …/androidTest/…/Script18.java` was classified `run_test`, because the
  *path* contained `androidTest`. It is a file read.
- `rm -rf .android-home .gradle-local` was classified `build`, because `.gradle-local`
  matched a `\bgradle\b` pattern. It is cleanup.
- A multi-line setup script ending in `./run_pipeline.sh Script18` was classified
  `env_setup`, because whitespace was normalised before splitting, collapsing the
  newline-separated script into one segment. It is a test run.

The lesson generalised into the design: **match the executed program, never a substring
of the command line.**

**Measured coverage over all 50 bugs × 3 agents** (5,402 tool calls, 2,782 of them shell
commands):

| | Result |
|---|---|
| distinct tool names in the corpus | 20 |
| tool names not in the lexicon | 0 |
| shell commands classified | 2,756 / 2,782 = **99.1%** |
| shell commands falling back to `run_shell` | 26 = 0.9% |

Coverage is not accuracy. Coverage says every action got a label; whether the label is
*right* is what the manual pass measures (§8).

### 6.3 High level — why the agent did it (8 phases)

Vocabulary: `orientation`, `reproduction`, `localization`, `planning`, `repair`,
`validation`, `environment`, `review`.

The high level is **not** a second word list. It is a positional rule over the mid-level
sequence, because the same action means different things at different points in a repair
run:

| Mid-level | Phase |
|---|---|
| `read_file`, `search_code`, `delegate`, `web` | `localization` |
| `orient`, `other` | `orientation` |
| `plan` | `planning` |
| `edit_file` | `repair` |
| `env_setup` | `environment` |
| `vcs` | `review` |
| `build`, `run_test`, `device_ops`, `run_shell` | **`reproduction` before the first `edit_file`, `validation` after it** |
| `wait_process` | inherits the phase of the action it waits on |

The bolded rule is the entire idea: `./gradlew connectedAndroidTest` is an attempt to
*reproduce* the bug when run before any patch, and an attempt to *validate* the fix when
run after one. A word list cannot express that; a position-aware rule can.

A **high-level trajectory** is then the run-length encoding of that phase sequence, e.g.
for bug-18 Claude Code: `localization(16) -> repair(6) -> validation(3)`.

Known limitation to check during the manual pass: an agent that re-runs the *original*
failing test late in the run, to re-confirm the symptom rather than to check its fix, will
be labelled `validation`. The annotation sheet has a column for exactly this correction.

### 6.4 Ordering: subagents

Subagent actions are spliced into the sequence **at the delegating call**, not appended,
so the phase rule sees a chronologically correct sequence. On bug-18 Claude Code
delegates first and its subagent's 10 actions occupy positions 2–11.

---

## 7. Why no LLM and no agent is used

The pipeline is fully deterministic. The reasons, in order of weight:

1. **Consistency across agents is the measurement.** Every claim in this project is a
   comparison between Claude Code, Codex and Gemini. An LLM labeller would see wordy
   narration from Gemini, terse preambles from Codex and occasional real thinking from
   Claude, and would label the same underlying action differently across them. The
   observed difference would then partly be a property of the labeller. A rule that reads
   only `(tool, arguments, result)` treats all three identically by construction.
2. **Reproducibility.** `convert` is a pure function of the input files and the code
   version. Re-running it a year from now, or by a reviewer, gives byte-identical output.
   No temperature, no model version, no API.
3. **Auditability.** Every label traces to a rule you can read in a table — the tables
   in §6 *are* the classifier. A reviewer asking "why is this `run_test`?" gets a
   one-line answer, not a probability.
4. **The input an LLM would want is missing.** The natural case for an LLM is inferring
   intent from reasoning. Three quarters of the actions have no reasoning text (§2.4), so
   an LLM would be inferring intent from the same `(tool, args, result)` the rules use —
   with added variance, and a strong tendency to narrate plausible intent where none is
   recorded.
5. **Cost and scale.** 5,402 actions × 50 bugs × repeated iterations of the taxonomy is
   a lot of inference for something a lookup table does in milliseconds.

**Where an LLM would be defensible.** Exactly one task in the plan is genuinely semantic
and not rule-expressible: naming a *high-level segment* in the sense of the framework —
"reproduce failing test", "localise crash to fragment", "fix target-fragment wiring" —
which requires reading a contiguous group of actions and summarising its goal. That is
the `manual_segment_label` column, and it is currently done by a human on purpose, so
that the human labels become the reference set.

If we later want to scale that step, the protocol should be: humans label bug-8 and
bug-18 first; an LLM labels the same two bugs blind; we report agreement (Cohen's κ)
against the human labels; and we only use the LLM on the remaining 48 bugs if agreement
is acceptable — reporting κ in the paper. Candidate prompts are in
[Appendix A](#appendix-a--prompts-only-if-we-decide-to-use-an-llm), unused for now.

**What is not automated at all.** Whether a patch is correct. We take the harness's
`test_results_run_<id>.csv` verdict for Codex and have no equivalent for the other two.
No part of this pipeline judges repair quality.

---

## 8. Outputs, and how the manual pass validates the automation

Per bug, `python3 -m atif.cli convert <id>` writes:

| File | Purpose |
|---|---|
| `data/atif/bug-<id>_<agent>.atif.json` | the normalised trajectory — the archival artefact |
| `data/annotation/bug-<id>_actions.csv` | one row per action, all three agents, automatic labels filled, manual columns blank |
| `data/annotation/bug-<id>_actions.jsonl` | same rows for scripts |
| `data/reading/bug-<id>_<agent>.md` | a TAR transcript for reading a run end to end |

The CSV carries five blank columns: `manual_mid_level`, `manual_high_level`,
`auto_label_correct`, `manual_segment_label`, `manual_notes`. The third one is the point:
filling it turns the manual pass into a **measurement of the automatic labeller**, which
is the number that belongs in the paper ("the rule-based labeller agreed with manual
annotation on X% of N actions"). The procedure is in
[Annotation codebook.md](Annotation%20codebook.md).

Current state: bug-8 (84 actions) and bug-18 (99 actions) are converted and awaiting
the manual pass.

| | Claude Code | Codex | Gemini CLI |
|---|---|---|---|
| bug-8: inferences / actions / failed / with real CoT | 16 / 16 / 1 / 5 | 31 / 47 / 6 / 0 | 23 / 21 / 0 / 0 |
| bug-18: inferences / actions / failed / with real CoT | 16 / 25 / 0 / 2 | 31 / 37 / 6 / 0 | 39 / 37 / 1 / 0 |

---

## 9. Threats to validity of the pipeline itself

Stated plainly, because they are what you should probe.

1. **Step boundaries are reconstructed, not recorded.** Claude Code's is validated
   against `num_turns`; Codex's and Gemini's rest on a reading of each format that has no
   independent cross-check in the log. If Gemini emits two inferences with no intervening
   tool call, we merge them.
2. **The first-edit rule defines reproduction vs validation.** A run that edits early and
   then genuinely re-reproduces will be mislabelled. Measurable via the manual pass.
3. **Failure detection differs by agent.** Codex exposes exit codes, Gemini a status
   field, Claude an `is_error` flag. They are not equally strict, so cross-agent failure
   counts are indicative rather than exact.
4. **Gemini's `generalist` delegation is opaque** — one `delegate` action can hide an
   unknown amount of work, which deflates Gemini's action counts relative to the others.
   Flagged per trajectory as `subagent_calls_not_in_stream`.
5. **The Claude log is a derived format.** No timestamps, no per-step tokens, no initial
   prompt. Anything temporal or cost-based excludes Claude until the native session JSONL
   is obtained. Details in [Log audit and collection spec.md](Log%20audit%20and%20collection%20spec.md).
6. **Two bugs are not the corpus.** The taxonomy was tuned against bug-18 and checked on
   bug-8. The 99.1% shell coverage figure is corpus-wide, but *accuracy* has only been
   eyeballed on two bugs. That is what the manual pass fixes.

---

## Appendix A — prompts, only if we decide to use an LLM

Not used by any code in `Parser/`. Recorded so the option is specified rather than
improvised, and so the decision is auditable either way.

**A.1 High-level segment naming** (the only genuinely semantic task)

```
You label segments of a software-repair agent's trajectory.

Input: a numbered list of consecutive actions from one agent working on one bug.
Each action has: mid_level type, target (file/pattern/command), failed (true/false),
and a 300-character result preview.

Task: split the list into contiguous segments and give each a short goal-oriented
name (2-6 words) describing what the agent was trying to accomplish, e.g.
"reproduce failing test", "localise crash to fragment", "fix target fragment wiring",
"resolve JDK toolchain", "verify fix on emulator".

Rules:
- Segments must be contiguous and must cover every action exactly once.
- Use only the actions given. Do not infer motives that the actions do not support.
- If a segment's purpose is not determinable from the actions, name it "unclear".

Output JSON only: [{"start": <action_index>, "end": <action_index>, "label": "<name>"}]
```

**A.2 Mid-level adjudication** (only for actions the rules left as `run_shell`/`other`)

```
Classify this single agent action into exactly one category:
read_file, search_code, orient, edit_file, build, run_test, device_ops, env_setup,
vcs, plan, delegate, wait_process, web, other.

Tool: <tool_name>
Arguments: <arguments json>
Result (first 300 chars): <result preview>

Answer with one category word and nothing else. If the action does not clearly fit
any category, answer "other".
```

Protocol if used: temperature 0, a pinned model version recorded in the output,
schema-constrained output, every LLM label written to a separate column
(`llm_mid_level`, `llm_segment_label`) so it never overwrites a rule label or a human
label, and Cohen's κ against the human pass reported before any use beyond the two
validation bugs.

---

## Appendix B — reproducing this report's numbers

```bash
cd Parser
python3 -m atif.cli list                       # 50/50 bugs have all three agents
python3 -m atif.cli convert 8 18               # the two converted bugs
python3 -m atif.cli validate --harbor          # 6/6 valid, both layers
python3 -m unittest discover -s tests -t .     # 22 tests
python3 -m atif.cli actions 18                 # granularity ladder summary
python3 -m atif.cli audit 8 18                 # retention, per record type (§5.3)
```

Corpus-wide lexicon coverage (5,402 tool calls, 20 distinct tool names, 0 unmapped;
2,782 shell commands, 99.1% classified) is measured by scanning every raw log and
applying `taxonomy.mid_level`; the scan is described in §6.2 and takes about 30 seconds.
