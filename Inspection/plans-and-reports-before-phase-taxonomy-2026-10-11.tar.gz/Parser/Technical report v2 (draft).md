# Technical report v2 (draft): automated multi-level segmentation of APR agent trajectories

**Status.** Draft, 2026-10-01. It describes the code as it stands in `Parser/atif/` and
`Parser/viewer/`, not the plan. Every number was recomputed on 2026-10-01 from
`viewer/data/corpus.js` (150 trajectories).

**Relation to v1.** [Technical report.md](Technical%20report.md) (v1) remains the reference
for stages 1–3: format detection, ATIF conversion and validation. This draft summarises
those stages in §2 and replaces v1 §6. The v1 "8 phases from position relative to the
first edit" is superseded by the state-based phase rule (§6) and by the segment and
purpose layers (§7–§11).

**Scope.** Every stage is deterministic and rule-based. No language model, no clustering
and no learned model is used anywhere. §15 explains why clustering was rejected.

---

## 1. Overview

### 1.1 Pipeline

```
raw log (Claude SDK repr / Codex rollout JSONL / Gemini stream-json)
  │  detect.py        format from file content
  │  claude.py │ codex.py │ gemini.py     → ATIF v1.7
  │  schema.py + Harbor validator          → valid / invalid
  ▼
ATIF trajectory
  │  taxonomy.actions    L0  one row per tool call, sub-agents spliced in
  │  taxonomy.mid_level  L1  15 categories
  │  verdict.attach          pass / fail / none + failure kind per action
  │  taxonomy.phases         per-action phase (rule v2)
  │  segment.micro_units … build_purposes
  │                      L2  segments: kind, type, outcome, flags
  │                      L3  purposes
  │  segment.detect_loops    loop overlay
  │  outcomes.badges         harness outcome + process badges
  │  segment.check_hierarchy invariants
  ▼
view.py → viewer/data/corpus.js (trajview/1) → viewer/index.html (6 views)
```

Commands, run from `Parser/`:

| Step | Command |
|---|---|
| Convert all raw logs to ATIF and write the annotation sheets | `python3 -m atif.cli convert --all` |
| Validate with our validator, then with Harbor's | `python3 -m atif.cli validate --harbor` |
| Print the segment outline of one bug | `python3 -m atif.cli segment 18` |
| Write the viewer dataset | `python3 -m atif.cli view --all` |
| Open the viewer | `open viewer/index.html` |
| Run the test suite | `python3 -m unittest discover -s tests -t .` |

### 1.2 The four levels

| Level | Unit | Vocabulary | How it is assigned | Count in corpus |
|---|---|---|---|---|
| **L0** low | one tool call | tool name + arguments + result | read from ATIF | 5,400 actions |
| **L1** mid | one tool call | 15 categories (Appendix A) | tool-name map; shell commands by the program they run (§4) | 5,400 labels |
| **L2** segment | a contiguous run of actions with one immediate goal | 7 kinds, 25 types, 6 outcomes, 14 flags | boundary rules R1–R6, outcome R7, flags R8, type precedence list (§7–§9) | 1,711 segments |
| **L3** purpose | a contiguous run of segments | 7 purposes | segment purpose + nesting rules R9–R10 (§10) | 899 purposes |

Every action belongs to exactly one segment, and every segment to exactly one purpose.
Medians per trajectory:

| | actions | segments | purposes |
|---|---|---|---|
| Claude Code | 18.5 | 5 | 3 |
| Codex | 35.5 | 11 | 6 |
| Gemini CLI | 35.5 | 13 | 6.5 |
| All 150 | 33 | 10 | 6 |

Each action also carries a per-action **phase** (§6). Phase and purpose share the same
seven labels but are computed differently. Phase is a per-action label from a fixed rule.
Purpose comes from the segment layer and can absorb short interruptions. Where the two
differ, the purpose is the one the viewer draws.

---

## 2. Stages 1–3: detection, conversion, validation (summary of v1)

- **Detection** (`detect.py`) reads file content, never the file name. Unrecognised files
  raise an error.
- **Conversion** recovers the inference-step boundary for each agent:
  - Claude: consecutive assistant messages are coalesced, checked against
    `ResultMessage.num_turns`.
  - Codex: one step per `reasoning` item.
  - Gemini: a new step when text resumes after a `tool_use`.

  Sub-agents become embedded `subagent_trajectories`. Outputs over 200,000 characters
  are stored head + tail and stay recoverable by call id (`atif.cli output`).
- **Validation**, two independent layers:

  | Check | Result 2026-10-01 |
  |---|---|
  | Our validator (`schema.py`) | 150/150 valid |
  | Harbor's official validator | 150/150 valid |
  | Retention audit (`atif.cli audit`): every text-bearing raw block found in the ATIF file | see v1 §5.3 |

---

## 3. L0: actions (`taxonomy.actions`, `taxonomy.annotate`)

- One row per ATIF `tool_call`, in execution order. The analysis unit is the tool call;
  the step id is kept so that parallel calls in one inference can be grouped.
- **Sub-agent splicing.** A sub-agent's actions are inserted right after the call that
  delegated to them, with `scope` = the sub-agent's trajectory id.
- **Background runs (Codex).** A command that returns `Process running with session ID N`
  is polled later by `write_stdin(session_id=N)`. `resolve_waits` links each poll to the
  command that *started* the session (`waits_on`). The verdict then belongs to that run,
  not to the poll.
- **Edited files.** For edit actions, the written paths come from the tool's path argument
  or from the `*** Update/Add/Delete File:` headers of an `apply_patch` body. This works
  whether the patch went through the patch tool or a shell heredoc. Paths are made
  relative to the bug checkout.

Thought text is not used by any rule. It is missing for most actions, and Codex encrypts
its reasoning.

---

## 4. L1: mid-level categories (`taxonomy.mid_level`)

### 4.1 Non-shell tools

A fixed map from tool name to category (`TOOL_MAP`), for example `Read`/`read_file` →
`read_file`, `Grep`/`Glob`/`grep_search` → `search_code`, `Edit`/`Write`/`replace`/
`apply_patch` → `edit_file`, `Agent`/`Task`/`generalist` → `delegate`,
`write_stdin`/`TaskOutput` → `wait_process`. A tool name that is not in the map becomes
`other`, never a plausible-looking guess.

### 4.2 Shell tools

For `Bash`, `exec_command` and `run_shell_command`, the label comes from the program the
command actually runs, not from substrings. `sed -n 1,220p src/androidTest/Script18.java`
is a read, not a test run.

1. **Split** the command line into simple commands at `&&`, `||`, `;`, `|` and newlines
   (`split_commands`). The splitter does not cut inside quotes, `$(...)`, backticks or
   heredoc bodies, and it drops `#` comments.
2. **Find the program** in each part:
   - skip `VAR=value` assignments and wrappers (`sudo`, `time`, `nohup`, `env`, `xargs`,
     `exec`);
   - ignore set-up parts (`cd`, `export`, `mkdir`, `source`, …);
   - classify `bash -c '<script>'` by recursing into the script.
3. **Map the program to a category** (`PROGRAM_KIND`, with the special cases below).
4. **Pick one label** for a compound command with the priority
   `run_test > build > device_ops > env_setup > edit_file > vcs > search_code > read_file
   > web > wait_process > orient > run_shell`. For example, `cd app && ./gradlew test | tail`
   is `run_test`. A command made only of set-up parts is `env_setup`.

Special cases:

| Program | Category |
|---|---|
| `gradle`, `gradlew`, `mvn`, `ant` with a test task (`test`, `check`, `connectedAndroidTest`, `:app:testDebugUnitTest`, …) | `run_test` |
| the same without a test task (`assembleDebug`, `assembleAndroidTest`) | `build` |
| `adb … instrument` | `run_test` |
| other `adb` | `device_ops` |
| a `*.sh` script whose name contains test, pipeline or script (e.g. `run_pipeline.sh`) | `run_test` |
| `python` with `pytest`/`unittest`; `java -cp …`/junit | `run_test` |
| `apply_patch <<'PATCH'` heredoc (Codex) | `edit_file` |
| `cat > f`, `tee > f` | `env_setup` (writing a file from the shell) |

### 4.3 Distribution

| Category | n | Category | n |
|---|---|---|---|
| read_file | 1,634 | vcs | 158 |
| search_code | 1,034 | env_setup | 151 |
| run_test | 885 | device_ops | 92 |
| edit_file | 524 | delegate | 26 |
| wait_process | 333 | run_shell | 23 |
| build | 332 | web | 5 |
| orient | 202 | other | 1 |
| | | plan | 0 |

`plan` is kept in the vocabulary for other corpora; no plan tool is called here.

---

## 5. Verdict and failure kind per action (`verdict.py`)

**Why it is needed.** The log's own error flag is exit-code based. The benchmark's
`run_pipeline.sh` exits 0 when the UI test fails, so that flag catches test failures for
Codex only. The verdict is therefore read from the result text.

Rules, first match wins:

1. Only executing or polling actions get a verdict: `build`, `run_test`, `device_ops`,
   `run_shell`, `env_setup`, `wait_process`. Reads and `git` never do, even when they
   print a test log.
2. Harness and JUnit markers:
   - `Results: N passed, M failed`: M > 0 → fail/test; N = M = 0 → fail/env (nothing
     ran); otherwise pass.
   - Then `>>> ScriptX: PASSED|FAILED`.
   - Then `FAILURES!!!`, `Tests run: N, Failures: M>0`, process crashed.
3. Gradle failures (`BUILD FAILED`, `Execution failed for task`). The kind is read inside
   the "What went wrong" block:
   - "There were failing tests" → `test`;
   - JDK, SDK, plugin, lock, licence or network signatures → `env`;
   - a compiler signature → `build`;
   - anything else → `env`.
4. A non-zero exit: `env` if the output matches an environment signature, else `exit`.
5. Passes need real test evidence:
   - `OK (N tests)`, `Tests run: N, Failures: 0`, per-test `PASSED` lines, or an executed
     Gradle unit-test task followed by `BUILD SUCCESSFUL`;
   - `BUILD SUCCESSFUL` or exit 0 *alone* gives `none` for a `run_test` (a `| head` can
     cut off the result) and `pass` for any other action.
6. A background run still in progress, or anything unrecognised → `none`.

Each verdict records which marker decided it (`verdict_evidence`), for auditing.

| Verdict | n | Failure kind (of fails) | n |
|---|---|---|---|
| none | 4,020 | env | 356 |
| fail | 694 | test | 313 |
| pass | 686 | build | 17 |
| | | exit | 8 |

**Error signature** (`error_signature`) is used for "the same failure again":
- test failures: the names of the failing tests, else the first exception class;
- other failures: the first line of "What went wrong", else the first error-like line;
- paths, hex ids and numbers are masked, so `/tmp/gradle-1` vs `/tmp/gradle-2` is the
  same error.

---

## 6. Per-action phase, rule v2 (`taxonomy.phases`)

- **Anchor:** the first edit to *application source*. Each edit is given a role from its
  files (`file_role`):

  | Role | Files |
  |---|---|
  | toolchain | `*.gradle`, `*.kts`, `*.pro`, `*.properties`, `gradlew`, wrapper files, `run_pipeline.sh`, `.java-version` |
  | test | paths under `reproducing_script_project/`, `androidTest/`, `test/` |
  | source | everything else (also an edit whose target is unknown) |

  Toolchain is checked first, so the reproducing project's own `build.gradle` counts as
  toolchain.

- **Phase per action:**

  | Mid-level | Before the anchor | After the anchor |
  |---|---|---|
  | build, run_test, device_ops, run_shell | reproduction | validation |
  | edit_file, source role | repair | repair |
  | edit_file, toolchain role | environment | environment |
  | edit_file, test role | reproduction | validation |
  | wait_process | phase of the run it polls, else of the previous action | same |
  | read_file, search_code, delegate, web | localization | localization |
  | orient, plan, other | orientation | orientation |
  | env_setup | environment | environment |
  | vcs | review | review |

**Why the anchor is the first *source* edit.** Under v1 the anchor was the first edit of
any file. A Gemini run that edits `build.gradle` to get the failing test to run would then
switch to "validation" before any fix exists (10/50 Gemini runs, 89 actions). The v1 label
is still written as `high_level` in the annotation sheets, for comparison.

---

## 7. L2: segment boundaries (`segment.py`, rules R1–R6)

### 7.1 Rules

| Rule | What it does |
|---|---|
| **R1 Macro-class** | Each action gets a class: **EXEC** (build, run_test, device_ops, run_shell, env_setup, wait_process), **EDIT**, **VCS**, or **EXPL** (read, search, orient, plan, web, other). Consecutive actions of one class form a block. |
| **R2 Harness exploration is execution work** | An EXPL action becomes EXEC (`env_probe`) when it reads `run_pipeline.sh`, `*.properties`, build outputs, `.log` or `.png` files, or touches only paths outside the repo that look like the toolchain (JDK, `.gradle`, SDK, `/tmp`, `/opt`, brew). |
| **R3a Delegation** | A delegate call plus its spliced sub-agent actions is one block. |
| **R3b Blip absorption** | Repeated until nothing changes: a short block between two blocks of the same class is merged into them. EXPL ≤1 action between EXEC blocks; EXPL ≤2 between EDIT blocks; VCS ≤1 between EDIT or EXEC blocks; any single `orient`/`wait`/`plan` action anywhere. |
| **R3c Diff before the run** | A VCS block of ≤2 actions between an EDIT block and an EXEC block joins the EDIT block. A `git diff` before the verifying run is part of the fix attempt. |
| **R4 Localization splits by code area** | Within an EXPL block, a new segment starts when the code area in focus changes. Areas: `test-scripts`, `harness`, `build-config`, `manifest`, `res/<type>`, `src/<package dir>`. An action with no known area takes the next known area, else the previous one; a single action in a different area does not split. |
| **R5 Execution splits after a decision** | An EXEC block is cut after a passing `run_test`, or after a passing build that ended a streak of failed builds. A trailing lone wait or orient joins the previous part. |
| **R5b An attempt includes its judgement** | An EDIT block plus the following EXEC block, up to and including the **first decisive run**, is one segment. A decisive run is a failing build/test or a passing test; a passing build alone does not decide. The rest of the EXEC block is split by R5. The edit's role sets the kind: `fix_attempt` (source), `test_edit` (test files only) or `toolchain_fix` (toolchain only). An EDIT block with no run after it is *unverified*. |
| **R6 Stuck repetition** | Two execution segments merge into one stuck segment when all of these hold: same purpose; both end in the same failing run (the same full command and the same error signature); at most one segment of ≤3 actions between them; no edit or `env_setup` between the two runs. "Same full command" keeps environment variables and drops only trailing output filters (`| tail`, `| grep`, `| tee`), so a re-run with a different `JAVA_HOME` is a workaround, not a repeat. |

Segment kinds in the corpus:

| explore | exec | fix_attempt | vcs | test_edit | delegate | toolchain_fix |
|---|---|---|---|---|---|---|
| 704 | 558 | 276 | 93 | 33 | 26 | 21 |

### 7.2 Segment purpose (`seg_purpose`)

Each segment gets one of the seven purpose labels:

| Segment | Purpose |
|---|---|
| fix_attempt | repair |
| toolchain_fix | environment |
| test_edit | reproduction before the anchor, repair after |
| vcs | review |
| delegate | repair if a sub-agent action edits or the instruction asks for a change, else localization |
| explore, all orient/plan/other | orientation |
| explore after the last edit, reading only files the agent edited (**R10**) | review |
| other explore | localization |
| exec of polls only | phase of the polled run |
| exec decided by a `run_test` | reproduction before the anchor, validation after |
| exec where ≥ half the actions are environment work and no test passed, or only orient/wait/probes | environment |
| other exec | reproduction before the anchor, validation after |

---

## 8. Segment outcome and flags (R7, R8)

### 8.1 Outcome (`exec_outcome`, `assign_outcomes`)

The **decisive verdict** of a segment is the last pass/fail of a build or test run (or of
a poll of one). Only if there is none, it is the last pass/fail of `device_ops` or
`run_shell`.

Execution-bearing segments (exec, fix_attempt, toolchain_fix, test_edit):

| Condition | Outcome | Detail |
|---|---|---|
| edit with no run after it | unverified | edit_not_followed_by_run |
| no decisive verdict | no_verdict | no_decisive_run |
| **before the anchor**, test failed | **succeeded** | **reproduced** |
| before the anchor, other failure | failed (looped if stuck) | blocked_build / blocked_env / blocked_exit |
| before the anchor, a test passed | failed | not_reproduced |
| before the anchor, a non-test run passed | succeeded | builds |
| toolchain_fix after the anchor, run passes or reaches a test failure | succeeded | toolchain_fixed |
| after the anchor, pass | succeeded | tests_pass / builds / ran_ok |
| **after the anchor**, test failed | **failed** (looped if stuck) | **tests_fail** |
| after the anchor, build or env failure | failed (looped if stuck) | patch_breaks_build / blocked_env / blocked_exit |

The two bold rows are the context-awareness claim (C1). The same event, "the target test
fails", is a success before the first source edit and a failure after it.

Exploration, delegation and VCS segments:
- `failed / tool_errors` when the last call errored or at least half the calls errored;
- `looped / repeats_same_lookup` when the same lookup recurs, with a repetition ratio
  ≥ 0.34;
- otherwise `completed`.

| completed | succeeded | failed | no_verdict | unverified | looped |
|---|---|---|---|---|---|
| 789 | 455 | 345 | 85 | 28 | 9 |

### 8.2 Flags (R8)

| Flag | Rule | n |
|---|---|---|
| retried_immediately | a failed segment; the next segment is an execution retry of the same purpose family | 166 |
| retried_after_detour | as above, but other segments come first | 145 |
| abandoned | a failed segment never retried later in its purpose family | 38 |
| ends_trajectory_unresolved | a failed segment is the last of the run | 5 |
| stuck_repeating_command | a strict repeat (R6) inside the segment, or a merged stuck segment | 9 |
| env_wrestling | an execution segment with an env failure, or a re-run that changed something | 193 |
| edits_toolchain | a toolchain_fix segment | 21 |
| edits_harness | a toolchain edit of `run_pipeline.sh` | 15 |
| edits_test_script | a test_edit; a fix attempt that also writes a test file; a delegated edit aimed at the reproducing project | 40 |
| reverts_changes | `git checkout/restore/stash/reset` | 12 |
| off_patch_exploration | ≥3-action localization reading only app files the agent never edits | 82 |
| rereads_same_file | one file read ≥3 times in a localization segment | 31 |
| tool_errors | any call in the segment errored | 256 |
| recovered_after_repeats | succeeded after strict repeats | 0 |

The purpose family used by the retry flags: a failed repair can be retried by
repair, validation or environment work, a failed reproduction by reproduction or
environment work, and so on (`FAMILY`).

---

## 9. Segment type (`segment_type`, codebook v0)

One type per segment, from the fields above. The first matching rule wins:

1. execution segment that looped → `stuck_repeating_failure`
2. test_edit, or the `edits_harness` flag → `test_or_harness_modification`
3. reproduction purpose, execution segment → `reproduction_succeeded` / `_blocked` /
   `_not_reproduced` / `_other`
4. toolchain_fix, or an environment exec → `toolchain_wrestling`
5. fix_attempt → `unverified_edit`, `fix_attempt_passed` / `_failed` / `_breaks_build` /
   `_blocked_by_env` / `_other`
6. validation exec → `validation_passed` / `_failed` / `_blocked_by_env` / `_other`
7. delegate → `delegated_edit` / `delegated_exploration`
8. vcs or review purpose → `review_patch`
9. orientation → `orientation_planning`
10. explore → `lookup_tool_errors` if it failed; `file_by_file_localization_sweep` with
    ≥3 reads of ≥3 files; else `targeted_lookup`

| Type | n | Type | n |
|---|---|---|---|
| targeted_lookup | 515 | fix_attempt_blocked_by_env | 46 |
| validation_passed | 204 | lookup_tool_errors | 29 |
| review_patch | 123 | orientation_planning | 25 |
| fix_attempt_passed | 110 | unverified_edit | 22 |
| file_by_file_localization_sweep | 105 | delegated_exploration | 18 |
| fix_attempt_failed | 86 | reproduction_other | 16 |
| validation_failed | 81 | validation_blocked_by_env | 10 |
| toolchain_wrestling | 69 | stuck_repeating_failure | 9 |
| validation_other | 65 | delegated_edit | 8 |
| reproduction_blocked | 56 | fix_attempt_other | 7 |
| reproduction_succeeded | 52 | fix_attempt_breaks_build | 5 |
| test_or_harness_modification | 48 | reproduction_not_reproduced | 2 |

The codebook's type names ([Annotation codebook.md](Annotation%20codebook.md) §4.3) match
these names. The codebook is written for human raters; this list is how the tool decides.

---

## 10. L3: purposes (R9, `build_purposes`)

A purpose is a maximal run of segments with the same **host purpose**. The host purpose
starts as the segment's own purpose (§7.2) and is changed by three nesting rules:

| Rule | Effect | Constant |
|---|---|---|
| **R9c Reproduction effort** | Before the anchor, an environment segment within 2 segments of a reproduction segment is hosted by reproduction. | `REPRO_REACH = 2` |
| **R9a Short interruptions** | A segment of ≤3 actions sandwiched between two segments of the same host purpose joins it. This applies to orientation segments anywhere, and to these (segment, host) pairs: (localization, repair), (validation, repair), (review, repair), (environment, reproduction / validation / repair / localization), (localization, validation / reproduction / environment). | `ABSORB_MAX = 3` |
| **R9b Fix–verify loop** | The segments between two repair segments are hosted by repair when every segment between them is localization, validation, environment, orientation or review, and together they hold ≤10 actions. | `REPAIR_GAP_MAX = 10` |

A nested segment keeps its own purpose at segment level (`nested = true`, 257 of 1,711
segments).

---

## 11. Loops (R11, `detect_loops`)

| Loop | Rule | Ending |
|---|---|---|
| fix_verify_loop | a repair purpose with ≥2 attempts (fix, test or toolchain edits, delegated edits) and at least one failed execution segment | passed if the purpose, or the validation right after it, ends in success; abandoned if execution continues later; else failed |
| reproduction_loop | ≥2 failed reproduction/environment execution segments before the first fix attempt | same |
| stuck_segment | any segment flagged stuck_repeating_command | passed if the same command passes later |

| | passed | abandoned | failed |
|---|---|---|---|
| fix_verify_loop | 27 | 14 | 1 |
| reproduction_loop | 4 | 4 | 0 |
| stuck_segment | 5 | 3 | 1 |

---

## 12. Outcomes and badges (`outcomes.py`)

**Harness outcome.** `Inspection/Dataset/APR_results/test_results_<agent>.csv`, config
`code_localization_tests`, column `all_pass`. Pass counts: Claude 40/50, Codex 45/50,
Gemini 39/50. The other three configs are carried in `by_config`.

**Badges.** Each badge is backed by the action indices that triggered it:

| Badge | Rule |
|---|---|
| self_claims_pass | the final message claims the target test or the suite passes. Regex classifier, strict: a failure report outranks any pass claim, and "BUILD SUCCESSFUL" is not a test claim |
| reproduced_before_fix | a test run failed with kind `test` before the first source edit |
| edits_test_script | an edit wrote under `reproducing_script_project/` or `androidTest/` |
| edits_harness | an edit wrote `run_pipeline.sh` |
| env_blocked_runs | number of build/test runs (a background run counts once) that failed with kind `env` |
| last_test_verdict | verdict of the last test run that produced one |

The viewer adds one derived badge, **CLAIM✗**: the agent claims a pass and the harness
says fail.

---

## 13. Export and invariants (`view.py`, `check_hierarchy`)

`view --all` writes `trajview/1` ([View data contract.md](View%20data%20contract.md)) as
`viewer/data/corpus.js`, so the viewer works from `file://` with no server.
`check_hierarchy` runs on every trajectory and raises an error on any violation:

1. `actions[k].i == k + 1`;
2. purposes are contiguous and cover actions 1..n exactly once;
3. segments are contiguous and cover their purpose exactly once;
4. `steps == range(start, end + 1)`;
5. loop `segment_ids` resolve;
6. every type, purpose, kind, outcome, flag, loop type, mid-level and phase value is in
   the vocabulary.

Result: 0 violations on 150 trajectories.

---

## 14. Worked example: bug-18 / Gemini (harness: fail)

| Actions | What happened | Segment (type / outcome) | Rules |
|---|---|---|---|
| 1–3 | runs Script18 → compile error; reads `run_pipeline.sh`; `assembleDebug` → compile error | s1 `reproduction_blocked` / failed | R2 makes the harness read part of execution work |
| 4–5 | searches `-Werror`, `allWarningsAsErrors` | s2 `targeted_lookup` / completed | R1 |
| 6–7 | edits `build.gradle`; runs Script18 → **test fails** | s3 `toolchain_wrestling` / succeeded, detail **reproduced** | R5b, R7 (before the anchor). Type is wrong, see §16 item 1 |
| 8–21 | reads and searches the fragment classes | s4 `file_by_file_localization_sweep` | R4 |
| 22–23 | edits `MedicineCreateOrEditFragment.java` (**anchor**); Script18 passes | s5 `fix_attempt_passed` / succeeded | R5b |
| 24–30 | orient, two delegated edits, lookups, full suite passes | s6–s10, all hosted by repair | R9a/b |
| 33–37 | edits `build.gradle` again; build fails; edits it once more with no run | s13 `toolchain_wrestling` / failed; s15 / **unverified** | R7 |

Purposes: reproduction [1–7] → localization [8–21] → repair [22–30] → localization [31]
→ validation [32] → environment [33–37].

The surfacing this shows: the target test passed three times (actions 23, 29, 32), and
the agent claims success, yet the harness says fail. The last purpose is an unverified
toolchain edit after a failing build. The viewer shows this at the end of the timeline as
a "blocked" segment followed by an "unverified" one, and puts a **CLAIM✗** badge on the run.

---

## 15. Design decisions

- **Rules, not clustering, define segments and types.** K-means on segment features was
  tried and rejected:
  - it ignores order: 30% of segments collide with a differently ordered one;
  - it conflates "reproduced" with "fix failed" in 48/59 cases, the distinction C1
    depends on;
  - with purpose features it only re-finds the input label (NMI 0.91);
  - silhouette has no peak for k = 4–30.

  Clustering may still be used *within* a purpose to suggest new types for the codebook.
- **Rules read actions and results, not thoughts.** Thoughts are missing for most actions.
- **Every rule constant is named** (`ABSORB_MAX`, `REPAIR_GAP_MAX`, `REPRO_REACH`, the
  R3b sizes, the 0.34 repetition ratio). The plan freezes them before test-set labelling
  starts.

---

## 16. Known issues and threats to validity

1. **The type precedence hides 5 reproductions.** In bug-18, 92, 114, 1130 and 1446
   (all Gemini), the test first fails inside a segment that also edits a test or
   toolchain file. The outcome detail is `reproduced`, but rules 2 and 4 of §9 are checked
   before rule 3, so the type says toolchain or test modification. The trajectory badge
   is correct. **Fix:** check `reproduced` before rules 2 and 4, or add a type for "test
   or toolchain edit that reproduced".
2. **46% of segments have no pass/fail outcome.** 789 of 1,711 are `completed`, mostly
   exploration. The outcome-aware claim applies to execution-bearing segments.
3. **Purposes compress little.** 602 of 899 purposes (67%) hold one segment.
4. **Rules were tuned on the whole corpus.** No held-out check or sensitivity analysis of
   the constants exists yet.
5. **Shell file writes are not edits.** `sed -i`, `echo >> gradle.properties` and similar
   writes (about 26, mostly toolchain config) never move the anchor and carry no edit
   role.
6. **Gemini sub-agent work is invisible.** `generalist` delegations log no inner actions:
   "Delegated edit (0 sub-agent actions)".
7. **Markers are corpus-specific.** `run_pipeline.sh`, AndroidJUnitRunner and Gradle 6–7
   output. Another harness needs its own markers.
8. **Host confound.** Each agent ran on a different machine, so environment failures are
   partly host effects.
9. **Labels can mislead.** s1 of bug-18/Gemini reads "with env fixes" because a read of
   `run_pipeline.sh` counts as an environment probe (R2).
10. **No human ground truth yet.** The tests check that the rules do what they say, not
    that what they say is right. That is RQ1.

---

## 17. Verification status

| Check | What it shows | Result |
|---|---|---|
| `tests/test_parsers.py` (24 tests) | conversion counts against the raw logs, retention, mid-level regressions | pass |
| `tests/test_segment.py` (27 tests) | partition invariants on all 150 runs; strict stuck vs env wrestling; quote/heredoc splitting; reproductions before the anchor; test evidence for passes; failure kinds; apply_patch heredocs; Gradle test tasks; edit roles; phase rule v2; outcomes for 50 × 3; strict self-report; badge vs segment agreement | pass |
| Our validator / Harbor's | ATIF legality | 150/150 / 150/150 |
| `check_hierarchy` | nesting and vocabulary | 0 violations |
| Viewer on real data | all 6 views render in headless Chrome, no page errors | pass; interaction self-test unfinished |

`test_badge_agrees_with_segments` passes although issue 1 exists. Despite its name, it
checks only that the reproduction badge is set for three Gemini runs and that its steps
lie before the anchor. It never compares the badge with the segments.

---

## Appendix A: mid-level categories

The abbreviation is what the viewer prints in the step strips.

| Category | Abbr. | Assigned to |
|---|---|---|
| read_file | rd | Read, read_file, read_many_files; shell `cat`, `sed`, `head`, `tail`, `less`, `nl`, `javap` |
| search_code | sr | Grep, Glob, grep_search, glob; shell `rg`, `grep`, `find`, `fd`, `ag` |
| orient | or | LS, list_directory; shell `ls`, `pwd`, `tree`, `which`, `env`, `stat`, `wc` |
| edit_file | ed | Edit, MultiEdit, Write, replace, write_file, apply_patch; shell `apply_patch` heredoc |
| build | bd | `gradle`/`gradlew`/`mvn`/`ant` without a test task; `make`, `javac`, `cmake`, `ninja` |
| run_test | rt | Gradle test tasks; `adb … instrument`; `run_pipeline.sh` and other test scripts; `pytest`; `java -cp`/junit |
| device_ops | dv | `adb` (not instrument), `emulator`, `avdmanager` |
| env_setup | en | `java_home`, `jenv`, `sdkmanager`, `brew`, `chmod`, `rm`/`cp`/`mv`/`ln`, `unzip`/`tar`, `keytool`, shell writes, set-up-only commands |
| vcs | vc | `git` |
| plan | pl | TodoWrite, update_plan, plan mode |
| delegate | dg | Agent, Task, generalist |
| wait_process | wt | write_stdin, TaskOutput, TaskStop; `sleep`, `kill`, `ps`, `timeout` |
| web | wb | WebFetch, WebSearch, web_search, google_web_search; `curl`, `wget` |
| run_shell | sh | any other shell program |
| other | ot | AskUserQuestion, Skill, ToolSearch, view_image, save_memory, unknown tools |

## Appendix B: what the viewer explains, and what it does not

| Element | Legend on screen | Definition on screen |
|---|---|---|
| Purpose colours | top-down, timeline, Sankey | no |
| Segment outcome colours | top-down, timeline, compare | no |
| Action verdict, failure kind | timeline, fingerprint | short tooltip |
| Loops | timeline | label only |
| Badges | statistics | tooltip |
| Mid-level abbreviations (rd, sr, ed, …) | **none** | no; the full names appear only as fingerprint row labels |
| Segment types | none; shown as text | no |
| Flags | none; short name, raw name in tooltip | no |
| Rules R1–R11 | none | no; only in this report and the code |

The `?` button lists keyboard shortcuts only.

The viewer's outcome legend differs from the data vocabulary (`viewer/core.js`):
- it shows `failed` segments whose detail starts with `blocked` as a separate "blocked"
  outcome;
- it shows `no_verdict` under "unverified / no verdict".

So the viewer shows "blocked 118", and the data has no outcome called blocked.

## Appendix C: where each rule lives

| Concern | File | Function |
|---|---|---|
| L0 actions, sub-agent splicing, poll linking | `atif/taxonomy.py` | `actions`, `resolve_waits` |
| L1 mid-level | `atif/taxonomy.py` | `mid_level`, `split_commands`, `_program_kind`, `TOOL_MAP`, `PROGRAM_KIND`, `KIND_PRIORITY` |
| Edit roles, phase rule v2 | `atif/taxonomy.py` | `file_role`, `edit_role`, `first_source_edit`, `phases` |
| Verdict, failure kind, error signature | `atif/verdict.py` | `verdict`, `_read`, `error_signature` |
| R1–R6 boundaries | `atif/segment.py` | `enrich`, `micro_units`, `split_explore`, `split_exec`, `first_decisive`, `segment_actions`, `merge_stuck` |
| Segment purpose, R10 | `atif/segment.py` | `seg_purpose` |
| R7 outcome, R8 flags | `atif/segment.py` | `exec_outcome`, `assign_outcomes` |
| Type | `atif/segment.py` | `segment_type`, `SEGMENT_TYPES` |
| R9 purposes | `atif/segment.py` | `build_purposes` and its constants |
| R11 loops | `atif/segment.py` | `detect_loops` |
| Invariants | `atif/segment.py` | `check_hierarchy` |
| Outcomes, badges, self-report | `atif/outcomes.py` | `load`, `badges`, `classify_self_report` |
| Export | `atif/view.py` | — |
| Viewer palettes, abbreviations, badges | `viewer/core.js` | `TV.MID_ABBR`, `TV.FLAG_SHORT`, `TV.BADGES` |
