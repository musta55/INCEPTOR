# Unified trajectory parsing — feasibility verdict and implementation plan

Scope: step 1 of the framework in [Implementation plan.md](../Implementation%20plan.md) — turn the raw
APR logs of Codex, Claude Code and Gemini into one schema we can annotate universally.

## 1. Verdict on `monperrus/trajectoriz`

**Use its schema and its Codex parser as a reference; do not build on it as a dependency.**

What it actually is: a CLI/library for *locating and browsing* agent sessions that already sit in the
local agent stores (`~/.claude/projects`, `~/.codex/sessions`, OpenCode/Copilot SQLite, …). Parsing is
a secondary feature — 8 modules, ~6.2k LOC, of which the parsers we care about are ~450 LOC. Its one
genuinely valuable idea for us is that it exports to **ATIF v1.7** (Agent Trajectory Interchange
Format), an external, versioned, documented trajectory schema from the Harbor framework.

Tested against our `Inspection/bug-8` data (Python 3.12 — the package needs ≥3.10, our system
`python3` is 3.9.6):

| Our log | trajectoriz result |
|---|---|
| `bug-8_codex.jsonl` | Parses. Correct session id, model `gpt-5.3-codex`, CLI `0.114.0`, 47 tool calls, token totals. **But: collapses the whole run into 2 steps, and silently drops all 30 reasoning items.** |
| `bug-8_claude.txt` | Not supported. It expects Claude Code's project JSONL; ours is a `repr()` dump of `claude-agent-sdk` message objects (`AssistantMessage(content=[ToolUseBlock(...)])`). |
| `bug-8_gemini.json` | Not supported at all — no Gemini parser exists in the repo. |

The 2-step Codex result is the disqualifier: its step boundary is a *user turn*, and our APR runs are
single-turn `codex exec`, so everything lands in one step. We need one step per LLM inference.

So: we take ATIF as the target schema, port ~450 LOC of parsing logic as a starting point, and own our
three parsers. Dependency-wise we only need `harbor` (PyPI, `pip install harbor`) for its official
schema validator.

## 2. What is built (phases 1-3 done)

[README.md](README.md) has the commands; [Annotation codebook.md](Annotation%20codebook.md)
is the manual-analysis entry point. Summary:

- `atif/` — a dependency-free package (system Python 3.9+) with one parser per agent,
  content-based format detection, a corpus locator for the three differently-named
  dataset folders, an ATIF validator, the granularity ladder, and the annotation export.
- `tests/` — 22 fidelity tests; run `python3 -m unittest discover -s tests -t .`
- Every converted trajectory passes both our validator and **Harbor's official ATIF
  validator** (`python3 -m atif.cli validate --harbor`).

Fidelity is asserted against the raw logs, not assumed: parsed tool-call counts equal
the raw counts for all three agents, Codex's token totals equal the raw maximum, Gemini's
stderr lines are counted rather than dropped, and the Claude turn coalescing is checked
against the log's own `ResultMessage.num_turns`.

## 3. Gaps in the data itself (worth fixing before scaling up collection)

These are logging gaps, not parsing gaps, and they cap what we can annotate later. Full audit,
including what the native logs of each agent contain and the collection recipe:
[Log audit and collection spec.md](Log%20audit%20and%20collection%20spec.md).

1. **Codex reasoning is encrypted.** All 30 reasoning items have `summary: []`, `content: null` and an
   `encrypted_content` blob. Codex's "Thought" is therefore only recoverable from the 10
   `agent_message` preambles. Re-collecting with reasoning summaries enabled
   (`model_reasoning_summary`) would give us real thoughts; otherwise Codex TAR annotation has a
   structurally weaker T than Claude's.
2. **Claude's log has no timestamps and no task prompt.** The SDK `repr` dump carries neither
   per-message timestamps (only a total `duration_ms` in `ResultMessage`) nor the initial user
   prompt — hence 26 agent steps and 0 user steps. Codex and Gemini both log ms-resolution
   timestamps and the full prompt. If the collection harness can wrap each message with its arrival
   time and emit the prompt as a first record, we get temporal analysis for free.
3. **Gemini thoughts are absent.** No `thought`/reasoning field; only narration text. Gemini CLI can
   emit thought summaries — worth checking the harness flags.
4. **Tool-output volume.** One Gemini `run_shell_command` output is 9.2 MB (of an 11.3 MB file). The
   schema needs a truncation policy: keep a head/tail slice plus full length in `extra`, and park the
   raw output in a sidecar if we ever need it.
5. **Tool vocabularies barely overlap**: Claude `Read/Edit/Bash/Grep/Glob/Agent`, Codex
   `exec_command/apply_patch/write_stdin`, Gemini `read_file/replace/run_shell_command/list_directory`.
   Cross-agent comparison needs a canonical action taxonomy (§5, phase 3) — this is the real
   normalization work, and it is ours, not trajectoriz's.

## 4. Target schema

**ATIF v1.7 as-is, extended only through its own `extra` fields.** Rationale: it is external and
versioned (so we cite it rather than defend a homegrown schema), it already carries exactly our TAR
triple — `reasoning_content` (Thought) / `tool_calls` (Action) / `observation.results` (Result) — it
has first-class subagent nesting, and it ships a validator we can run in CI.

Our extensions, all inside `extra` so the validator stays green:

| Where | Field | Purpose |
|---|---|---|
| root `extra` | `source_format`, `source_file`, `parser_version` | provenance |
| root `extra` | `bug_id`, `benchmark`, `repo`, `run_index` | dataset keys (bug-8, Android/UI-APR, …) |
| root `extra` | `outcome`, `patch_applied`, `tests_passed` | APR ground truth for correlating with trajectory shape |
| step `extra` | `action_type`, `action_granularity` | phase-3 canonical taxonomy |
| step `extra` | `annotations` | where human/LLM TAR labels land |
| step `extra` | `raw_indices` | source line numbers, so every step is traceable to the raw log |
| observation `extra` | `is_error`, `status`, `truncated_chars`, `exit_code` | normalized result status |

## 5. Implementation plan

Layout (Python package in this repo, `python>=3.10`, stdlib only + `harbor` for validation):

```
Parser/
  atif/
    __init__.py
    schema.py         # ATIF dataclasses + our extra-field contracts + emit/validate
    claude.py         # claude-agent-sdk repr dump  -> ATIF   (from the POC)
    codex.py          # codex rollout jsonl         -> ATIF   (ported from trajectoriz, reasoning kept)
    gemini.py         # gemini harness jsonl        -> ATIF   (new)
    detect.py         # sniff format from content, not filename
    taxonomy.py       # tool name + args -> canonical action type
    cli.py            # trajparse convert / validate / stats
  tests/              # golden-file tests, one per agent
  data/atif/          # generated corpus, one file per (bug, agent, version)
```

| Phase | Work | Done when |
|---|---|---|
| 1 ✅ | `Parser/atif/` package, `detect.py`, `corpus.py`, `trajparse convert`, validator wired into the tests | done — `convert` + `validate --harbor` green |
| 2 ✅ | Fidelity tests: 17 invariants — matched observations, sequential step ids, counts equal to the raw logs, no silent drops | done — counts match for all three agents |
| 3 ✅ | `taxonomy.py`: 15 mid-level types and 8 high-level phases, shell commands classified by the program they run | done — 0 unclassified actions on bug-18; see §7 |
| 4 ✅ | TAR view layer: `tar.py` emits iteration rows, the annotation CSV/JSONL and the per-run reading views, keeping `step_id` and `parallel_calls_in_step` | done — delivered early because manual analysis needs it |
| 5 | Scale to all 50 bugs (`convert --all`), spot-check the labeller on a second bug, then subsequence / recurrent-pattern mining across trajectories | all 50 bugs × 3 agents converted and validated; recurrent patterns reported |

Phase 5 is the remaining research work. Before scaling, do the manual pass on bug-18 and
bug-8 so the `auto_label_correct` column gives us a labeller-accuracy number to quote.

## 6. Open decisions

1. **Granularity**: ATIF storage at one-step-per-inference, TAR as a derived view (recommended, §5
   phase 4) — versus exploding to one step per tool call at parse time. The former keeps both views
   available; the latter loses the "4 parallel calls from one thought" signal that bug-8 already shows.
2. **Tool-output truncation threshold**: POC uses 8 KB head with a truncation marker. Pick a number
   we can defend; keep full outputs in a sidecar if annotation needs them.
3. **Codex reasoning**: accept the encrypted gap, or re-collect with reasoning summaries on.

## 7. Granularity ladder results

[atif/taxonomy.py](atif/taxonomy.py) derives mid- and high-level actions from ATIF using
only tool name, argument inspection and result status — `reasoning_content` is never
read, because it is absent for most actions in this corpus. Subagent actions are spliced
in at the delegating call, so sequences stay in execution order.

Ladder: **low** = one ATIF `tool_call`; **mid** = one of 15 types (`read_file`,
`search_code`, `edit_file`, `build`, `run_test`, `device_ops`, `env_setup`, `vcs`,
`orient`, `plan`, `delegate`, `wait_process`, `web`, `run_shell`, `other`); **high** =
phase, from the mid-level type plus its position relative to the first `edit_file`, so
the same `./gradlew` call is `reproduction` before the patch and `validation` after.

Shell commands are classified by **the program they run**, not by substring matching —
`sed -n '1,220p' src/androidTest/Script18.java` is a file read, not a test run, and
`rm -rf .gradle-local` is cleanup, not a build. In a compound command the
highest-priority segment wins and `cd`/`export`/`mkdir` prefixes are ignored. Every one
of these cases is a regression test, found by reading bug-18 by hand.

### bug-18 (Calendula, stock dialog on a target fragment)

```
claude-code  16 inferences, 25 actions,  0 failed,  2/25 with real CoT
  localization(16) -> repair(6) -> validation(3)
codex        31 inferences, 37 actions,  6 failed,  0/37 with real CoT
  localization(1) -> reproduction(2) -> environment(1) -> reproduction(2)
  -> localization(12) -> repair(3) -> review(1) -> validation(3) -> localization(1)
  -> validation(4) -> review(1) -> environment(1) -> localization(4) -> review(1)
gemini-cli   39 inferences, 37 actions,  1 failed,  0/37 with real CoT
  reproduction(1) -> localization(1) -> reproduction(1) -> localization(2) -> repair(1)
  -> validation(1) -> localization(14) -> repair(1) -> validation(1) -> orientation(1)
  -> localization(3) -> orientation(1) -> validation(1) -> localization(2)
  -> validation(1) -> repair(1) -> validation(1) -> localization(2) -> repair(1)
```

Observations that survive from bug-8 to bug-18, i.e. candidates for corpus-wide claims:

- **Claude Code does not reproduce before it patches.** Same shape on both bugs: a long
  localization run, then edits, then a single build. It never ran the failing test on
  either bug. On bug-18 it delegated the first 10 actions to a subagent that emitted no
  thought at all.
- **Codex is validation- and environment-heavy.** 6 failed actions on bug-18, and the
  environment phases are the JDK/Gradle toolchain again — it ends up writing a fake
  `jenv` shim into `/tmp/fakebin` to get the harness script to run. Its trajectory ends
  `task_complete`, but the harness CSV shipped with the run records `pass=No,
  test_fail=Yes` — **the agent's own terminal event disagrees with the ground truth**,
  which is exactly the kind of discrepancy this corpus can quantify.
- **Gemini interleaves repair and validation** rather than separating them: 4 edit
  actions spread across the run, each followed by a check, versus Claude's single
  repair block. It is also the only agent whose phase sequence fragments (19 segments
  for 37 actions).

The automatic labels are a starting point for the manual pass, not ground truth — the
`auto_label_correct` column in the annotation CSV exists to measure them.
