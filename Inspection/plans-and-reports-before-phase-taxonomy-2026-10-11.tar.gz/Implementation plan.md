
**
Definitions:

1. Agent: a tool that implements an agentic harness with an LLM, which allows calling tools, calling the LLM, etc.
2. Agent traces: a list of sequential raw messages an agent generates for solving a problem
3. Action: an activity that an agent performs, which is expressed in one or more raw messages.

   1. Examples: running tool X, searching for Y on the internet, editing file Z, defining a plan, etc.
   2. Exam
4. Results of an action: the outcomes of actions performed by the agent.
5. From paper “Understanding Software Engineering Agents: A Study of Thought-Action-Result Trajectories - ASE 25”:
6. Iteration: a low-level or atomic action performed by an agent followed by the result
7. TAR (Thought-action-results) annotation:
8. A representation of an iteration as three components:
9. Thought (optional??): reasoning given by the agent
10. Action: the activity the agent performs
11. Result: the outcome of the activity
12. Agent trajectory: a sequence of iterations that each consist of three components: T = [(t1, a1, r1), (t2, a2, r2), . . . , (tn, an, rn)]
13. Granularity of an action:
14. The level of specificity of an action: low-, mid-, high-level
15. Examples of low-level ones: running tool X, running tool Y, searching for Y on the internet, editing file Z, defining a plan, etc.
16. Examples of mid-level ones: a TAR annotation that represents some higher-level action: running tool, web search, file edit, etc.
17. Examples of high-level ones: a subsequence of TAR annotations that represents a higher-level action, such as reproducing a bug, performing refactoring, localizing a bug, etc.
18. (rule-based, clustering, classification)
19. Agent trajectory: a graph of actions (low-, mid-, high-level) identified from an agent trace
20. Nodes: actions
21. Edges: control transfer, consequence, and other relationships

Features of our framework:

1. Build trajectories:

   1. Identify low-level, mid-level, and high-level actions in agent traces (one or more traces)
   2. Identify the type of edges between two sequential actions
2. Single-trace analysis (applicable to any granularity):
3. Identify subsequences of actions in one trajectory
4. Identify recurrent subsequences of actions
5. Count appearances of subsequences, sort them, and, based on a threshold, identify the recurrent ones
6. Multi-trace analysis (applicable to any granularity):
7. Identify subsequences of actions in multiple trajectories
8. Identify recurrent subsequences of actions across trajectories
9. Visualization of single trajectories
10. Visualization of multiple trajectories

**
