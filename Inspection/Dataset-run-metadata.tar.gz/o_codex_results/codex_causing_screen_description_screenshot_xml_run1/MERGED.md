# Merged from codex_causing_screen_description_screenshot_xml_run1_fill

The original sweep of this config was killed after 29 of 50 bugs. The remaining
21 were patched in a separate run, `..._run1_fill`: same agent, same model
(gpt-5.6-sol, reasoning effort medium, codex-cli 0.138.0), same prompt set and
same --keep-info; only the date differs.

The 21 bugs: 8 18 44 53 54 71 84 92 181 191 192 271 273 275 358 365 382 447
2587 2677 2678

Merged on 2026-09-29, and the _fill folder removed:

- codex/   the fill's per-bug session logs were already merged into this
           folder's codex/ on 2026-09-23, and its net-guard.jsonl appended here.
- logs/    the 21 bugs' test logs were REPLACED with the fill's. The ones here
           before tested this run's own tree for those bugs, where the agent
           never ran, so they were tests of unpatched code (20 of 21 FAILED).
- results.csv  the 21 bugs' rows replaced with the fill's, for the same reason.
- BLITZ    both halves were tested with `exp test-blitz`; see the note in BLITZ.
