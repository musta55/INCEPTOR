/* Trajectory viewer - app shell: sidebar filters, trajectory list, tabs, playhead, drawer,
 * keyboard, URL hash. Views live in view-*.js and register themselves on TV.views. */
(function () {
  'use strict';
  var TV = window.TV;
  if (!TV || !TV.ok) {
    document.getElementById('app').hidden = true;
    document.getElementById('nodata').hidden = false;
    if (window.TRAJ_DATA && !(window.TRAJ_DATA.trajectories || []).length) {
      document.querySelector('#nodata h1').textContent = 'Corpus is empty';
    }
    return;
  }
  var S = TV.state, $ = TV.$, $$ = TV.$$, esc = TV.esc;
  var VIEWS = ['topdown', 'timeline', 'fingerprint', 'compare', 'sankey', 'stats'];
  var TRAJ_VIEWS = { topdown: 1, timeline: 1, fingerprint: 1 };

  /* ---------------------------------------------------------------- theme */
  var THEMES = ['auto', 'light', 'dark'];
  var theme = 'auto';
  try { theme = localStorage.getItem('tv-theme') || 'auto'; } catch (e) { /* storage blocked */ }
  function applyTheme() {
    if (theme === 'auto') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', theme);
    $('#themeBtn').textContent = 'Theme: ' + theme;
  }
  $('#themeBtn').addEventListener('click', function () {
    theme = THEMES[(THEMES.indexOf(theme) + 1) % THEMES.length];
    try { localStorage.setItem('tv-theme', theme); } catch (e) { /* ignore */ }
    applyTheme();
  });
  applyTheme();

  /* ---------------------------------------------------------------- render scheduling */
  var dirty = {}, raf = 0;
  TV.invalidate = function (which) {
    (which || VIEWS).forEach(function (v) { dirty[v] = 1; });
    if (!raf) raf = requestAnimationFrame(flush);
  };
  function flush() {
    raf = 0;
    renderChrome();
    var v = S.view;
    if (dirty[v] && TV.views[v]) {
      dirty[v] = 0;
      try { TV.views[v].render($('#view-' + v)); }
      catch (err) { $('#view-' + v).innerHTML = '<div class="err">View error: ' + esc(err && err.message) + '</div>'; if (window.console) console.error(err); }
      if (TV.views[v].onCursor) TV.views[v].onCursor(S.cursor, { initial: true });
    }
  }

  /* ---------------------------------------------------------------- state setters */
  TV.setView = function (v) {
    if (VIEWS.indexOf(v) < 0) return;
    S.view = v;
    TV.tip.hide();
    $$('.tabs [data-view]').forEach(function (b) { b.setAttribute('aria-selected', b.dataset.view === v ? 'true' : 'false'); });
    $$('.view').forEach(function (el) { el.hidden = el.id !== 'view-' + v; });
    dirty[v] = 1;
    TV.invalidate([]);
    writeHash();
  };
  TV.setTraj = function (id, opts) {
    opts = opts || {};
    var t = TV.byId[id];
    if (!t) return;
    var changed = id !== S.traj;
    S.traj = id;
    if (changed) { S.range = null; stopPlay(); }
    S.cursor = TV.clamp(opts.cursor || (changed ? 1 : S.cursor), 1, t.n);
    if (opts.revealSeg) {
      var e = TV.exp(t), s = t.segById[opts.revealSeg];
      if (s) { e.p[s.p.id] = 1; e.s[s.id] = 1; S.cursor = s.start; }
    }
    if (!S.compare.bug || changed) S.compare.bug = t.bug;
    TV.invalidate();
    if (opts.view) TV.setView(opts.view);
    updateCursorUI();
    writeHash();
  };
  TV.setCursor = function (i, opts) {
    var t = TV.traj();
    i = TV.clamp(Math.round(i), 1, t.n);
    if (i === S.cursor && !(opts && opts.force)) return;
    S.cursor = i;
    updateCursorUI();
    var v = TV.views[S.view];
    if (v && v.onCursor && !dirty[S.view]) v.onCursor(i, opts || {});
    writeHashSoon();
  };
  TV.setLevel = function (lvl) {
    S.level = lvl;
    TV.applyLevel(TV.traj(), lvl);
    TV.invalidate();
    writeHash();
  };
  TV.setRange = function (r) {
    S.range = r && r[0] <= r[1] ? r : null;
    TV.invalidate();
  };
  TV.filtersChanged = function () { TV.invalidate(); renderFilters(); };

  /* ---------------------------------------------------------------- chrome */
  function renderChrome() {
    var t = TV.traj();
    $('#trajSelect').value = t.id;
    $$('.seg-ctl [data-level]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.level === S.level ? 'true' : 'false'); });
    var trajView = !!TRAJ_VIEWS[S.view];
    $('#playhead').hidden = !trajView;
    $('.seg-ctl').hidden = !(S.view === 'topdown' || S.view === 'timeline');
    $('#drawerBtn').hidden = !trajView;
    document.body.classList.toggle('drawer-open', trajView && S.drawer);
    var rc = $('#rangeChip');
    rc.hidden = !S.range || !trajView;
    if (S.range) rc.innerHTML = 'Range #' + S.range[0] + '–#' + S.range[1] + ' <button class="x" title="Clear range (Esc)" aria-label="Clear range">×</button>';
    renderTrajList();
    updateCursorUI();
  }

  function trajOptions() {
    var html = '';
    TV.bugs.forEach(function (b) {
      html += '<optgroup label="bug-' + esc(b) + '">';
      TV.trajsByBug[b].forEach(function (t) {
        html += '<option value="' + esc(t.id) + '">' + esc(t.id) + ' (' + t.oc + ', ' + t.n + ')</option>';
      });
      html += '</optgroup>';
    });
    $('#trajSelect').innerHTML = html;
  }

  function miniStrip(t) {
    return '<span class="ministrip" aria-hidden="true">' + t.purposes.map(function (p) {
      return '<i style="flex:' + (p.end - p.start + 1) + ';background:' + TV.purposeVar(p.label) + '"></i>';
    }).join('') + '</span>';
  }
  function renderTrajList() {
    var m = 0, html = '';
    TV.trajs.forEach(function (t) {
      var ok = TV.trajMatch(t);
      if (ok) m++;
      if (!ok && S.filters.hide) return;
      html += '<div class="trow' + (ok ? '' : ' off') + (t.id === S.traj ? ' cur' : '') + '" role="option" aria-selected="' +
        (t.id === S.traj) + '" data-id="' + esc(t.id) + '" tabindex="-1">' +
        '<span class="tid">bug-' + esc(t.bug) + '</span><span class="tag ag" style="--ag:' + TV.agentVar(t.agent) + '">' + esc(t.agent) + '</span>' +
        '<span class="tg t-' + t.oc + '" title="harness: ' + t.oc + '">' + (t.oc === 'pass' ? '✓' : t.oc === 'fail' ? '✗' : '?') + '</span>' +
        miniStrip(t) + '<span class="tn">' + t.n + '</span></div>';
    });
    $('#trajList').innerHTML = html;
    $('#trajCount').innerHTML = '<b>' + m + '</b> of ' + TV.trajs.length + ' trajectories match' +
      (TV.anyFilter() ? '' : ' <span class="muted">(no filters)</span>');
    var cur = $('#trajList .cur');
    if (cur && cur.scrollIntoViewIfNeeded) cur.scrollIntoViewIfNeeded(false);
  }
  $('#trajList').addEventListener('click', function (e) {
    var r = e.target.closest('.trow');
    if (r) TV.setTraj(r.dataset.id, { view: TRAJ_VIEWS[S.view] || S.view === 'compare' ? S.view : 'topdown' });
  });
  $('#trajSelect').addEventListener('change', function (e) { TV.setTraj(e.target.value); });
  function stepTraj(d) {
    var list = TV.navList(), k = list.indexOf(TV.traj());
    if (k < 0) k = d > 0 ? -1 : list.length;
    var nk = TV.clamp(k + d, 0, list.length - 1);
    if (list[nk]) TV.setTraj(list[nk].id);
  }
  $('#prevTraj').addEventListener('click', function () { stepTraj(-1); });
  $('#nextTraj').addEventListener('click', function () { stepTraj(1); });
  $$('.tabs [data-view]').forEach(function (b) { b.addEventListener('click', function () { TV.setView(b.dataset.view); }); });
  $$('.seg-ctl [data-level]').forEach(function (b) { b.addEventListener('click', function () { TV.setLevel(b.dataset.level); }); });
  $('#rangeChip').addEventListener('click', function (e) { if (e.target.closest('.x')) TV.setRange(null); });
  $('#drawerBtn').addEventListener('click', function () { S.drawer = !S.drawer; TV.invalidate(); setTimeout(function () { TV.invalidate(); }, 50); });

  /* ---------------------------------------------------------------- filters sidebar */
  var corpusCounts = { types: {}, flags: {}, segOutcomes: {}, purposes: {} };
  TV.trajs.forEach(function (t) {
    t.segs.forEach(function (s) {
      corpusCounts.types[s.type] = (corpusCounts.types[s.type] || 0) + 1;
      corpusCounts.segOutcomes[s.disp] = (corpusCounts.segOutcomes[s.disp] || 0) + 1;
      s.flags.forEach(function (f) { corpusCounts.flags[f] = (corpusCounts.flags[f] || 0) + 1; });
    });
    t.purposes.forEach(function (p) { corpusCounts.purposes[p.label] = (corpusCounts.purposes[p.label] || 0) + 1; });
  });
  var openSections = { quick: 1, agents: 1, outcome: 1, purposes: 1, segOutcomes: 1 };
  function chip(group, key, label, pressed, extraStyle, count) {
    return '<button class="fchip" data-g="' + group + '" data-k="' + esc(key) + '" aria-pressed="' + (pressed ? 'true' : 'false') + '"' +
      (extraStyle ? ' style="' + extraStyle + '"' : '') + '>' + label + (count != null ? ' <span class="cnt">' + count + '</span>' : '') + '</button>';
  }
  function section(id, title, body, active) {
    return '<details class="fsec" data-sec="' + id + '"' + (openSections[id] ? ' open' : '') + '><summary>' + title +
      (active ? ' <span class="act">' + active + '</span>' : '') + '</summary><div class="fbody">' + body + '</div></details>';
  }
  function nAct(o) { var n = TV.setKeys(o).length; return n ? n + ' on' : ''; }
  function renderFilters() {
    var f = S.filters, h = '';
    h += '<div class="fquick">' +
      '<label class="tog"><input type="checkbox" id="fProblems"' + (f.problems ? ' checked' : '') + '> Only failure &amp; inefficiency</label>' +
      '<label class="tog"><input type="checkbox" id="fHide"' + (f.hide ? ' checked' : '') + '> Hide instead of grey</label>' +
      '<button class="btn small" id="fReset"' + (TV.anyFilter() ? '' : ' disabled') + '>Reset filters</button></div>';
    if (f.sankey) h += '<div class="sankeysel">Sankey link: ' + esc(f.sankey.label) + ' <button class="x" id="fSankeyX" aria-label="Clear Sankey selection">×</button></div>';
    h += section('agents', 'Agent', TV.agents.map(function (a) {
      return chip('agents', a, '<i class="dot" style="background:' + TV.agentVar(a) + '"></i>' + esc(a), f.agents[a], '',
        TV.trajs.filter(function (t) { return t.agent === a; }).length);
    }).join(''), nAct(f.agents));
    h += section('outcome', 'Outcome (harness)', ['pass', 'fail', 'unknown'].map(function (o) {
      var n = TV.trajs.filter(function (t) { return t.oc === o; }).length;
      return n || o !== 'unknown' ? chip('outcome', o, '<b class="t-' + o + '">' + (o === 'pass' ? '✓' : o === 'fail' ? '✗' : '?') + '</b> ' + o, f.outcome[o], '', n) : '';
    }).join(''), nAct(f.outcome));
    h += section('badges', 'Badges (all must hold)', TV.BADGES.map(function (b) {
      return chip('badges', b.key, '<span class="badge sev-' + b.sev + ' compact">' + esc(b.short) + '</span> ' + esc(b.label), f.badges[b.key], '',
        TV.trajs.filter(b.test).length);
    }).join(''), nAct(f.badges));
    h += section('purposes', 'Purpose', TV.PURPOSES.map(function (p) {
      return chip('purposes', p, '<i class="sw" style="background:' + TV.purposeVar(p) + '"></i>' + esc(p), f.purposes[p], '', corpusCounts.purposes[p] || 0);
    }).join(''), nAct(f.purposes));
    h += section('segOutcomes', 'Segment outcome', TV.OUTCOMES.map(function (o) {
      return chip('segOutcomes', o, '<b class="og o-' + o + '">' + TV.OUTCOME_GLYPH[o] + '</b> ' + esc(o), f.segOutcomes[o], '', corpusCounts.segOutcomes[o] || 0);
    }).join(''), nAct(f.segOutcomes));
    h += section('types', 'Segment type', '<div class="flist">' + TV.SEG_TYPES.map(function (k) {
      return chip('types', k, esc(TV.humanize(k)), f.types[k], '', corpusCounts.types[k] || 0);
    }).join('') + '</div>', nAct(f.types));
    h += section('flags', 'Flags (any)', '<div class="flist">' + TV.FLAGS.map(function (k) {
      return chip('flags', k, '<span class="flag sev-' + TV.flagSeverity(k) + '">' + esc(TV.FLAG_SHORT[k] || k) + '</span> <span class="muted">' + esc(TV.humanize(k)) + '</span>', f.flags[k], '', corpusCounts.flags[k] || 0);
    }).join('') + '</div>', nAct(f.flags));
    $('#filters').innerHTML = h;
  }
  $('#filters').addEventListener('click', function (e) {
    var c = e.target.closest('.fchip');
    if (c) {
      var g = S.filters[c.dataset.g], k = c.dataset.k;
      if (g[k]) delete g[k]; else g[k] = 1;
      TV.filtersChanged();
      return;
    }
    if (e.target.id === 'fReset') {
      var f = S.filters;
      ['agents', 'outcome', 'purposes', 'types', 'segOutcomes', 'flags', 'badges'].forEach(function (k) { f[k] = {}; });
      f.problems = false; f.sankey = null;
      TV.filtersChanged();
    }
    if (e.target.id === 'fSankeyX') { S.filters.sankey = null; TV.filtersChanged(); }
  });
  $('#filters').addEventListener('change', function (e) {
    if (e.target.id === 'fProblems') { S.filters.problems = e.target.checked; TV.filtersChanged(); }
    if (e.target.id === 'fHide') { S.filters.hide = e.target.checked; TV.filtersChanged(); }
  });
  $('#filters').addEventListener('toggle', function (e) {
    var d = e.target;
    if (d.dataset && d.dataset.sec) { if (d.open) openSections[d.dataset.sec] = 1; else delete openSections[d.dataset.sec]; }
  }, true);

  /* ---------------------------------------------------------------- playhead */
  var timer = 0;
  function stopPlay() {
    if (timer) clearInterval(timer);
    timer = 0;
    S.playing = false;
    var b = $('#playBtn');
    b.innerHTML = '&#9654;'; b.setAttribute('aria-label', 'Play');
  }
  function startPlay() {
    var t = TV.traj();
    if (S.cursor >= t.n) TV.setCursor(1);
    S.playing = true;
    var b = $('#playBtn');
    b.innerHTML = '&#10074;&#10074;'; b.setAttribute('aria-label', 'Pause');
    timer = setInterval(function () {
      var tt = TV.traj();
      if (S.cursor >= tt.n) { stopPlay(); return; }
      TV.setCursor(S.cursor + 1, { playing: true });
    }, 1000 / S.speed);
  }
  TV.togglePlay = function () { if (S.playing) stopPlay(); else startPlay(); };
  $('#playBtn').addEventListener('click', TV.togglePlay);
  $('#stepBack').addEventListener('click', function () { TV.setCursor(S.cursor - 1); });
  $('#stepFwd').addEventListener('click', function () { TV.setCursor(S.cursor + 1); });
  $('#cursor').addEventListener('input', function (e) { TV.setCursor(+e.target.value); });
  $('#speed').addEventListener('change', function (e) { S.speed = +e.target.value; if (S.playing) { stopPlay(); startPlay(); } });
  function updateCursorUI() {
    var t = TV.traj(), a = t.actions[S.cursor - 1];
    var c = $('#cursor');
    c.max = t.n; c.value = S.cursor;
    $('#cursorLabel').innerHTML = '<b>#' + S.cursor + '</b>/' + t.n + (a ? ' <span class="muted">' + esc(a.mid) + '</span>' : '');
    renderDrawer();
  }

  /* ---------------------------------------------------------------- drawer */
  function renderDrawer() {
    var el = $('#drawer');
    if (!TRAJ_VIEWS[S.view] || !S.drawer) { el.innerHTML = ''; return; }
    var t = TV.traj(), a = t.actions[S.cursor - 1];
    if (!a) { el.innerHTML = '<p class="muted">No action.</p>'; return; }
    var s = a.seg, p = a.purp, h = '';
    h += '<div class="dr-h"><span class="dr-i">#' + a.i + '</span><span class="muted small">of ' + t.n + ' · step ' + esc(a.step) +
      (a.scope && a.scope !== 'main' ? ' · <span class="tag">sub-agent</span>' : '') + '</span></div>';
    h += '<div class="dr-row"><span class="midchip">' + esc(a.mid) + '</span> ' + esc(a.tool) +
      (a.verdict !== 'none' ? ' <span class="vg v-' + a.verdict + '">' + TV.VERDICT_GLYPH[a.verdict] + ' ' + a.verdict +
        (a.fail_kind ? ' · ' + esc(TV.FAIL_KIND_LABEL[a.fail_kind] || a.fail_kind) : '') + '</span>' : '') +
      (a.failed_raw ? ' <span class="tag warn" title="the log’s own error flag">log error</span>' : '') + '</div>';
    h += '<div class="dr-row">phase ' + TV.purposeChip(a.phase) + (a.ts ? ' <span class="muted small">' + esc(a.ts) + '</span>' : '') + '</div>';
    if (a.target) h += '<div class="dr-k">Target</div><pre class="dr-code">' + esc(a.target) + '</pre>';
    h += '<div class="dr-k">Thought</div><div class="dr-text">' + (a.thought ? esc(a.thought) : '<span class="muted">(none)</span>') + '</div>';
    h += '<div class="dr-k">Result</div><pre class="dr-code res">' + (a.result ? esc(a.result) : '<span class="muted">(empty)</span>') + '</pre>';
    if (p) h += '<div class="dr-k">Purpose</div><div>' + TV.purposeChip(p.label) + ' <span class="muted small">#' + p.start + '–#' + p.end + '</span></div>';
    if (s) {
      h += '<div class="dr-k">Segment</div><div class="dr-seg">' + TV.outcomePill(s.disp, TV.humanize(s.type)) +
        ' <span class="muted small">#' + s.start + '–#' + s.end + (s.nested ? ' · nested ' + esc(s.purpose) : '') + '</span>' +
        '<div class="dr-text">' + esc(s.label) + '</div>' +
        (s.outcome_detail ? '<div class="muted small">detail: ' + esc(TV.humanize(s.outcome_detail)) + '</div>' : '') +
        '<div>' + s.flags.map(function (f) { return '<span class="flag sev-' + TV.flagSeverity(f) + '" title="' + esc(f) + '">' + esc(TV.FLAG_SHORT[f] || f) + '</span>'; }).join('') + '</div></div>';
    }
    var ls = t.loops.filter(function (l) { return a.i >= l.start && a.i <= l.end; });
    if (ls.length) h += '<div class="dr-k">Loops</div>' + ls.map(function (l) {
      return '<div class="loopline">↻ ' + esc(TV.LOOP_LABEL[l.type] || l.type) + ' #' + l.start + '–#' + l.end +
        (l.iterations != null ? ' · ' + l.iterations + ' iter' : '') + (l.failed_iterations != null ? ', ' + l.failed_iterations + ' failed' : '') +
        (l.ended ? ' · ended ' + esc(l.ended) : '') + '</div>';
    }).join('');
    if (a.call_id) h += '<div class="muted small dr-call">call ' + esc(a.call_id) + '</div>';
    el.innerHTML = h;
  }

  /* ---------------------------------------------------------------- keyboard */
  document.addEventListener('keydown', function (e) {
    var tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' && e.target.type !== 'range' && e.target.type !== 'checkbox') return;
    if (tag === 'select' || tag === 'textarea' || e.metaKey || e.ctrlKey || e.altKey) return;
    var k = e.key;
    if (k === 'j') { TV.setCursor(S.cursor + 1); e.preventDefault(); }
    else if (k === 'k') { TV.setCursor(S.cursor - 1); e.preventDefault(); }
    else if (k === '[') { stepTraj(-1); e.preventDefault(); }
    else if (k === ']') { stepTraj(1); e.preventDefault(); }
    else if (k === ' ' && TRAJ_VIEWS[S.view] && tag !== 'button') { TV.togglePlay(); e.preventDefault(); }
    else if (k >= '1' && k <= '6') { TV.setView(['topdown', 'timeline', 'fingerprint', 'compare', 'sankey', 'stats'][+k - 1]); }
    else if (k === 'e' && S.view === 'topdown') { TV.setLevel('steps'); }
    else if (k === 'c' && S.view === 'topdown') { TV.setLevel('purposes'); }
    else if (k === 'Escape') { $('#help').hidden = true; if (S.range) TV.setRange(null); }
    else if (k === '?') { $('#help').hidden = !$('#help').hidden; }
  });
  $('#helpBtn').addEventListener('click', function () { $('#help').hidden = !$('#help').hidden; });
  $('#helpClose').addEventListener('click', function () { $('#help').hidden = true; });

  /* ---------------------------------------------------------------- URL hash (deep links) */
  var hashTimer = 0;
  function writeHash() {
    var h = 'v=' + S.view + '&t=' + encodeURIComponent(S.traj) + '&i=' + S.cursor + '&lvl=' + S.level;
    try { history.replaceState(null, '', '#' + h); } catch (e) { /* file:// in some browsers */ }
  }
  function writeHashSoon() { clearTimeout(hashTimer); hashTimer = setTimeout(writeHash, 250); }
  function readHash() {
    var q = {};
    (location.hash || '').replace(/^#/, '').split('&').forEach(function (kv) {
      var p = kv.split('='); if (p[0]) q[p[0]] = decodeURIComponent(p[1] || '');
    });
    if (q.t && TV.byId[q.t]) S.traj = q.t;
    if (q.lvl && /^(purposes|segments|steps)$/.test(q.lvl)) S.level = q.lvl;
    if (q.i) S.cursor = TV.clamp(+q.i || 1, 1, TV.traj().n);
    if (q.theme) { theme = q.theme; applyTheme(); }
    if (q.split) S.sankey.split = q.split;
    if (q.problems) S.filters.problems = true;
    if (q.time) S.timeMode = true;
    if (q.drawer === '0') S.drawer = false;
    return q;
  }

  /* ---------------------------------------------------------------- init */
  var d = TV.data;
  $('#dataInfo').textContent = TV.trajs.length + ' traj · ' + TV.trajs.reduce(function (n, t) { return n + t.n; }, 0) + ' actions';
  $('#dataInfo').title = (d.generated_by || '') + ' · schema ' + (d.schema || '?') + ' · outcome config ' + (d.outcome_config || '?');
  if (d.schema && d.schema !== 'trajview/1') {
    $('#dataInfo').textContent += ' · WARNING: schema ' + d.schema + ' (expected trajview/1)';
  }
  trajOptions();
  renderFilters();
  var q = readHash();
  S.compare.bug = TV.traj().bug;
  TV.exp(TV.traj());
  window.addEventListener('resize', function () { TV.invalidate(['timeline', 'fingerprint', 'sankey', 'compare', 'stats']); });
  TV.setView(q.v && VIEWS.indexOf(q.v) >= 0 ? q.v : 'topdown');
  TV.invalidate();
})();
