/* Bug page > Compare: segment sequences of 2-3 trajectories of this bug, aligned with
 * progressive Needleman-Wunsch over segment types. Default: the 3 agents in the selected
 * run; toggle: the selected agent across its runs. Click a segment to open it in the
 * Trajectory tab. */
(function () {
  'use strict';
  var TV = window.TV, esc = TV.esc;
  var GAP = -1.5;

  function family(t) {
    if (!t) return '';
    if (/^fix_attempt|^unverified_edit/.test(t)) return 'fix';
    if (/^reproduction/.test(t)) return 'repro';
    if (/^validation/.test(t)) return 'valid';
    if (/^delegated/.test(t)) return 'deleg';
    if (/lookup|sweep/.test(t)) return 'explore';
    if (/toolchain|stuck|harness/.test(t)) return 'env';
    return t;
  }
  function score(a, b) {
    if (a.type === b.type) return 3;
    if (family(a.type) === family(b.type)) return 1;
    if (a.p.label === b.p.label) return 0;
    return -1;
  }
  function colScore(col, s) {
    var tot = 0, n = 0;
    col.forEach(function (c) { if (c) { tot += score(c, s); n++; } });
    return n ? tot / n : 0;
  }
  /* align a sequence to a profile (array of columns, each = array of k segments-or-null) */
  function alignTo(profile, k, seq) {
    var n = profile.length, m = seq.length, i, j;
    var F = [], T = [];
    for (i = 0; i <= n; i++) { F.push(new Float64Array(m + 1)); T.push(new Uint8Array(m + 1)); }
    for (i = 1; i <= n; i++) { F[i][0] = i * GAP; T[i][0] = 1; }
    for (j = 1; j <= m; j++) { F[0][j] = j * GAP; T[0][j] = 2; }
    for (i = 1; i <= n; i++) for (j = 1; j <= m; j++) {
      var d = F[i - 1][j - 1] + colScore(profile[i - 1], seq[j - 1]);
      var u = F[i - 1][j] + GAP, l = F[i][j - 1] + GAP;
      if (d >= u && d >= l) { F[i][j] = d; T[i][j] = 0; }
      else if (u >= l) { F[i][j] = u; T[i][j] = 1; }
      else { F[i][j] = l; T[i][j] = 2; }
    }
    var out = [];
    i = n; j = m;
    while (i > 0 || j > 0) {
      var tr = i > 0 && j > 0 ? T[i][j] : (i > 0 ? 1 : 2);
      if (tr === 0) { out.push(profile[i - 1].concat([seq[j - 1]])); i--; j--; }
      else if (tr === 1) { out.push(profile[i - 1].concat([null])); i--; }
      else { var c = []; for (var q = 0; q < k; q++) c.push(null); c.push(seq[j - 1]); out.push(c); j--; }
    }
    return out.reverse();
  }
  TV.alignSegments = function (trajs) {
    var prof = trajs[0].segs.map(function (s) { return [s]; });
    for (var r = 1; r < trajs.length; r++) prof = alignTo(prof, r, trajs[r].segs);
    return prof;
  };

  function rows() {
    var B = TV.bugData, cur = TV.traj();
    if (TV.state.cmp === 'runs') {
      return B.runs.map(function (r) { return B.byKey[cur.agent + '-r' + r]; }).filter(Boolean);
    }
    return B.agents.map(function (a) { return B.byKey[a + '-r' + cur.run]; }).filter(Boolean);
  }

  function render(el) {
    var cur = TV.traj(), trajs = rows(), byRuns = TV.state.cmp === 'runs';
    var h = '<div class="legend" style="margin-bottom:10px"><span class="lg-t">Box</span><span class="lgm muted">fill = segment outcome, left edge = purpose</span>' +
      TV.outcomeLegend() + '<span class="lg-t">Links</span><span class="lgm"><i class="cmk same"></i>same type</span><span class="lgm"><i class="cmk fam"></i>same family</span>' +
      '<span class="lgm"><i class="cmk ins"></i>only this row</span><span class="lgm"><i class="cmk gap"></i>gap</span></div>';
    if (trajs.length < 2) {
      el.innerHTML = h + '<p class="note">Only one trajectory to compare' + (byRuns ? ' (the other runs of ' + esc(cur.agent) + ' are not converted).' : ' in run ' + cur.run + '.') + '</p>';
      return;
    }
    var cols = TV.alignSegments(trajs), k = trajs.length;
    var pairs = [];
    for (var a = 0; a < k; a++) for (var b = a + 1; b < k; b++) {
      var same = 0;
      cols.forEach(function (c) { if (c[a] && c[b] && c[a].type === c[b].type) same++; });
      var share = same / Math.max(1, Math.max(trajs[a].segs.length, trajs[b].segs.length));
      pairs.push('<span>' + esc(rowName(trajs[a], byRuns)) + ' – ' + esc(rowName(trajs[b], byRuns)) + ': <b>' + same + '</b> same-type matches (' + TV.pct(share) + ' of the longer)</span>');
    }
    h += '<div class="cmp-sum"><span class="muted">' + cols.length + ' aligned columns</span>' + pairs.join('') + '</div>';
    var grid = '<div class="cmp" style="grid-template-columns:var(--cmp-h) repeat(' + cols.length + ',var(--cmp-w))">';
    trajs.forEach(function (t, r) {
      grid += '<div class="cmp-ag' + (t.key === cur.key ? ' cur' : '') + '">' +
        (byRuns ? '<b>run ' + t.run + '</b>' : TV.agentHTML(t.agent)) + '<span>' + TV.passPill(t.outcome.pass) + '</span>' +
        '<span class="muted small">' + t.segs.length + ' seg · ' + t.n + ' act · ' + TV.plural(t.loops.length, 'loop') + '</span></div>';
      cols.forEach(function (c) {
        var s = c[r];
        if (!s) { grid += '<div class="cbox gap" aria-hidden="true"></div>'; return; }
        var others = c.filter(function (x, q) { return x && q !== r; }).length;
        grid += '<button type="button" class="cbox o-' + s.disp + (others ? '' : ' ins') + '" data-key="' + esc(t.key) + '" data-sid="' + esc(s.id) + '" style="--pc:' + TV.purposeVar(s.p.label) + '" ' +
          'data-tip="' + esc(s.label + ' (#' + s.start + '–#' + s.end + ', ' + s.disp + (s.outcome_detail ? ' / ' + TV.humanize(s.outcome_detail) : '') + ')' +
            (s.flags.length ? ' · ' + s.flags.map(function (f) { return (TV.FLAG_INFO[f] || [f])[0]; }).join(', ') : '')) + '">' +
          '<span class="cb-t"><b aria-hidden="true">' + TV.OUTCOME_GLYPH[s.disp] + '</b> ' + esc(TV.humanize(s.type)) + '</span>' +
          '<span class="cb-r">#' + s.start + '–' + s.end + (s.loops.length ? ' ↻' : '') + (s.flags.length ? ' ⚑' + s.flags.length : '') + '</span></button>';
      });
      if (r < k - 1) {
        grid += '<div class="cmp-link-h"></div>';
        cols.forEach(function (c) {
          var x = c[r], y = c[r + 1], cls = '';
          if (x && y) cls = x.type === y.type ? 'same' : (family(x.type) === family(y.type) ? 'fam' : 'diff');
          grid += '<div class="clink ' + cls + '" aria-hidden="true">' + (cls === 'diff' ? '≠' : '') + '</div>';
        });
      }
    });
    grid += '</div>';
    h += '<div class="cmp-wrap">' + grid + '</div><p class="hint">Click a segment to open it in the Trajectory tab. Alignment: progressive Needleman–Wunsch over segment types (same type +3, same family +1, same purpose 0, otherwise −1, gap −1.5).</p>';
    el.innerHTML = h;
    el.querySelectorAll('.cbox[data-sid]').forEach(function (bx) {
      bx.addEventListener('click', function () { TV.select(bx.dataset.key, { view: 'trajectory', revealSeg: bx.dataset.sid }); });
    });
  }
  function rowName(t, byRuns) { return byRuns ? 'run ' + t.run : t.agent; }

  TV.views.compare = { render: render };
})();
