/* Phase Sankey (corpus): layered Sankey of purpose sequences of the filtered trajectories.
 * Nodes = (position k, purpose) up to a cap, plus one END node per harness outcome. Links are
 * stacked ribbons, one per split value, so the split colours the flow. Own layout, no library. */
(function () {
  'use strict';
  var TV = window.TV;
  if (!TV || !TV.ok) return;
  var esc = TV.esc, S = TV.state;
  var SPLITS = {
    agent: { label: 'agent', vals: function () { return TV.agents; }, of: function (t) { return t.agent; }, color: TV.agentVar },
    outcome: { label: 'outcome pass vs fail', vals: function () { return ['pass', 'fail', 'unknown']; }, of: function (t) { return t.oc; },
      color: function (v) { return v === 'pass' ? 'var(--o-succeeded)' : v === 'fail' ? 'var(--o-failed)' : 'var(--o-unverified)'; } },
    failheavy: { label: 'fail-heavy (failed actions per action > agent median)', vals: function () { return ['fail-heavy', 'not fail-heavy']; },
      of: function (t) { return t.failHeavy ? 'fail-heavy' : 'not fail-heavy'; },
      color: function (v) { return v === 'fail-heavy' ? 'var(--o-failed)' : 'var(--s-neutral)'; } }
  };
  var nodes, links;

  function build(trajs, cap) {
    var N = {}, Lk = {}, maxLen = 1;
    trajs.forEach(function (t) { maxLen = Math.max(maxLen, Math.min(cap, t.purposeSeq.length)); });
    var split = SPLITS[S.sankey.split] || SPLITS.agent;
    function node(key, col, label, kind) {
      return N[key] || (N[key] = { key: key, col: col, label: label, kind: kind, inV: 0, outV: 0, ids: {}, ins: [], outs: [] });
    }
    trajs.forEach(function (t) {
      var seq = t.purposeSeq.slice(0, cap), sv = split.of(t);
      var path = seq.map(function (p, k) { return node(k + '|' + p, k, p, 'purpose'); });
      path.push(node('END|' + t.oc, maxLen, 'end · ' + t.oc, 'end'));
      path.forEach(function (n) { n.ids[t.id] = 1; });
      for (var k = 0; k < path.length - 1; k++) {
        var a = path[k], b = path[k + 1], key = a.key + '>' + b.key;
        var l = Lk[key] || (Lk[key] = { key: key, s: a, t: b, v: 0, by: {}, ids: {}, truncated: 0 });
        l.v++; l.by[sv] = (l.by[sv] || 0) + 1; l.ids[t.id] = 1;
        if (b.kind === 'end' && t.purposeSeq.length > cap) l.truncated++;
        a.outV++; b.inV++;
      }
    });
    return { nodes: Object.keys(N).map(function (k) { return N[k]; }), links: Object.keys(Lk).map(function (k) { return Lk[k]; }), ncol: maxLen + 1, split: split };
  }

  function render(el) {
    var trajs = TV.matchingTrajs(), cap = S.sankey.cap;
    var g = build(trajs, cap);
    nodes = g.nodes; links = g.links;
    var W = TV.innerW(el, 640), H = 470, padT = 26, padL = 8, padR = 118, nodeW = 12, gapN = 8;
    var colX = function (c) { return padL + c * (W - padL - padR - nodeW) / Math.max(1, g.ncol - 1); };
    var cols = [];
    nodes.forEach(function (n) { n.v = Math.max(n.inV, n.outV); (cols[n.col] = cols[n.col] || []).push(n); });
    var order = function (n) { return n.kind === 'end' ? ['end · pass', 'end · fail', 'end · unknown'].indexOf(n.label) : TV.PURPOSES.indexOf(n.label); };
    var ky = Infinity;
    cols.forEach(function (c) {
      if (!c) return;
      c.sort(function (a, b) { return order(a) - order(b); });
      var tot = c.reduce(function (s, n) { return s + n.v; }, 0);
      ky = Math.min(ky, (H - padT - 10 - gapN * (c.length - 1)) / Math.max(1, tot));
    });
    cols.forEach(function (c) {
      if (!c) return;
      var tot = c.reduce(function (s, n) { return s + n.v * ky; }, 0) + gapN * (c.length - 1);
      var y = padT + (H - padT - 10 - tot) / 2;
      c.forEach(function (n) { n.x = colX(n.col); n.y = y; n.h = Math.max(1, n.v * ky); y += n.h + gapN; });
    });
    /* stack links at both ends, ordered by the opposite node's y */
    var vals = g.split.vals();
    nodes.forEach(function (n) { n.outs = []; n.ins = []; });
    links.forEach(function (l) { l.s.outs.push(l); l.t.ins.push(l); });
    nodes.forEach(function (n) {
      n.outs.sort(function (a, b) { return a.t.y - b.t.y; });
      n.ins.sort(function (a, b) { return a.s.y - b.s.y; });
      var y = n.y;
      n.outs.forEach(function (l) { l.sy = y; y += l.v * ky; });
      y = n.y;
      n.ins.forEach(function (l) { l.ty = y; y += l.v * ky; });
    });
    var s = '<svg class="sk" width="' + W + '" height="' + H + '" role="img" aria-label="Phase Sankey of ' + trajs.length + ' trajectories">';
    for (var c = 0; c < g.ncol; c++) {
      s += '<text class="colhdr" x="' + (colX(c) + nodeW / 2) + '" y="12" text-anchor="middle">' + (c === g.ncol - 1 ? 'END' : 'k=' + (c + 1)) + '</text>';
    }
    links.forEach(function (l, li) {
      var x0 = l.s.x + nodeW, x1 = l.t.x, xm = (x0 + x1) / 2, sy = l.sy, ty = l.ty;
      vals.forEach(function (v) {
        var cnt = l.by[v];
        if (!cnt) return;
        var w = cnt * ky;
        s += '<path class="lk" data-l="' + li + '" fill="' + g.split.color(v) + '" d="M' + x0 + ' ' + sy + 'C' + xm + ' ' + sy + ' ' + xm + ' ' + ty + ' ' + x1 + ' ' + ty +
          'L' + x1 + ' ' + (ty + w) + 'C' + xm + ' ' + (ty + w) + ' ' + xm + ' ' + (sy + w) + ' ' + x0 + ' ' + (sy + w) + 'Z"/>';
        sy += w; ty += w;
      });
    });
    nodes.forEach(function (n, ni) {
      s += '<rect class="sknode ' + (n.kind === 'end' ? 'end t-' + n.label.split(' ').pop() : '') + '" data-n="' + ni + '" x="' + n.x + '" y="' + n.y + '" width="' + nodeW + '" height="' + n.h + '"' +
        (n.kind === 'purpose' ? ' fill="' + TV.purposeVar(n.label) + '"' : '') + ' rx="2"/>';
      if (n.h >= 9) {
        var lx = n.x + nodeW + 4, anchor = 'start';
        s += '<text class="sklbl" x="' + lx + '" y="' + (n.y + n.h / 2) + '" text-anchor="' + anchor + '" dominant-baseline="middle">' + esc(n.label) + ' <tspan class="muted">' + n.v + '</tspan></text>';
      }
    });
    s += '</svg>';
    var h = '<div class="vhead"><h2>Phase Sankey <span class="muted small">' + trajs.length + ' of ' + TV.trajs.length + ' trajectories (current filters)</span></h2><div class="vctl">' +
      '<label class="small">Split links by <select data-split>' + Object.keys(SPLITS).map(function (k) {
        return '<option value="' + k + '"' + (k === S.sankey.split ? ' selected' : '') + '>' + esc(SPLITS[k].label) + '</option>';
      }).join('') + '</select></label>' +
      '<label class="small">Max positions <select data-cap>' + [4, 6, 8, 10, 12, 16].map(function (k) {
        return '<option' + (k === cap ? ' selected' : '') + '>' + k + '</option>';
      }).join('') + '</select></label></div></div>';
    h += '<div class="legend"><span class="lg-t">Links (' + esc(g.split.label) + ')</span>' + vals.map(function (v) {
      var n = trajs.filter(function (t) { return g.split.of(t) === v; }).length;
      return n ? '<span class="lgm"><i class="sw" style="background:' + g.split.color(v) + '"></i>' + esc(v) + ' <span class="muted">' + n + '</span></span>' : '';
    }).join('') + '<span class="lg-t">Nodes</span>' + TV.PURPOSES.map(TV.purposeChip).join('') +
      '<span class="lgm"><i class="sw endsw"></i>END per harness outcome</span></div>';
    if (!trajs.length) h += '<div class="note warn">No trajectory matches the current filters.</div>';
    h += '<div class="sk-wrap">' + s + '</div>';
    h += '<p class="muted small">Repeated neighbouring purposes are collapsed; sequences longer than ' + cap + ' purposes are cut and jump to END. ' +
      'Hover a ribbon for counts; click it to filter the trajectory list to the trajectories that traverse it' +
      (S.filters.sankey ? ' (active: ' + esc(S.filters.sankey.label) + ' — clear it in the sidebar).' : '.') + '</p>';
    el.innerHTML = h;
    el.querySelector('[data-split]').addEventListener('change', function (e) { S.sankey.split = e.target.value; TV.invalidate(['sankey']); });
    el.querySelector('[data-cap]').addEventListener('change', function (e) { S.sankey.cap = +e.target.value; TV.invalidate(['sankey']); });
    var svg = el.querySelector('svg.sk');
    function linkTip(l) {
      return '<div class="tt-h">' + esc(l.s.label) + ' (k=' + (l.s.col + 1) + ') → ' + esc(l.t.label) + (l.t.kind === 'end' ? '' : ' (k=' + (l.t.col + 1) + ')') + '</div>' +
        '<div class="tt-m"><b>' + l.v + '</b> trajectories' + (l.truncated ? ' (' + l.truncated + ' cut at the cap)' : '') + '</div>' +
        vals.filter(function (v) { return l.by[v]; }).map(function (v) {
          return '<div class="tt-m"><i class="sw" style="background:' + g.split.color(v) + '"></i>' + esc(v) + ': ' + l.by[v] + '</div>';
        }).join('') + '<div class="tt-m muted">click to filter to these trajectories</div>';
    }
    svg.addEventListener('mousemove', function (ev) {
      var p = ev.target.closest('.lk'), n = ev.target.closest('.sknode');
      svg.classList.toggle('hovering', !!p);
      svg.querySelectorAll('.lk.hl').forEach(function (x) { x.classList.remove('hl'); });
      if (p) {
        svg.querySelectorAll('.lk[data-l="' + p.dataset.l + '"]').forEach(function (x) { x.classList.add('hl'); });
        TV.tip.show(linkTip(links[+p.dataset.l]), ev);
      } else if (n) {
        var nd = nodes[+n.dataset.n];
        TV.tip.show('<div class="tt-h">' + esc(nd.label) + (nd.kind === 'end' ? '' : ' at position ' + (nd.col + 1)) + '</div><div class="tt-m">' + nd.v + ' trajectories</div>', ev);
      } else TV.tip.hide();
    });
    svg.addEventListener('mouseleave', function () { TV.tip.hide(); svg.classList.remove('hovering'); });
    svg.addEventListener('click', function (ev) {
      var p = ev.target.closest('.lk'), n = ev.target.closest('.sknode'), l, label, ids;
      if (p) { l = links[+p.dataset.l]; ids = l.ids; label = l.s.label + ' (k=' + (l.s.col + 1) + ') → ' + l.t.label + (l.t.kind === 'end' ? '' : ' (k=' + (l.t.col + 1) + ')') + ' [' + l.v + ']'; }
      else if (n) { var nd = nodes[+n.dataset.n]; ids = nd.ids; label = nd.label + (nd.kind === 'end' ? '' : ' at k=' + (nd.col + 1)) + ' [' + nd.v + ']'; }
      else return;
      TV.tip.hide();
      S.filters.sankey = { label: label, ids: ids };
      TV.filtersChanged();
    });
  }
  TV.views.sankey = { render: render };
})();
